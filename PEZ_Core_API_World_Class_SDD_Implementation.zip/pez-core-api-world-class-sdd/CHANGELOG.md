# Changelog

## 1.0.0-world-class-baseline
- Added formal business requirement catalog
- Added JSON Schemas for capabilities, workflows, MCP skill contracts, and state machines
- Added per-capability MCP SDK skill contracts and input/output schemas
- Added MCP catalog baseline example
- Added posting state machine and financial-safety invariants
- Added failure-mode matrix
- Added SLO/NFR placeholder specification
- Added security threat model and trust boundaries
- Added deployment runtime specification and diagram
- Added governance/change-classification model
- Added architecture rules and architecture review checklist
- Added end-to-end requirement -> design -> code -> test -> telemetry traceability
- Added GitHub and GitLab CI examples
- Added executable repository quality-gate scripts
- Added golden scenarios and MCP contract-testing strategy

## 0.1.0
- Initial PEZ spec-driven baseline
