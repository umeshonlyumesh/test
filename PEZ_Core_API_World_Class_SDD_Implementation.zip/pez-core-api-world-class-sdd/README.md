# PEZ Core API — World-Class Spec-Driven Engineering Baseline

This repository is a **spec-driven engineering baseline** for PEZ Core API.

The intent is not to create a large design document that becomes stale. Instead, the repository makes architecture, workflow, API, MCP SDK contracts, failure behavior, security, NFRs, traceability, and quality gates explicit and machine-verifiable.

## Architecture

```text
Consumer / CPS / Channel
        |
        v
  PEZ Core API
        |
        v
Business Workflow / State Machine
        |
        v
Logical Capability
        |
        v
Capability -> MCP Skill Binding
        |
        v
Skills MCP Client
        |
        v
Skills MCP Server
   |      |       |       |
   v      v       v       v
 CIF   Validation Fraud  Posting ...
```

## What makes this implementation spec-driven

The repository contains first-class, version-controlled specifications for:

1. Business requirements and capabilities
2. Workflow and state transitions
3. OpenAPI contract
4. MCP SDK skill contracts
5. Error semantics
6. Security and threat model
7. Resiliency and failure-mode behavior
8. Performance/SLO expectations
9. Deployment and operational architecture
10. Requirement -> design -> code -> test -> telemetry traceability
11. CI quality gates that validate the specification set

Unknown PEZ-specific values are deliberately represented as `TBD`, `PLACEHOLDER`, or example defaults. They should be replaced through architecture review rather than guessed.

## Repository structure

```text
docs/
  sdd/                       Master SDD and governance
  adr/                       Architecture Decision Records
  diagrams/                  Mermaid architecture/sequence/state diagrams
  security/                  Threat model and trust boundaries
  operations/                Runbook/SLO/alerting/deployment notes

specs/
  requirements/              Requirement catalog
  capabilities/              Business capability specs
  workflows/                 Executable workflow specs
  state-machines/            Posting/transaction state specs
  api/                       OpenAPI
  skills/                    MCP SDK skill bindings + contract baselines
  schemas/                   JSON Schemas used to validate specs
  errors/                    Canonical PEZ errors
  nfr/                       Security, resiliency, performance, observability
  failure-modes/             Failure behavior matrix
  deployment/                Runtime/dependency/deployment requirements
  traceability/              End-to-end traceability

quality/
  architecture-rules/        Architecture constraints
  checklists/                Review and production-readiness checklists

scripts/
  validate_all.py            Main repository quality gate
  validate_yaml_syntax.py    YAML syntax validation if PyYAML is available
  traceability_check.py      Traceability checks
  mcp_contract_check.py      MCP contract/binding baseline checks

.github/workflows/
  spec-quality.yml           GitHub example quality gate

.gitlab-ci.yml               GitLab example quality gate
```

## Quality gate

Run:

```bash
python scripts/validate_all.py
```

This verifies repository structure, requirement IDs, traceability, skill bindings, schema references, and placeholder hygiene.

## Production principle

> PEZ Core business code references logical capabilities. It does not directly depend on concrete SDK implementation classes or arbitrary MCP tool names.

## Placeholder policy

A placeholder is acceptable only when:
- the real value is genuinely unknown,
- it is clearly marked,
- there is an owner or review gate for replacing it,
- it does not hide unsafe behavior.

Examples:
- `TBD_SLO_P95_MS`
- `TBD_TEAM_NAME`
- `TBD_MCP_TOOL_NAME`
- `TBD_RTO`
