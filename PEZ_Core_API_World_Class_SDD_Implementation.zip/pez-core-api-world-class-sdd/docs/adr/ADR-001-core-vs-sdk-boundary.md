# ADR-001 — Core versus SDK responsibility

**Status:** Accepted baseline

## Context
PEZ needs stable orchestration while provider integrations evolve independently.

## Decision
Core owns business workflow and canonical semantics. SDK skills own downstream/provider integration.

## Consequences
- SDK implementation details do not leak into Core.
- SDK skill contracts must be explicit.
- Core needs a catalog/binding layer.
