# ADR-002 — Use Skills MCP Server as the SDK capability boundary

**Status:** Accepted baseline

## Context
Existing SDK capabilities are already exposed through an MCP Skills Server.

## Decision
PEZ Core discovers and invokes approved SDK skills as MCP tools rather than directly linking SDK implementation artifacts.

## Consequences
- startup validation is mandatory;
- skill naming/schema are deployable contracts;
- MCP availability becomes a Core dependency;
- transport/auth/schema-drift must be governed.
