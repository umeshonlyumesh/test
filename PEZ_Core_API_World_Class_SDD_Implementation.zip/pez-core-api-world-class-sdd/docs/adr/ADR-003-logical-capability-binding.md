# ADR-003 — Bind logical capabilities to skill names

**Status:** Accepted baseline

## Decision
Business code references logical capabilities such as `FRAUD_CHECK`, not concrete MCP tool names.

## Rationale
This decouples business orchestration from SDK naming/versioning and makes environment migrations configuration-driven.
