# ADR-004 — Posting idempotency and ambiguous outcomes

**Status:** Required before production

## Decision
Core must persist idempotency state and must not automatically retry a posting after an ambiguous downstream outcome.

## Rationale
A transport timeout does not prove that a financial side effect did not occur.
