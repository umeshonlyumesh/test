# ADR-005 — MCP Streamable HTTP transport

**Status:** Baseline

## Decision
Use MCP Streamable HTTP for remote Skills MCP connectivity.

## Rationale
It is the current MCP transport direction and avoids new dependence on legacy SSE transport.
