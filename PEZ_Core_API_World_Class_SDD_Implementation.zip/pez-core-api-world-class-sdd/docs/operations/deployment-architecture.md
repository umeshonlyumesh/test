# Deployment Architecture

```mermaid
flowchart TB
    CLIENT[Consumer / CPS] --> GW[API Gateway / Ingress]
    GW --> SVC[PEZ Core Service]

    subgraph K8S[Kubernetes / TBD Platform]
      SVC --> P1[PEZ Pod]
      SVC --> P2[PEZ Pod]
      P1 --> MCP[Skills MCP Endpoint]
      P2 --> MCP
      P1 --> DB[(Idempotency / Transaction Store)]
      P2 --> DB
    end

    MCP --> SDK[SDK Skills]
    SDK --> EXT[External Providers]

    P1 --> OBS[Logs / Metrics / Traces]
    P2 --> OBS
```

## Production placeholders to resolve

- cluster/platform
- ingress/API gateway
- autoscaling policy
- network policy
- workload identity
- secret/certificate delivery
- database technology and HA model
- observability backend
- DR region/site
