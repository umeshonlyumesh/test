# PEZ Production Readiness Checklist

## Contract
- [ ] OpenAPI approved
- [ ] exact MCP tool names approved
- [ ] skill input/output schemas baselined
- [ ] backward compatibility checked

## Runtime
- [ ] mandatory tools discovered during readiness
- [ ] MCP timeout configured
- [ ] OAuth/workload auth configured
- [ ] mTLS/truststore configured where required
- [ ] no credentials in source

## Financial safety
- [ ] posting idempotency persisted
- [ ] ambiguous posting outcome path implemented
- [ ] reconciliation capability/process defined
- [ ] no blind posting retry

## Security
- [ ] PII log masking verified
- [ ] skill allowlist enforced
- [ ] dependency/SAST/container scans clean to policy
- [ ] secrets rotation tested

## Observability
- [ ] correlation across Core/MCP/SDK/provider
- [ ] latency/error metrics
- [ ] dashboards
- [ ] actionable alerts
- [ ] runbook links

## Resilience
- [ ] MCP unavailable test
- [ ] missing skill test
- [ ] skill timeout test
- [ ] partial workflow failure test
- [ ] pod restart during posting test
