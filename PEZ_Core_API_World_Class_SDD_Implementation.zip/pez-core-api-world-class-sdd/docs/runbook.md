# PEZ Core Runbook

## Readiness fails: missing skill
1. Inspect startup error for `CAPABILITY->toolName`.
2. Compare `application.yml` binding to the Skills MCP Server `tools/list` response.
3. Confirm the skill is deployed and visible to the PEZ runtime identity.
4. Do not bypass mandatory validation in production.

## MCP initialization fails
1. Verify base URL and `/mcp` endpoint.
2. Verify TLS chain/truststore.
3. Verify OAuth/service identity.
4. Verify protocol compatibility.
5. Confirm no HTTP redirect is being relied upon; configure the actual MCP endpoint.

## Posting timeout
Treat as ambiguous outcome until reconciled. Do not manually replay unless the provider state and idempotency design prove it is safe.

## High latency
Separate:
- Core processing
- MCP transport
- skill execution
- external provider latency
using trace spans and per-skill timers.
