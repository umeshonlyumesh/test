# PEZ Core API — Software Design Description (SDD)

**Document ID:** PEZ-SDD-CORE-001  
**Status:** Draft baseline  
**Architecture style:** Spec-driven orchestration with SDK Skills MCP Server  
**Primary implementation:** Java 21 / Spring Boot  

## 1. Purpose

PEZ Core API provides a stable business-facing API and orchestrates reusable SDK capabilities exposed by a Skills MCP Server.

The design deliberately separates:
- business capability and workflow decisions,
- runtime skill discovery and invocation,
- provider/SDK implementation,
- transport/security concerns,
- error semantics,
- observability,
- idempotency and recovery.

## 2. Scope

Included:
- Qualification
- Enrichment / CIF
- Account validation
- Balance enquiry
- Fraud check
- Posting / deposit
- Customer alert
- MCP skill discovery and execution
- canonical error handling
- audit/correlation context
- resiliency, security and operational controls

Excluded:
- internal implementation of each SDK
- external provider implementation details
- enterprise IAM/token-service implementation
- infrastructure provisioning details not specific to Core behavior

## 3. Design principles

| ID | Principle |
|---|---|
| PEZ-PRN-001 | Core owns orchestration; SDK skills own downstream integration. |
| PEZ-PRN-002 | Core depends on logical capabilities, not SDK implementation classes. |
| PEZ-PRN-003 | All required SDK capabilities must be discoverable from MCP at startup. |
| PEZ-PRN-004 | Skill names are configuration/spec data, not business-code constants. |
| PEZ-PRN-005 | Non-idempotent operations are never blindly retried. |
| PEZ-PRN-006 | All external errors are normalized at the Core boundary. |
| PEZ-PRN-007 | Correlation, request, transaction, client and channel context propagate end to end. |
| PEZ-PRN-008 | PII is not logged in clear text. |
| PEZ-PRN-009 | Specs and acceptance criteria are version controlled with code. |
| PEZ-PRN-010 | Breaking API or skill-contract changes require an ADR and compatibility plan. |

## 4. Architecture

```mermaid
flowchart LR
    C[Consumer / CPS / Channel] --> API[PEZ Core API]
    API --> VAL[Request Validation]
    VAL --> WF[Workflow Orchestrator]
    WF --> BIND[Capability-to-Skill Binding]
    BIND --> MCP[MCP Skill Client]
    MCP --> SMCP[Skills MCP Server]

    SMCP --> CIF[CIF / Enrichment Skill]
    SMCP --> AV[Account Validation Skill]
    SMCP --> BAL[Balance Enquiry Skill]
    SMCP --> FR[Fraud Skill]
    SMCP --> POST[Posting / Deposit Skill]
    SMCP --> ALT[Customer Alert Skill]
```

## 5. Responsibility boundary

| Concern | PEZ Core | Skills MCP Server | SDK skill |
|---|---:|---:|---:|
| Public API contract | Owns | - | - |
| Business workflow/order | Owns | - | - |
| Capability-to-tool binding | Owns spec/config | Exposes catalog | - |
| Tool discovery | Client | Owns exposure | Registers |
| Provider DTO mapping | - | - | Owns |
| Provider authentication | Policy/context | May broker | Owns/implements |
| PEZ error normalization | Owns | Supplies error | Supplies detail |
| Correlation propagation | Owns | Propagates | Propagates |
| Retry eligibility | Owns policy | Transport behavior | Provider-aware |
| Provider call | - | - | Owns |

## 6. Runtime startup contract

1. Build MCP transport.
2. Initialize MCP client.
3. Discover tools/skills.
4. Load required PEZ capability bindings.
5. Verify every required binding resolves to an MCP tool.
6. Fail startup for missing mandatory skills.
7. Expose health/readiness only after validation succeeds.

## 7. Invocation contract

For every operation:

```text
HTTP Request
  -> Validate request
  -> Create ExecutionContext
  -> Resolve workflow
  -> Resolve logical capability
  -> Resolve configured MCP skill name
  -> Invoke skill with canonical context + payload
  -> Normalize result/error
  -> Record metrics/tracing/audit
  -> Aggregate response
```

## 8. Core workflows

### Qualification

Default mandatory sequence:
1. enrichment
2. account validation
3. balance enquiry

The exact order and conditional rules are specified in:
`specs/workflows/qualification.yaml`

### Posting

Posting is treated as a side-effecting operation.
An idempotency key and transaction state guard are required before production use.

### Fraud

Fraud result must be represented as a business outcome distinct from technical failure.

### Alert

Alert should normally be non-blocking relative to successful monetary posting unless business requirements explicitly say otherwise.

## 9. MCP Skills model

A "skill" is represented by an MCP tool exposed by the Skills MCP Server.

Core stores only a logical capability key, for example:

```text
ENRICHMENT
ACCOUNT_VALIDATION
BALANCE_ENQUIRY
FRAUD_CHECK
POSTING
CUSTOMER_ALERT
```

The mapping to concrete MCP tool names lives in:
`specs/skills/sdk-skill-bindings.yaml`

This prevents PEZ business code from depending on SDK naming/versioning details.

## 10. Failure model

PEZ distinguishes:
- validation failures,
- business rejections,
- dependency failures,
- timeouts,
- authentication/authorization failures,
- rate limiting,
- conflict/idempotency state,
- internal system failures.

See `specs/errors/pez-errors.yaml`.

## 11. Idempotency

`POSTING` must not be automatically retried unless the provider-side contract proves idempotency.

Required production rule:

> When a previously completed Idempotency-Key is submitted again, Core returns the recorded outcome and does not invoke the posting skill again.

## 12. Security

Mandatory controls include:
- OAuth/service identity for MCP
- mTLS where required by enterprise standards
- secrets external to source control
- PII masking/tokenization policy
- deny-by-default logging of sensitive fields
- allowlisted MCP tool bindings
- tool input schema validation
- least-privilege runtime identity

## 13. Observability

Required dimensions:
- correlationId
- requestId
- transactionId
- operation
- capability
- MCP skill name
- outcome
- dependency
- duration
- retryCount

Do not use raw account number or SSN as labels.

## 14. Change control

Any change to:
- public API
- workflow ordering
- mandatory vs optional step
- idempotency rule
- canonical error semantics
- skill contract shape

requires spec update, impact analysis, tests and where appropriate an ADR.

## 15. Source-of-truth hierarchy

1. Approved business requirement
2. Capability specification
3. API/workflow/skill contract
4. ADR
5. Acceptance criteria
6. Code
7. generated or operational documentation

Implementation must not silently override a documented spec.
