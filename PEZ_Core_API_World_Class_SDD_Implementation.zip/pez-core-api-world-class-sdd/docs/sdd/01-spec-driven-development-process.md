# Spec-Driven Development Process

## Lifecycle

```text
Requirement
  -> Requirement ID
  -> Capability Spec
  -> API / Workflow Spec
  -> Skill Contract
  -> ADR when design choice is significant
  -> Acceptance Criteria
  -> Implementation
  -> Contract / Component / E2E Tests
  -> Traceability update
```

## Definition of Ready

A PEZ capability is implementation-ready only when:

- requirement IDs exist,
- request/response semantics are explicit,
- required skills are identified,
- failure behavior is defined,
- timeout/retry/idempotency rules are defined,
- security classification is known,
- telemetry expectations are defined,
- acceptance tests are written or enumerated.

## Definition of Done

A capability is done when:

- implementation satisfies the approved spec,
- required MCP skills are startup-validated,
- all error mappings are implemented,
- no PII leaks through logs/metrics,
- resiliency behavior is testable,
- API compatibility has been checked,
- traceability row is complete,
- SDD and ADRs are current.

## Review gates

### Gate 1 — Business semantics
Does the workflow represent the intended business behavior?

### Gate 2 — Contract
Are OpenAPI, capability inputs/outputs, MCP skill bindings and errors explicit?

### Gate 3 — Architecture
Are Core/SDK boundaries respected? Any SDK-to-SDK coupling?

### Gate 4 — Production readiness
Timeouts, idempotency, retries, telemetry, security, recovery.

### Gate 5 — Verification
Do tests prove the numbered requirements?
