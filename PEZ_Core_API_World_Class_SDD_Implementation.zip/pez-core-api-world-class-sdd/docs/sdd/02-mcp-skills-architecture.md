# Skills MCP Architecture

## Goal

PEZ Core must be able to use SDK capabilities already registered in the enterprise Skills MCP Server without compiling SDK-specific adapters into the Core application.

## Logical model

```text
PEZ capability
   |
   v
Binding Registry
   |
   v
MCP tool name
   |
   v
MCP tools/list validation
   |
   v
MCP tools/call
```

## Discovery

Core calls MCP `tools/list` during startup/readiness and compares the discovered tool names with all mandatory configured bindings.

A missing mandatory tool is considered a deployment/configuration defect and blocks readiness.

## Invocation envelope

Every skill invocation should include:

```json
{
  "context": {
    "correlationId": "...",
    "requestId": "...",
    "transactionId": "...",
    "clientId": "...",
    "channelId": "..."
  },
  "payload": {}
}
```

If existing skills use a different contract, adapt this once inside the MCP adapter rather than inside each business service.

## Allowlist

Only explicitly bound skill names may be invoked by Core.

Do not accept arbitrary tool names from inbound API clients.

## Schema drift

Recommended policy:
- record discovered MCP input/output schema hashes at startup,
- compare against approved contract metadata when available,
- block or alarm on incompatible required-skill drift,
- permit backward-compatible optional field additions per policy.

## Authentication

The reference code leaves token acquisition environment-specific.
The production transport should add authorization headers and corporate mTLS using centrally managed credentials.

## Tool-change notifications

If the MCP server emits tool list changes, production can refresh a cached catalog.
Core must never silently switch a capability to a different tool unless the binding itself changes.
