# Idempotency and Recovery

## Posting safety rule

Posting/deposit is treated as non-idempotent unless the downstream contract explicitly guarantees otherwise.

## Required state model

```text
RECEIVED
VALIDATED
QUALIFIED
FRAUD_APPROVED
POSTING_STARTED
POSTED
ALERT_PENDING
COMPLETED
FAILED
UNKNOWN_POSTING_OUTCOME
```

## Duplicate request

For the same logical operation + Idempotency-Key:

- if COMPLETED/POSTED: return recorded outcome; do not re-call posting skill.
- if POSTING_STARTED: determine whether outcome is known before any retry.
- if UNKNOWN_POSTING_OUTCOME: use provider reconciliation/status capability if available.
- if FAILED before side effect: retry may be permitted by policy.

## Network ambiguity

A timeout after posting request transmission is not proof of failure.

PEZ must not convert "response not received" into "safe to retry."

## Persistence

Production implementation should persist:
- idempotency key
- request fingerprint
- transaction ID
- state
- downstream reference
- final response fingerprint
- timestamps
- reconciliation status

with a uniqueness constraint protecting the idempotency key scope.
