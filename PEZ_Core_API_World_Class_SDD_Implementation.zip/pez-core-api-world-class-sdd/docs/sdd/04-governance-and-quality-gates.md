# SDD Governance and Quality Gates

## Change classification

### Level 1 — Non-behavioral
Examples: typo, comments, diagram labels.

### Level 2 — Backward-compatible
Examples: optional response field, new optional skill metadata.

Requires:
- spec review
- tests
- compatibility check

### Level 3 — Behavior or contract change
Examples:
- workflow ordering
- mandatory/optional step
- timeout/retry/idempotency change
- MCP skill contract change
- public API semantic change

Requires:
- architecture review
- ADR
- impact analysis
- security review when applicable
- compatibility plan
- test evidence

### Level 4 — Financial safety / security critical
Examples:
- posting replay semantics
- credential model
- restricted PII handling
- reconciliation design

Requires explicit approval by designated owners.

## CI blocking checks

A merge should fail when:
- requirement IDs are duplicated,
- mandatory traceability is missing,
- workflow references an unbound capability,
- a skill contract references a missing schema,
- an MCP binding is not allowlisted,
- posting blind-retry policy becomes > 0 without an ADR,
- OpenAPI is invalid,
- schema validation fails,
- forbidden secrets are detected,
- restricted PII test rules fail.

## Architecture review questions

1. Is this decision represented in a spec or ADR?
2. Can a machine detect contract drift?
3. What happens during partial failure?
4. What happens after pod/process failure?
5. Can the operation be replayed safely?
6. What evidence proves the requirement?
7. What telemetry proves production behavior?
