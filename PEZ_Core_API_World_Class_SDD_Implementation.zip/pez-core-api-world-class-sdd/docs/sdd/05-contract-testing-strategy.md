# MCP Contract Testing Strategy

## Goal

Prove that each approved PEZ capability remains compatible with the skill currently exposed by the Skills MCP Server.

## Layers

### 1. Static contract validation
Validate the committed input/output JSON schemas.

### 2. Catalog validation
Compare approved skill names against MCP `tools/list`.

### 3. Schema drift validation
Capture tool schema hash/version metadata and compare to an approved baseline.

### 4. Consumer contract test
For each capability:
- construct canonical PEZ invocation envelope,
- validate request against approved input schema,
- call test/stub MCP skill,
- validate response against approved output schema,
- validate PEZ error normalization.

### 5. Environment smoke test
In non-production:
- initialize MCP,
- list required tools,
- call safe/read-only test capability or approved test mode,
- verify telemetry/correlation.

## Blocking drift

CI/deployment should block when:
- required tool disappears,
- required input becomes stricter incompatibly,
- required output field disappears,
- tool semantics/version change without approved compatibility review.

## Non-blocking drift

Potentially acceptable after policy review:
- new optional input field,
- new optional output field,
- description text change.
