# Golden Scenarios

## GS-001 Qualification success
Enrichment -> Account Validation -> Balance Enquiry -> success.

## GS-002 Qualification mandatory dependency timeout
A required skill times out. Workflow stops. PEZ returns normalized dependency/timeout error.

## GS-003 Fraud business rejection
Fraud skill returns a valid reject outcome. PEZ returns a business outcome, not a technical failure.

## GS-004 Posting success
Idempotency state is persisted, posting is invoked once, provider reference is recorded, final result becomes replay-safe.

## GS-005 Duplicate posting request
Same idempotency scope is received after success. Previously stored result is returned. Posting skill is not called again.

## GS-006 Ambiguous posting outcome
Posting is dispatched and the response is lost. State becomes UNKNOWN_POSTING_OUTCOME. Reconciliation occurs before any replay.

## GS-007 Pod crash after dispatch
Recovery identifies an incomplete financial transaction and reconciles with provider before replay.

## GS-008 Alert failure after posting
Posting remains successful. Alert moves to retry/pending/dead-letter behavior according to approved alert policy.

## GS-009 MCP skill missing
Mandatory skill missing from discovery causes readiness failure.

## GS-010 MCP schema drift
Runtime/catalog schema no longer matches approved contract baseline. Deployment or readiness is blocked according to policy.
