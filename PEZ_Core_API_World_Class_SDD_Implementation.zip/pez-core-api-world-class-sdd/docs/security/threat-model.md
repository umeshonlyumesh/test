# PEZ Core API Threat Model

**Status:** Baseline with PEZ-specific placeholders

## Trust boundaries

```mermaid
flowchart LR
    U[Consumer / CPS] -->|Boundary A| G[Gateway / Ingress]
    G -->|Boundary B| P[PEZ Core]
    P -->|Boundary C| M[Skills MCP Server]
    M -->|Boundary D| S[SDK Skills]
    S -->|Boundary E| X[External Providers]
    P --> D[(PEZ Transaction / Idempotency Store)]
```

## Key assets

- account and customer identifiers
- SSN / restricted PII where present
- transaction state
- posting result/provider reference
- idempotency keys
- MCP credentials/tokens
- TLS material
- audit records

## STRIDE-oriented baseline

| Threat | Example | Control |
|---|---|---|
| Spoofing | Unauthorized workload calls MCP | Workload identity, OAuth/mTLS, audience validation |
| Tampering | Workflow/skill binding modified | Git review, signed release, CI validation, config RBAC |
| Repudiation | Posting action disputed | Immutable audit correlation + provider reference |
| Information Disclosure | PII in logs | Field classification, structured redaction, log tests |
| Denial of Service | MCP/provider saturation | timeouts, concurrency control, rate limits, circuit policy |
| Elevation of Privilege | Arbitrary MCP tool execution | explicit allowlisted capability-to-tool bindings |

## Required security decisions

- `TBD`: enterprise token acquisition method
- `TBD`: mTLS requirement between Core and MCP
- `TBD`: secrets manager/platform
- `TBD`: encryption keys/KMS ownership
- `TBD`: data retention duration
- `TBD`: audit sink
- `TBD`: approval path for new MCP tool binding

## Security invariants

1. Inbound clients never provide executable MCP tool names.
2. Restricted PII never becomes a metric label.
3. Secrets never appear in repo or application logs.
4. Posting reconciliation records are auditable.
5. Skill schema drift is treated as a contract/security event.
