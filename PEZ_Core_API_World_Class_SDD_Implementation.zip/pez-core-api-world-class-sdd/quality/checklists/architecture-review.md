# PEZ Architecture Review Checklist

- [ ] Business requirement ID exists
- [ ] Capability spec updated
- [ ] Workflow/state transition updated
- [ ] API/skill contract updated
- [ ] Failure modes reviewed
- [ ] Idempotency implications reviewed
- [ ] Security/PII implications reviewed
- [ ] Timeout/retry behavior explicit
- [ ] Observability defined
- [ ] Test evidence defined
- [ ] Traceability row updated
- [ ] ADR added/updated when behavior changed
- [ ] Production rollback/recovery considered
