from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
count = 0
for path in ROOT.rglob("*.json"):
    if ".git" in path.parts:
        continue
    count += 1
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT)}: {exc}")

if errors:
    print("JSON VALIDATION FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"JSON VALIDATION PASSED ({count} files)")
