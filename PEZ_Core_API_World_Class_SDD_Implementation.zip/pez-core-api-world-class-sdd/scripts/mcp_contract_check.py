from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
contracts = list((ROOT / "specs/skills/contracts").glob("*.yaml"))
errors = []

for contract in contracts:
    text = contract.read_text(encoding="utf-8")
    for key in ("capability:", "tool:", "owner:", "contract:", "execution:", "security:", "failure:", "observability:"):
        if key not in text:
            errors.append(f"{contract.name}: missing section {key}")

    for m in re.findall(r"(specs/skills/contracts/schemas/[A-Za-z0-9_.-]+\.json)", text):
        if not (ROOT / m).exists():
            errors.append(f"{contract.name}: missing referenced schema {m}")

posting = ROOT / "specs/skills/contracts/posting.yaml"
if posting.exists():
    txt = posting.read_text(encoding="utf-8")
    m = re.search(r"maxBlindRetries:\s*(\d+)", txt)
    if not m or int(m.group(1)) != 0:
        errors.append("Posting maxBlindRetries must be 0 unless architecture policy is explicitly changed.")

if errors:
    print("MCP CONTRACT CHECK FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"MCP CONTRACT CHECK PASSED ({len(contracts)} contracts)")
