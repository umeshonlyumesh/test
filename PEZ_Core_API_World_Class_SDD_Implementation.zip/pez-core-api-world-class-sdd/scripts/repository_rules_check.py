from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

# Ensure important artifacts exist
required = [
    "specs/requirements/requirements.yaml",
    "specs/state-machines/posting-state-machine.yaml",
    "specs/failure-modes/failure-matrix.yaml",
    "specs/nfr/slo.yaml",
    "docs/security/threat-model.md",
    "quality/architecture-rules/architecture-rules.yaml",
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"Missing required artifact: {rel}")

# Collect duplicate PEZ IDs in YAML/MD/CSV, but allow repeats across references.
# Enforce unique definitions in requirements catalog.
req = (ROOT / "specs/requirements/requirements.yaml").read_text(encoding="utf-8")
ids = re.findall(r"^\s*-\s+id:\s*(PEZ-REQ-\d+)\s*$", req, re.M)
if len(ids) != len(set(ids)):
    errors.append("Duplicate PEZ-REQ IDs in requirements catalog.")

# Placeholder policy: dangerous placeholders should remain visibly marked.
for path in [ROOT / "specs/nfr/slo.yaml", ROOT / "specs/deployment/runtime.yaml"]:
    text = path.read_text(encoding="utf-8")
    if "TBD" not in text:
        errors.append(f"{path.relative_to(ROOT)} unexpectedly contains no TBD markers; verify placeholders were not silently guessed.")

if errors:
    print("REPOSITORY RULES CHECK FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("REPOSITORY RULES CHECK PASSED")
