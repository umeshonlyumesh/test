from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
req_file = ROOT / "specs/requirements/requirements.yaml"
trace_file = ROOT / "specs/traceability/end-to-end.csv"

req_text = req_file.read_text(encoding="utf-8")
rows = list(csv.DictReader(trace_file.open(encoding="utf-8")))

errors = []
for row in rows:
    rid = row["business_requirement"].strip()
    if rid and rid not in req_text:
        errors.append(f"Traceability references unknown requirement: {rid}")

required_columns = [
    "business_requirement", "capability", "workflow_or_state", "api_or_contract",
    "design_or_adr", "code_component", "test_evidence", "telemetry", "status"
]
if rows:
    for c in required_columns:
        if c not in rows[0]:
            errors.append(f"Missing traceability column: {c}")

if errors:
    print("TRACEABILITY CHECK FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"TRACEABILITY CHECK PASSED ({len(rows)} rows)")
