from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

checks = [
    "repository_rules_check.py",
    "json_schema_check.py",
    "validate_yaml_syntax.py",
    "traceability_check.py",
    "mcp_contract_check.py",
    "verify-specs.py",
]

failed = []
for script in checks:
    path = ROOT / "scripts" / script
    if not path.exists():
        failed.append(f"Missing validation script: {script}")
        continue

    print(f"\n=== {script} ===")
    result = subprocess.run([sys.executable, str(path)], cwd=ROOT)
    if result.returncode != 0:
        failed.append(script)

if failed:
    print("\nPEZ SPEC QUALITY GATE FAILED")
    for item in failed:
        print(" -", item)
    sys.exit(1)

print("\nPEZ SPEC QUALITY GATE PASSED")
