from pathlib import Path
import sys

try:
    import yaml
except ImportError:
    print("PyYAML not installed; YAML syntax validation skipped.")
    sys.exit(0)

ROOT = Path(__file__).resolve().parents[1]
errors = []
count = 0
for path in ROOT.rglob("*.yaml"):
    if ".git" in path.parts:
        continue
    count += 1
    try:
        yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"{path.relative_to(ROOT)}: {exc}")

if errors:
    print("YAML VALIDATION FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"YAML VALIDATION PASSED ({count} files)")
