from pathlib import Path
import csv
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

required = [
    "docs/sdd/00-master-sdd.md",
    "specs/api/pez-core-api.yaml",
    "specs/skills/sdk-skill-bindings.yaml",
    "specs/errors/pez-errors.yaml",
    "specs/traceability/requirements.csv",
]

errors = []

for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"Missing required file: {rel}")

binding_text = (ROOT / "specs/skills/sdk-skill-bindings.yaml").read_text()
runtime_text = (ROOT / "src/main/resources/application.yml").read_text()

tool_names = re.findall(r"toolName:\s*([A-Za-z0-9_.:-]+)", binding_text)
for tool in tool_names:
    if tool not in runtime_text:
        errors.append(f"Binding in spec is not mirrored in runtime config: {tool}")

trace = ROOT / "specs/traceability/requirements.csv"
if trace.exists():
    rows = list(csv.DictReader(trace.open()))
    ids = [r["requirement_id"] for r in rows]
    if len(ids) != len(set(ids)):
        errors.append("Duplicate requirement_id found in traceability CSV")

if errors:
    print("SPEC VERIFICATION FAILED")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("SPEC VERIFICATION PASSED")
print(f"Checked {len(required)} required artifacts and {len(tool_names)} skill bindings.")
