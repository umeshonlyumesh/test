package com.pez.core;

import com.pez.core.config.McpSkillsProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(McpSkillsProperties.class)
public class PezCoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(PezCoreApplication.class, args);
    }
}
