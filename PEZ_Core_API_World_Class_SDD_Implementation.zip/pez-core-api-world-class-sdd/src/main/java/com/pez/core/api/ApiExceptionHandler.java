package com.pez.core.api;

import com.pez.core.orchestration.SkillInvocationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(SkillInvocationException.class)
    ResponseEntity<Map<String, Object>> skillFailure(SkillInvocationException ex) {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Map.of(
                "code", "PEZ-DEP-001",
                "category", "DEPENDENCY",
                "message", "Required downstream capability failed",
                "capability", ex.capability().name(),
                "skill", ex.skillName()));
    }
}
