package com.pez.core.api;

import com.pez.core.domain.ExecutionContext;
import com.pez.core.orchestration.SkillDrivenOrchestrator;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/v1")
public class QualificationController {

    private final SkillDrivenOrchestrator orchestrator;

    public QualificationController(SkillDrivenOrchestrator orchestrator) {
        this.orchestrator = orchestrator;
    }

    @PostMapping("/qualification")
    ResponseEntity<Map<String, Object>> qualify(
            @RequestHeader("X-Correlation-Id") @NotBlank String correlationId,
            @RequestHeader("X-Request-Id") @NotBlank String requestId,
            @RequestHeader("X-Client-Id") @NotBlank String clientId,
            @RequestHeader("X-Channel-Id") @NotBlank String channelId,
            @RequestBody Map<String, Object> request) {

        ExecutionContext context = new ExecutionContext(
                correlationId,
                requestId,
                UUID.randomUUID().toString(),
                clientId,
                channelId,
                Instant.now());

        Map<String, Object> result = orchestrator.executeQualification(context, request);

        return ResponseEntity.ok(Map.of(
                "correlationId", correlationId,
                "transactionId", context.transactionId(),
                "status", "COMPLETED",
                "data", result));
    }
}
