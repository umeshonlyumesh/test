package com.pez.core.config;

import io.modelcontextprotocol.client.McpClient;
import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.client.transport.HttpClientStreamableHttpTransport;
import io.modelcontextprotocol.spec.McpTransport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class McpClientConfiguration {

    @Bean(destroyMethod = "closeGracefully")
    McpSyncClient pezMcpClient(McpSkillsProperties properties) {
        var mcp = properties.getMcp();

        McpTransport transport = HttpClientStreamableHttpTransport
                .builder(mcp.getBaseUrl())
                .endpoint(mcp.getEndpoint())
                .build();

        McpSyncClient client = McpClient.sync(transport)
                .requestTimeout(mcp.getRequestTimeout())
                .build();

        client.initialize();
        return client;
    }
}
