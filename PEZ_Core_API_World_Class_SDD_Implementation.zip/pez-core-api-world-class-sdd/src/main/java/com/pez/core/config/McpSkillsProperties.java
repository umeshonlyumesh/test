package com.pez.core.config;

import com.pez.core.domain.Capability;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;

@ConfigurationProperties(prefix = "pez")
public class McpSkillsProperties {

    private final Mcp mcp = new Mcp();
    private final Skills skills = new Skills();

    public Mcp getMcp() {
        return mcp;
    }

    public Skills getSkills() {
        return skills;
    }

    public static class Mcp {
        private String baseUrl;
        private String endpoint = "/mcp";
        private Duration requestTimeout = Duration.ofSeconds(5);

        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }

        public String getEndpoint() { return endpoint; }
        public void setEndpoint(String endpoint) { this.endpoint = endpoint; }

        public Duration getRequestTimeout() { return requestTimeout; }
        public void setRequestTimeout(Duration requestTimeout) { this.requestTimeout = requestTimeout; }
    }

    public static class Skills {
        private boolean failOnMissingMandatory = true;
        private Map<Capability, String> bindings = new EnumMap<>(Capability.class);

        public boolean isFailOnMissingMandatory() { return failOnMissingMandatory; }
        public void setFailOnMissingMandatory(boolean value) { this.failOnMissingMandatory = value; }

        public Map<Capability, String> getBindings() { return bindings; }
        public void setBindings(Map<Capability, String> bindings) {
            this.bindings = new EnumMap<>(Capability.class);
            if (bindings != null) {
                this.bindings.putAll(bindings);
            }
        }
    }
}
