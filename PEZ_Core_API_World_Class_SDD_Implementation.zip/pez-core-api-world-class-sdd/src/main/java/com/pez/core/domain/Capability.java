package com.pez.core.domain;

public enum Capability {
    ENRICHMENT,
    ACCOUNT_VALIDATION,
    BALANCE_ENQUIRY,
    FRAUD_CHECK,
    POSTING,
    CUSTOMER_ALERT
}
