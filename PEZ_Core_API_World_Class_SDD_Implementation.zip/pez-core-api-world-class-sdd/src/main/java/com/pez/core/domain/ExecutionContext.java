package com.pez.core.domain;

import java.time.Instant;

public record ExecutionContext(
        String correlationId,
        String requestId,
        String transactionId,
        String clientId,
        String channelId,
        Instant receivedAt) {
}
