package com.pez.core.mcp;

import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.spec.McpSchema;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class McpSkillCatalogClient implements SkillCatalogClient {

    private final McpSyncClient client;

    public McpSkillCatalogClient(McpSyncClient client) {
        this.client = client;
    }

    @Override
    public List<SkillDescriptor> listSkills() {
        return client.listTools().tools().stream()
                .map(tool -> new SkillDescriptor(tool.name(), tool.description()))
                .toList();
    }

    @Override
    public SkillInvocationResult invoke(String skillName, Map<String, Object> arguments) {
        McpSchema.CallToolResult result = client.callTool(
                McpSchema.CallToolRequest.builder(skillName)
                        .arguments(arguments)
                        .build());

        return new SkillInvocationResult(
                Boolean.TRUE.equals(result.isError()),
                result.structuredContent(),
                result.content());
    }
}
