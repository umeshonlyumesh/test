package com.pez.core.mcp;

import java.util.List;
import java.util.Map;

public interface SkillCatalogClient {
    List<SkillDescriptor> listSkills();
    SkillInvocationResult invoke(String skillName, Map<String, Object> arguments);
}
