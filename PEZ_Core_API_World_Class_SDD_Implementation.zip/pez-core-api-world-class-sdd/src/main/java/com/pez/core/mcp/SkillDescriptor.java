package com.pez.core.mcp;

public record SkillDescriptor(String name, String description) {
}
