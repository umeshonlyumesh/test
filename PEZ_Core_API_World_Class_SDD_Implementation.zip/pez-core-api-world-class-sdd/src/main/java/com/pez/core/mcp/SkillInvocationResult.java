package com.pez.core.mcp;

public record SkillInvocationResult(
        boolean error,
        Object structuredContent,
        Object content) {
}
