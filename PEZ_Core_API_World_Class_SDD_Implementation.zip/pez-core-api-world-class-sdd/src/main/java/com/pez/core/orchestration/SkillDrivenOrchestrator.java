package com.pez.core.orchestration;

import com.pez.core.domain.Capability;
import com.pez.core.domain.ExecutionContext;
import com.pez.core.mcp.SkillCatalogClient;
import com.pez.core.mcp.SkillInvocationResult;
import com.pez.core.skills.SkillBindingRegistry;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class SkillDrivenOrchestrator {

    private final SkillBindingRegistry bindings;
    private final SkillCatalogClient skills;

    public SkillDrivenOrchestrator(
            SkillBindingRegistry bindings,
            SkillCatalogClient skills) {
        this.bindings = bindings;
        this.skills = skills;
    }

    public Map<String, Object> executeQualification(
            ExecutionContext context,
            Map<String, Object> payload) {

        List<Capability> workflow = List.of(
                Capability.ENRICHMENT,
                Capability.ACCOUNT_VALIDATION,
                Capability.BALANCE_ENQUIRY);

        Map<String, Object> aggregate = new LinkedHashMap<>();
        Map<String, Object> currentPayload = new LinkedHashMap<>(payload);

        for (Capability capability : workflow) {
            String skillName = bindings.requiredSkill(capability);

            Map<String, Object> arguments = Map.of(
                    "context", contextMap(context),
                    "payload", currentPayload);

            SkillInvocationResult result = skills.invoke(skillName, arguments);

            if (result.error()) {
                throw new SkillInvocationException(capability, skillName, result.content());
            }

            aggregate.put(capability.name(), result.structuredContent());

            if (result.structuredContent() instanceof Map<?, ?> structured) {
                structured.forEach((key, value) -> currentPayload.put(String.valueOf(key), value));
            }
        }

        return aggregate;
    }

    private Map<String, Object> contextMap(ExecutionContext context) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("correlationId", context.correlationId());
        map.put("requestId", context.requestId());
        map.put("transactionId", context.transactionId());
        map.put("clientId", context.clientId());
        map.put("channelId", context.channelId());
        return map;
    }
}
