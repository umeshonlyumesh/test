package com.pez.core.orchestration;

import com.pez.core.domain.Capability;

public class SkillInvocationException extends RuntimeException {

    private final Capability capability;
    private final String skillName;
    private final Object detail;

    public SkillInvocationException(Capability capability, String skillName, Object detail) {
        super("Skill invocation failed for capability " + capability);
        this.capability = capability;
        this.skillName = skillName;
        this.detail = detail;
    }

    public Capability capability() { return capability; }
    public String skillName() { return skillName; }
    public Object detail() { return detail; }
}
