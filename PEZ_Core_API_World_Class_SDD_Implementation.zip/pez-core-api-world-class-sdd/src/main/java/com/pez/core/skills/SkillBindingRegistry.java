package com.pez.core.skills;

import com.pez.core.config.McpSkillsProperties;
import com.pez.core.domain.Capability;
import org.springframework.stereotype.Component;

@Component
public class SkillBindingRegistry {

    private final McpSkillsProperties properties;

    public SkillBindingRegistry(McpSkillsProperties properties) {
        this.properties = properties;
    }

    public String requiredSkill(Capability capability) {
        String value = properties.getSkills().getBindings().get(capability);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException("No MCP skill binding configured for " + capability);
        }
        return value;
    }
}
