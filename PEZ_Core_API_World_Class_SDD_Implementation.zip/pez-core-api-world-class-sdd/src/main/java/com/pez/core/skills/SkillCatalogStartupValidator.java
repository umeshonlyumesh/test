package com.pez.core.skills;

import com.pez.core.config.McpSkillsProperties;
import com.pez.core.mcp.SkillCatalogClient;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

@Component
public class SkillCatalogStartupValidator {

    private final SkillCatalogClient catalog;
    private final McpSkillsProperties properties;

    public SkillCatalogStartupValidator(
            SkillCatalogClient catalog,
            McpSkillsProperties properties) {
        this.catalog = catalog;
        this.properties = properties;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void validate() {
        Set<String> discovered = catalog.listSkills().stream()
                .map(skill -> skill.name())
                .collect(Collectors.toSet());

        var missing = properties.getSkills().getBindings().entrySet().stream()
                .filter(entry -> entry.getValue() != null && !entry.getValue().isBlank())
                .filter(entry -> !discovered.contains(entry.getValue()))
                .toList();

        if (!missing.isEmpty() && properties.getSkills().isFailOnMissingMandatory()) {
            throw new IllegalStateException(
                    "Missing required MCP skills: " +
                            missing.stream()
                                    .map(e -> e.getKey() + "->" + e.getValue())
                                    .toList());
        }
    }
}
