package com.pez.core.contracts;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * Placeholder security acceptance test for PEZ-REQ-005.
 */
class PiiLoggingTest {

    @Disabled("TBD: wire to approved logging/redaction component")
    @Test
    void restrictedPiiMustNotAppearInLogsMetricsOrTraces() {
        // Exercise representative requests containing restricted fields
        // and assert observability outputs contain only approved masked forms.
    }
}
