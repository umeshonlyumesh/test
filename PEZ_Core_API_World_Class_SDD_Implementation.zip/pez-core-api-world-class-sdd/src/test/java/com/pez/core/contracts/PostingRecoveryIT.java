package com.pez.core.contracts;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 * Placeholder integration test specification for PEZ-REQ-003.
 *
 * Replace with a real persistence + MCP/provider simulation test once the
 * idempotency store and reconciliation contract are confirmed.
 */
class PostingRecoveryIT {

    @Disabled("TBD: implement after idempotency store and provider reconciliation contract are approved")
    @Test
    void ambiguousPostingOutcomeMustReconcileBeforeReplay() {
        // Arrange:
        // 1. Persist POSTING_STARTED.
        // 2. Simulate provider accepting posting.
        // 3. Drop/timeout response before Core records POSTED.
        //
        // Act:
        // Restart/recover Core and process incomplete transaction.
        //
        // Assert:
        // Provider status/reconciliation is checked before any posting replay.
    }
}
