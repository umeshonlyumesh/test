package com.pez.core.orchestration;

import com.pez.core.config.McpSkillsProperties;
import com.pez.core.domain.Capability;
import com.pez.core.domain.ExecutionContext;
import com.pez.core.mcp.SkillCatalogClient;
import com.pez.core.mcp.SkillDescriptor;
import com.pez.core.mcp.SkillInvocationResult;
import com.pez.core.skills.SkillBindingRegistry;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

class QualificationWorkflowTest {

    @Test
    void executesQualificationSkillsInApprovedOrder() {
        McpSkillsProperties properties = new McpSkillsProperties();
        properties.getSkills().setBindings(Map.of(
                Capability.ENRICHMENT, "sdk.cif.enrichment",
                Capability.ACCOUNT_VALIDATION, "sdk.account.validation",
                Capability.BALANCE_ENQUIRY, "sdk.balance.enquiry"));

        RecordingCatalog catalog = new RecordingCatalog();
        SkillDrivenOrchestrator orchestrator =
                new SkillDrivenOrchestrator(new SkillBindingRegistry(properties), catalog);

        ExecutionContext context = new ExecutionContext(
                "c1", "r1", "t1", "client", "channel", Instant.now());

        orchestrator.executeQualification(context, Map.of("account", Map.of("id", "masked")));

        assertThat(catalog.calls).containsExactly(
                "sdk.cif.enrichment",
                "sdk.account.validation",
                "sdk.balance.enquiry");
    }

    static class RecordingCatalog implements SkillCatalogClient {
        final List<String> calls = new ArrayList<>();

        @Override
        public List<SkillDescriptor> listSkills() {
            return List.of();
        }

        @Override
        public SkillInvocationResult invoke(String skillName, Map<String, Object> arguments) {
            calls.add(skillName);
            return new SkillInvocationResult(false, Map.of("ok", true), List.of());
        }
    }
}
