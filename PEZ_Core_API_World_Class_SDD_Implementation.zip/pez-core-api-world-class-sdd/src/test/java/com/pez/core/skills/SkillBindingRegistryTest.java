package com.pez.core.skills;

import com.pez.core.config.McpSkillsProperties;
import com.pez.core.domain.Capability;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SkillBindingRegistryTest {

    @Test
    void resolvesConfiguredSkill() {
        McpSkillsProperties p = new McpSkillsProperties();
        p.getSkills().setBindings(Map.of(Capability.FRAUD_CHECK, "sdk.fraud.check"));

        assertThat(new SkillBindingRegistry(p).requiredSkill(Capability.FRAUD_CHECK))
                .isEqualTo("sdk.fraud.check");
    }

    @Test
    void rejectsUnboundCapability() {
        McpSkillsProperties p = new McpSkillsProperties();

        assertThatThrownBy(() ->
                new SkillBindingRegistry(p).requiredSkill(Capability.POSTING))
                .isInstanceOf(IllegalStateException.class);
    }
}
