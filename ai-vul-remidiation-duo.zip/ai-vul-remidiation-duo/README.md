# Spring Boot Vulnerability Remediation

An initial multi-module foundation for a GitLab Duo-assisted remediation system designed for Maven Spring Boot applications.

The authoritative product and security requirements are in [SPEC.md](SPEC.md).

## Modules

```text
remediation-contracts     Versioned HTTP and worker contracts
remediation-domain        Framework-free domain model and ports
remediation-control-plane Spring Boot API, H2 persistence, audit and logging
remediation-worker        Separately deployable isolated-worker entry point
```

Dependencies point inward: adapters depend on domain ports; the domain does not depend on Spring, GitLab, Duo, H2, or Artifactory.

## Current runnable slice

- Create a remediation campaign.
- Retrieve a remediation campaign.
- Idempotent campaign creation using `Idempotency-Key`.
- H2 in-memory persistence managed by Flyway.
- Persisted audit events.
- Correlation IDs propagated through response headers and logs.
- Request completion and application lifecycle logging.
- Actuator liveness and readiness endpoints.
- GitLab OAuth authorization-code flow with PKCE, one-time state, refresh-token rotation, revocation, and in-memory grants.
- Campaign creation fails closed unless the request carries a valid OAuth-backed Duo session.
- Explicit GitLab Duo capability boundary. The default adapter reports Duo as unconfigured rather than silently using another provider.
- Separate worker process with structured startup/completion logging.

This slice establishes the OAuth boundary but does not yet trigger a GitLab Duo flow, run Maven/Artifactory validation, or create an MR. Those operations remain behind module boundaries and will be implemented against `SPEC.md`.

## Prerequisites

- Java 21 or newer.
- Maven 3.9.x installed from the organization-approved distribution.
- Organization Maven `settings.xml` configured to mirror all repositories through Artifactory.

The POM declares no public repositories. Maven must be configured outside this repository to use organization Artifactory.

## Build

```text
mvn -s <path-to-corporate-settings.xml> clean verify
```

## Run the control plane locally

```text
mvn -s <path-to-corporate-settings.xml> \
  -pl remediation-control-plane -am spring-boot:run \
  -Dspring-boot.run.profiles=local
```

The default port is `8080`.

### Configure GitLab Duo OAuth

Register a confidential GitLab OAuth application with this local callback URI:

```text
http://localhost:5173/api/gitlab-duo/oauth/callback
```

Enable the `api` and `ai_features` scopes, then set these environment variables before starting the control plane:

```text
GITLAB_DUO_OAUTH_ENABLED=true
GITLAB_BASE_URL=https://your-gitlab.example.com
GITLAB_DUO_OAUTH_CLIENT_ID=<application-id>
GITLAB_DUO_OAUTH_CLIENT_SECRET=<application-secret>
GITLAB_DUO_OAUTH_REDIRECT_URIS=http://localhost:5173/api/gitlab-duo/oauth/callback
```

The client secret, access token, refresh token, PKCE verifier, and OAuth state are never logged or persisted. Because this local version uses in-memory storage, OAuth sessions are cleared when the control plane stops.

Useful endpoints:

```text
POST /api/v1/remediation-campaigns
GET  /api/v1/remediation-campaigns/{campaignId}
GET  /api/v1/admin/capabilities
POST /api/v1/integrations/gitlab-duo/oauth/authorizations
POST /api/v1/integrations/gitlab-duo/oauth/callbacks
GET  /api/v1/integrations/gitlab-duo/oauth/status
DELETE /api/v1/integrations/gitlab-duo/oauth/session
GET  /actuator/health/liveness
GET  /actuator/health/readiness
GET  /internal/h2-console
```

Example campaign request:

```json
{
  "projectId": "4812",
  "projectPath": "security/example-spring-app",
  "targetBranch": "main",
  "expectedHeadSha": "0123456789abcdef0123456789abcdef01234567",
  "requestedBy": "local-developer",
  "vulnerabilityIds": [
    "gid://gitlab/Vulnerability/101"
  ],
  "policyProfile": "spring-production-strict"
}
```

Supply an optional `Idempotency-Key` header and the opaque `X-Duo-Session-Id` created by the OAuth flow. Repeating the request with the same key returns the original campaign only while the caller remains OAuth-authorized.

## Local H2 database

The `local` profile uses:

```text
jdbc:h2:mem:remediation;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1
```

The database and audit history are discarded on shutdown. The H2 console is a local-only diagnostic feature and must remain disabled outside the local profile.

## Logging

Every request receives or preserves an `X-Correlation-ID`. Logs include:

- service name;
- correlation ID;
- campaign ID when available;
- log level, thread, and logger;
- structured key/value fields;
- request method, path, status, and duration.

Request bodies, credentials, Maven settings, tokens, and source code are intentionally not logged.

## Package name

`com.organization.security.remediation` is a placeholder organization namespace. Replace it once the approved internal Java package and Maven group ID are known.
