package com.organization.security.remediation.contracts.campaign;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public record CreateRemediationCampaignRequest(
        @NotBlank String projectId,
        @NotBlank String projectPath,
        @NotBlank String targetBranch,
        @NotBlank
        @Pattern(regexp = "[0-9a-fA-F]{40,64}", message = "must be a 40-64 character Git commit SHA")
        String expectedHeadSha,
        @NotBlank String requestedBy,
        @NotEmpty @Size(max = 500) Set<@NotBlank String> vulnerabilityIds,
        @NotBlank String policyProfile
) {
    public CreateRemediationCampaignRequest {
        if (vulnerabilityIds == null) {
            vulnerabilityIds = Set.of();
        } else {
            LinkedHashSet<String> normalized = new LinkedHashSet<>();
            vulnerabilityIds.forEach(value -> normalized.add(value == null ? null : value.trim()));
            vulnerabilityIds = Collections.unmodifiableSet(normalized);
        }
    }
}
