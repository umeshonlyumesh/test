package com.organization.security.remediation.contracts.campaign;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;

public record RemediationCampaignResponse(
        UUID campaignId,
        String projectId,
        String projectPath,
        String targetBranch,
        String targetSha,
        String requestedBy,
        String policyProfile,
        String status,
        Set<String> vulnerabilityIds,
        OffsetDateTime createdAt,
        OffsetDateTime updatedAt
) {
    public RemediationCampaignResponse {
        vulnerabilityIds = Set.copyOf(vulnerabilityIds);
    }
}

