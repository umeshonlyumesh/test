package com.organization.security.remediation.contracts.capability;

public record RuntimeCapabilitiesResponse(
        boolean gitLabDuoRequired,
        boolean gitLabDuoConfigured,
        boolean gitLabDuoAuthorized,
        String gitLabDuoMode,
        boolean containerRemediationEnabled,
        String databaseMode
) {
}
