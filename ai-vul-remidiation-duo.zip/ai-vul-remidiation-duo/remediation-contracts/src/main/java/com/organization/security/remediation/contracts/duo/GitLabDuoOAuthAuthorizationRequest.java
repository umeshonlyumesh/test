package com.organization.security.remediation.contracts.duo;

import jakarta.validation.constraints.NotBlank;

public record GitLabDuoOAuthAuthorizationRequest(
        @NotBlank String redirectUri,
        String rootNamespaceId
) {
}
