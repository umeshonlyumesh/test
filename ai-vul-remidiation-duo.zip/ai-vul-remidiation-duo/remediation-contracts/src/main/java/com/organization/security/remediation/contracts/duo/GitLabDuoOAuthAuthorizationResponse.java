package com.organization.security.remediation.contracts.duo;

import java.time.OffsetDateTime;

public record GitLabDuoOAuthAuthorizationResponse(
        String authorizationUrl,
        String sessionId,
        OffsetDateTime expiresAt
) {
}
