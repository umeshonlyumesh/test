package com.organization.security.remediation.contracts.duo;

import jakarta.validation.constraints.NotBlank;

public record GitLabDuoOAuthCallbackRequest(
        @NotBlank String code,
        @NotBlank String state,
        @NotBlank String sessionId
) {
}
