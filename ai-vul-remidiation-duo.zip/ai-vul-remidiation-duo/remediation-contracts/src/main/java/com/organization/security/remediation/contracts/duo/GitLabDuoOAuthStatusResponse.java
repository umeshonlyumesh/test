package com.organization.security.remediation.contracts.duo;

import java.time.OffsetDateTime;
import java.util.Set;

public record GitLabDuoOAuthStatusResponse(
        boolean configured,
        boolean authorized,
        String mode,
        String gitLabBaseUrl,
        String username,
        String displayName,
        OffsetDateTime expiresAt,
        Set<String> scopes,
        String detail
) {
}
