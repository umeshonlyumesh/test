package com.organization.security.remediation.controlplane;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.Clock;

@SpringBootApplication
public class RemediationControlPlaneApplication {
    private static final Logger log = LoggerFactory.getLogger(RemediationControlPlaneApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(RemediationControlPlaneApplication.class, args);
        log.atInfo()
                .addKeyValue("event", "control_plane_started")
                .log("Remediation control plane started");
    }

    @Bean
    Clock systemClock() {
        return Clock.systemUTC();
    }
}

