package com.organization.security.remediation.controlplane.api;

import com.organization.security.remediation.controlplane.application.CampaignNotFoundException;
import com.organization.security.remediation.domain.duo.DuoAuthorizationRequiredException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;

@RestControllerAdvice
public class ApiExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(CampaignNotFoundException.class)
    ProblemDetail handleNotFound(CampaignNotFoundException exception) {
        log.atInfo()
                .addKeyValue("event", "campaign_not_found")
                .log("{}", exception.getMessage());
        return problem(HttpStatus.NOT_FOUND, "Campaign not found", exception.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    ProblemDetail handleBadRequest(IllegalArgumentException exception) {
        log.atWarn()
                .addKeyValue("event", "invalid_request")
                .log("Request rejected: {}", exception.getMessage());
        return problem(HttpStatus.BAD_REQUEST, "Invalid request", exception.getMessage());
    }

    @ExceptionHandler(DuoAuthorizationRequiredException.class)
    ProblemDetail handleDuoAuthorizationRequired(DuoAuthorizationRequiredException exception) {
        log.atWarn()
                .addKeyValue("event", "gitlab_duo_oauth_required")
                .log("GitLab Duo OAuth authorization is required");
        return problem(HttpStatus.UNAUTHORIZED, "GitLab Duo authorization required", exception.getMessage());
    }

    private static ProblemDetail problem(HttpStatus status, String title, String detail) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setTitle(title);
        problem.setType(URI.create("urn:problem:remediation:" + status.value()));
        problem.setProperty("correlationId", MDC.get("correlationId"));
        return problem;
    }
}
