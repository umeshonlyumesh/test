package com.organization.security.remediation.controlplane.api;

import com.organization.security.remediation.contracts.campaign.CreateRemediationCampaignRequest;
import com.organization.security.remediation.contracts.campaign.RemediationCampaignResponse;
import com.organization.security.remediation.controlplane.application.CampaignService;
import com.organization.security.remediation.domain.campaign.RemediationCampaign;
import jakarta.validation.Valid;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/remediation-campaigns")
public class CampaignController {
    private final CampaignService campaignService;

    public CampaignController(CampaignService campaignService) {
        this.campaignService = campaignService;
    }

    @PostMapping
    public ResponseEntity<RemediationCampaignResponse> create(
            @Valid @RequestBody CreateRemediationCampaignRequest request,
            @RequestHeader(name = "Idempotency-Key", required = false) String idempotencyKey,
            @RequestHeader(name = "X-Duo-Session-Id", required = false) String duoSessionId,
            UriComponentsBuilder uriBuilder
    ) {
        RemediationCampaign campaign = campaignService.create(request, idempotencyKey, duoSessionId);
        URI location = uriBuilder
                .path("/api/v1/remediation-campaigns/{campaignId}")
                .buildAndExpand(campaign.id())
                .toUri();
        return ResponseEntity.accepted()
                .location(location)
                .body(toResponse(campaign));
    }

    @GetMapping("/{campaignId}")
    public RemediationCampaignResponse get(@PathVariable UUID campaignId) {
        try (MDC.MDCCloseable ignored = MDC.putCloseable("campaignId", campaignId.toString())) {
            return toResponse(campaignService.get(campaignId));
        }
    }

    private static RemediationCampaignResponse toResponse(RemediationCampaign campaign) {
        return new RemediationCampaignResponse(
                campaign.id(),
                campaign.projectId(),
                campaign.projectPath(),
                campaign.targetBranch(),
                campaign.targetSha(),
                campaign.requestedBy(),
                campaign.policyProfile(),
                campaign.status().name(),
                campaign.vulnerabilityIds(),
                campaign.createdAt(),
                campaign.updatedAt()
        );
    }
}
