package com.organization.security.remediation.controlplane.api;

import com.organization.security.remediation.contracts.capability.RuntimeCapabilitiesResponse;
import com.organization.security.remediation.domain.duo.DuoCapabilities;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/admin/capabilities")
public class CapabilityController {
    private final GitLabDuoGateway duoGateway;

    public CapabilityController(GitLabDuoGateway duoGateway) {
        this.duoGateway = duoGateway;
    }

    @GetMapping
    public RuntimeCapabilitiesResponse get(
            @RequestHeader(name = "X-Duo-Session-Id", required = false) String duoSessionId
    ) {
        DuoCapabilities duo = duoGateway.capabilities(duoSessionId);
        return new RuntimeCapabilitiesResponse(
                true,
                duo.configured(),
                duo.authorized(),
                duo.mode(),
                false,
                "H2_IN_MEMORY"
        );
    }
}
