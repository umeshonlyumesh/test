package com.organization.security.remediation.controlplane.application;

import java.util.UUID;

public final class CampaignNotFoundException extends RuntimeException {
    public CampaignNotFoundException(UUID campaignId) {
        super("Remediation campaign not found: " + campaignId);
    }
}

