package com.organization.security.remediation.controlplane.application;

import com.organization.security.remediation.contracts.campaign.CreateRemediationCampaignRequest;
import com.organization.security.remediation.domain.audit.AuditEvent;
import com.organization.security.remediation.domain.audit.AuditTrail;
import com.organization.security.remediation.domain.campaign.RemediationCampaign;
import com.organization.security.remediation.domain.campaign.RemediationCampaignRepository;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.UUID;

@Service
public class CampaignService {
    private static final Logger log = LoggerFactory.getLogger(CampaignService.class);

    private final RemediationCampaignRepository campaignRepository;
    private final AuditTrail auditTrail;
    private final Clock clock;
    private final GitLabDuoGateway duoGateway;

    public CampaignService(
            RemediationCampaignRepository campaignRepository,
            AuditTrail auditTrail,
            Clock clock,
            GitLabDuoGateway duoGateway
    ) {
        this.campaignRepository = campaignRepository;
        this.auditTrail = auditTrail;
        this.clock = clock;
        this.duoGateway = duoGateway;
    }

    @Transactional
    public RemediationCampaign create(
            CreateRemediationCampaignRequest request,
            String suppliedIdempotencyKey,
            String duoSessionId
    ) {
        duoGateway.requireAuthorization(duoSessionId);
        String idempotencyKey = normalizeIdempotencyKey(suppliedIdempotencyKey);
        var existing = campaignRepository.findByIdempotencyKey(idempotencyKey);
        if (existing.isPresent()) {
            ensureSameRequest(existing.get(), request);
            log.atInfo()
                    .addKeyValue("event", "campaign_idempotency_hit")
                    .addKeyValue("campaignId", existing.get().id())
                    .log("Returning existing remediation campaign");
            return existing.get();
        }

        OffsetDateTime now = OffsetDateTime.now(clock);
        RemediationCampaign campaign = RemediationCampaign.create(
                UUID.randomUUID(),
                idempotencyKey,
                request.projectId(),
                request.projectPath(),
                request.targetBranch(),
                request.expectedHeadSha(),
                request.requestedBy(),
                request.policyProfile(),
                request.vulnerabilityIds(),
                now
        );

        RemediationCampaign saved = campaignRepository.save(campaign);
        auditTrail.append(new AuditEvent(
                UUID.randomUUID(),
                "REMEDIATION_CAMPAIGN",
                saved.id().toString(),
                "CAMPAIGN_CREATED",
                saved.requestedBy(),
                correlationId(),
                "projectId=" + saved.projectId() + ",findingCount=" + saved.vulnerabilityIds().size(),
                now
        ));

        log.atInfo()
                .addKeyValue("event", "campaign_created")
                .addKeyValue("campaignId", saved.id())
                .addKeyValue("projectId", saved.projectId())
                .addKeyValue("findingCount", saved.vulnerabilityIds().size())
                .log("Remediation campaign accepted");
        return saved;
    }

    @Transactional(readOnly = true)
    public RemediationCampaign get(UUID campaignId) {
        return campaignRepository.findById(campaignId)
                .orElseThrow(() -> new CampaignNotFoundException(campaignId));
    }

    private static String normalizeIdempotencyKey(String supplied) {
        if (supplied == null || supplied.isBlank()) {
            return UUID.randomUUID().toString();
        }
        String normalized = supplied.trim();
        if (normalized.length() > 128) {
            throw new IllegalArgumentException("Idempotency-Key must not exceed 128 characters");
        }
        return normalized;
    }

    private static void ensureSameRequest(
            RemediationCampaign existing,
            CreateRemediationCampaignRequest request
    ) {
        boolean matches = existing.projectId().equals(request.projectId().trim())
                && existing.projectPath().equals(request.projectPath().trim())
                && existing.targetBranch().equals(request.targetBranch().trim())
                && existing.targetSha().equals(request.expectedHeadSha().trim())
                && existing.requestedBy().equals(request.requestedBy().trim())
                && existing.policyProfile().equals(request.policyProfile().trim())
                && existing.vulnerabilityIds().equals(request.vulnerabilityIds());
        if (!matches) {
            throw new IllegalArgumentException(
                    "Idempotency-Key was already used for a different campaign request"
            );
        }
    }

    private static String correlationId() {
        return MDC.get("correlationId") == null ? "not-available" : MDC.get("correlationId");
    }
}
