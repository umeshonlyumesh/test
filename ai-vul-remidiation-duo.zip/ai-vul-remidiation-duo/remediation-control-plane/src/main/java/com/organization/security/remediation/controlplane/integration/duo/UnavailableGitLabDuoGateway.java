package com.organization.security.remediation.controlplane.integration.duo;

import com.organization.security.remediation.domain.duo.DuoCapabilities;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "remediation.gitlab.oauth", name = "enabled", havingValue = "false", matchIfMissing = true)
public class UnavailableGitLabDuoGateway implements GitLabDuoGateway {
    private static final Logger log = LoggerFactory.getLogger(UnavailableGitLabDuoGateway.class);

    public UnavailableGitLabDuoGateway() {
        log.atWarn()
                .addKeyValue("event", "gitlab_duo_not_configured")
                .log("GitLab Duo gateway is not configured; AI remediation is fail-closed");
    }

    @Override
    public DuoCapabilities capabilities(String sessionId) {
        return new DuoCapabilities(
                false,
                false,
                "UNCONFIGURED",
                "Configure GitLab OAuth before executing Duo remediation"
        );
    }

    @Override
    public void requireAuthorization(String sessionId) {
        throw new com.organization.security.remediation.domain.duo.DuoAuthorizationRequiredException(
                "GitLab Duo OAuth is not configured"
        );
    }
}
