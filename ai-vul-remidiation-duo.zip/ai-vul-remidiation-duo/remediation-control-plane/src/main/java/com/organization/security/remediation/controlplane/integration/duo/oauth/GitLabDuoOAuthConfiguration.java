package com.organization.security.remediation.controlplane.integration.duo.oauth;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(prefix = "remediation.gitlab.oauth", name = "enabled", havingValue = "true")
@EnableConfigurationProperties(GitLabDuoOAuthProperties.class)
class GitLabDuoOAuthConfiguration {
}
