package com.organization.security.remediation.controlplane.integration.duo.oauth;

import java.time.OffsetDateTime;
import java.util.Set;

record GitLabDuoOAuthGrant(
        String accessToken,
        String refreshToken,
        OffsetDateTime expiresAt,
        Set<String> scopes,
        String gitLabUserId,
        String username,
        String displayName
) {
}
