package com.organization.security.remediation.controlplane.integration.duo.oauth;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Validated
@ConfigurationProperties("remediation.gitlab.oauth")
public class GitLabDuoOAuthProperties {
    private boolean enabled;
    @NotBlank
    private String baseUrl = "https://gitlab.com";
    @NotBlank
    private String clientId;
    @NotBlank
    private String clientSecret;
    @NotEmpty
    private List<@NotBlank String> redirectUris = new ArrayList<>();
    @NotEmpty
    private List<@NotBlank String> scopes = new ArrayList<>(List.of("api", "ai_features"));
    @Valid
    private Duration stateTtl = Duration.ofMinutes(10);
    @Valid
    private Duration refreshSkew = Duration.ofMinutes(1);

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }
    public String getClientSecret() { return clientSecret; }
    public void setClientSecret(String clientSecret) { this.clientSecret = clientSecret; }
    public List<String> getRedirectUris() { return List.copyOf(redirectUris); }
    public void setRedirectUris(List<String> redirectUris) { this.redirectUris = new ArrayList<>(redirectUris); }
    public List<String> getScopes() { return List.copyOf(scopes); }
    public void setScopes(List<String> scopes) { this.scopes = new ArrayList<>(scopes); }
    public Duration getStateTtl() { return stateTtl; }
    public void setStateTtl(Duration stateTtl) { this.stateTtl = stateTtl; }
    public Duration getRefreshSkew() { return refreshSkew; }
    public void setRefreshSkew(Duration refreshSkew) { this.refreshSkew = refreshSkew; }
}
