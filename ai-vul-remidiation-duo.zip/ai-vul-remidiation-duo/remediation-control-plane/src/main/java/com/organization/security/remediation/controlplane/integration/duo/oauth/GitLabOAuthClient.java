package com.organization.security.remediation.controlplane.integration.duo.oauth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.net.URI;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

@Component
@ConditionalOnProperty(prefix = "remediation.gitlab.oauth", name = "enabled", havingValue = "true")
class GitLabOAuthClient {
    private static final Logger log = LoggerFactory.getLogger(GitLabOAuthClient.class);

    private final GitLabDuoOAuthProperties properties;
    private final RestClient restClient;
    private final Clock clock;

    GitLabOAuthClient(GitLabDuoOAuthProperties properties, RestClient.Builder restClientBuilder, Clock clock) {
        this.properties = properties;
        this.restClient = restClientBuilder.build();
        this.clock = clock;
    }

    GitLabDuoOAuthGrant exchange(String code, String verifier, String redirectUri) {
        MultiValueMap<String, String> form = commonTokenForm();
        form.add("grant_type", "authorization_code");
        form.add("code", code);
        form.add("code_verifier", verifier);
        form.add("redirect_uri", redirectUri);
        return toGrant(requestToken(form), null);
    }

    GitLabDuoOAuthGrant refresh(GitLabDuoOAuthGrant previous) {
        if (previous.refreshToken() == null || previous.refreshToken().isBlank()) {
            throw new GitLabOAuthException("GitLab OAuth refresh token is unavailable");
        }
        MultiValueMap<String, String> form = commonTokenForm();
        form.add("grant_type", "refresh_token");
        form.add("refresh_token", previous.refreshToken());
        return toGrant(requestToken(form), previous);
    }

    void revoke(GitLabDuoOAuthGrant grant) {
        MultiValueMap<String, String> form = commonTokenForm();
        form.add("token", grant.accessToken());
        try {
            restClient.post()
                    .uri(endpoint("/oauth/revoke"))
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form)
                    .retrieve()
                    .toBodilessEntity();
        } catch (RestClientResponseException exception) {
            log.atWarn()
                    .addKeyValue("event", "gitlab_oauth_revoke_failed")
                    .addKeyValue("status", exception.getStatusCode().value())
                    .log("GitLab OAuth token revocation failed");
        }
    }

    private OAuthTokenResponse requestToken(MultiValueMap<String, String> form) {
        try {
            OAuthTokenResponse response = restClient.post()
                    .uri(endpoint("/oauth/token"))
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form)
                    .retrieve()
                    .body(OAuthTokenResponse.class);
            if (response == null || response.accessToken() == null || response.accessToken().isBlank()) {
                throw new GitLabOAuthException("GitLab returned an invalid OAuth token response");
            }
            return response;
        } catch (RestClientResponseException exception) {
            log.atWarn()
                    .addKeyValue("event", "gitlab_oauth_token_request_failed")
                    .addKeyValue("status", exception.getStatusCode().value())
                    .log("GitLab OAuth token request failed");
            throw new GitLabOAuthException("GitLab rejected the OAuth token request", exception);
        }
    }

    private GitLabDuoOAuthGrant toGrant(OAuthTokenResponse token, GitLabDuoOAuthGrant previous) {
        GitLabUserResponse user = fetchUser(token.accessToken());
        long expiresIn = token.expiresIn() == null ? 7200L : token.expiresIn();
        Set<String> scopes = parseScopes(token.scope());
        String refreshToken = token.refreshToken() == null ? previous == null ? null : previous.refreshToken() : token.refreshToken();
        return new GitLabDuoOAuthGrant(
                token.accessToken(),
                refreshToken,
                OffsetDateTime.now(clock).plusSeconds(expiresIn),
                scopes,
                String.valueOf(user.id()),
                user.username(),
                user.name()
        );
    }

    private GitLabUserResponse fetchUser(String accessToken) {
        try {
            GitLabUserResponse user = restClient.get()
                    .uri(endpoint("/api/v4/user"))
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)
                    .retrieve()
                    .body(GitLabUserResponse.class);
            if (user == null || user.username() == null) {
                throw new GitLabOAuthException("GitLab did not return the authorized user");
            }
            return user;
        } catch (RestClientResponseException exception) {
            log.atWarn()
                    .addKeyValue("event", "gitlab_oauth_user_lookup_failed")
                    .addKeyValue("status", exception.getStatusCode().value())
                    .log("GitLab OAuth user lookup failed");
            throw new GitLabOAuthException("Unable to verify the authorized GitLab user", exception);
        }
    }

    private MultiValueMap<String, String> commonTokenForm() {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("client_id", properties.getClientId());
        form.add("client_secret", properties.getClientSecret());
        return form;
    }

    private URI endpoint(String path) {
        return URI.create(properties.getBaseUrl().replaceAll("/+$", "") + path);
    }

    private static Set<String> parseScopes(String scope) {
        if (scope == null || scope.isBlank()) return Set.of();
        return java.util.Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(scope.trim().split("\\s+"))));
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record OAuthTokenResponse(
            @JsonProperty("access_token") String accessToken,
            @JsonProperty("token_type") String tokenType,
            @JsonProperty("expires_in") Long expiresIn,
            @JsonProperty("refresh_token") String refreshToken,
            String scope
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record GitLabUserResponse(long id, String username, String name) {
    }

    static class GitLabOAuthException extends RuntimeException {
        GitLabOAuthException(String message) { super(message); }
        GitLabOAuthException(String message, Throwable cause) { super(message, cause); }
    }
}
