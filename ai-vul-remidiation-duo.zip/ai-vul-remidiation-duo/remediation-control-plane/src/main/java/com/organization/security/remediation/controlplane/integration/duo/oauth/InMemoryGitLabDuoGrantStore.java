package com.organization.security.remediation.controlplane.integration.duo.oauth;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Component
@ConditionalOnProperty(prefix = "remediation.gitlab.oauth", name = "enabled", havingValue = "true")
class InMemoryGitLabDuoGrantStore {
    private final ConcurrentHashMap<String, GitLabDuoOAuthGrant> grants = new ConcurrentHashMap<>();

    void save(String sessionId, GitLabDuoOAuthGrant grant) {
        grants.put(sessionId, grant);
    }

    Optional<GitLabDuoOAuthGrant> find(String sessionId) {
        if (sessionId == null || sessionId.isBlank()) return Optional.empty();
        return Optional.ofNullable(grants.get(sessionId));
    }

    Optional<GitLabDuoOAuthGrant> remove(String sessionId) {
        if (sessionId == null || sessionId.isBlank()) return Optional.empty();
        return Optional.ofNullable(grants.remove(sessionId));
    }
}
