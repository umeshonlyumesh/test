package com.organization.security.remediation.controlplane.integration.duo.oauth;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@ConditionalOnProperty(prefix = "remediation.gitlab.oauth", name = "enabled", havingValue = "true")
class PendingOAuthAuthorizationStore {
    private final SecureRandom secureRandom = new SecureRandom();
    private final Map<String, PendingAuthorization> pending = new ConcurrentHashMap<>();
    private final GitLabDuoOAuthProperties properties;
    private final Clock clock;

    PendingOAuthAuthorizationStore(GitLabDuoOAuthProperties properties, Clock clock) {
        this.properties = properties;
        this.clock = clock;
    }

    PendingAuthorization create(String redirectUri) {
        purgeExpired();
        String verifier = randomUrlSafe(64);
        PendingAuthorization authorization = new PendingAuthorization(
                randomUrlSafe(32),
                randomUrlSafe(32),
                verifier,
                challenge(verifier),
                redirectUri,
                OffsetDateTime.now(clock).plus(properties.getStateTtl())
        );
        pending.put(authorization.state(), authorization);
        return authorization;
    }

    PendingAuthorization consume(String state, String sessionId) {
        PendingAuthorization authorization = pending.get(state);
        if (authorization == null
                || authorization.expiresAt().isBefore(OffsetDateTime.now(clock))
                || !constantTimeEquals(authorization.sessionId(), sessionId)) {
            throw new IllegalArgumentException("OAuth state is invalid, expired, or bound to another browser session");
        }
        if (!pending.remove(state, authorization)) {
            throw new IllegalArgumentException("OAuth state was already consumed");
        }
        return authorization;
    }

    private void purgeExpired() {
        OffsetDateTime now = OffsetDateTime.now(clock);
        pending.entrySet().removeIf(entry -> entry.getValue().expiresAt().isBefore(now));
    }

    private String randomUrlSafe(int bytes) {
        byte[] value = new byte[bytes];
        secureRandom.nextBytes(value);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value);
    }

    private static String challenge(String verifier) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }

    private static boolean constantTimeEquals(String left, String right) {
        if (right == null) return false;
        return MessageDigest.isEqual(
                left.getBytes(java.nio.charset.StandardCharsets.UTF_8),
                right.getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );
    }

    record PendingAuthorization(
            String sessionId,
            String state,
            String verifier,
            String challenge,
            String redirectUri,
            OffsetDateTime expiresAt
    ) {
    }
}
