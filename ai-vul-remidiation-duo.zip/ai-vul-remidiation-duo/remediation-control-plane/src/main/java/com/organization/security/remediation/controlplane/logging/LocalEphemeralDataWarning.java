package com.organization.security.remediation.controlplane.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("local")
public class LocalEphemeralDataWarning implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(LocalEphemeralDataWarning.class);

    @Override
    public void run(ApplicationArguments args) {
        log.atWarn()
                .addKeyValue("event", "local_ephemeral_database_enabled")
                .addKeyValue("database", "H2_IN_MEMORY")
                .log("Local mode uses an in-memory database; campaign and audit data will be lost at shutdown");
    }
}
