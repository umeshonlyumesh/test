package com.organization.security.remediation.controlplane.persistence.audit;

import com.organization.security.remediation.domain.audit.AuditEvent;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "audit_event")
class AuditEventJpaEntity {
    @Id
    private UUID id;

    @Column(name = "aggregate_type", nullable = false, length = 64)
    private String aggregateType;

    @Column(name = "aggregate_id", nullable = false, length = 255)
    private String aggregateId;

    @Column(name = "event_type", nullable = false, length = 128)
    private String eventType;

    @Column(name = "actor", nullable = false, length = 255)
    private String actor;

    @Column(name = "correlation_id", nullable = false, length = 128)
    private String correlationId;

    @Column(name = "details", nullable = false, length = 4000)
    private String details;

    @Column(name = "occurred_at", nullable = false)
    private OffsetDateTime occurredAt;

    protected AuditEventJpaEntity() {
    }

    static AuditEventJpaEntity fromDomain(AuditEvent event) {
        AuditEventJpaEntity entity = new AuditEventJpaEntity();
        entity.id = event.id();
        entity.aggregateType = event.aggregateType();
        entity.aggregateId = event.aggregateId();
        entity.eventType = event.eventType();
        entity.actor = event.actor();
        entity.correlationId = event.correlationId();
        entity.details = event.details();
        entity.occurredAt = event.occurredAt();
        return entity;
    }
}

