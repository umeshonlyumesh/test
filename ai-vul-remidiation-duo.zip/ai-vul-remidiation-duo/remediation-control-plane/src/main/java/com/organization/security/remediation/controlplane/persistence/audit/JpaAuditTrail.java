package com.organization.security.remediation.controlplane.persistence.audit;

import com.organization.security.remediation.domain.audit.AuditEvent;
import com.organization.security.remediation.domain.audit.AuditTrail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class JpaAuditTrail implements AuditTrail {
    private static final Logger log = LoggerFactory.getLogger(JpaAuditTrail.class);

    private final SpringDataAuditEventRepository repository;

    public JpaAuditTrail(SpringDataAuditEventRepository repository) {
        this.repository = repository;
    }

    @Override
    public void append(AuditEvent event) {
        repository.save(AuditEventJpaEntity.fromDomain(event));
        log.atInfo()
                .addKeyValue("event", "audit_event_persisted")
                .addKeyValue("eventType", event.eventType())
                .addKeyValue("aggregateType", event.aggregateType())
                .addKeyValue("aggregateId", event.aggregateId())
                .log("Audit event persisted");
    }
}

