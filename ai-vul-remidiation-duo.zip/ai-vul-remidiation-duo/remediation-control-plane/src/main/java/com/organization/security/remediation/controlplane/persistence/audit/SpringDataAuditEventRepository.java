package com.organization.security.remediation.controlplane.persistence.audit;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

interface SpringDataAuditEventRepository extends JpaRepository<AuditEventJpaEntity, UUID> {
}

