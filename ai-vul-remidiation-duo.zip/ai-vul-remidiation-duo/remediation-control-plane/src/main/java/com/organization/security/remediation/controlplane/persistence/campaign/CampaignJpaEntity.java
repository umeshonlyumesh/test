package com.organization.security.remediation.controlplane.persistence.campaign;

import com.organization.security.remediation.domain.campaign.CampaignStatus;
import com.organization.security.remediation.domain.campaign.RemediationCampaign;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import jakarta.persistence.Version;

import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "remediation_campaign")
class CampaignJpaEntity {
    @Id
    private UUID id;

    @Column(name = "idempotency_key", nullable = false, unique = true, length = 128)
    private String idempotencyKey;

    @Column(name = "project_id", nullable = false, length = 255)
    private String projectId;

    @Column(name = "project_path", nullable = false, length = 1024)
    private String projectPath;

    @Column(name = "target_branch", nullable = false, length = 255)
    private String targetBranch;

    @Column(name = "target_sha", nullable = false, length = 64)
    private String targetSha;

    @Column(name = "requested_by", nullable = false, length = 255)
    private String requestedBy;

    @Column(name = "policy_profile", nullable = false, length = 255)
    private String policyProfile;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "campaign_vulnerability", joinColumns = @JoinColumn(name = "campaign_id"))
    @Column(name = "vulnerability_id", nullable = false, length = 1024)
    private Set<String> vulnerabilityIds = new LinkedHashSet<>();

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 32)
    private CampaignStatus status;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    @Version
    @Column(name = "entity_version", nullable = false)
    private long entityVersion;

    protected CampaignJpaEntity() {
    }

    static CampaignJpaEntity fromDomain(RemediationCampaign campaign) {
        CampaignJpaEntity entity = new CampaignJpaEntity();
        entity.id = campaign.id();
        entity.idempotencyKey = campaign.idempotencyKey();
        entity.projectId = campaign.projectId();
        entity.projectPath = campaign.projectPath();
        entity.targetBranch = campaign.targetBranch();
        entity.targetSha = campaign.targetSha();
        entity.requestedBy = campaign.requestedBy();
        entity.policyProfile = campaign.policyProfile();
        entity.vulnerabilityIds = new LinkedHashSet<>(campaign.vulnerabilityIds());
        entity.status = campaign.status();
        entity.createdAt = campaign.createdAt();
        entity.updatedAt = campaign.updatedAt();
        return entity;
    }

    RemediationCampaign toDomain() {
        return RemediationCampaign.rehydrate(
                id,
                idempotencyKey,
                projectId,
                projectPath,
                targetBranch,
                targetSha,
                requestedBy,
                policyProfile,
                vulnerabilityIds,
                status,
                createdAt,
                updatedAt
        );
    }
}

