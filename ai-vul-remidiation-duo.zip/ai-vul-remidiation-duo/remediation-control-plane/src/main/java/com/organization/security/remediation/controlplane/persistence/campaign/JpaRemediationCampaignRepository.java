package com.organization.security.remediation.controlplane.persistence.campaign;

import com.organization.security.remediation.domain.campaign.RemediationCampaign;
import com.organization.security.remediation.domain.campaign.RemediationCampaignRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public class JpaRemediationCampaignRepository implements RemediationCampaignRepository {
    private final SpringDataCampaignRepository repository;

    public JpaRemediationCampaignRepository(SpringDataCampaignRepository repository) {
        this.repository = repository;
    }

    @Override
    public RemediationCampaign save(RemediationCampaign campaign) {
        return repository.save(CampaignJpaEntity.fromDomain(campaign)).toDomain();
    }

    @Override
    public Optional<RemediationCampaign> findById(UUID id) {
        return repository.findById(id).map(CampaignJpaEntity::toDomain);
    }

    @Override
    public Optional<RemediationCampaign> findByIdempotencyKey(String idempotencyKey) {
        return repository.findByIdempotencyKey(idempotencyKey).map(CampaignJpaEntity::toDomain);
    }
}

