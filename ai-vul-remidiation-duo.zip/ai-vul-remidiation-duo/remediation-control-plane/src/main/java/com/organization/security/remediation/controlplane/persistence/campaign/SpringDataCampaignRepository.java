package com.organization.security.remediation.controlplane.persistence.campaign;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

interface SpringDataCampaignRepository extends JpaRepository<CampaignJpaEntity, UUID> {
    Optional<CampaignJpaEntity> findByIdempotencyKey(String idempotencyKey);
}

