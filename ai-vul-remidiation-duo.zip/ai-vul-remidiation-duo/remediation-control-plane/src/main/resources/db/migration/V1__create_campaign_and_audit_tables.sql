create table remediation_campaign (
    id uuid primary key,
    idempotency_key varchar(128) not null unique,
    project_id varchar(255) not null,
    project_path varchar(1024) not null,
    target_branch varchar(255) not null,
    target_sha varchar(64) not null,
    requested_by varchar(255) not null,
    policy_profile varchar(255) not null,
    status varchar(32) not null,
    created_at timestamp with time zone not null,
    updated_at timestamp with time zone not null,
    entity_version bigint not null default 0
);

create table campaign_vulnerability (
    campaign_id uuid not null,
    vulnerability_id varchar(1024) not null,
    primary key (campaign_id, vulnerability_id),
    constraint fk_campaign_vulnerability_campaign
        foreign key (campaign_id) references remediation_campaign(id)
);

create table audit_event (
    id uuid primary key,
    aggregate_type varchar(64) not null,
    aggregate_id varchar(255) not null,
    event_type varchar(128) not null,
    actor varchar(255) not null,
    correlation_id varchar(128) not null,
    details varchar(4000) not null,
    occurred_at timestamp with time zone not null
);

create index idx_audit_event_aggregate
    on audit_event (aggregate_type, aggregate_id, occurred_at);

create index idx_campaign_project_status
    on remediation_campaign (project_id, status);

