package com.organization.security.remediation.controlplane.api;

import com.organization.security.remediation.controlplane.RemediationControlPlaneApplication;
import com.organization.security.remediation.domain.duo.DuoCapabilities;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = {RemediationControlPlaneApplication.class, CampaignApiIntegrationTest.AuthorizedDuoTestConfiguration.class})
@AutoConfigureMockMvc
@ActiveProfiles("test")
class CampaignApiIntegrationTest {
    private static final String DUO_SESSION_ID = "test-duo-oauth-session";
    private static final String REQUEST = """
            {
              "projectId": "4812",
              "projectPath": "security/example-spring-app",
              "targetBranch": "main",
              "expectedHeadSha": "0123456789abcdef0123456789abcdef01234567",
              "requestedBy": "local-developer",
              "vulnerabilityIds": ["gid://gitlab/Vulnerability/101"],
              "policyProfile": "spring-production-strict"
            }
            """;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void createsAndRetrievesCampaignWithCorrelationId() throws Exception {
        String response = mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "integration-test-campaign")
                        .header("X-Duo-Session-Id", DUO_SESSION_ID)
                        .header("X-Correlation-ID", "test-correlation")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(REQUEST))
                .andExpect(status().isAccepted())
                .andExpect(header().string("X-Correlation-ID", "test-correlation"))
                .andExpect(jsonPath("$.status", is("RECEIVED")))
                .andReturn()
                .getResponse()
                .getContentAsString();

        String campaignId = new com.fasterxml.jackson.databind.ObjectMapper()
                .readTree(response)
                .get("campaignId")
                .asText();

        mockMvc.perform(get("/api/v1/remediation-campaigns/{campaignId}", campaignId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.campaignId", is(campaignId)))
                .andExpect(jsonPath("$.projectId", is("4812")));
    }

    @Test
    void idempotencyKeyReturnsSameCampaign() throws Exception {
        String first = mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "same-campaign")
                        .header("X-Duo-Session-Id", DUO_SESSION_ID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(REQUEST))
                .andExpect(status().isAccepted())
                .andReturn().getResponse().getContentAsString();

        String second = mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "same-campaign")
                        .header("X-Duo-Session-Id", DUO_SESSION_ID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(REQUEST))
                .andExpect(status().isAccepted())
                .andReturn().getResponse().getContentAsString();

        var mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        assertEquals(
                mapper.readTree(first).get("campaignId").asText(),
                mapper.readTree(second).get("campaignId").asText()
        );
    }

    @Test
    void rejectsIdempotencyKeyReusedForDifferentRequest() throws Exception {
        mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "conflicting-campaign")
                        .header("X-Duo-Session-Id", DUO_SESSION_ID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(REQUEST))
                .andExpect(status().isAccepted());

        String differentRequest = REQUEST.replace(
                "security/example-spring-app",
                "security/different-spring-app"
        );

        mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "conflicting-campaign")
                        .header("X-Duo-Session-Id", DUO_SESSION_ID)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(differentRequest))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title", is("Invalid request")));
    }

    @Test
    void rejectsCampaignWithoutGitLabDuoOAuthSession() throws Exception {
        mockMvc.perform(post("/api/v1/remediation-campaigns")
                        .header("Idempotency-Key", "missing-duo-oauth")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(REQUEST))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.title", is("GitLab Duo authorization required")));
    }

    @TestConfiguration(proxyBeanMethods = false)
    static class AuthorizedDuoTestConfiguration {
        @Bean
        @Primary
        GitLabDuoGateway authorizedDuoGateway() {
            return new GitLabDuoGateway() {
                @Override
                public DuoCapabilities capabilities(String sessionId) {
                    return new DuoCapabilities(true, DUO_SESSION_ID.equals(sessionId), "TEST_OAUTH", "Test OAuth grant");
                }

                @Override
                public void requireAuthorization(String sessionId) {
                    if (!DUO_SESSION_ID.equals(sessionId)) {
                        throw new com.organization.security.remediation.domain.duo.DuoAuthorizationRequiredException(
                                "Test GitLab Duo OAuth session is required"
                        );
                    }
                }
            };
        }
    }
}
