package com.organization.security.remediation.controlplane.integration.duo.oauth;

import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PendingOAuthAuthorizationStoreTest {
    private final GitLabDuoOAuthProperties properties = properties();
    private final PendingOAuthAuthorizationStore store = new PendingOAuthAuthorizationStore(
            properties,
            Clock.fixed(Instant.parse("2026-09-12T12:00:00Z"), ZoneOffset.UTC)
    );

    @Test
    void bindsStateToSessionAndConsumesItOnce() {
        var pending = store.create("https://console.example.com/api/gitlab-duo/oauth/callback");

        assertThrows(IllegalArgumentException.class, () -> store.consume(pending.state(), "another-session"));
        assertEquals(pending, store.consume(pending.state(), pending.sessionId()));
        assertThrows(IllegalArgumentException.class, () -> store.consume(pending.state(), pending.sessionId()));
    }

    @Test
    void createsPkceS256MaterialWithoutReusingSecrets() {
        var first = store.create("https://console.example.com/api/gitlab-duo/oauth/callback");
        var second = store.create("https://console.example.com/api/gitlab-duo/oauth/callback");

        assertNotEquals(first.state(), second.state());
        assertNotEquals(first.sessionId(), second.sessionId());
        assertNotEquals(first.verifier(), second.verifier());
        assertNotEquals(first.verifier(), first.challenge());
    }

    private static GitLabDuoOAuthProperties properties() {
        GitLabDuoOAuthProperties properties = new GitLabDuoOAuthProperties();
        properties.setStateTtl(Duration.ofMinutes(10));
        return properties;
    }
}
