package com.organization.security.remediation.domain.audit;

import java.time.OffsetDateTime;
import java.util.Objects;
import java.util.UUID;

public record AuditEvent(
        UUID id,
        String aggregateType,
        String aggregateId,
        String eventType,
        String actor,
        String correlationId,
        String details,
        OffsetDateTime occurredAt
) {
    public AuditEvent {
        Objects.requireNonNull(id, "id is required");
        Objects.requireNonNull(occurredAt, "occurredAt is required");
        aggregateType = requireText(aggregateType, "aggregateType");
        aggregateId = requireText(aggregateId, "aggregateId");
        eventType = requireText(eventType, "eventType");
        actor = requireText(actor, "actor");
        correlationId = requireText(correlationId, "correlationId");
        details = details == null ? "" : details;
    }

    private static String requireText(String value, String name) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(name + " is required");
        }
        return value.trim();
    }
}

