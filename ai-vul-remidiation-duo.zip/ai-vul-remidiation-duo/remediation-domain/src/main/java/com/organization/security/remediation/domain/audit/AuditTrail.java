package com.organization.security.remediation.domain.audit;

public interface AuditTrail {
    void append(AuditEvent event);
}

