package com.organization.security.remediation.domain.campaign;

public enum CampaignStatus {
    RECEIVED,
    SNAPSHOTTING,
    PLANNING,
    EXECUTING,
    WAITING_FOR_MRS,
    COMPLETED,
    REJECTED,
    FAILED,
    CANCELLED
}

