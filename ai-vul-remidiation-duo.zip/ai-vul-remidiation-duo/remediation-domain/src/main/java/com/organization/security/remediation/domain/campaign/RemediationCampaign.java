package com.organization.security.remediation.domain.campaign;

import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

public final class RemediationCampaign {
    private final UUID id;
    private final String idempotencyKey;
    private final String projectId;
    private final String projectPath;
    private final String targetBranch;
    private final String targetSha;
    private final String requestedBy;
    private final String policyProfile;
    private final Set<String> vulnerabilityIds;
    private final CampaignStatus status;
    private final OffsetDateTime createdAt;
    private final OffsetDateTime updatedAt;

    private RemediationCampaign(
            UUID id,
            String idempotencyKey,
            String projectId,
            String projectPath,
            String targetBranch,
            String targetSha,
            String requestedBy,
            String policyProfile,
            Set<String> vulnerabilityIds,
            CampaignStatus status,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
        this.id = Objects.requireNonNull(id, "id is required");
        this.idempotencyKey = requireText(idempotencyKey, "idempotencyKey");
        this.projectId = requireText(projectId, "projectId");
        this.projectPath = requireText(projectPath, "projectPath");
        this.targetBranch = requireText(targetBranch, "targetBranch");
        this.targetSha = requireText(targetSha, "targetSha");
        this.requestedBy = requireText(requestedBy, "requestedBy");
        this.policyProfile = requireText(policyProfile, "policyProfile");
        this.vulnerabilityIds = immutableNonEmpty(vulnerabilityIds);
        this.status = Objects.requireNonNull(status, "status is required");
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt is required");
        this.updatedAt = Objects.requireNonNull(updatedAt, "updatedAt is required");
    }

    public static RemediationCampaign create(
            UUID id,
            String idempotencyKey,
            String projectId,
            String projectPath,
            String targetBranch,
            String targetSha,
            String requestedBy,
            String policyProfile,
            Set<String> vulnerabilityIds,
            OffsetDateTime now
    ) {
        return new RemediationCampaign(
                id,
                idempotencyKey,
                projectId,
                projectPath,
                targetBranch,
                targetSha,
                requestedBy,
                policyProfile,
                vulnerabilityIds,
                CampaignStatus.RECEIVED,
                now,
                now
        );
    }

    public static RemediationCampaign rehydrate(
            UUID id,
            String idempotencyKey,
            String projectId,
            String projectPath,
            String targetBranch,
            String targetSha,
            String requestedBy,
            String policyProfile,
            Set<String> vulnerabilityIds,
            CampaignStatus status,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
        return new RemediationCampaign(
                id,
                idempotencyKey,
                projectId,
                projectPath,
                targetBranch,
                targetSha,
                requestedBy,
                policyProfile,
                vulnerabilityIds,
                status,
                createdAt,
                updatedAt
        );
    }

    private static String requireText(String value, String name) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(name + " is required");
        }
        return value.trim();
    }

    private static Set<String> immutableNonEmpty(Set<String> values) {
        if (values == null || values.isEmpty()) {
            throw new IllegalArgumentException("At least one vulnerability ID is required");
        }
        LinkedHashSet<String> normalized = new LinkedHashSet<>();
        for (String value : values) {
            normalized.add(requireText(value, "vulnerabilityId"));
        }
        return Set.copyOf(normalized);
    }

    public UUID id() {
        return id;
    }

    public String idempotencyKey() {
        return idempotencyKey;
    }

    public String projectId() {
        return projectId;
    }

    public String projectPath() {
        return projectPath;
    }

    public String targetBranch() {
        return targetBranch;
    }

    public String targetSha() {
        return targetSha;
    }

    public String requestedBy() {
        return requestedBy;
    }

    public String policyProfile() {
        return policyProfile;
    }

    public Set<String> vulnerabilityIds() {
        return vulnerabilityIds;
    }

    public CampaignStatus status() {
        return status;
    }

    public OffsetDateTime createdAt() {
        return createdAt;
    }

    public OffsetDateTime updatedAt() {
        return updatedAt;
    }
}

