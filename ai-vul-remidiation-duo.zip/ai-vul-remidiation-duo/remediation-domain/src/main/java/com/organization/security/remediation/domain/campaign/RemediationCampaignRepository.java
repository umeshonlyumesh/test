package com.organization.security.remediation.domain.campaign;

import java.util.Optional;
import java.util.UUID;

public interface RemediationCampaignRepository {
    RemediationCampaign save(RemediationCampaign campaign);

    Optional<RemediationCampaign> findById(UUID id);

    Optional<RemediationCampaign> findByIdempotencyKey(String idempotencyKey);
}

