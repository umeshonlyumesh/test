package com.organization.security.remediation.domain.duo;

public class DuoAuthorizationRequiredException extends RuntimeException {
    public DuoAuthorizationRequiredException(String message) {
        super(message);
    }
}
