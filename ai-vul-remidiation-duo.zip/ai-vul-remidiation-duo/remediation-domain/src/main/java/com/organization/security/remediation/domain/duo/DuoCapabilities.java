package com.organization.security.remediation.domain.duo;

public record DuoCapabilities(
        boolean configured,
        boolean authorized,
        String mode,
        String detail
) {
}
