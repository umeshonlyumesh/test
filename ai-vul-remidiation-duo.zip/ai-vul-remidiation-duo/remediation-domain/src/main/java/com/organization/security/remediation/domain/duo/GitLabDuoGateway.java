package com.organization.security.remediation.domain.duo;

public interface GitLabDuoGateway {
    DuoCapabilities capabilities(String sessionId);

    void requireAuthorization(String sessionId);
}
