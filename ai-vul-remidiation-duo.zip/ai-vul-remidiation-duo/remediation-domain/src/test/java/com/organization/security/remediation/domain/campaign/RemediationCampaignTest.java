package com.organization.security.remediation.domain.campaign;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RemediationCampaignTest {
    @Test
    void createsReceivedCampaignWithImmutableFindingSet() {
        OffsetDateTime now = OffsetDateTime.parse("2026-09-12T12:00:00Z");

        RemediationCampaign campaign = RemediationCampaign.create(
                UUID.randomUUID(),
                "idempotency-key",
                "42",
                "security/example",
                "main",
                "0123456789abcdef0123456789abcdef01234567",
                "developer",
                "spring-production-strict",
                Set.of("vulnerability-1"),
                now
        );

        assertEquals(CampaignStatus.RECEIVED, campaign.status());
        assertEquals(now, campaign.createdAt());
        assertEquals(Set.of("vulnerability-1"), campaign.vulnerabilityIds());
    }

    @Test
    void rejectsEmptyVulnerabilitySelection() {
        assertThrows(IllegalArgumentException.class, () -> RemediationCampaign.create(
                UUID.randomUUID(),
                "idempotency-key",
                "42",
                "security/example",
                "main",
                "0123456789abcdef0123456789abcdef01234567",
                "developer",
                "spring-production-strict",
                Set.of(),
                OffsetDateTime.now()
        ));
    }
}

