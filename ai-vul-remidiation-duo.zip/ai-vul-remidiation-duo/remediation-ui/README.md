# Duo Remediation UI

Operations console for the Spring Boot vulnerability remediation backend. The UI uses realistic in-memory demo findings by default and can submit remediation campaigns to the backend.

## Run locally

Requirements: Node.js 22.13 or newer.

```powershell
npm install
npm run dev
```

Open `http://localhost:5173`.

## Connect the backend

Copy `.env.example` to `.env.local`, keep the backend on port `8080`, and restart the UI. The UI server owns the browser-facing OAuth callback and stores only an opaque GitLab Duo session identifier in a secure, HTTP-only cookie. Access and refresh tokens remain in the Spring backend.

Select **Connect GitLab Duo** to start GitLab's authorization-code flow with PKCE. The OAuth application's allowlisted callback must be `http://localhost:5173/api/gitlab-duo/oauth/callback` for local testing.

When the variable is absent, the UI uses a short local simulation so the complete interaction can be tested without Maven, Artifactory, or GitLab credentials.

## Safety behavior

- Container base-image/package findings are visible but cannot be selected for automatic remediation.
- Backend-connected campaign creation requires a current GitLab Duo OAuth grant and never merges code automatically.
- The review dialog explains the build, test, rescan, and Draft MR stages before submission.
- Page-scoped WebMCP tools expose reading, staging, and campaign creation to compatible AI assistants with the same guardrails.
