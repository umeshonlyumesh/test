import { NextResponse } from "next/server";
import { DUO_SESSION_COOKIE, readCookie, remediationBackendUrl } from "@/lib/duo-oauth-server";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const backendUrl = remediationBackendUrl();
  const sessionId = readCookie(request, DUO_SESSION_COOKIE);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const providerError = url.searchParams.get("error");
  if (!backendUrl || !sessionId || !code || !state || providerError) {
    return NextResponse.redirect(new URL("/?duo=error", request.url));
  }

  try {
    const response = await fetch(`${backendUrl}/api/v1/integrations/gitlab-duo/oauth/callbacks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code, state, sessionId }),
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`OAuth callback returned ${response.status}`);
    const redirect = NextResponse.redirect(new URL("/?duo=connected", request.url));
    redirect.cookies.set(DUO_SESSION_COOKIE, sessionId, {
      httpOnly: true,
      secure: url.protocol === "https:",
      sameSite: "lax",
      path: "/",
      maxAge: 2 * 60 * 60,
    });
    return redirect;
  } catch (error) {
    console.error("[duo-oauth] Authorization callback failed", error);
    return NextResponse.redirect(new URL("/?duo=error", request.url));
  }
}
