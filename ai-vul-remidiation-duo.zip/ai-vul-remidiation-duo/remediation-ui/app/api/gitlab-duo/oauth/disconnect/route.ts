import { NextResponse } from "next/server";
import { DUO_SESSION_COOKIE, readCookie, remediationBackendUrl } from "@/lib/duo-oauth-server";

export async function POST(request: Request) {
  const backendUrl = remediationBackendUrl();
  const sessionId = readCookie(request, DUO_SESSION_COOKIE);
  if (backendUrl && sessionId) {
    await fetch(`${backendUrl}/api/v1/integrations/gitlab-duo/oauth/session`, {
      method: "DELETE",
      headers: { "X-Duo-Session-Id": sessionId },
      cache: "no-store",
    }).catch((error) => console.error("[duo-oauth] Disconnect failed", error));
  }
  const response = NextResponse.json({ authorized: false });
  response.cookies.set(DUO_SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return response;
}
