import { NextResponse } from "next/server";
import { DUO_SESSION_COOKIE, readCookie, remediationBackendUrl } from "@/lib/duo-oauth-server";

export async function GET(request: Request) {
  const backendUrl = remediationBackendUrl();
  if (!backendUrl) {
    return NextResponse.json({ configured: false, authorized: false, mode: "PREVIEW_ONLY", detail: "Backend is not configured" });
  }
  const sessionId = readCookie(request, DUO_SESSION_COOKIE);
  try {
    const response = await fetch(`${backendUrl}/api/v1/integrations/gitlab-duo/oauth/status`, {
      headers: sessionId ? { "X-Duo-Session-Id": sessionId } : {},
      cache: "no-store",
    });
    if (response.status === 404) {
      return NextResponse.json({ configured: false, authorized: false, mode: "UNCONFIGURED", detail: "GitLab Duo OAuth is disabled in the backend" });
    }
    if (!response.ok) throw new Error(`OAuth status returned ${response.status}`);
    return new Response(await response.text(), {
      status: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("[duo-oauth] Status check failed", error);
    return NextResponse.json({ configured: true, authorized: false, mode: "OAUTH_ERROR", detail: "OAuth status is unavailable" }, { status: 503 });
  }
}
