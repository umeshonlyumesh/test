import { NextResponse } from "next/server";
import { DUO_SESSION_COOKIE, readCookie } from "@/lib/duo-oauth-server";

export async function POST(request: Request) {
  const body = await request.text();
  const backendUrl = process.env.REMEDIATION_API_URL?.replace(/\/$/, "");

  if (!backendUrl) {
    await new Promise((resolve) => setTimeout(resolve, 650));
    return NextResponse.json({ campaignId: "A7F2-91C4", status: "PLANNING", mode: "demo" });
  }

  const sessionId = readCookie(request, DUO_SESSION_COOKIE);
  if (!sessionId) {
    return NextResponse.json({ message: "GitLab Duo OAuth authorization is required" }, { status: 401 });
  }

  try {
    const response = await fetch(`${backendUrl}/api/v1/remediation-campaigns`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Idempotency-Key": request.headers.get("Idempotency-Key") ?? crypto.randomUUID(),
        "X-Duo-Session-Id": sessionId,
      },
      body,
      cache: "no-store",
    });
    return new Response(await response.text(), {
      status: response.status,
      headers: { "Content-Type": response.headers.get("Content-Type") ?? "application/json" },
    });
  } catch (error) {
    console.error("[campaign-proxy] Backend request failed", error);
    return NextResponse.json({ message: "The remediation backend is unavailable" }, { status: 502 });
  }
}
