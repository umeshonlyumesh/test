import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Duo Remediation · Spring Security Operations",
  description: "Evidence-driven GitLab Duo remediation console for Maven Spring Boot applications.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
