import { RemediationConsole } from "@/components/remediation-console";

export default function Home() {
  return <RemediationConsole />;
}
