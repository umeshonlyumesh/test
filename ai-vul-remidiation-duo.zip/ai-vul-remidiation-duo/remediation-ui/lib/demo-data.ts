export type Severity = "Critical" | "High" | "Medium" | "Low";
export type FindingType = "Dependency" | "SAST" | "Container";
export type DuoReadiness = "Ready" | "Review" | "Unsupported";

export type Vulnerability = {
  id: string;
  shortId: string;
  title: string;
  identifier: string;
  severity: Severity;
  type: FindingType;
  location: string;
  version?: string;
  fixedVersion?: string;
  scanner: string;
  detected: string;
  readiness: DuoReadiness;
  description: string;
  strategy: string;
  evidence: string[];
  files: string[];
};

export const vulnerabilities: Vulnerability[] = [
  {
    id: "gid://gitlab/Vulnerability/101", shortId: "VULN-101",
    title: "Improper neutralization in Spring Web", identifier: "CVE-2026-21418",
    severity: "Critical", type: "Dependency", location: "pom.xml · payments-api",
    version: "6.2.8", fixedVersion: "6.2.11", scanner: "GitLab Dependency Scanning",
    detected: "18 min ago", readiness: "Ready",
    description: "The resolved Spring Web version is managed transitively through the Spring Boot dependency BOM. Organization Artifactory contains an approved fixed release.",
    strategy: "Upgrade the owning Spring Boot patch line, then verify the effective POM and complete dependency graph.",
    evidence: ["Version owner identified", "Fixed artifact available internally", "No major framework migration"],
    files: ["pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/102", shortId: "VULN-102",
    title: "Authorization bypass in invoice endpoint", identifier: "CWE-862",
    severity: "Critical", type: "SAST", location: "InvoiceController.java:84",
    scanner: "GitLab SAST", detected: "24 min ago", readiness: "Ready",
    description: "The invoice download endpoint accepts an invoice identifier without confirming that the authenticated principal owns the underlying account.",
    strategy: "Trace controller-to-service ownership checks, enforce authorization at the service boundary, and generate negative and positive MockMvc tests.",
    evidence: ["Source location verified", "Authentication context available", "Existing MockMvc test harness"],
    files: ["src/main/java/com/acme/payments/InvoiceService.java", "src/test/java/com/acme/payments/InvoiceSecurityTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/103", shortId: "VULN-103",
    title: "SQL injection in transaction search", identifier: "CWE-89",
    severity: "High", type: "SAST", location: "TransactionRepository.java:117",
    scanner: "GitLab SAST", detected: "41 min ago", readiness: "Ready",
    description: "A request parameter is concatenated into a native query used by the transaction search endpoint.",
    strategy: "Replace string concatenation with a parameterized query and prove the behavior with a regression test that fails on the original revision.",
    evidence: ["Supported CWE recipe", "Repository test fixture found", "Affected execution path isolated"],
    files: ["src/main/java/com/acme/payments/TransactionRepository.java", "src/test/java/com/acme/payments/TransactionRepositoryTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/104", shortId: "VULN-104",
    title: "Vulnerable Jackson Databind release", identifier: "CVE-2026-11204",
    severity: "High", type: "Dependency", location: "pom.xml · payment-events",
    version: "2.18.3", fixedVersion: "2.18.5", scanner: "GitLab Dependency Scanning",
    detected: "1 hr ago", readiness: "Ready",
    description: "Jackson Databind is controlled by the Spring Boot BOM and reaches payment-events through the JSON starter.",
    strategy: "Select the smallest approved Boot-managed upgrade available in Artifactory and compare serialization tests before and after.",
    evidence: ["Dependency path resolved", "Fixed artifact available internally", "Serialization tests discovered"],
    files: ["pom.xml", "payment-events/pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/105", shortId: "VULN-105",
    title: "Path traversal in statement download", identifier: "CWE-22",
    severity: "Medium", type: "SAST", location: "StatementController.java:63",
    scanner: "GitLab SAST", detected: "2 hr ago", readiness: "Review",
    description: "A user-controlled filename is resolved against the statement export directory without a canonical path boundary check.",
    strategy: "Normalize and constrain the resolved path, then test encoded and nested traversal attempts. Security review remains mandatory.",
    evidence: ["Source location verified", "Filesystem boundary inferred", "Security reviewer required"],
    files: ["src/main/java/com/acme/payments/StatementController.java", "src/test/java/com/acme/payments/StatementSecurityTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/106", shortId: "VULN-106",
    title: "Netty HTTP/2 denial of service", identifier: "CVE-2026-07731",
    severity: "Medium", type: "Dependency", location: "pom.xml · notification-client",
    version: "4.1.116.Final", fixedVersion: "4.1.119.Final", scanner: "GitLab Dependency Scanning",
    detected: "3 hr ago", readiness: "Ready",
    description: "The reactive notification client brings Netty transitively through Spring WebFlux.",
    strategy: "Update the existing Netty BOM property after confirming Spring compatibility and run the reactive integration suite.",
    evidence: ["Transitive path resolved", "Approved internal artifact", "WebFlux integration tests found"],
    files: ["notification-client/pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/107", shortId: "VULN-107",
    title: "OpenSSL package vulnerability", identifier: "CVE-2026-30112",
    severity: "High", type: "Container", location: "registry / payments-service",
    version: "3.2.1-r0", scanner: "GitLab Container Scanning", detected: "4 hr ago",
    readiness: "Unsupported",
    description: "The finding originates from the runtime image. Container remediation is intentionally outside this product's automated scope.",
    strategy: "Route to the platform image owner. This console will not change Dockerfiles, base images, or operating-system packages.",
    evidence: ["Container finding", "Manual platform action required"], files: [],
  },
];

export const severityOrder: Record<Severity, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };
