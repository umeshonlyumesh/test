package com.organization.security.remediation.worker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.UUID;

@SpringBootApplication
public class RemediationWorkerApplication {
    private static final Logger log = LoggerFactory.getLogger(RemediationWorkerApplication.class);

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(RemediationWorkerApplication.class);
        application.setWebApplicationType(WebApplicationType.NONE);
        application.run(args);
    }

    @Bean
    ApplicationRunner workerRunner() {
        return this::runWorker;
    }

    private void runWorker(ApplicationArguments arguments) {
        String jobId = value(arguments, "job-id", UUID.randomUUID().toString());
        String campaignId = value(arguments, "campaign-id", "not-supplied");
        String correlationId = value(arguments, "correlation-id", UUID.randomUUID().toString());

        try (MDC.MDCCloseable ignoredCorrelation = MDC.putCloseable("correlationId", correlationId);
             MDC.MDCCloseable ignoredCampaign = MDC.putCloseable("campaignId", campaignId)) {
            log.atInfo()
                    .addKeyValue("event", "worker_started")
                    .addKeyValue("jobId", jobId)
                    .log("Remediation worker started");
            log.atWarn()
                    .addKeyValue("event", "worker_no_task_handler")
                    .addKeyValue("jobId", jobId)
                    .log("Worker scaffold has no remediation task handler yet");
            log.atInfo()
                    .addKeyValue("event", "worker_completed")
                    .addKeyValue("jobId", jobId)
                    .log("Remediation worker completed");
        }
    }

    private static String value(ApplicationArguments arguments, String name, String fallback) {
        if (!arguments.containsOption(name) || arguments.getOptionValues(name) == null
                || arguments.getOptionValues(name).isEmpty()) {
            return fallback;
        }
        return arguments.getOptionValues(name).getFirst();
    }
}

