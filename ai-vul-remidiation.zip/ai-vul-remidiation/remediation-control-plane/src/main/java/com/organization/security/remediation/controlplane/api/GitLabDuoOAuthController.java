package com.organization.security.remediation.controlplane.api;

import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthAuthorizationRequest;
import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthAuthorizationResponse;
import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthCallbackRequest;
import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthStatusResponse;
import com.organization.security.remediation.controlplane.integration.duo.oauth.GitLabDuoOAuthService;
import jakarta.validation.Valid;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/integrations/gitlab-duo/oauth")
@ConditionalOnProperty(prefix = "remediation.duo", name = "mode", havingValue = "oauth")
public class GitLabDuoOAuthController {
    private final GitLabDuoOAuthService oauthService;

    public GitLabDuoOAuthController(GitLabDuoOAuthService oauthService) {
        this.oauthService = oauthService;
    }

    @PostMapping("/authorizations")
    public GitLabDuoOAuthAuthorizationResponse authorize(
            @Valid @RequestBody GitLabDuoOAuthAuthorizationRequest request
    ) {
        return oauthService.beginAuthorization(request.redirectUri(), request.rootNamespaceId());
    }

    @PostMapping("/callbacks")
    public GitLabDuoOAuthStatusResponse callback(
            @Valid @RequestBody GitLabDuoOAuthCallbackRequest request
    ) {
        return oauthService.completeAuthorization(request.code(), request.state(), request.sessionId());
    }

    @GetMapping("/status")
    public GitLabDuoOAuthStatusResponse status(
            @RequestHeader(name = "X-Duo-Session-Id", required = false) String sessionId
    ) {
        return oauthService.status(sessionId);
    }

    @DeleteMapping("/session")
    public ResponseEntity<Void> disconnect(
            @RequestHeader(name = "X-Duo-Session-Id") String sessionId
    ) {
        oauthService.disconnect(sessionId);
        return ResponseEntity.noContent().build();
    }
}
