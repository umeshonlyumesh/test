package com.organization.security.remediation.controlplane.integration.duo;

import com.organization.security.remediation.domain.duo.DuoCapabilities;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Local-only deterministic Duo adapter. It authorizes every request without a token and must never
 * be enabled in a shared or production environment.
 */
@Component
@ConditionalOnProperty(prefix = "remediation.duo", name = "mode", havingValue = "mock", matchIfMissing = true)
public class MockGitLabDuoGateway implements GitLabDuoGateway {
    private static final Logger log = LoggerFactory.getLogger(MockGitLabDuoGateway.class);

    public MockGitLabDuoGateway() {
        log.atWarn()
                .addKeyValue("event", "gitlab_duo_mock_enabled")
                .addKeyValue("duoMode", "mock")
                .log("GitLab Duo MOCK mode is active; no real Duo or OAuth calls will be made");
    }

    @Override
    public DuoCapabilities capabilities(String sessionId) {
        return new DuoCapabilities(
                true,
                true,
                "MOCK",
                "Deterministic local Duo mock is active"
        );
    }

    @Override
    public void requireAuthorization(String sessionId) {
        // Intentionally authorized in mock mode. No OAuth session is required.
    }
}
