package com.organization.security.remediation.controlplane.integration.duo.oauth;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(prefix = "remediation.duo", name = "mode", havingValue = "oauth")
@EnableConfigurationProperties(GitLabDuoOAuthProperties.class)
class GitLabDuoOAuthConfiguration {
}
