package com.organization.security.remediation.controlplane.integration.duo.oauth;

import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthAuthorizationResponse;
import com.organization.security.remediation.contracts.duo.GitLabDuoOAuthStatusResponse;
import com.organization.security.remediation.domain.duo.DuoAuthorizationRequiredException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
@ConditionalOnProperty(prefix = "remediation.duo", name = "mode", havingValue = "oauth")
public class GitLabDuoOAuthService {
    private static final Logger log = LoggerFactory.getLogger(GitLabDuoOAuthService.class);

    private final GitLabDuoOAuthProperties properties;
    private final PendingOAuthAuthorizationStore pendingStore;
    private final InMemoryGitLabDuoGrantStore grantStore;
    private final GitLabOAuthClient oauthClient;
    private final Clock clock;

    GitLabDuoOAuthService(
            GitLabDuoOAuthProperties properties,
            PendingOAuthAuthorizationStore pendingStore,
            InMemoryGitLabDuoGrantStore grantStore,
            GitLabOAuthClient oauthClient,
            Clock clock
    ) {
        this.properties = properties;
        this.pendingStore = pendingStore;
        this.grantStore = grantStore;
        this.oauthClient = oauthClient;
        this.clock = clock;
        validateConfiguration();
    }

    public GitLabDuoOAuthAuthorizationResponse beginAuthorization(String redirectUri, String rootNamespaceId) {
        String authorizedRedirectUri = validateRedirectUri(redirectUri);
        PendingOAuthAuthorizationStore.PendingAuthorization pending = pendingStore.create(authorizedRedirectUri);
        UriComponentsBuilder authorizationUrl = UriComponentsBuilder
                .fromUriString(normalizedBaseUrl())
                .path("/oauth/authorize")
                .queryParam("client_id", properties.getClientId())
                .queryParam("redirect_uri", authorizedRedirectUri)
                .queryParam("response_type", "code")
                .queryParam("state", pending.state())
                .queryParam("scope", String.join(" ", properties.getScopes()))
                .queryParam("code_challenge", pending.challenge())
                .queryParam("code_challenge_method", "S256");
        if (rootNamespaceId != null && !rootNamespaceId.isBlank()) {
            authorizationUrl.queryParam("root_namespace_id", rootNamespaceId.trim());
        }
        log.atInfo()
                .addKeyValue("event", "gitlab_duo_oauth_started")
                .addKeyValue("redirectOrigin", URI.create(authorizedRedirectUri).getHost())
                .log("Started GitLab Duo OAuth authorization");
        return new GitLabDuoOAuthAuthorizationResponse(
                authorizationUrl.build().encode().toUriString(),
                pending.sessionId(),
                pending.expiresAt()
        );
    }

    public GitLabDuoOAuthStatusResponse completeAuthorization(String code, String state, String sessionId) {
        PendingOAuthAuthorizationStore.PendingAuthorization pending = pendingStore.consume(state, sessionId);
        GitLabDuoOAuthGrant grant = oauthClient.exchange(code, pending.verifier(), pending.redirectUri());
        assertRequiredScopes(grant.scopes());
        grantStore.save(sessionId, grant);
        log.atInfo()
                .addKeyValue("event", "gitlab_duo_oauth_completed")
                .addKeyValue("gitLabUserId", grant.gitLabUserId())
                .addKeyValue("username", grant.username())
                .log("GitLab Duo OAuth authorization completed");
        return toStatus(grant, "GitLab Duo OAuth authorization is active");
    }

    public GitLabDuoOAuthStatusResponse status(String sessionId) {
        return grantStore.find(sessionId)
                .map(grant -> refreshIfNeeded(sessionId, grant))
                .map(grant -> toStatus(grant, "GitLab Duo OAuth authorization is active"))
                .orElseGet(() -> unauthorizedStatus("Authorize with GitLab before creating remediation campaigns"));
    }

    public void requireAuthorization(String sessionId) {
        if (sessionId == null || sessionId.isBlank()) {
            throw new DuoAuthorizationRequiredException("A GitLab Duo OAuth browser session is required");
        }
        GitLabDuoOAuthGrant grant = grantStore.find(sessionId)
                .map(value -> refreshIfNeeded(sessionId, value))
                .orElseThrow(() -> new DuoAuthorizationRequiredException("GitLab Duo OAuth authorization is missing or expired"));
        assertRequiredScopes(grant.scopes());
    }

    public void disconnect(String sessionId) {
        grantStore.remove(sessionId).ifPresent(oauthClient::revoke);
        log.atInfo()
                .addKeyValue("event", "gitlab_duo_oauth_disconnected")
                .log("GitLab Duo OAuth session disconnected");
    }

    private GitLabDuoOAuthGrant refreshIfNeeded(String sessionId, GitLabDuoOAuthGrant grant) {
        if (grant.expiresAt().isAfter(OffsetDateTime.now(clock).plus(properties.getRefreshSkew()))) {
            return grant;
        }
        try {
            GitLabDuoOAuthGrant refreshed = oauthClient.refresh(grant);
            assertRequiredScopes(refreshed.scopes());
            grantStore.save(sessionId, refreshed);
            log.atInfo()
                    .addKeyValue("event", "gitlab_duo_oauth_refreshed")
                    .addKeyValue("gitLabUserId", refreshed.gitLabUserId())
                    .log("GitLab Duo OAuth token refreshed");
            return refreshed;
        } catch (RuntimeException exception) {
            grantStore.remove(sessionId);
            log.atWarn()
                    .addKeyValue("event", "gitlab_duo_oauth_refresh_failed")
                    .log("GitLab Duo OAuth refresh failed; session removed");
            throw new DuoAuthorizationRequiredException("GitLab Duo OAuth authorization expired; authorize again");
        }
    }

    private GitLabDuoOAuthStatusResponse toStatus(GitLabDuoOAuthGrant grant, String detail) {
        return new GitLabDuoOAuthStatusResponse(
                true,
                true,
                "OAUTH_AUTHORIZATION_CODE_PKCE",
                normalizedBaseUrl(),
                grant.username(),
                grant.displayName(),
                grant.expiresAt(),
                grant.scopes(),
                detail
        );
    }

    private GitLabDuoOAuthStatusResponse unauthorizedStatus(String detail) {
        return new GitLabDuoOAuthStatusResponse(
                true,
                false,
                "OAUTH_AUTHORIZATION_CODE_PKCE",
                normalizedBaseUrl(),
                null,
                null,
                null,
                Set.of(),
                detail
        );
    }

    private void assertRequiredScopes(Set<String> grantedScopes) {
        Set<String> required = new LinkedHashSet<>(properties.getScopes());
        if (!grantedScopes.containsAll(required)) {
            throw new DuoAuthorizationRequiredException("GitLab OAuth grant does not contain every required scope");
        }
    }

    private String validateRedirectUri(String redirectUri) {
        if (redirectUri == null || !properties.getRedirectUris().contains(redirectUri)) {
            throw new IllegalArgumentException("OAuth redirect URI is not allowlisted");
        }
        URI uri = URI.create(redirectUri);
        boolean localHttp = "http".equalsIgnoreCase(uri.getScheme())
                && ("localhost".equalsIgnoreCase(uri.getHost()) || "127.0.0.1".equals(uri.getHost()));
        if (!"https".equalsIgnoreCase(uri.getScheme()) && !localHttp) {
            throw new IllegalArgumentException("OAuth redirect URI must use HTTPS except on localhost");
        }
        return uri.toString();
    }

    private void validateConfiguration() {
        URI baseUri = URI.create(normalizedBaseUrl());
        boolean localHttp = "http".equalsIgnoreCase(baseUri.getScheme())
                && ("localhost".equalsIgnoreCase(baseUri.getHost()) || "127.0.0.1".equals(baseUri.getHost()));
        if (!"https".equalsIgnoreCase(baseUri.getScheme()) && !localHttp) {
            throw new IllegalStateException("GitLab OAuth base URL must use HTTPS except on localhost");
        }
        if (!properties.getScopes().contains("ai_features")) {
            throw new IllegalStateException("GitLab Duo OAuth must request the ai_features scope");
        }
    }

    private String normalizedBaseUrl() {
        return properties.getBaseUrl().replaceAll("/+$", "");
    }
}
