package com.organization.security.remediation.controlplane.integration.duo.oauth;

import com.organization.security.remediation.domain.duo.DuoCapabilities;
import com.organization.security.remediation.domain.duo.GitLabDuoGateway;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(prefix = "remediation.duo", name = "mode", havingValue = "oauth")
public class OAuthGitLabDuoGateway implements GitLabDuoGateway {
    private final GitLabDuoOAuthService oauthService;

    public OAuthGitLabDuoGateway(GitLabDuoOAuthService oauthService) {
        this.oauthService = oauthService;
    }

    @Override
    public DuoCapabilities capabilities(String sessionId) {
        var status = oauthService.status(sessionId);
        return new DuoCapabilities(status.configured(), status.authorized(), status.mode(), status.detail());
    }

    @Override
    public void requireAuthorization(String sessionId) {
        oauthService.requireAuthorization(sessionId);
    }
}
