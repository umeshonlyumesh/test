# Duo Remediation UI

Operations console for the Spring Boot vulnerability remediation backend. The UI uses realistic in-memory demo findings by default and can submit remediation campaigns to the backend.

## Repository-first workflow

1. Search GitLab projects by numeric ID, project name, or full namespace path.
2. Choose a repository branch and inspect its report status before seeing findings.
3. A branch is marked clean only when a complete report matches the current head SHA and contains zero findings.
4. Stale, incomplete, and missing reports have distinct blocking states. A green pipeline is never presented as proof that a branch is vulnerability-free.
5. On vulnerable branches, filter findings, select all actionable items, inspect Duo readiness, and review the exact project/branch/SHA boundary before starting remediation.
6. GitLab Duo proposes fixes; Maven resolves through organization Artifactory; build, tests, and a security rescan gate creation of Draft MRs.

## Run locally

Requirements: Node.js 22.13 or newer.

```powershell
npm install
npm run dev
```

Open `http://localhost:5173`.

## Connect the backend

Copy `.env.example` to `.env.local`, keep the backend on port `8080`, and restart the UI. Real OAuth is the default. The UI server owns the browser-facing OAuth callback and stores only an opaque GitLab Duo session identifier in a secure, HTTP-only cookie. Access and refresh tokens remain in the Spring backend.

Select **Connect GitLab Duo** to start GitLab's authorization-code flow with PKCE. The OAuth application's allowlisted callback must be `http://localhost:5173/api/gitlab-duo/oauth/callback` for local testing.

To use the deterministic mock instead, change only `REMEDIATION_DUO_MODE=mock` in the environment used to start both the UI and backend. The interface always labels mock mode and never silently falls back to it.

## Safety behavior

- Container base-image/package findings are visible but cannot be selected for automatic remediation.
- Container image digest, Dockerfile, and operating-system package changes are explicitly routed to manual platform handling.
- Backend-connected campaign creation requires a current GitLab Duo OAuth grant and never merges code automatically.
- The review dialog explains the build, test, rescan, and Draft MR stages before submission.
- Page-scoped WebMCP tools expose project discovery, branch/report inspection, finding staging, and campaign creation to compatible AI assistants with the same guardrails.
