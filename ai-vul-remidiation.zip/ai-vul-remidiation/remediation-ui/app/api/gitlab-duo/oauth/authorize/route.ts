import { NextResponse } from "next/server";
import { DUO_SESSION_COOKIE, duoMode, oauthCallbackUri, remediationBackendUrl } from "@/lib/duo-oauth-server";

export async function GET(request: Request) {
  if (duoMode() === "mock") return NextResponse.redirect(new URL("/?duo=mock", request.url));
  const backendUrl = remediationBackendUrl();
  if (!backendUrl) return NextResponse.redirect(new URL("/?duo=error", request.url));

  try {
    const response = await fetch(`${backendUrl}/api/v1/integrations/gitlab-duo/oauth/authorizations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ redirectUri: oauthCallbackUri(request) }),
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`OAuth authorization initialization returned ${response.status}`);
    const authorization = await response.json() as { authorizationUrl: string; sessionId: string };
    const target = new URL(authorization.authorizationUrl);
    if (!['https:', 'http:'].includes(target.protocol)) throw new Error("Unsupported OAuth authorization protocol");
    const redirect = NextResponse.redirect(target);
    redirect.cookies.set(DUO_SESSION_COOKIE, authorization.sessionId, {
      httpOnly: true,
      secure: new URL(request.url).protocol === "https:",
      sameSite: "lax",
      path: "/",
      maxAge: 10 * 60,
    });
    return redirect;
  } catch (error) {
    console.error("[duo-oauth] Unable to start authorization", error);
    return NextResponse.redirect(new URL("/?duo=error", request.url));
  }
}
