"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Activity, AlertTriangle, ArrowRight, Bot, Check, CheckCircle2, ChevronDown,
  ChevronRight, Circle, CircleDot, Clock3, ExternalLink, FileCode2, Filter,
  GitBranch, GitCommitHorizontal, GitPullRequest, KeyRound, LayoutDashboard,
  LockKeyhole, LogIn, Menu, Package, RefreshCw, Search, Settings, ShieldAlert,
  ShieldCheck, Sparkles, TestTube2, XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  projects, severityOrder, vulnerabilityById, type DuoReadiness, type GitLabProject,
  type RepositoryBranch, type ReportState, type Severity, type Vulnerability,
} from "@/lib/demo-data";

type WebMcpTool = {
  name: string; title: string; description: string; inputSchema: Record<string, unknown>;
  annotations: { readOnlyHint: boolean; untrustedContentHint: boolean };
  execute: (input: unknown) => unknown | Promise<unknown>;
};

type DuoOAuthStatus = {
  configured: boolean; authorized: boolean; mode: string; username?: string | null;
  displayName?: string | null; expiresAt?: string | null; detail?: string;
};

declare global {
  interface Document {
    readonly modelContext?: { registerTool: (tool: WebMcpTool, options?: { signal?: AbortSignal }) => void | Promise<void> };
  }
}

const stateMeta: Record<ReportState, { label: string; short: string; tone: string }> = {
  VULNERABLE: { label: "Action required", short: "findings", tone: "text-rose-700 bg-rose-50 border-rose-200 dark:text-rose-300 dark:bg-rose-950/40 dark:border-rose-900" },
  CLEAN: { label: "No findings", short: "Clean", tone: "text-emerald-700 bg-emerald-50 border-emerald-200 dark:text-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-900" },
  STALE: { label: "Report stale", short: "Stale", tone: "text-amber-800 bg-amber-50 border-amber-200 dark:text-amber-200 dark:bg-amber-950/40 dark:border-amber-900" },
  INCOMPLETE: { label: "Scan incomplete", short: "Incomplete", tone: "text-orange-800 bg-orange-50 border-orange-200 dark:text-orange-200 dark:bg-orange-950/40 dark:border-orange-900" },
  NO_REPORT: { label: "No report", short: "No report", tone: "text-slate-600 bg-slate-50 border-slate-200 dark:text-slate-300 dark:bg-slate-900 dark:border-slate-700" },
};

function SeverityBadge({ severity }: { severity: Severity }) {
  return <Badge variant="outline" className={cn("rounded-md px-2 py-1 text-[0.72rem] font-semibold",
    severity === "Critical" && "border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950/50 dark:text-rose-300",
    severity === "High" && "border-orange-200 bg-orange-50 text-orange-700 dark:border-orange-900 dark:bg-orange-950/50 dark:text-orange-300",
    severity === "Medium" && "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950/50 dark:text-amber-300",
    severity === "Low" && "border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-900 dark:bg-sky-950/50 dark:text-sky-300")}>{severity}</Badge>;
}

function ReportBadge({ branch, compact = false }: { branch: RepositoryBranch; compact?: boolean }) {
  const meta = stateMeta[branch.state];
  const label = branch.state === "VULNERABLE" ? `${branch.findingIds.length} ${meta.short}` : compact ? meta.short : meta.label;
  return <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold", meta.tone)}>
    <span className="size-1.5 rounded-full bg-current" />{label}
  </span>;
}

function Readiness({ status }: { status: DuoReadiness }) {
  if (status === "Unsupported") return <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground"><Circle className="size-3 fill-current" /> Manual</span>;
  if (status === "Review") return <span className="inline-flex items-center gap-1.5 text-sm text-amber-700 dark:text-amber-300"><AlertTriangle className="size-3.5" /> Review</span>;
  return <span className="inline-flex items-center gap-1.5 text-sm text-emerald-700 dark:text-emerald-300"><Sparkles className="size-3.5" /> Duo ready</span>;
}

function BrandMark() {
  return <div className="relative grid size-9 place-items-center rounded-xl bg-[#7c65ee] text-white shadow-[0_8px_20px_rgba(124,101,238,0.34)]"><ShieldCheck className="size-5" strokeWidth={2.2} /><span className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full border-2 border-[#111c2b] bg-[#54dbb4]" /></div>;
}

function SidebarContent({ duoStatus, onConnect, count }: { duoStatus: DuoOAuthStatus | null; onConnect: () => void; count: number }) {
  const mock = duoStatus?.mode === "MOCK"; const connected = Boolean(duoStatus?.authorized) && !mock;
  const navItems = [
    { label: "Overview", icon: LayoutDashboard },
    { label: "Vulnerabilities", icon: ShieldAlert, active: true, count },
    { label: "Campaigns", icon: Sparkles, count: 1 },
    { label: "Merge requests", icon: GitPullRequest },
    { label: "Evidence", icon: TestTube2 },
  ];
  return <div className="flex h-full flex-col bg-[#111c2b] text-slate-200">
    <div className="flex h-[72px] items-center gap-3 border-b border-white/8 px-5"><BrandMark /><div><p className="text-sm font-semibold text-white">Duo Remediation</p><p className="text-xs text-slate-400">Spring security ops</p></div></div>
    <nav aria-label="Primary navigation" className="flex-1 space-y-1 px-3 py-5">
      <p className="mb-3 px-3 text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-slate-500">Workspace</p>
      {navItems.map((item) => { const Icon = item.icon; return <button key={item.label} type="button" className={cn("flex min-h-10 w-full items-center gap-3 rounded-lg px-3 text-left text-sm transition-colors", item.active ? "bg-white/10 font-medium text-white" : "text-slate-400 hover:bg-white/6 hover:text-white")}><Icon className={cn("size-[18px]", item.active && "text-[#9c8cff]")} /><span className="flex-1">{item.label}</span>{item.count ? <span className="rounded-md bg-white/8 px-1.5 py-0.5 text-xs">{item.count}</span> : null}</button>; })}
    </nav>
    <div className="p-3">
      <div className="mb-3 rounded-xl border border-white/8 bg-white/[0.035] p-3">
        <div className="mb-2 flex items-center justify-between gap-2 text-xs"><span className="font-medium">GitLab Duo</span><span className={cn("flex items-center gap-1", connected ? "text-[#6ee7c2]" : mock ? "text-slate-300" : "text-amber-300")}><span className="size-1.5 rounded-full bg-current" />{connected ? "OAuth active" : mock ? "Mock active" : !duoStatus ? "Checking" : duoStatus.configured ? "Authorization needed" : "Not configured"}</span></div>
        <p className="text-xs leading-5 text-slate-500">{connected ? `Authorized as @${duoStatus?.username}` : mock ? "No real Duo calls are made" : duoStatus?.configured ? "Authorization code + PKCE" : "Enable OAuth in the control plane"}</p>
        {duoStatus?.configured && !connected ? <button type="button" onClick={onConnect} className="mt-3 flex min-h-8 w-full items-center justify-center gap-2 rounded-lg bg-[#7964e8] px-3 text-xs font-semibold text-white hover:bg-[#8874ec]"><LogIn className="size-3.5" /> Connect GitLab</button> : null}
      </div>
      <button type="button" className="flex min-h-10 w-full items-center gap-3 rounded-lg px-3 text-sm text-slate-400 hover:bg-white/6 hover:text-white"><Settings className="size-[18px]" /> Settings</button>
      <div className="mt-3 flex items-center gap-3 border-t border-white/8 px-3 pt-4"><div className="grid size-8 place-items-center rounded-full bg-[#2b3a4d] text-xs font-semibold text-white">UK</div><div className="min-w-0"><p className="truncate text-sm font-medium text-white">Umesh Karan</p><p className="truncate text-xs text-slate-500">Security engineering</p></div></div>
    </div>
  </div>;
}

function DetailPanel({ vulnerability }: { vulnerability: Vulnerability }) {
  const unsupported = vulnerability.readiness === "Unsupported";
  return <Card className="gap-0 overflow-hidden border-[#dfe4ea] py-0 shadow-[0_12px_32px_rgba(22,34,51,0.06)] dark:border-white/10">
    <div className="h-1 bg-gradient-to-r from-[#765ee8] via-[#9b84ff] to-[#5fddbb]" />
    <CardHeader className="gap-4 border-b px-5 py-5"><div className="flex items-start justify-between gap-3"><div className="grid size-10 place-items-center rounded-xl bg-primary/10 text-primary">{vulnerability.type === "Dependency" ? <Package className="size-5" /> : <FileCode2 className="size-5" />}</div><SeverityBadge severity={vulnerability.severity} /></div><div><p className="mb-1 text-xs font-semibold uppercase tracking-[0.1em] text-muted-foreground">{vulnerability.shortId} · {vulnerability.identifier}</p><CardTitle className="text-lg leading-6">{vulnerability.title}</CardTitle><CardDescription className="mt-2 leading-5">{vulnerability.location}</CardDescription></div></CardHeader>
    <CardContent className="space-y-5 px-5 py-5"><section><h3 className="mb-2 text-sm font-semibold">Finding context</h3><p className="text-sm leading-6 text-muted-foreground">{vulnerability.description}</p></section><section className={cn("rounded-xl p-4", unsupported ? "bg-slate-100 dark:bg-slate-900" : "bg-[#f5f3ff] dark:bg-[#1d1935]")}><div className={cn("mb-2 flex items-center gap-2 text-sm font-semibold", unsupported ? "text-slate-600 dark:text-slate-300" : "text-[#5944c3] dark:text-[#b9adff]")}><Bot className="size-4" /> {unsupported ? "Manual handling" : "Duo proposed approach"}</div><p className="text-sm leading-6 text-[#4d4767] dark:text-[#cbc5e6]">{vulnerability.strategy}</p></section><section><h3 className="mb-3 text-sm font-semibold">Readiness evidence</h3><div className="space-y-3">{vulnerability.evidence.map((item, index) => <div key={item} className="flex items-start gap-3"><div className={cn("mt-0.5 grid size-5 place-items-center rounded-full", unsupported ? "bg-muted text-muted-foreground" : "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300")}>{unsupported ? <Circle className="size-2 fill-current" /> : <Check className="size-3" strokeWidth={3} />}</div><div className="flex-1 border-b pb-3 text-sm"><p>{item}</p>{index === 0 && vulnerability.version ? <p className="mt-1 text-xs text-muted-foreground">{vulnerability.version} <ArrowRight className="mx-1 inline size-3" /> {vulnerability.fixedVersion ?? "platform review"}</p> : null}</div></div>)}</div></section>{vulnerability.files.length ? <section><h3 className="mb-2 text-sm font-semibold">Expected scope</h3><div className="space-y-1.5">{vulnerability.files.map((file) => <div key={file} className="flex items-center gap-2 rounded-md bg-muted/60 px-2.5 py-2 font-mono text-xs text-muted-foreground"><FileCode2 className="size-3.5 shrink-0" /><span className="truncate">{file}</span></div>)}</div></section> : null}</CardContent>
  </Card>;
}

function ProjectPicker({ open, onOpenChange, current, onSelect }: { open: boolean; onOpenChange: (open: boolean) => void; current: GitLabProject; onSelect: (project: GitLabProject) => void }) {
  return <CommandDialog open={open} onOpenChange={onOpenChange} title="Find a GitLab project" description="Search accessible Spring Boot projects by ID, name, or full path." className="sm:max-w-[640px]">
    <div className="border-b bg-[#111c2b] px-5 py-4 text-white"><p className="text-sm font-semibold">Choose a GitLab project</p><p className="mt-1 text-xs text-slate-400">Search by project ID, name, or full namespace path</p></div>
    <CommandInput autoFocus placeholder="Try 4812, payments-service, or payments/platform…" className="h-14" />
    <CommandList className="max-h-[420px] p-2"><CommandEmpty><div className="px-6 py-8"><Search className="mx-auto mb-3 size-6 text-muted-foreground" /><p className="font-semibold text-foreground">No accessible project found</p><p className="mt-1 text-muted-foreground">Check the ID or full path and your GitLab OAuth access.</p></div></CommandEmpty><CommandGroup heading="Accessible Spring Boot projects">{projects.map((project) => {
      const defaultBranch = project.branches.find((branch) => branch.name === project.defaultBranch) ?? project.branches[0];
      return <CommandItem key={project.id} value={`${project.id} ${project.name} ${project.pathWithNamespace}`} onSelect={() => { onSelect(project); onOpenChange(false); }} className="min-h-[76px] rounded-xl px-3 py-3"><div className="grid size-10 shrink-0 place-items-center rounded-xl bg-[#eef1f5] text-xs font-bold text-[#324052] dark:bg-white/10 dark:text-slate-200">{project.initials}</div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><p className="truncate font-semibold">{project.name}</p>{project.id === current.id ? <Badge variant="secondary" className="text-[10px]">Current</Badge> : null}</div><p className="mt-0.5 truncate text-xs text-muted-foreground">{project.pathWithNamespace} · ID {project.id}</p><p className="mt-1 text-xs text-muted-foreground">{project.framework} · {project.accessLevel}</p></div><ReportBadge branch={defaultBranch} compact /></CommandItem>;
    })}</CommandGroup></CommandList>
    <div className="flex items-center justify-between border-t bg-muted/30 px-4 py-3 text-xs text-muted-foreground"><span>{projects.length} projects from GitLab OAuth</span><span>↵ select · esc close</span></div>
  </CommandDialog>;
}

function BranchPicker({ open, onOpenChange, project, current, onSelect }: { open: boolean; onOpenChange: (open: boolean) => void; project: GitLabProject; current: RepositoryBranch; onSelect: (branch: RepositoryBranch) => void }) {
  return <CommandDialog open={open} onOpenChange={onOpenChange} title="Choose a branch" description={`Select a security report for ${project.name}.`} className="sm:max-w-[620px]">
    <div className="border-b bg-[#111c2b] px-5 py-4 text-white"><p className="text-sm font-semibold">Choose a branch</p><p className="mt-1 truncate text-xs text-slate-400">{project.pathWithNamespace}</p></div>
    <CommandInput autoFocus placeholder="Search branch name…" className="h-14" />
    <CommandList className="max-h-[420px] p-2"><CommandEmpty>No matching branch.</CommandEmpty><CommandGroup heading={`${project.branches.length} repository branches`}>{project.branches.map((branch) => <CommandItem key={branch.name} value={branch.name} onSelect={() => { onSelect(branch); onOpenChange(false); }} className="min-h-[70px] rounded-xl px-3 py-3"><div className={cn("grid size-9 shrink-0 place-items-center rounded-lg", branch.state === "CLEAN" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950" : branch.state === "VULNERABLE" ? "bg-rose-100 text-rose-700 dark:bg-rose-950" : "bg-amber-100 text-amber-700 dark:bg-amber-950")}><GitBranch className="size-4" /></div><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><p className="truncate font-semibold">{branch.name}</p>{branch.default ? <Badge variant="secondary" className="text-[10px]">Default</Badge> : null}{branch.protected ? <LockKeyhole className="size-3 text-muted-foreground" /> : null}</div><p className="mt-1 font-mono text-xs text-muted-foreground">{branch.headSha.slice(0, 8)} {branch.pipelineId ? `· Pipeline #${branch.pipelineId}` : "· No pipeline report"}</p></div><ReportBadge branch={branch} compact />{branch.name === current.name ? <Check className="size-4 text-primary" /> : null}</CommandItem>)}</CommandGroup></CommandList>
  </CommandDialog>;
}

function ReportProvenance({ branch }: { branch: RepositoryBranch }) {
  return <div className="mb-5 grid gap-px overflow-hidden rounded-xl border bg-border shadow-sm sm:grid-cols-2 xl:grid-cols-4">
    <div className="bg-background px-4 py-3"><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Source</p><p className="mt-1 flex items-center gap-2 text-sm font-medium"><ShieldCheck className="size-4 text-[#6a55d4]" /> Repository security report</p></div>
    <div className="bg-background px-4 py-3"><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Pipeline</p><p className="mt-1 flex items-center gap-2 text-sm font-medium">{branch.pipelineStatus === "passed" ? <CheckCircle2 className="size-4 text-emerald-600" /> : branch.pipelineStatus === "failed" ? <XCircle className="size-4 text-rose-600" /> : <Circle className="size-4 text-slate-400" />}{branch.pipelineId ? `#${branch.pipelineId} · ${branch.pipelineStatus}` : "Not available"}</p></div>
    <div className="bg-background px-4 py-3"><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Branch head</p><p className="mt-1 flex items-center gap-2 font-mono text-sm font-medium"><GitCommitHorizontal className="size-4 text-muted-foreground" />{branch.headSha.slice(0, 12)}</p></div>
    <div className="bg-background px-4 py-3"><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Report generated</p><p className="mt-1 flex items-center gap-2 text-sm font-medium"><Clock3 className="size-4 text-muted-foreground" />{branch.scannedAt ?? "No report"}</p></div>
  </div>;
}

function NonActionableState({ branch, onChangeBranch }: { branch: RepositoryBranch; onChangeBranch: () => void }) {
  const clean = branch.state === "CLEAN";
  return <Card className="overflow-hidden border-[#dfe4ea] py-0 shadow-[0_14px_38px_rgba(22,34,51,0.06)] dark:border-white/10">
    <div className={cn("h-1.5", clean ? "bg-emerald-500" : branch.state === "NO_REPORT" ? "bg-slate-400" : "bg-amber-500")} />
    <div className="grid min-h-[440px] place-items-center px-6 py-12 text-center"><div className="max-w-xl"><div className={cn("mx-auto mb-6 grid size-20 place-items-center rounded-full ring-8", clean ? "bg-emerald-100 text-emerald-700 ring-emerald-50 dark:bg-emerald-950 dark:text-emerald-300 dark:ring-emerald-950/40" : "bg-amber-100 text-amber-700 ring-amber-50 dark:bg-amber-950 dark:text-amber-300 dark:ring-amber-950/40")}>{clean ? <ShieldCheck className="size-9" /> : branch.state === "NO_REPORT" ? <ShieldAlert className="size-9" /> : <AlertTriangle className="size-9" />}</div><ReportBadge branch={branch} /><h2 className="mt-5 text-2xl font-semibold tracking-tight">{clean ? "No vulnerabilities detected" : branch.state === "STALE" ? "The report is behind this branch" : branch.state === "INCOMPLETE" ? "The security scan is incomplete" : "No security report is available"}</h2><p className="mx-auto mt-3 max-w-lg text-sm leading-6 text-muted-foreground">{clean ? "No vulnerabilities were detected by the latest complete scan. This is evidence for the exact commit below—not a permanent security guarantee." : branch.reason}</p>
      <div className="mx-auto mt-7 grid max-w-lg grid-cols-2 gap-3 rounded-xl border bg-muted/25 p-4 text-left sm:grid-cols-3"><div><p className="text-[11px] uppercase tracking-wider text-muted-foreground">Branch</p><p className="mt-1 truncate text-sm font-semibold">{branch.name}</p></div><div><p className="text-[11px] uppercase tracking-wider text-muted-foreground">Commit</p><p className="mt-1 font-mono text-sm font-semibold">{branch.headSha.slice(0, 8)}</p></div><div className="col-span-2 sm:col-span-1"><p className="text-[11px] uppercase tracking-wider text-muted-foreground">Scanners</p><p className="mt-1 text-sm font-semibold">{branch.scanners.length ? `${branch.scanners.length} complete` : "None"}</p></div></div>
      {branch.state === "STALE" ? <div className="mx-auto mt-4 flex max-w-lg items-center justify-center gap-2 rounded-lg bg-amber-50 px-3 py-2 font-mono text-xs text-amber-900 dark:bg-amber-950/40 dark:text-amber-200"><span>report {branch.reportSha?.slice(0, 8)}</span><ArrowRight className="size-3" /><span>head {branch.headSha.slice(0, 8)}</span></div> : null}
      <div className="mt-7 flex flex-wrap justify-center gap-3"><Button onClick={onChangeBranch} variant={clean ? "outline" : "default"} className={cn(!clean && "bg-[#6f58dd] text-white hover:bg-[#6049cf]")}><GitBranch className="size-4" /> Choose another branch</Button>{!clean ? <Button variant="outline"><ExternalLink className="size-4" /> View GitLab pipeline</Button> : null}</div>
    </div></div>
  </Card>;
}

export function RemediationConsole() {
  const router = useRouter();
  const [project, setProject] = useState(projects[0]);
  const [branch, setBranch] = useState(projects[0].branches[0]);
  const [projectPickerOpen, setProjectPickerOpen] = useState(false);
  const [branchPickerOpen, setBranchPickerOpen] = useState(false);
  const [loadingReport, setLoadingReport] = useState(false);
  const [query, setQuery] = useState(""); const [severity, setSeverity] = useState("all"); const [type, setType] = useState("all");
  const [selected, setSelected] = useState<Set<string>>(new Set()); const [focusedId, setFocusedId] = useState<string | null>(branch.findingIds[0] ?? null);
  const [reviewOpen, setReviewOpen] = useState(false); const [launching, setLaunching] = useState(false); const [launchError, setLaunchError] = useState("");
  const [campaign, setCampaign] = useState<null | { id: string; status: string }>(null); const [duoStatus, setDuoStatus] = useState<DuoOAuthStatus | null>(null);

  useEffect(() => {
    let active = true;
    fetch("/api/gitlab-duo/oauth/status", { cache: "no-store" }).then(async (response) => { const status = await response.json() as DuoOAuthStatus; if (active) setDuoStatus(status); }).catch((error) => { console.error("[duo-oauth] Unable to load status", error); if (active) setDuoStatus({ configured: true, authorized: false, mode: "OAUTH_ERROR", detail: "OAuth status is unavailable" }); });
    const url = new URL(window.location.href); if (url.searchParams.has("duo")) { url.searchParams.delete("duo"); window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`); }
    return () => { active = false; };
  }, []);

  const branchFindings = useMemo(() => branch.findingIds.map((id) => vulnerabilityById.get(id)).filter((item): item is Vulnerability => Boolean(item)), [branch]);
  const filtered = useMemo(() => { const search = query.trim().toLowerCase(); return branchFindings.filter((item) => severity === "all" || item.severity === severity).filter((item) => type === "all" || item.type === type).filter((item) => !search || [item.title, item.identifier, item.location, item.shortId].join(" ").toLowerCase().includes(search)).sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]); }, [branchFindings, query, severity, type]);
  const fixable = filtered.filter((item) => item.readiness !== "Unsupported"); const allSelected = fixable.length > 0 && fixable.every((item) => selected.has(item.id));
  const selectedFindings = branchFindings.filter((item) => selected.has(item.id)); const detail = branchFindings.find((item) => item.id === focusedId) ?? branchFindings[0];
  const mockMode = duoStatus?.mode === "MOCK"; const duoConnected = Boolean(duoStatus?.authorized) && !mockMode; const oauthRequired = Boolean(duoStatus?.configured && !duoConnected && !mockMode); const duoUnavailable = Boolean(duoStatus && !duoStatus.configured);

  function connectDuo() { router.push("/api/gitlab-duo/oauth/authorize"); }
  function resetWorkbench(nextBranch: RepositoryBranch) { setSelected(new Set()); setFocusedId(nextBranch.findingIds[0] ?? null); setQuery(""); setSeverity("all"); setType("all"); setCampaign(null); setLaunchError(""); }
  function loadBranch(nextBranch: RepositoryBranch) { setLoadingReport(true); resetWorkbench(nextBranch); window.setTimeout(() => { setBranch(nextBranch); setLoadingReport(false); }, 420); }
  function chooseProject(nextProject: GitLabProject) { setProject(nextProject); const nextBranch = nextProject.branches.find((item) => item.name === nextProject.defaultBranch) ?? nextProject.branches[0]; loadBranch(nextBranch); }
  function toggleFinding(id: string, checked: boolean) { if (branchFindings.find((item) => item.id === id)?.readiness === "Unsupported") return; setSelected((current) => { const next = new Set(current); if (checked) next.add(id); else next.delete(id); return next; }); }
  function toggleAll(checked: boolean) { setSelected((current) => { const next = new Set(current); fixable.forEach((item) => { if (checked) next.add(item.id); else next.delete(item.id); }); return next; }); }

  const createCampaign = useCallback(async (findingIds: string[]) => {
    setLaunching(true); setLaunchError("");
    try {
      const response = await fetch("/api/remediation-campaigns", { method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": crypto.randomUUID() }, body: JSON.stringify({ projectId: project.id, projectPath: project.pathWithNamespace, targetBranch: branch.name, expectedHeadSha: branch.headSha, reportPipelineId: branch.pipelineId, requestedBy: "local-developer", vulnerabilityIds: findingIds, policyProfile: "spring-production-strict" }) });
      if (!response.ok) { const problem = await response.json().catch(() => ({})) as { message?: string; detail?: string }; if (response.status === 401) setDuoStatus((current) => ({ ...(current ?? { configured: true, mode: "OAUTH_AUTHORIZATION_CODE_PKCE" }), authorized: false })); throw new Error(problem.detail ?? problem.message ?? `Campaign service returned ${response.status}`); }
      const result = await response.json() as { campaignId?: string; id?: string; status?: string }; const id = result.campaignId ?? result.id ?? "A7F2-91C4"; setCampaign({ id, status: result.status ?? "PLANNING" }); setReviewOpen(false); return { campaignId: id, status: result.status ?? "PLANNING", project: project.pathWithNamespace, branch: branch.name, expectedHeadSha: branch.headSha };
    } catch (error) { setLaunchError(error instanceof Error ? error.message : "Unable to start remediation campaign"); return null; } finally { setLaunching(false); }
  }, [branch, project]);

  useEffect(() => {
    const context = document.modelContext; if (!context?.registerTool) return; const lifecycle = new AbortController();
    const register = (tool: WebMcpTool) => { try { void Promise.resolve(context.registerTool(tool, { signal: lifecycle.signal })).catch((error) => console.error(`[WebMCP] Failed to register ${tool.name}`, error)); } catch (error) { console.error(`[WebMCP] Failed to register ${tool.name}`, error); } };
    const parseFindingIds = (input: unknown) => { if (branch.state !== "VULNERABLE") throw new Error(`Branch ${branch.name} is ${branch.state.toLowerCase()} and cannot start remediation`); if (!input || typeof input !== "object" || !Array.isArray((input as { findingIds?: unknown }).findingIds)) throw new Error("findingIds must be an array of vulnerability IDs"); const ids = [...new Set((input as { findingIds: unknown[] }).findingIds)]; if (!ids.length || ids.some((id) => typeof id !== "string")) throw new Error("findingIds must contain at least one string ID"); const findingIds = ids as string[]; const unknown = findingIds.filter((id) => !branch.findingIds.includes(id)); if (unknown.length) throw new Error(`Findings are not in the selected branch report: ${unknown.join(", ")}`); const unsupported = findingIds.filter((id) => vulnerabilityById.get(id)?.readiness === "Unsupported"); if (unsupported.length) throw new Error(`Container findings require manual platform action: ${unsupported.join(", ")}`); return findingIds; };
    register({ name: "read_gitlab_projects", title: "Read GitLab projects", description: "List Spring Boot projects accessible through the current GitLab OAuth context.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: () => ({ projects: projects.map(({ id, name, pathWithNamespace, defaultBranch, accessLevel }) => ({ id, name, pathWithNamespace, defaultBranch, accessLevel })) }) });
    register({ name: "read_repository_branches", title: "Read repository branches", description: "List branches and authoritative report states for the selected GitLab project.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: () => ({ project: project.pathWithNamespace, branches: project.branches.map(({ name, state, headSha, reportSha, pipelineId, findingIds }) => ({ name, state, headSha, reportSha, pipelineId, findingCount: findingIds.length })) }) });
    register({ name: "read_remediation_findings", title: "Read remediation findings", description: "Read the findings in the selected branch's repository security report.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: () => ({ project: project.pathWithNamespace, branch: branch.name, reportState: branch.state, headSha: branch.headSha, findings: branchFindings.map(({ id, identifier, title, severity: findingSeverity, type: findingType, readiness }) => ({ id, identifier, title, severity: findingSeverity, type: findingType, readiness, fixable: readiness !== "Unsupported" })) }) });
    register({ name: "stage_remediation_findings", title: "Stage remediation findings", description: "Stage actionable findings from the current branch and open the safety review.", inputSchema: { type: "object", properties: { findingIds: { type: "array", minItems: 1, uniqueItems: true, items: { type: "string" } } }, required: ["findingIds"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, async execute(input) { const findingIds = parseFindingIds(input); setSelected(new Set(findingIds)); setFocusedId(findingIds[0]); setReviewOpen(true); await new Promise<void>((resolve) => requestAnimationFrame(() => resolve())); return { stagedFindingIds: findingIds, project: project.pathWithNamespace, branch: branch.name, exactSha: branch.headSha, reviewOpen: true }; } });
    register({ name: "create_remediation_campaign", title: "Create remediation campaign", description: "Create a Duo-assisted campaign for staged findings. Generates Draft MRs only and never merges automatically.", inputSchema: { type: "object", properties: { findingIds: { type: "array", minItems: 1, uniqueItems: true, items: { type: "string" } } }, required: ["findingIds"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, async execute(input) { const findingIds = parseFindingIds(input); setSelected(new Set(findingIds)); const result = await createCampaign(findingIds); if (!result) throw new Error("Campaign creation failed; see the visible error message"); return result; } });
    return () => lifecycle.abort();
  }, [branch, branchFindings, createCampaign, project]);

  const actionableCount = branchFindings.filter((item) => item.readiness !== "Unsupported").length; const highCount = branchFindings.filter((item) => item.severity === "Critical" || item.severity === "High").length;

  return <TooltipProvider><div className="min-h-screen bg-[#f4f6f8] text-foreground dark:bg-background">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[236px] lg:block"><SidebarContent duoStatus={duoStatus} onConnect={connectDuo} count={branchFindings.length} /></aside>
    <div className="lg:pl-[236px]">
      <header className="sticky top-0 z-20 flex min-h-[72px] items-center justify-between border-b border-[#dde2e8] bg-background/95 px-4 py-2 backdrop-blur md:px-7 lg:px-9 dark:border-white/10">
        <div className="flex min-w-0 items-center gap-2 sm:gap-3"><Sheet><SheetTrigger asChild><Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation"><Menu className="size-5" /></Button></SheetTrigger><SheetContent side="left" className="w-[280px] border-0 p-0"><SheetHeader className="sr-only"><SheetTitle>Navigation</SheetTitle><SheetDescription>Application navigation</SheetDescription></SheetHeader><SidebarContent duoStatus={duoStatus} onConnect={connectDuo} count={branchFindings.length} /></SheetContent></Sheet><div className="lg:hidden"><BrandMark /></div><Separator orientation="vertical" className="hidden h-7 sm:block lg:hidden" />
          <button type="button" onClick={() => setProjectPickerOpen(true)} className="group flex min-w-0 items-center gap-2 rounded-xl border border-transparent p-1.5 text-left hover:border-border hover:bg-muted/70"><div className="hidden size-9 place-items-center rounded-lg bg-[#ebeff3] text-xs font-bold text-[#324052] sm:grid dark:bg-white/10 dark:text-slate-200">{project.initials}</div><div className="min-w-0"><p className="truncate text-sm font-semibold">{project.name}</p><p className="hidden truncate text-xs text-muted-foreground sm:block">{project.pathWithNamespace} · ID {project.id}</p></div><ChevronDown className="size-4 shrink-0 text-muted-foreground" /></button>
          <ChevronRight className="hidden size-4 text-muted-foreground md:block" />
          <button type="button" onClick={() => setBranchPickerOpen(true)} className="hidden min-w-0 items-center gap-2 rounded-lg border px-3 py-2 text-left hover:bg-muted/70 md:flex"><GitBranch className="size-4 shrink-0 text-muted-foreground" /><span className="max-w-[190px] truncate text-sm font-medium">{branch.name}</span><ReportBadge branch={branch} compact /><ChevronDown className="size-3.5 text-muted-foreground" /></button>
        </div>
        <div className="flex items-center gap-2 sm:gap-3"><button type="button" onClick={oauthRequired ? connectDuo : undefined} className={cn("flex items-center gap-2 rounded-full border px-2.5 py-1.5 text-xs font-medium", duoConnected && "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-300", mockMode && "border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300", oauthRequired && "border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100 dark:border-amber-900 dark:bg-amber-950/50 dark:text-amber-200", (!duoStatus || duoUnavailable) && "border-slate-200 bg-slate-50 text-slate-500")}><KeyRound className="size-3.5" /><span className="hidden sm:inline">{duoConnected ? `Duo OAuth · @${duoStatus?.username}` : mockMode ? "Duo mock" : oauthRequired ? "Connect Duo OAuth" : duoUnavailable ? "Duo unavailable" : "Checking Duo"}</span><span className="sm:hidden">Duo</span></button><Tooltip><TooltipTrigger asChild><Button variant="ghost" size="icon" aria-label="Security policy"><LockKeyhole className="size-[18px]" /></Button></TooltipTrigger><TooltipContent>spring-production-strict policy</TooltipContent></Tooltip></div>
      </header>

      <main className="mx-auto max-w-[1580px] px-4 py-6 md:px-7 lg:px-9 lg:py-8">
        <div className="mb-4 flex items-center gap-2 md:hidden"><Button variant="outline" onClick={() => setBranchPickerOpen(true)} className="w-full justify-between"><span className="flex min-w-0 items-center gap-2"><GitBranch className="size-4" /><span className="truncate">{branch.name}</span></span><ReportBadge branch={branch} compact /></Button></div>
        <div className="mb-6 flex flex-col justify-between gap-5 xl:flex-row xl:items-end"><div><div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-[#6a55d4]"><Activity className="size-3.5" /> Repository security</div><div className="flex flex-wrap items-center gap-3"><h1 className="text-2xl font-semibold tracking-[-0.025em] md:text-[1.8rem]">{branch.name}</h1><ReportBadge branch={branch} /></div><p className="mt-1.5 text-sm text-muted-foreground">Authoritative GitLab report for <span className="font-medium text-foreground">{project.pathWithNamespace}</span></p></div>
          {branch.state === "VULNERABLE" ? <div className="flex divide-x rounded-xl border border-[#dfe4ea] bg-background px-1 shadow-sm dark:border-white/10">{[[branchFindings.length, "Open"], [highCount, "Critical + high"], [actionableCount, "Actionable"]].map(([value, label], index) => <div key={label} className="px-4 py-2.5"><p className={cn("text-xl font-semibold tabular-nums", index === 1 && "text-rose-600", index === 2 && "text-[#6751d0]")}>{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>)}</div> : null}
        </div>
        <ReportProvenance branch={branch} />

        {loadingReport ? <Card className="grid min-h-[440px] place-items-center border-[#dfe4ea]"><div className="text-center"><RefreshCw className="mx-auto mb-4 size-7 animate-spin text-[#6f58dd]" /><p className="font-semibold">Loading branch security report</p><p className="mt-1 text-sm text-muted-foreground">Verifying report SHA against the branch head…</p></div></Card> : branch.state !== "VULNERABLE" ? <NonActionableState branch={branch} onChangeBranch={() => setBranchPickerOpen(true)} /> : <>
          {campaign ? <div className="mb-5 rounded-xl border border-[#d8d1ff] bg-[#f7f5ff] px-4 py-4 dark:border-[#3e3568] dark:bg-[#17142a] md:px-5"><div className="flex flex-col gap-4 md:flex-row md:items-center"><div className="flex min-w-0 flex-1 items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#7058df] text-white"><Bot className="size-5" /></div><div><div className="flex flex-wrap items-center gap-2"><p className="font-semibold">Campaign {campaign.id.slice(0, 8)}</p><Badge className="bg-[#e7e1ff] text-[#563fc0] dark:bg-[#31285a] dark:text-[#c9c0ff]">Duo planning</Badge></div><p className="mt-1 text-sm text-muted-foreground">Bound to {branch.name} at {branch.headSha.slice(0, 8)}. No repository changes yet.</p></div></div><div className="w-full md:w-[260px]"><div className="mb-2 flex justify-between text-xs font-medium"><span>Analysis</span><span className="text-muted-foreground">42%</span></div><Progress value={42} className="bg-[#dcd5fb] [&_[data-slot=progress-indicator]]:bg-[#7058df]" /></div><Button variant="outline" size="sm">View campaign <ChevronRight className="size-4" /></Button></div></div> : null}
          <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]"><Card className="min-w-0 gap-0 overflow-hidden border-[#dfe4ea] py-0 shadow-[0_12px_32px_rgba(22,34,51,0.055)] dark:border-white/10">
            <div className="flex flex-col gap-3 border-b px-4 py-4 md:flex-row md:items-center md:px-5"><div className="relative min-w-0 flex-1 md:max-w-[420px]"><Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search CVE, CWE, file or dependency" aria-label="Search vulnerabilities" className="h-10 rounded-lg border-[#dfe4ea] bg-[#f8f9fb] pl-9 shadow-none dark:border-white/10 dark:bg-white/[0.035]" /></div><div className="flex flex-wrap items-center gap-2"><Select value={severity} onValueChange={setSeverity}><SelectTrigger className="h-10 min-w-[132px] rounded-lg shadow-none"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All severities</SelectItem>{["Critical", "High", "Medium", "Low"].map((value) => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select><Select value={type} onValueChange={setType}><SelectTrigger className="h-10 min-w-[128px] rounded-lg shadow-none"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All types</SelectItem>{["Dependency", "SAST", "Container"].map((value) => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select><Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" className="size-10" aria-label="More filters"><Filter className="size-4" /></Button></TooltipTrigger><TooltipContent>More filters</TooltipContent></Tooltip></div></div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b bg-[#fbfcfd] px-4 py-2.5 text-xs text-muted-foreground md:px-5 dark:bg-white/[0.02]"><span className="font-medium text-foreground">{filtered.length} findings</span><span>·</span><span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-300"><CircleDot className="size-3" /> report matches branch head</span><span>·</span><span>{branch.scanners.join(", ")}</span></div>
            <div className="overflow-x-auto"><Table className="min-w-[820px]"><TableHeader><TableRow className="bg-background hover:bg-background"><TableHead className="w-12 pl-5"><Checkbox checked={allSelected} onCheckedChange={(value) => toggleAll(Boolean(value))} aria-label="Select all actionable findings" /></TableHead><TableHead>Finding</TableHead><TableHead>Severity</TableHead><TableHead>Type</TableHead><TableHead>GitLab Duo</TableHead><TableHead className="pr-5 text-right">Detected</TableHead></TableRow></TableHeader><TableBody>{filtered.map((item) => { const checked = selected.has(item.id); const focused = focusedId === item.id; const disabled = item.readiness === "Unsupported"; return <TableRow key={item.id} data-state={checked ? "selected" : undefined} onClick={() => setFocusedId(item.id)} className={cn("cursor-pointer border-[#edf0f3] bg-background hover:bg-[#f9fafc] dark:border-white/7 dark:hover:bg-white/[0.035]", focused && "bg-[#f7f5ff] hover:bg-[#f7f5ff] dark:bg-[#1b1730] dark:hover:bg-[#1b1730]")}><TableCell className="pl-5"><Checkbox checked={checked} disabled={disabled} onClick={(event) => event.stopPropagation()} onCheckedChange={(value) => toggleFinding(item.id, Boolean(value))} aria-label={`Select ${item.title}`} /></TableCell><TableCell className="max-w-[360px] py-4"><button type="button" onClick={() => setFocusedId(item.id)} className="block max-w-full text-left"><span className="block truncate text-sm font-semibold">{item.title}</span><span className="mt-1 block truncate text-xs text-muted-foreground">{item.identifier} · {item.location}</span></button></TableCell><TableCell><SeverityBadge severity={item.severity} /></TableCell><TableCell><span className="text-sm">{item.type}</span>{item.version ? <span className="mt-1 block text-xs text-muted-foreground">{item.version}</span> : null}</TableCell><TableCell><Readiness status={item.readiness} /></TableCell><TableCell className="pr-5 text-right text-xs text-muted-foreground">{item.detected}</TableCell></TableRow>; })}</TableBody></Table></div>
            {filtered.length === 0 ? <div className="grid min-h-56 place-items-center p-8 text-center"><div><Search className="mx-auto mb-3 size-6 text-muted-foreground" /><p className="font-semibold">No findings match</p><p className="mt-1 text-sm text-muted-foreground">Try a different search or filter.</p></div></div> : null}
            <div className="sticky bottom-0 flex min-h-[68px] flex-col gap-3 border-t bg-background/95 px-4 py-3 backdrop-blur md:flex-row md:items-center md:justify-between md:px-5"><div className="text-sm"><span className="font-semibold">{selected.size}</span> <span className="text-muted-foreground">selected</span>{selected.size ? <button type="button" onClick={() => setSelected(new Set())} className="ml-3 font-medium text-[#654dcc] hover:underline">Clear</button> : null}</div><Button disabled={!selected.size || duoUnavailable} onClick={oauthRequired ? connectDuo : () => setReviewOpen(true)} className="h-10 rounded-lg bg-[#6f58dd] px-5 text-white shadow-[0_8px_18px_rgba(111,88,221,0.24)] hover:bg-[#6049cf]">{oauthRequired ? <><LogIn className="size-4" /> Connect GitLab Duo</> : duoUnavailable ? <><KeyRound className="size-4" /> Configure Duo OAuth</> : <><Sparkles className="size-4" /> {mockMode ? "Run mock remediation" : "Fix selected with Duo"}</>}</Button></div>
          </Card><aside className="hidden xl:block">{detail ? <div className="sticky top-[92px]"><DetailPanel vulnerability={detail} /></div> : null}</aside></div>{detail ? <div className="mt-5 xl:hidden"><DetailPanel vulnerability={detail} /></div> : null}
        </>}
        <div className="mt-6 flex flex-col gap-3 border-t pt-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between"><p className="flex items-center gap-1.5"><LockKeyhole className="size-3.5" /> Exact-SHA evidence policy · automatic merge disabled</p><p>GitLab report is authoritative · Duo proposes and validates fixes</p></div>
      </main>
    </div>

    <ProjectPicker open={projectPickerOpen} onOpenChange={setProjectPickerOpen} current={project} onSelect={chooseProject} />
    <BranchPicker open={branchPickerOpen} onOpenChange={setBranchPickerOpen} project={project} current={branch} onSelect={loadBranch} />
    <Dialog open={reviewOpen} onOpenChange={setReviewOpen}><DialogContent className="gap-0 overflow-hidden border-0 p-0 sm:max-w-[680px]"><div className="bg-[#111c2b] px-6 py-6 text-white"><div className="mb-5 flex items-center gap-3"><div className="grid size-10 place-items-center rounded-xl bg-[#7964e8]"><Sparkles className="size-5" /></div><div><p className="text-xs font-medium uppercase tracking-[0.1em] text-[#a99cff]">{mockMode ? "Mock campaign" : "GitLab Duo OAuth campaign"}</p><DialogTitle className="mt-1 text-xl">Review the remediation boundary</DialogTitle></div></div><DialogDescription className="leading-6 text-slate-300">Duo receives only the selected findings and normalized evidence for this exact project, branch, and commit.</DialogDescription></div>
      <div className="max-h-[65vh] space-y-5 overflow-y-auto px-6 py-5"><div className="grid gap-3 rounded-xl border bg-muted/25 p-4 sm:grid-cols-2"><div><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Project</p><p className="mt-1 text-sm font-semibold">{project.name} <span className="font-normal text-muted-foreground">· ID {project.id}</span></p><p className="mt-0.5 truncate text-xs text-muted-foreground">{project.pathWithNamespace}</p></div><div><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Target</p><p className="mt-1 text-sm font-semibold">{branch.name}</p><p className="mt-0.5 font-mono text-xs text-muted-foreground">{branch.headSha}</p></div><div><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Evidence</p><p className="mt-1 text-sm font-semibold">Pipeline #{branch.pipelineId} · report current</p></div><div><p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Identity</p><p className="mt-1 text-sm font-semibold">{duoConnected ? `OAuth · @${duoStatus?.username}` : mockMode ? "Local mock adapter" : "OAuth required"}</p></div></div>
        <div className="grid grid-cols-3 divide-x rounded-xl border py-3 text-center">{[[selected.size, "Selected"], [selectedFindings.filter((item) => item.type === "Dependency").length, "Dependencies"], [selectedFindings.filter((item) => item.type === "SAST").length, "SAST"]].map(([value, label]) => <div key={label}><p className="text-xl font-semibold">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>)}</div>
        <div><p className="mb-3 text-sm font-semibold">Validation gates</p><div className="space-y-2">{[{ icon: Bot, label: "Duo analyzes Spring and Maven context" }, { icon: Package, label: "Dependencies resolve only through Artifactory" }, { icon: TestTube2, label: "Build, tests, and security rescan must pass" }, { icon: GitPullRequest, label: "Verified groups become Draft MRs" }].map((step, index) => { const Icon = step.icon; return <div key={step.label} className="flex items-center gap-3"><div className="grid size-8 place-items-center rounded-lg bg-[#f0edff] text-[#654dcc] dark:bg-[#252044] dark:text-[#b9adff]"><Icon className="size-4" /></div><p className="flex-1 text-sm">{step.label}</p><span className="text-xs text-muted-foreground">0{index + 1}</span></div>; })}</div></div>
        {branchFindings.some((item) => item.readiness === "Unsupported") ? <div className="flex items-start gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"><Circle className="mt-1 size-2.5 shrink-0 fill-current" /><p>{branchFindings.filter((item) => item.readiness === "Unsupported").length} container finding is excluded. Base-image, digest, package, and Dockerfile changes remain manual.</p></div> : null}
        <div className="flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200"><AlertTriangle className="mt-0.5 size-4 shrink-0" /><p>Campaigns never merge code. A human must review and approve every Draft MR.</p></div>{launchError ? <div role="alert" className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{launchError}</div> : null}</div>
      <DialogFooter className="border-t bg-muted/20 px-6 py-4"><Button variant="ghost" onClick={() => setReviewOpen(false)} disabled={launching}>Cancel</Button><Button onClick={() => void createCampaign(selectedFindings.map((item) => item.id))} disabled={launching || !selected.size} className="bg-[#6f58dd] text-white hover:bg-[#6049cf]">{launching ? <><RefreshCw className="size-4 animate-spin" /> Starting campaign</> : <><Sparkles className="size-4" /> {mockMode ? "Run mock campaign" : "Start verified campaign"}</>}</Button></DialogFooter>
    </DialogContent></Dialog>
  </div></TooltipProvider>;
}
