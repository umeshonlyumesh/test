export type Severity = "Critical" | "High" | "Medium" | "Low";
export type FindingType = "Dependency" | "SAST" | "Container";
export type DuoReadiness = "Ready" | "Review" | "Unsupported";
export type ReportState = "VULNERABLE" | "CLEAN" | "STALE" | "INCOMPLETE" | "NO_REPORT";

export type Vulnerability = {
  id: string; shortId: string; title: string; identifier: string; severity: Severity;
  type: FindingType; location: string; version?: string; fixedVersion?: string;
  scanner: string; detected: string; readiness: DuoReadiness; description: string;
  strategy: string; evidence: string[]; files: string[];
};

export type RepositoryBranch = {
  name: string; state: ReportState; default?: boolean; protected?: boolean;
  headSha: string; reportSha?: string; pipelineId?: string;
  pipelineStatus?: "passed" | "failed" | "running"; scannedAt?: string;
  scanners: string[]; findingIds: string[]; reason?: string;
};

export type GitLabProject = {
  id: string; name: string; pathWithNamespace: string; description: string;
  defaultBranch: string; language: string; framework: string;
  accessLevel: "Maintainer" | "Developer"; lastActivity: string;
  initials: string; branches: RepositoryBranch[];
};

export const vulnerabilities: Vulnerability[] = [
  {
    id: "gid://gitlab/Vulnerability/101", shortId: "VULN-101",
    title: "Improper neutralization in Spring Web", identifier: "CVE-2026-21418",
    severity: "Critical", type: "Dependency", location: "pom.xml · payments-api",
    version: "6.2.8", fixedVersion: "6.2.11", scanner: "Dependency Scanning",
    detected: "18 min ago", readiness: "Ready",
    description: "The resolved Spring Web version is managed transitively through the Spring Boot dependency BOM. Organization Artifactory contains an approved fixed release.",
    strategy: "Upgrade the owning Spring Boot patch line, then verify the effective POM and complete dependency graph against Artifactory.",
    evidence: ["Version owner identified", "Fixed artifact available in Artifactory", "No major framework migration"],
    files: ["pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/102", shortId: "VULN-102",
    title: "Authorization bypass in invoice endpoint", identifier: "CWE-862",
    severity: "Critical", type: "SAST", location: "InvoiceController.java:84",
    scanner: "SAST", detected: "24 min ago", readiness: "Ready",
    description: "The invoice download endpoint accepts an invoice identifier without confirming that the authenticated principal owns the underlying account.",
    strategy: "Trace controller-to-service ownership checks, enforce authorization at the service boundary, and generate negative and positive MockMvc tests.",
    evidence: ["Source location verified", "Authentication context available", "Existing MockMvc test harness"],
    files: ["src/main/java/com/acme/payments/InvoiceService.java", "src/test/java/com/acme/payments/InvoiceSecurityTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/103", shortId: "VULN-103",
    title: "SQL injection in transaction search", identifier: "CWE-89",
    severity: "High", type: "SAST", location: "TransactionRepository.java:117",
    scanner: "SAST", detected: "41 min ago", readiness: "Ready",
    description: "A request parameter is concatenated into a native query used by the transaction search endpoint.",
    strategy: "Replace string concatenation with a parameterized query and prove the behavior with a regression test that fails on the original revision.",
    evidence: ["Supported CWE recipe", "Repository test fixture found", "Affected execution path isolated"],
    files: ["src/main/java/com/acme/payments/TransactionRepository.java", "src/test/java/com/acme/payments/TransactionRepositoryTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/104", shortId: "VULN-104",
    title: "Vulnerable Jackson Databind release", identifier: "CVE-2026-11204",
    severity: "High", type: "Dependency", location: "pom.xml · payment-events",
    version: "2.18.3", fixedVersion: "2.18.5", scanner: "Dependency Scanning",
    detected: "1 hr ago", readiness: "Ready",
    description: "Jackson Databind is controlled by the Spring Boot BOM and reaches payment-events through the JSON starter.",
    strategy: "Select the smallest approved Boot-managed upgrade available in Artifactory and compare serialization tests before and after.",
    evidence: ["Dependency path resolved", "Fixed artifact available in Artifactory", "Serialization tests discovered"],
    files: ["pom.xml", "payment-events/pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/105", shortId: "VULN-105",
    title: "Path traversal in statement download", identifier: "CWE-22",
    severity: "Medium", type: "SAST", location: "StatementController.java:63",
    scanner: "SAST", detected: "2 hr ago", readiness: "Review",
    description: "A user-controlled filename is resolved against the statement export directory without a canonical path boundary check.",
    strategy: "Normalize and constrain the resolved path, then test encoded and nested traversal attempts. Security review remains mandatory.",
    evidence: ["Source location verified", "Filesystem boundary inferred", "Security reviewer required"],
    files: ["src/main/java/com/acme/payments/StatementController.java", "src/test/java/com/acme/payments/StatementSecurityTest.java"],
  },
  {
    id: "gid://gitlab/Vulnerability/106", shortId: "VULN-106",
    title: "Netty HTTP/2 denial of service", identifier: "CVE-2026-07731",
    severity: "Medium", type: "Dependency", location: "pom.xml · notification-client",
    version: "4.1.116.Final", fixedVersion: "4.1.119.Final", scanner: "Dependency Scanning",
    detected: "3 hr ago", readiness: "Ready",
    description: "The reactive notification client brings Netty transitively through Spring WebFlux.",
    strategy: "Update the existing Netty BOM property after confirming Spring compatibility and run the reactive integration suite.",
    evidence: ["Transitive path resolved", "Approved internal artifact", "WebFlux integration tests found"],
    files: ["notification-client/pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/107", shortId: "VULN-107",
    title: "OpenSSL package vulnerability", identifier: "CVE-2026-30112",
    severity: "High", type: "Container", location: "registry / payments-service",
    version: "3.2.1-r0", scanner: "Container Scanning", detected: "4 hr ago",
    readiness: "Unsupported",
    description: "The finding originates from the runtime image. Container remediation is intentionally outside this product's automated scope.",
    strategy: "Route to the platform image owner. This console will not change Dockerfiles, base images, image digests, or operating-system packages.",
    evidence: ["Container finding", "Manual platform action required"], files: [],
  },
  {
    id: "gid://gitlab/Vulnerability/201", shortId: "VULN-201",
    title: "Spring Security matcher bypass", identifier: "CVE-2026-18442",
    severity: "Critical", type: "Dependency", location: "pom.xml · customer-api",
    version: "6.4.2", fixedVersion: "6.4.5", scanner: "Dependency Scanning",
    detected: "36 min ago", readiness: "Ready",
    description: "The affected Spring Security release is managed by the parent Spring Boot BOM.",
    strategy: "Move to the approved Spring Boot patch in Artifactory and validate the effective security filter chain.",
    evidence: ["BOM ownership verified", "Approved artifact available", "Security integration suite found"],
    files: ["pom.xml"],
  },
  {
    id: "gid://gitlab/Vulnerability/202", shortId: "VULN-202",
    title: "PII exposed in audit logging", identifier: "CWE-532",
    severity: "Medium", type: "SAST", location: "CustomerAuditService.java:52",
    scanner: "SAST", detected: "39 min ago", readiness: "Review",
    description: "A customer request object containing personal data is written to an application log.",
    strategy: "Replace object logging with an allowlisted audit event and cover redaction with a log-capture test.",
    evidence: ["Log sink traced", "PII fields identified", "Privacy review required"],
    files: ["src/main/java/com/acme/customer/CustomerAuditService.java"],
  },
];

const paymentBranches: RepositoryBranch[] = [
  { name: "main", state: "VULNERABLE", default: true, protected: true, headSha: "9f3a2de7810bf3ed2e6df435707074a879a680b1", reportSha: "9f3a2de7810bf3ed2e6df435707074a879a680b1", pipelineId: "18422", pipelineStatus: "passed", scannedAt: "Sep 12, 2026 · 9:42 AM", scanners: ["SAST", "Dependency Scanning", "Container Scanning"], findingIds: vulnerabilities.slice(0, 7).map((item) => item.id) },
  { name: "release/2026.09", state: "CLEAN", protected: true, headSha: "e481c23e6bd63fe113cb19747c70140d40e1079d", reportSha: "e481c23e6bd63fe113cb19747c70140d40e1079d", pipelineId: "18409", pipelineStatus: "passed", scannedAt: "Sep 12, 2026 · 8:11 AM", scanners: ["SAST", "Dependency Scanning", "Container Scanning"], findingIds: [] },
  { name: "feature/payment-validation", state: "STALE", headSha: "7bc912f600a9959273accd4ac4a35c2bc4478720", reportSha: "546f21a5e49d223de86f08a3e4ac40d8a6ce74cb", pipelineId: "18392", pipelineStatus: "passed", scannedAt: "Sep 11, 2026 · 6:24 PM", scanners: ["SAST", "Dependency Scanning"], findingIds: [vulnerabilities[2].id, vulnerabilities[4].id], reason: "The latest report was generated for an older commit. Remediation is blocked until the current branch SHA is scanned." },
  { name: "feature/spring-boot-3.5", state: "INCOMPLETE", headSha: "8ed6189131b87ab2f09a58957c971ac1abbc8f30", reportSha: "8ed6189131b87ab2f09a58957c971ac1abbc8f30", pipelineId: "18417", pipelineStatus: "failed", scannedAt: "Sep 12, 2026 · 9:03 AM", scanners: ["SAST"], findingIds: [vulnerabilities[0].id], reason: "Dependency and container scanners did not complete. A partial report cannot establish branch security." },
  { name: "hotfix/refund-timeout", state: "NO_REPORT", headSha: "4d512ac88df08437898374250b9cf6df33e1c3c0", scanners: [], findingIds: [], reason: "No security report is available for this branch yet." },
];

export const projects: GitLabProject[] = [
  { id: "4812", name: "payments-service", pathWithNamespace: "payments/platform/payments-service", description: "Core payments orchestration API", defaultBranch: "main", language: "Java", framework: "Spring Boot 3.4", accessLevel: "Maintainer", lastActivity: "12 min ago", initials: "PS", branches: paymentBranches },
  { id: "6144", name: "customer-profile-api", pathWithNamespace: "customer/experience/customer-profile-api", description: "Customer profile and preferences", defaultBranch: "main", language: "Java", framework: "Spring Boot 3.4", accessLevel: "Developer", lastActivity: "28 min ago", initials: "CP", branches: [
    { name: "main", state: "VULNERABLE", default: true, protected: true, headSha: "f527f2431037d892de8ff11b1038c055a15ca5e3", reportSha: "f527f2431037d892de8ff11b1038c055a15ca5e3", pipelineId: "9218", pipelineStatus: "passed", scannedAt: "Sep 12, 2026 · 9:25 AM", scanners: ["SAST", "Dependency Scanning"], findingIds: [vulnerabilities[7].id, vulnerabilities[8].id] },
    { name: "release/3.4", state: "CLEAN", protected: true, headSha: "b76a1a1d0a7050c9fb481fce6ce8e481297454e2", reportSha: "b76a1a1d0a7050c9fb481fce6ce8e481297454e2", pipelineId: "9202", pipelineStatus: "passed", scannedAt: "Sep 12, 2026 · 6:40 AM", scanners: ["SAST", "Dependency Scanning"], findingIds: [] },
    { name: "feature/consent-v2", state: "NO_REPORT", headSha: "750b0d0f8da307a3a526ee7a33a46324304367a1", scanners: [], findingIds: [], reason: "No security report is available for this branch yet." },
  ] },
  { id: "9331", name: "notification-service", pathWithNamespace: "shared/platform/notification-service", description: "Email and event notification platform", defaultBranch: "main", language: "Java", framework: "Spring Boot 3.3", accessLevel: "Maintainer", lastActivity: "1 hr ago", initials: "NS", branches: [
    { name: "main", state: "CLEAN", default: true, protected: true, headSha: "3d3acc9c86938f71a6eaa0284f90c36a824bf144", reportSha: "3d3acc9c86938f71a6eaa0284f90c36a824bf144", pipelineId: "7731", pipelineStatus: "passed", scannedAt: "Sep 12, 2026 · 8:02 AM", scanners: ["SAST", "Dependency Scanning", "Container Scanning"], findingIds: [] },
    { name: "feature/provider-failover", state: "INCOMPLETE", headSha: "9bbdca9470e83669f7a33cebd6971d79b12780d1", reportSha: "9bbdca9470e83669f7a33cebd6971d79b12780d1", pipelineId: "7725", pipelineStatus: "failed", scannedAt: "Sep 12, 2026 · 7:31 AM", scanners: ["SAST"], findingIds: [], reason: "Dependency scanner failed before producing a complete report." },
  ] },
  { id: "10772", name: "billing-gateway", pathWithNamespace: "finance/billing/billing-gateway", description: "Billing provider gateway and reconciliation", defaultBranch: "trunk", language: "Java", framework: "Spring Boot 3.4", accessLevel: "Developer", lastActivity: "Yesterday", initials: "BG", branches: [
    { name: "trunk", state: "CLEAN", default: true, protected: true, headSha: "aae0c4402613c739b1edc2f7f809799fb0ab30fa", reportSha: "aae0c4402613c739b1edc2f7f809799fb0ab30fa", pipelineId: "4472", pipelineStatus: "passed", scannedAt: "Sep 11, 2026 · 4:18 PM", scanners: ["SAST", "Dependency Scanning"], findingIds: [] },
  ] },
];

export const severityOrder: Record<Severity, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };
export const vulnerabilityById = new Map(vulnerabilities.map((item) => [item.id, item]));
