export const DUO_SESSION_COOKIE = "duo_oauth_session";

export type DuoMode = "oauth" | "mock";

export function duoMode(): DuoMode {
  const configured = (process.env.REMEDIATION_DUO_MODE ?? "oauth").trim().toLowerCase();
  if (configured !== "oauth" && configured !== "mock") {
    throw new Error("REMEDIATION_DUO_MODE must be 'oauth' or 'mock'");
  }
  return configured;
}

export function remediationBackendUrl() {
  return process.env.REMEDIATION_API_URL?.replace(/\/$/, "");
}

export function readCookie(request: Request, name: string) {
  const cookie = request.headers.get("cookie");
  if (!cookie) return undefined;
  return cookie.split(";").map((item) => item.trim()).find((item) => item.startsWith(`${name}=`))
    ?.slice(name.length + 1);
}

export function oauthCallbackUri(request: Request) {
  return new URL("/api/gitlab-duo/oauth/callback", request.url).toString();
}
