package com.organization.security.remediation.worker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Component
@ConfigurationProperties(prefix = "remediation.maven")
public class MavenRepositoryProperties implements InitializingBean {
    private static final Logger log = LoggerFactory.getLogger(MavenRepositoryProperties.class);

    private RepositoryMode repositoryMode = RepositoryMode.CENTRAL;
    private Path settingsPath;

    public RepositoryMode getRepositoryMode() {
        return repositoryMode;
    }

    public void setRepositoryMode(RepositoryMode repositoryMode) {
        this.repositoryMode = repositoryMode;
    }

    public Path getSettingsPath() {
        return settingsPath;
    }

    public void setSettingsPath(Path settingsPath) {
        this.settingsPath = settingsPath;
    }

    /** Arguments that every worker Maven invocation must include. */
    public List<String> commandArguments() {
        if (repositoryMode == RepositoryMode.ARTIFACTORY) {
            return List.of("-s", settingsPath.toAbsolutePath().normalize().toString());
        }
        return List.of();
    }

    @Override
    public void afterPropertiesSet() {
        if (repositoryMode == RepositoryMode.ARTIFACTORY
                && (settingsPath == null || !Files.isRegularFile(settingsPath))) {
            throw new IllegalStateException(
                    "REMEDIATION_MAVEN_SETTINGS_PATH must reference an existing settings.xml in Artifactory mode"
            );
        }
        log.atInfo()
                .addKeyValue("event", "maven_repository_mode_selected")
                .addKeyValue("repositoryMode", repositoryMode.name().toLowerCase())
                .addKeyValue("customSettings", repositoryMode == RepositoryMode.ARTIFACTORY)
                .log("Maven repository mode configured");
    }

    public enum RepositoryMode {
        CENTRAL,
        ARTIFACTORY
    }
}
