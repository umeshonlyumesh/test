package com.mq.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApacheMqDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApacheMqDemoApplication.class, args);
    }

}
