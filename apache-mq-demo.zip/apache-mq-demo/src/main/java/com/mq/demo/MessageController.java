package com.mq.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MessageController {

    @Autowired
    private MessageProducer producer;

    @GetMapping("/publish")
    public String publish(@RequestParam("msg") String message) {
        producer.sendMessage(message);
        return "Message sent to ActiveMQ: " + message;
    }
}
