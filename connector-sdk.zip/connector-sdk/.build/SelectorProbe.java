import java.nio.channels.Selector;
import java.net.http.HttpClient;
public class SelectorProbe {
    public static void main(String[] args) throws Exception {
        try (var selector = Selector.open(); var client = HttpClient.newHttpClient()) {
            System.out.println("SELECTOR_HTTP_OK " + selector.getClass().getSimpleName());
        }
    }
}
