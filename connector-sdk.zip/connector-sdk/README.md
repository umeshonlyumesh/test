# connector-sdk

A modular Java 21 SDK for Spring Boot 4. The default working copy focuses on **REST, MQ and Redis**. SDK transport beans are opt-in; applications select their providers and named endpoints through configuration.

## Modules and design

| Module | Capability |
| --- | --- |
| `connector-sdk-core` | Framework-independent connector contract, typed registry, errors and fail-fast execution |
| `connector-sdk-spring` | Conditional Boot configuration, Micrometer observations and replacement-bean validation |
| `connector-sdk-rest` | Pooled HTTP client; bounded bodies/deadlines; mTLS, Basic, Bearer/JWT, OAuth2 client credentials |
| `connector-sdk-mq` | Portable Jakarta JMS for IBM MQ, ActiveMQ Classic 6 and Artemis |
| `connector-sdk-rabbitmq` | Native RabbitMQ AMQP, correlated publisher confirms and mandatory returns |
| `connector-sdk-redis` | Binary Redis get/set/delete, atomic increment and SET NX with expiry |
| `connector-sdk-bom` | Consistent SDK artifact versions |
| `connector-sdk-*-spring-boot-starter` | Integration dependencies, one starter per transport |

The SDK uses ports and adapters, composition, strategy interfaces, per-client factories, conditional auto-configuration and semaphore bulkheads. A new connector implements the open `Connector` contract and adds its own module/auto-configuration; no central enum or protocol switch changes are needed. See [architecture and extension guide](docs/architecture.md).

The default reactor contains 14 modules, including cross-module isolation tests and a compilable consumer application. Existing gRPC code is preserved behind `-Pgrpc` for later work and is outside the default scope. Source coordinates are `io.github.connectorsdk:...:0.1.0-SNAPSHOT`; assign your organization’s coordinates before publication.

## Build and run

Use JDK 21 and run from this directory:

```powershell
.\mvnw.cmd -B -ntp clean verify
.\mvnw.cmd -B -ntp install
java -jar examples/consumer-app/target/connector-sdk-consumer-example-0.1.0-SNAPSHOT.jar
```

Linux/macOS: `sh mvnw -B -ntp clean verify`. The wrapper pins Maven 3.9.11 with a distribution checksum. The build pins Spring Boot 4.1.1 and Java `--release 21`. `-Prelease` produces source/Javadoc artifacts. CI covers Java 21/25 with Boot 4.1.1; local validation evidence is in [verification.md](docs/verification.md). Earlier Boot 4 minor versions require a separate compatibility qualification.

Some Windows host environments fail when the JDK opens its internal Unix-domain selector pipe. For that host condition, use `powershell -File scripts/verify.ps1 -UseTcpSelectorFallback`. This affects only the build invocation and restores the previous environment afterward.

## Calling application

Import `connector-sdk-bom` with version `0.1.0-SNAPSHOT`, type `pom`, scope `import`, in application dependency management. Keep the application’s Spring Boot dependency management. Add only needed starters:

```xml
<dependencies>
  <dependency>
    <groupId>io.github.connectorsdk</groupId>
    <artifactId>connector-sdk-rest-spring-boot-starter</artifactId>
  </dependency>
  <dependency>
    <groupId>io.github.connectorsdk</groupId>
    <artifactId>connector-sdk-mq-spring-boot-starter</artifactId>
  </dependency>
  <dependency>
    <groupId>io.github.connectorsdk</groupId>
    <artifactId>connector-sdk-redis-spring-boot-starter</artifactId>
  </dependency>
</dependencies>
```

```java
@SpringBootApplication
@EnableRestConnector
@EnableMqConnector
@EnableRedisConnector
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

Annotation imports are `io.github.connectorsdk.rest.EnableRestConnector`, `io.github.connectorsdk.mq.EnableMqConnector` and `io.github.connectorsdk.redis.EnableRedisConnector`.

| Selection | Configuration prefix | Bean name |
| --- | --- | --- |
| REST | `connector.sdk.rest.clients` | `restConnector.<name>` |
| JMS / IBM / ActiveMQ | `connector.sdk.mq.clients` | `mqConnector.<name>` |
| RabbitMQ | `connector.sdk.rabbitmq.clients` | `rabbitMqConnector.<name>` |
| Redis | `connector.sdk.redis.clients` | `redisConnector.<name>` |

`@EnableMqConnector` selects configured JMS and RabbitMQ providers when the MQ starter is present. Rabbit-only applications can use `connector-sdk-rabbitmq-spring-boot-starter` and `@EnableRabbitMqConnector`, without JMS dependencies. Per-provider `enabled=true` properties are annotation alternatives; explicit `enabled=false` overrides activation for that provider. Dependencies alone create no SDK transport connector. Disabled transports skip their configuration validation. Lightweight factory/registry infrastructure may exist.

Use constructor injection with `@Qualifier("restConnector.partner")`, or a typed `Map<String, RestConnector>`. `ConnectorRegistry.require("rest", "partner", RestConnector.class)` provides explicit lookup. A custom bean using a configured name/alias overrides the default; incompatible capability or identity fails startup. Client state is bound at startup; live configuration reload is not implemented.

## REST security

```yaml
connector:
  sdk:
    rest:
      clients:
        partner:
          base-url: ${PARTNER_BASE_URL:https://partner.example/api/}
          request-timeout: 5s
          connect-timeout: 2s
          max-response-bytes: 1048576
          max-concurrent-calls: 32
          ssl-bundle: partner-mtls
          auth:
            type: OAUTH2_CLIENT_CREDENTIALS
            token-url: ${PARTNER_TOKEN_URL}
            client-id: ${PARTNER_CLIENT_ID}
            client-secret: ${PARTNER_CLIENT_SECRET}
            client-authentication: CLIENT_SECRET_BASIC
            scopes: [orders.read]
            token-request-timeout: 2s
            refresh-skew: 30s
```

`ssl-bundle` references a Spring Boot `spring.ssl.bundle.jks` or PEM bundle containing the client key/certificate and trusted server certificates. Hostname verification stays enabled. mTLS can be combined with any auth mode. Bundles are applied when clients are constructed; certificate rotation requires recreation/restart.

`auth.type=BASIC` uses username/password; `BEARER` uses a configured token, including JWT. The SDK sends JWTs as opaque bearer credentials; token issuance and resource-server validation belong to your identity system. `OAUTH2_CLIENT_CREDENTIALS` fetches and caches access tokens with expiry-aware, single-flight refresh, bounded token responses and shared request deadlines. Both client-secret Basic and POST authentication are available. `RestCredentialsProvider` supports custom flows, rotating JWTs and secret-store integration. Providers must honor their finite deadline contract. See [REST security details](connector-sdk-rest/README.md) and [complete configuration example](examples/configuration/connectors.yml).

```java
RestResponse response = partner.exchange(RestRequest.get("orders"));
```

Requests use relative same-origin paths; redirects are disabled. Responses preserve HTTP status and bytes, including non-2xx business responses. JSON serialization belongs to the application. TLS is default; HTTP requires explicit `allow-insecure=true`. Sensitive credentials and payloads are omitted from diagnostic output and transport exception chains.

## MQ providers

JMS clients name caller-owned Jakarta JMS `ConnectionFactory` beans. This supports IBM MQ Jakarta clients, ActiveMQ Classic 6 and Artemis without forcing a vendor jar into other SDK consumers. Legacy `javax.jms` clients are incompatible. The native RabbitMQ adapter uses a caller-owned Spring AMQP `ConnectionFactory`.

```yaml
connector:
  sdk:
    mq:
      clients:
        ibm:
          connection-factory-bean: ibmMqConnectionFactory
          destination: ORDER.EVENTS
          receive-timeout: 2s
        active:
          connection-factory-bean: activeMqConnectionFactory
          destination: order.events
          receive-timeout: 2s
    rabbitmq:
      clients:
        rabbit:
          connection-factory-bean: rabbitConnectionFactory
          exchange: order.events
          routing-key: order.created
          queue: order.events.consumer
          publisher-confirms: true
          confirm-timeout: 5s
          receive-timeout: 2s
```

JMS exposes text/byte send, correlation/scalar properties and timed receive. RabbitMQ exposes text/byte send, safe AMQP metadata and timed receive. By default Rabbit publishes wait for correlated broker confirms and reject mandatory returns; this confirms broker acceptance/routing, not consumer processing. Declare topology outside the SDK and configure factory connection/send timeouts and pooling. Factories remain caller-owned.

Both synchronous receive APIs acknowledge before business processing outside a caller-managed transaction. Use transactional listeners or an explicit acknowledgement consumer capability for reliable processing. See [JMS providers and semantics](connector-sdk-mq/README.md) and [RabbitMQ integration](connector-sdk-rabbitmq/README.md).

## Redis

```yaml
connector:
  sdk:
    redis:
      clients:
        cache:
          connection-factory-bean: redisConnectionFactory
          key-prefix: 'orders:'
          max-concurrent-calls: 32
          max-key-bytes: 1024
          max-payload-bytes: 1048576
```

The Redis starter supplies Lettuce; the application supplies a `RedisConnectionFactory` for standalone, Sentinel or Cluster, including ACL/TLS and finite connect/command timeouts. This keeps topology/provider choice independent of SDK operations.

```java
cache.put("123", payload, Duration.ofMinutes(10));
Optional<byte[]> value = cache.get("123");
boolean created = cache.setIfAbsent("dedup:123", token, Duration.ofMinutes(5));
long sequence = cache.increment("sequence");
boolean deleted = cache.delete("123");
```

Values remain bytes; Java object serialization is disabled. Keys include the configured prefix in their size bound. TTL writes and SET NX with expiry are atomic. Persistent writes are explicit. Scalar APIs reject pipeline/queued transaction connections. See [Redis integration](connector-sdk-redis/README.md).

## Runtime and release boundary

Every client has independent fail-fast concurrency limits and safe error codes. Micrometer emits `connector.invocation` with bounded logical labels; add an exporter/bridge in the caller. SDK telemetry failures cannot alter transport results. The SDK adds no retry loops or exactly-once delivery promises; provider reconnect/replay behavior must be configured deliberately. Use an application decorator for business-specific retry/circuit-breaker rules and define idempotency first.

This copy is version `0.1.0-SNAPSHOT`. [Production qualification](docs/production.md) identifies remaining environment checks: actual IBM/ActiveMQ/Rabbit/Redis services, TLS/identity deployment, failure/recovery, load limits and monitoring export. Automated unit/integration tests do not certify every provider or deployment. No publishing destination is configured and no artifacts are uploaded automatically.
