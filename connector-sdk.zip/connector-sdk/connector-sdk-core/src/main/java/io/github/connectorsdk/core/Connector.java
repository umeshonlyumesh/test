package io.github.connectorsdk.core;

/**
 * Common identity and lifecycle for a named connector.
 *
 * <p>Transport capabilities belong on transport-specific interfaces. Implementations must be
 * safe for concurrent use and must document the ownership of transport resources.</p>
 */
public interface Connector extends AutoCloseable {

    /** Returns the configured logical name, never a credential or endpoint address. */
    String name();

    /** Returns the stable transport identifier, for example {@code rest} or {@code grpc}. */
    String type();

    /** Closes SDK-owned resources. Implementations should make this operation idempotent. */
    @Override
    default void close() {
    }
}
