package io.github.connectorsdk.core;

/** Stable error categories; applications should branch on these rather than exception messages. */
public enum ConnectorErrorCode {
    CONFIGURATION,
    UNAVAILABLE,
    TIMEOUT,
    REMOTE_ERROR,
    SATURATED,
    INTERRUPTED,
    CLOSED
}
