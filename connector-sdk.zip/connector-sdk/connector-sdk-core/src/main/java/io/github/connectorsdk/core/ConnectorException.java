package io.github.connectorsdk.core;

import java.util.Objects;

/**
 * A transport failure with stable connector identity and category.
 *
 * <p>Messages supplied by SDK adapters must use logical names and fixed descriptions. They
 * must never include request bodies, credentials, headers, query strings, or raw remote errors.
 * A caller-supplied cause is retained as provided. SDK adapters should use
 * {@link #redactedCause(Throwable)} when transport exceptions may contain sensitive details.</p>
 */
public class ConnectorException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    private final ConnectorErrorCode errorCode;
    private final String connectorType;
    private final String connectorName;

    public ConnectorException(ConnectorErrorCode errorCode, String connectorType,
                              String connectorName, String message) {
        this(errorCode, connectorType, connectorName, message, null);
    }

    public ConnectorException(ConnectorErrorCode errorCode, String connectorType,
                              String connectorName, String message, Throwable cause) {
        super(Objects.requireNonNull(message, "message"), cause);
        this.errorCode = Objects.requireNonNull(errorCode, "errorCode");
        this.connectorType = Objects.requireNonNull(connectorType, "connectorType");
        this.connectorName = Objects.requireNonNull(connectorName, "connectorName");
    }

    public ConnectorErrorCode errorCode() {
        return errorCode;
    }

    public String connectorType() {
        return connectorType;
    }

    public String connectorName() {
        return connectorName;
    }

    /**
     * Retains the failure's class name and stack while removing its message, causal chain and
     * suppressed exceptions. The returned throwable holds no reference to the original failure.
     *
     * <p>This also prevents observation exporters from collecting secrets through exception
     * messages. It intentionally loses protocol details: preserve safe error categories on the
     * enclosing {@code ConnectorException} instead.</p>
     *
     * @param cause potentially sensitive transport failure, or {@code null}
     * @return a sanitized diagnostic throwable, or {@code null}
     */
    public static Throwable redactedCause(Throwable cause) {
        return cause == null ? null : new RedactedCause(cause);
    }

    private static final class RedactedCause extends RuntimeException {
        private static final long serialVersionUID = 1L;

        private RedactedCause(Throwable original) {
            super("Transport failure type: " + original.getClass().getName(), null, false, true);
            setStackTrace(original.getStackTrace());
        }
    }
}
