package io.github.connectorsdk.core;

import java.util.Objects;
import java.util.concurrent.Semaphore;
import java.util.function.Supplier;

/**
 * Bounded, fail-fast execution for one connector instance. There is no waiting queue or retry.
 * Transport adapters remain responsible for deadlines, failure mapping and resource lifecycle.
 */
public final class ConnectorExecutor {
    private final String type;
    private final String name;
    private final Semaphore permits;
    private final InvocationObserver observer;

    public ConnectorExecutor(String type, String name, int maxConcurrency, InvocationObserver observer) {
        this.type = requireIdentifier(type, "type");
        this.name = requireIdentifier(name, "name");
        if (maxConcurrency < 1) {
            throw new IllegalArgumentException("maxConcurrency must be positive");
        }
        this.permits = new Semaphore(maxConcurrency);
        this.observer = Objects.requireNonNull(observer, "observer");
    }

    public <T> T execute(String operation, Supplier<T> invocation) {
        requireIdentifier(operation, "operation");
        Objects.requireNonNull(invocation, "invocation");
        InvocationObservation observation = startObservation(operation);
        if (!permits.tryAcquire()) {
            ConnectorException failure = new ConnectorException(ConnectorErrorCode.SATURATED, type, name,
                    "Connector concurrency limit reached");
            completeObservation(observation, failure);
            throw failure;
        }

        Throwable failure = null;
        try {
            return invocation.get();
        }
        catch (RuntimeException | Error exception) {
            failure = exception;
            throw exception;
        }
        finally {
            permits.release();
            completeObservation(observation, failure);
        }
    }

    private InvocationObservation startObservation(String operation) {
        try {
            InvocationObservation observation = observer.start(type, name, operation);
            return observation != null ? observation : InvocationObservation.NONE;
        }
        catch (Throwable ignored) {
            // Optional telemetry must not fail a transport call or leak a semaphore permit.
            return InvocationObservation.NONE;
        }
    }

    private static void completeObservation(InvocationObservation observation, Throwable failure) {
        try {
            observation.completed(failure);
        }
        catch (Throwable ignored) {
            // Preserve the original transport outcome, including when observation handlers fail.
        }
    }

    private static String requireIdentifier(String value, String field) {
        Objects.requireNonNull(value, field);
        if (value.isBlank()) {
            throw new IllegalArgumentException(field + " must not be blank");
        }
        return value;
    }
}
