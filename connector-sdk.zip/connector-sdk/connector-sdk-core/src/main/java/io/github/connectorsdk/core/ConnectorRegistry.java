package io.github.connectorsdk.core;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Immutable registry. Identity is scoped by transport so {@code rest/orders} and {@code mq/orders} coexist. */
public final class ConnectorRegistry {
    private final Map<Key, Connector> byIdentity;
    private final List<Connector> connectors;

    public ConnectorRegistry(Collection<? extends Connector> connectors) {
        Objects.requireNonNull(connectors, "connectors");
        Map<Key, Connector> registered = new LinkedHashMap<>();
        for (Connector connector : connectors) {
            Objects.requireNonNull(connector, "connector");
            Key key = new Key(requireIdentity(connector.type(), "type"),
                    requireIdentity(connector.name(), "name"));
            if (registered.putIfAbsent(key, connector) != null) {
                throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, key.type(), key.name(),
                        "Multiple connectors registered for transport '" + key.type()
                                + "' and name '" + key.name() + "'");
            }
        }
        this.byIdentity = Collections.unmodifiableMap(registered);
        this.connectors = List.copyOf(registered.values());
    }

    /** Looks up a named connector and verifies the requested transport capability. */
    public <T extends Connector> T require(String type, String name, Class<T> capability) {
        Key key = new Key(requireIdentity(type, "type"), requireIdentity(name, "name"));
        Objects.requireNonNull(capability, "capability");
        Connector connector = byIdentity.get(key);
        if (connector == null) {
            throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, key.type(), key.name(),
                    "No connector registered for transport '" + key.type()
                            + "' and name '" + key.name() + "'");
        }
        if (!capability.isInstance(connector)) {
            throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, key.type(), key.name(),
                    "Connector '" + key.type() + "/" + key.name()
                            + "' does not implement " + capability.getName());
        }
        return capability.cast(connector);
    }

    /** Returns an immutable snapshot in registration order. The registry does not own connector lifecycle. */
    public List<Connector> connectors() {
        return connectors;
    }

    private static String requireIdentity(String value, String field) {
        Objects.requireNonNull(value, field);
        if (value.isBlank() || !value.equals(value.trim())) {
            throw new IllegalArgumentException("Connector " + field + " must be non-blank without surrounding whitespace");
        }
        return value;
    }

    private record Key(String type, String name) {
    }
}
