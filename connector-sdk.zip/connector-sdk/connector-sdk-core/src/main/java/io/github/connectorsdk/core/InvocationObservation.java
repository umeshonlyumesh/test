package io.github.connectorsdk.core;

/** One invocation's observation; {@code failure} is null on success. */
@FunctionalInterface
public interface InvocationObservation {
    InvocationObservation NONE = failure -> { };

    void completed(Throwable failure);
}
