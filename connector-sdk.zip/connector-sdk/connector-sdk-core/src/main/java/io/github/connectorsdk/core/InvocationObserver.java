package io.github.connectorsdk.core;

/**
 * Optional telemetry hook. Values must be bounded logical identifiers, never remote URLs or payloads.
 * Implementations must be thread-safe. Observer failures are isolated from connector execution.
 */
@FunctionalInterface
public interface InvocationObserver {
    InvocationObserver NONE = (type, name, operation) -> InvocationObservation.NONE;

    InvocationObservation start(String type, String name, String operation);
}
