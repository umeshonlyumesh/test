package io.github.connectorsdk.core;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import static org.assertj.core.api.Assertions.assertThat;

class ConnectorExceptionTest {

    @Test
    void redactsMessagesNestedCausesAndSuppressedFailuresWithoutMutatingOriginal() {
        IllegalStateException nested = new IllegalStateException("Bearer nested-secret");
        IOException original = new IOException("https://user:password@example.test?token=url-secret", nested);
        RuntimeException suppressed = new RuntimeException("response-body-secret");
        original.addSuppressed(suppressed);
        StackTraceElement[] originalStack = {
                new StackTraceElement("com.example.Transport", "invoke", "Transport.java", 42)
        };
        original.setStackTrace(originalStack);

        Throwable sanitized = ConnectorException.redactedCause(original);
        assertThat(sanitized).isNotSameAs(original);
        assertThat(sanitized.getMessage()).contains(IOException.class.getName());
        assertThat(sanitized.getCause()).isNull();
        assertThat(sanitized.getSuppressed()).isEmpty();
        assertThat(sanitized.getStackTrace()).containsExactly(originalStack);
        sanitized.addSuppressed(new RuntimeException("later-secret"));
        assertThat(sanitized.getSuppressed()).isEmpty();

        ConnectorException wrapper = new ConnectorException(ConnectorErrorCode.UNAVAILABLE,
                "rest", "orders", "REST transport failed", sanitized);
        StringWriter printed = new StringWriter();
        wrapper.printStackTrace(new PrintWriter(printed));
        assertThat(printed.toString()).contains("java.io.IOException", "Transport.java:42")
                .doesNotContain("password", "url-secret", "nested-secret", "response-body-secret", "later-secret");

        assertThat(original.getMessage()).contains("password");
        assertThat(original.getCause()).isSameAs(nested);
        assertThat(original.getSuppressed()).containsExactly(suppressed);
        assertThat(original.getStackTrace()).containsExactly(originalStack);
    }

    @Test
    void constructorsPreserveCustomConnectorCauseByDefault() {
        RuntimeException customCause = new RuntimeException("caller-defined diagnostics");
        ConnectorException failure = new ConnectorException(ConnectorErrorCode.REMOTE_ERROR,
                "custom", "orders", "Custom connector failed", customCause);
        assertThat(failure.getCause()).isSameAs(customCause);
    }

    @Test
    void redactingAbsentCauseReturnsNull() {
        assertThat(ConnectorException.redactedCause(null)).isNull();
    }
}
