package io.github.connectorsdk.core;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ConnectorExecutorTest {

    @Test
    void rejectsConcurrentCallWithoutRunningItsSupplierAndRecoversAfterRelease() throws Exception {
        List<Throwable> observedFailures = new CopyOnWriteArrayList<>();
        ConnectorExecutor executor = new ConnectorExecutor("rest", "orders", 1,
                (type, name, operation) -> failure -> {
                    if (failure != null) {
                        observedFailures.add(failure);
                    }
                });
        CountDownLatch started = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        AtomicBoolean rejectedSupplierCalled = new AtomicBoolean();
        try (var workers = Executors.newVirtualThreadPerTaskExecutor()) {
            var active = workers.submit(() -> executor.execute("get", () -> {
                started.countDown();
                try {
                    if (!release.await(5, TimeUnit.SECONDS)) {
                        throw new IllegalStateException("Test call was not released");
                    }
                    return "first";
                }
                catch (InterruptedException failure) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException(failure);
                }
            }));
            try {
                assertThat(started.await(5, TimeUnit.SECONDS)).isTrue();
                assertThatExceptionOfType(ConnectorException.class)
                        .isThrownBy(() -> executor.execute("get", () -> {
                            rejectedSupplierCalled.set(true);
                            return "rejected";
                        }))
                        .satisfies(failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.SATURATED));
                assertThat(rejectedSupplierCalled).isFalse();
                assertThat(observedFailures).hasSize(1);
            }
            finally {
                release.countDown();
            }
            assertThat(active.get(5, TimeUnit.SECONDS)).isEqualTo("first");
        }
        assertThat(executor.execute("get", () -> "next")).isEqualTo("next");
    }

    @Test
    void failedCallReleasesCapacityAndReportsOriginalFailure() {
        RuntimeException original = new IllegalStateException("transport failed");
        List<Throwable> failures = new ArrayList<>();
        ConnectorExecutor executor = new ConnectorExecutor("mq", "orders", 1,
                (type, name, operation) -> failures::add);

        assertThatThrownBy(() -> executor.execute("send", () -> { throw original; })).isSameAs(original);
        assertThat(executor.execute("send", () -> "ok")).isEqualTo("ok");
        assertThat(failures).containsExactly(original, null);
    }

    @Test
    void observationFailuresCannotReplaceSuccessFailureOrLeakCapacity() {
        ConnectorExecutor startFailure = new ConnectorExecutor("rest", "orders", 1,
                (type, name, operation) -> { throw new AssertionError("broken start observer"); });
        assertThat(startFailure.execute("get", () -> "ok")).isEqualTo("ok");

        ConnectorExecutor stopFailure = new ConnectorExecutor("rest", "orders", 1,
                (type, name, operation) -> failure -> { throw new AssertionError("broken completion observer"); });
        RuntimeException original = new IllegalStateException("transport failed");
        assertThatThrownBy(() -> stopFailure.execute("get", () -> { throw original; })).isSameAs(original);
        assertThat(stopFailure.execute("get", () -> "ok")).isEqualTo("ok");
        assertThat(stopFailure.execute("get", () -> "still ok")).isEqualTo("still ok");
    }

    @Test
    void transportErrorsAlsoReleaseCapacity() {
        ConnectorExecutor executor = new ConnectorExecutor("grpc", "orders", 1, InvocationObserver.NONE);
        AssertionError original = new AssertionError("transport error");
        assertThatThrownBy(() -> executor.execute("call", () -> { throw original; })).isSameAs(original);
        assertThat(executor.<String>execute("call", () -> null)).isNull();
    }
}
