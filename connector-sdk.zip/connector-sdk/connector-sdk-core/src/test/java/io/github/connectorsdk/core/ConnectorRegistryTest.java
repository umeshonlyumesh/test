package io.github.connectorsdk.core;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ConnectorRegistryTest {

    @Test
    void identityIsScopedByTransportAndSnapshotDoesNotFollowInputMutations() {
        SampleConnector rest = new SampleConnector("rest", "orders");
        SampleConnector mq = new SampleConnector("mq", "orders");
        List<Connector> input = new ArrayList<>(List.of(rest, mq));
        ConnectorRegistry registry = new ConnectorRegistry(input);
        input.clear();

        assertThat(registry.require("rest", "orders", SampleConnector.class)).isSameAs(rest);
        assertThat(registry.require("mq", "orders", Connector.class)).isSameAs(mq);
        assertThat(registry.connectors()).containsExactly(rest, mq);
        assertThatThrownBy(() -> registry.connectors().clear()).isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void rejectsDuplicateIdentity() {
        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> new ConnectorRegistry(List.of(
                        new SampleConnector("rest", "orders"), new SampleConnector("rest", "orders"))))
                .satisfies(failure -> {
                    assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CONFIGURATION);
                    assertThat(failure.connectorType()).isEqualTo("rest");
                    assertThat(failure.connectorName()).isEqualTo("orders");
                })
                .withMessageContaining("Multiple connectors registered");
    }

    @Test
    void reportsMissingAndMismatchedCapabilities() {
        ConnectorRegistry registry = new ConnectorRegistry(List.of(new SampleConnector("rest", "orders")));
        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> registry.require("mq", "orders", Connector.class))
                .withMessageContaining("No connector registered");
        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> registry.require("rest", "orders", OtherConnector.class))
                .withMessageContaining("does not implement")
                .satisfies(failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CONFIGURATION));
    }

    private record SampleConnector(String type, String name) implements Connector { }

    private interface OtherConnector extends Connector { }
}
