package io.github.connectorsdk.grpc;

import org.springframework.context.annotation.Import;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Opt in to gRPC connector auto-configuration. An explicit enabled=false takes precedence. */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(GrpcConnectorEnabled.class)
public @interface EnableGrpcConnector {
}
