package io.github.connectorsdk.grpc;

import io.grpc.ManagedChannelBuilder;

/**
 * Customize authentication interceptors, TLS, load balancing, and channel options.
 * Implementations may use Spring's {@code Ordered} or {@code @Order} to specify order.
 * The application is responsible for the security of custom transport settings.
 */
@FunctionalInterface
public interface GrpcChannelBuilderCustomizer {
    void customize(String clientName, GrpcConnectorProperties.Client properties, ManagedChannelBuilder<?> builder);
}
