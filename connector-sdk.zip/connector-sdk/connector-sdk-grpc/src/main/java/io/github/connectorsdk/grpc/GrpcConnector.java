package io.github.connectorsdk.grpc;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.grpc.CallOptions;
import io.grpc.Deadline;
import io.grpc.ManagedChannel;
import io.grpc.MethodDescriptor;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.ClientCalls;

import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A reusable, synchronous unary gRPC connector. The connector owns its channel.
 * Each call has a finite configured deadline; caller options may shorten it and
 * supply credentials, compression, or other transport-specific call settings.
 * Streaming RPCs are intentionally outside this API.
 */
public final class GrpcConnector implements Connector {
    private final String name;
    private final ManagedChannel channel;
    private final long requestTimeoutNanos;
    private final long shutdownTimeoutNanos;
    private final ConnectorExecutor executor;
    private final AtomicBoolean closed = new AtomicBoolean();

    public GrpcConnector(String name, ManagedChannel channel, Duration requestTimeout,
                         Duration shutdownTimeout, ConnectorExecutor executor) {
        this.name = Objects.requireNonNull(name, "name");
        if (name.isBlank()) {
            throw new IllegalArgumentException("gRPC connector name must not be blank");
        }
        this.channel = Objects.requireNonNull(channel, "channel");
        this.requestTimeoutNanos = positiveNanos(requestTimeout, "requestTimeout");
        this.shutdownTimeoutNanos = positiveNanos(shutdownTimeout, "shutdownTimeout");
        this.executor = Objects.requireNonNull(executor, "executor");
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String type() {
        return "grpc";
    }

    public <ReqT, RespT> RespT unaryCall(MethodDescriptor<ReqT, RespT> method, ReqT request) {
        return unaryCall(method, request, CallOptions.DEFAULT);
    }

    public <ReqT, RespT> RespT unaryCall(MethodDescriptor<ReqT, RespT> method, ReqT request,
                                       CallOptions options) {
        Objects.requireNonNull(method, "method");
        Objects.requireNonNull(request, "request");
        Objects.requireNonNull(options, "options");
        if (method.getType() != MethodDescriptor.MethodType.UNARY) {
            throw new IllegalArgumentException("GrpcConnector supports only unary methods");
        }
        ensureOpen();
        Deadline configuredDeadline = Deadline.after(requestTimeoutNanos, TimeUnit.NANOSECONDS);
        Deadline requestedDeadline = options.getDeadline();
        CallOptions boundedOptions = options.withDeadline(requestedDeadline == null
                ? configuredDeadline : configuredDeadline.minimum(requestedDeadline));
        return executor.execute(method.getFullMethodName(), () -> {
            ensureOpen();
            try {
                return ClientCalls.blockingUnaryCall(channel, method, boundedOptions, request);
            } catch (StatusRuntimeException exception) {
                throw mapFailure(exception);
            }
        });
    }

    public boolean isClosed() {
        return closed.get();
    }

    /** Waits at most the configured shutdown timeout, then cancels remaining calls. */
    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        channel.shutdown();
        try {
            if (!channel.awaitTermination(shutdownTimeoutNanos, TimeUnit.NANOSECONDS)) {
                channel.shutdownNow();
            }
        } catch (InterruptedException exception) {
            channel.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private void ensureOpen() {
        if (closed.get()) {
            throw new ConnectorException(ConnectorErrorCode.CLOSED, type(), name,
                    "gRPC connector is closed");
        }
    }

    private ConnectorException mapFailure(StatusRuntimeException exception) {
        Status.Code status = exception.getStatus().getCode();
        ConnectorErrorCode code = switch (status) {
            case DEADLINE_EXCEEDED -> ConnectorErrorCode.TIMEOUT;
            case UNAVAILABLE -> ConnectorErrorCode.UNAVAILABLE;
            case RESOURCE_EXHAUSTED -> ConnectorErrorCode.SATURATED;
            case CANCELLED -> Thread.currentThread().isInterrupted()
                    ? ConnectorErrorCode.INTERRUPTED : ConnectorErrorCode.REMOTE_ERROR;
            default -> ConnectorErrorCode.REMOTE_ERROR;
        };
        // Observation handlers and application stack traces must not receive server-controlled
        // descriptions/trailers, which can include credentials, request data, or response details.
        StatusRuntimeException sanitizedCause = Status.fromCode(status).asRuntimeException();
        sanitizedCause.setStackTrace(exception.getStackTrace());
        return new ConnectorException(code, type(), name,
                "gRPC call failed with status " + status.name(), sanitizedCause);
    }

    private static long positiveNanos(Duration duration, String field) {
        Objects.requireNonNull(duration, field);
        if (duration.isNegative() || duration.isZero()) {
            throw new IllegalArgumentException(field + " must be positive");
        }
        try {
            return duration.toNanos();
        } catch (ArithmeticException exception) {
            throw new IllegalArgumentException(field + " exceeds the supported duration", exception);
        }
    }
}
