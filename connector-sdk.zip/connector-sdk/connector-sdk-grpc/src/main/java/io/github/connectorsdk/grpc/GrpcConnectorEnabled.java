package io.github.connectorsdk.grpc;

/** Internal activation marker imported by {@link EnableGrpcConnector}. */
public final class GrpcConnectorEnabled {
}
