package io.github.connectorsdk.grpc;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

@ConfigurationProperties("connector.sdk.grpc")
public class GrpcConnectorProperties {
    private Boolean enabled;
    private Map<String, Client> clients = new LinkedHashMap<>();

    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public Map<String, Client> getClients() { return clients; }
    public void setClients(Map<String, Client> clients) { this.clients = clients; }

    public void validate() {
        if (clients == null || clients.isEmpty()) {
            throw new IllegalArgumentException("Enabled gRPC connector requires connector.sdk.grpc.clients");
        }
        clients.forEach((name, client) -> {
            if (name == null || !name.matches("[a-zA-Z][a-zA-Z0-9._-]{0,63}")) {
                throw new IllegalArgumentException("gRPC client names must begin with a letter and contain at most 64 letters, digits, '.', '_' or '-'");
            }
            if (client == null) {
                throw new IllegalArgumentException("gRPC client '" + name + "' requires configuration");
            }
            client.validate(name);
        });
    }

    public static class Client {
        private String target;
        private Duration requestTimeout = Duration.ofSeconds(5);
        private Duration shutdownTimeout = Duration.ofSeconds(5);
        private int maxInboundMessageSize = 4 * 1024 * 1024;
        private int maxConcurrentCalls = 64;
        private boolean allowPlaintext;

        public String getTarget() { return target; }
        public void setTarget(String target) { this.target = target; }
        public Duration getRequestTimeout() { return requestTimeout; }
        public void setRequestTimeout(Duration requestTimeout) { this.requestTimeout = requestTimeout; }
        public Duration getShutdownTimeout() { return shutdownTimeout; }
        public void setShutdownTimeout(Duration shutdownTimeout) { this.shutdownTimeout = shutdownTimeout; }
        public int getMaxInboundMessageSize() { return maxInboundMessageSize; }
        public void setMaxInboundMessageSize(int maxInboundMessageSize) { this.maxInboundMessageSize = maxInboundMessageSize; }
        public int getMaxConcurrentCalls() { return maxConcurrentCalls; }
        public void setMaxConcurrentCalls(int maxConcurrentCalls) { this.maxConcurrentCalls = maxConcurrentCalls; }
        public boolean isAllowPlaintext() { return allowPlaintext; }
        public void setAllowPlaintext(boolean allowPlaintext) { this.allowPlaintext = allowPlaintext; }

        public void validate(String name) {
            String prefix = "gRPC client '" + name + "': ";
            String address = target != null && target.startsWith("dns:///") ? target.substring(7) : target;
            URI endpoint;
            try {
                endpoint = new URI("grpc://" + (address == null ? "" : address));
            } catch (URISyntaxException exception) {
                throw new IllegalArgumentException(prefix + "target must be host:port, [IPv6]:port or dns:///host:port");
            }
            if (endpoint.getHost() == null || endpoint.getHost().isBlank()
                    || endpoint.getRawUserInfo() != null || endpoint.getRawQuery() != null
                    || endpoint.getRawFragment() != null || !endpoint.getRawPath().isEmpty()) {
                throw new IllegalArgumentException(prefix + "target must be host:port, [IPv6]:port or dns:///host:port");
            }
            int port = endpoint.getPort();
            if (port < 1 || port > 65535) {
                throw new IllegalArgumentException(prefix + "target port must be between 1 and 65535");
            }
            validateDuration(requestTimeout, prefix + "request-timeout");
            validateDuration(shutdownTimeout, prefix + "shutdown-timeout");
            if (maxInboundMessageSize < 1) {
                throw new IllegalArgumentException(prefix + "max-inbound-message-size must be positive");
            }
            if (maxConcurrentCalls < 1) {
                throw new IllegalArgumentException(prefix + "max-concurrent-calls must be positive");
            }
        }

        private static void validateDuration(Duration duration, String field) {
            if (duration == null || duration.isZero() || duration.isNegative()) {
                throw new IllegalArgumentException(field + " must be positive");
            }
            try {
                duration.toNanos();
            } catch (ArithmeticException exception) {
                throw new IllegalArgumentException(field + " exceeds the supported duration", exception);
            }
        }
    }
}
