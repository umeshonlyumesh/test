package io.github.connectorsdk.grpc.autoconfigure;

import io.github.connectorsdk.grpc.GrpcChannelBuilderCustomizer;
import io.github.connectorsdk.grpc.GrpcConnector;
import io.github.connectorsdk.grpc.GrpcConnectorEnabled;
import io.github.connectorsdk.grpc.GrpcConnectorProperties;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.github.connectorsdk.spring.ConnectorBeanValidator;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.env.Environment;

@AutoConfiguration(after = ConnectorRuntimeAutoConfiguration.class)
@ConditionalOnClass({ManagedChannel.class, ConnectorExecutorFactory.class})
@ConditionalOnProperty(prefix = "connector.sdk.grpc", name = "enabled", havingValue = "true", matchIfMissing = true)
@Conditional(GrpcConnectorAutoConfiguration.EnabledCondition.class)
@EnableConfigurationProperties(GrpcConnectorProperties.class)
public class GrpcConnectorAutoConfiguration {
    @Bean
    ConnectorBeanValidator grpcConnectorBeanValidator(ConfigurableListableBeanFactory factory, GrpcConnectorProperties properties) {
        return new ConnectorBeanValidator(factory, properties.getClients().keySet().stream()
                .map(name -> new ConnectorBeanValidator.Expectation("grpcConnector." + name, "grpc", name, GrpcConnector.class))
                .toList());
    }

    @Bean
    static BeanDefinitionRegistryPostProcessor grpcConnectorBeanRegistrar(Environment environment) {
        GrpcConnectorProperties properties = Binder.get(environment)
                .bind("connector.sdk.grpc", Bindable.of(GrpcConnectorProperties.class))
                .orElseGet(GrpcConnectorProperties::new);
        properties.validate();
        return new GrpcBeanRegistrar(properties);
    }

    static final class EnabledCondition extends AnyNestedCondition {
        EnabledCondition() { super(ConfigurationPhase.REGISTER_BEAN); }

        @ConditionalOnBean(GrpcConnectorEnabled.class)
        static class AnnotationEnabled { }

        @ConditionalOnProperty(prefix = "connector.sdk.grpc", name = "enabled", havingValue = "true")
        static class PropertyEnabled { }
    }

    private static final class GrpcBeanRegistrar implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware {
        private final GrpcConnectorProperties properties;
        private ConfigurableListableBeanFactory beanFactory;

        private GrpcBeanRegistrar(GrpcConnectorProperties properties) { this.properties = properties; }

        @Override
        public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
            this.beanFactory = (ConfigurableListableBeanFactory) beanFactory;
        }

        @Override
        public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            properties.getClients().forEach((name, client) -> {
                String beanName = "grpcConnector." + name;
                if (registry.containsBeanDefinition(beanName) || registry.isAlias(beanName)
                        || beanFactory.containsSingleton(beanName)) {
                    return;
                }
                RootBeanDefinition definition = new RootBeanDefinition(GrpcConnector.class);
                definition.setInstanceSupplier(() -> createConnector(name, client));
                definition.setDestroyMethodName("close");
                registry.registerBeanDefinition(beanName, definition);
            });
        }

        private GrpcConnector createConnector(String name, GrpcConnectorProperties.Client client) {
            // Channel credentials are secure by default. Plaintext requires explicit opt-in.
            String target = client.getTarget().startsWith("dns:///")
                    ? client.getTarget() : "dns:///" + client.getTarget();
            ManagedChannelBuilder<?> builder = ManagedChannelBuilder.forTarget(target)
                    .maxInboundMessageSize(client.getMaxInboundMessageSize());
            if (client.isAllowPlaintext()) {
                builder.usePlaintext();
            } else {
                builder.useTransportSecurity();
            }
            beanFactory.getBeanProvider(GrpcChannelBuilderCustomizer.class).orderedStream()
                    .forEach(customizer -> customizer.customize(name, client, builder));
            builder.disableRetry();
            var executor = beanFactory.getBean(ConnectorExecutorFactory.class)
                    .create("grpc", name, client.getMaxConcurrentCalls());
            ManagedChannel channel = builder.build();
            try {
                return new GrpcConnector(name, channel, client.getRequestTimeout(), client.getShutdownTimeout(), executor);
            } catch (RuntimeException | Error exception) {
                channel.shutdownNow();
                throw exception;
            }
        }

        @Override
        public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) { }
    }
}
