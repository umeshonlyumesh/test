package io.github.connectorsdk.grpc;

import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.grpc.autoconfigure.GrpcConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class GrpcConnectorAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                    ConnectorSupportAutoConfiguration.class, GrpcConnectorAutoConfiguration.class));

    @Test
    void classpathPresenceDoesNotEnableGrpc() {
        runner.withPropertyValues("connector.sdk.grpc.clients.orders.target=localhost:50051")
                .run(context -> {
                    assertThat(context).hasNotFailed().doesNotHaveBean(GrpcConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).isEmpty();
                });
    }

    @Test
    void absentGrpcDependencyDoesNotCreateOptionalTransportBeans() {
        runner.withClassLoader(new FilteredClassLoader("io.grpc"))
                .withPropertyValues("connector.sdk.grpc.enabled=true")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(GrpcConnector.class));
    }

    @Test
    void annotationActivatesOneNamedInjectableClientAndRegistry() {
        runner.withUserConfiguration(AnnotationEnabled.class)
                .withPropertyValues("connector.sdk.grpc.clients.orders.target=localhost:50051")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(GrpcConnector.class)
                            .hasBean("grpcConnector.orders");
                    GrpcConnector connector = context.getBean(GrpcConnector.class);
                    assertThat(connector.name()).isEqualTo("orders");
                    assertThat(context.getBean(ConnectorRegistry.class)
                            .require("grpc", "orders", GrpcConnector.class)).isSameAs(connector);
                });
    }

    @Test
    void propertyCanActivateMultipleNamedClientsWithoutAnnotation() {
        runner.withPropertyValues("connector.sdk.grpc.enabled=true",
                        "connector.sdk.grpc.clients.orders.target=localhost:50051",
                        "connector.sdk.grpc.clients.billing.target=localhost:50052")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context.getBeansOfType(GrpcConnector.class))
                            .containsOnlyKeys("grpcConnector.orders", "grpcConnector.billing");
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(2);
                });
    }

    @Test
    void explicitFalseDisablesAnnotationAndSkipsValidationOfDisabledTransport() {
        runner.withUserConfiguration(AnnotationEnabled.class)
                .withPropertyValues("connector.sdk.grpc.enabled=false",
                        "connector.sdk.grpc.clients.orders.target=invalid")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(GrpcConnector.class));
    }

    @Test
    void enabledClientFailsStartupWithActionableValidation() {
        runner.withPropertyValues("connector.sdk.grpc.enabled=true")
                .run(context -> assertThat(context).hasFailed());
        runner.withPropertyValues("connector.sdk.grpc.enabled=true",
                        "connector.sdk.grpc.clients.orders.target=localhost:50051",
                        "connector.sdk.grpc.clients.orders.max-concurrent-calls=0")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasRootCauseMessage(
                            "gRPC client 'orders': max-concurrent-calls must be positive");
                });
    }

    @Test
    void customNamedClientAliasTakesPrecedence() {
        runner.withUserConfiguration(CustomNamedClient.class)
                .withPropertyValues("connector.sdk.grpc.enabled=true",
                        "connector.sdk.grpc.clients.orders.target=localhost:50051")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(GrpcConnector.class);
                    assertThat(context.getBean("grpcConnector.orders")).isSameAs(
                            context.getBean(CustomNamedClient.class).connector);
                });
    }

    @Test
    void customizerRunsOncePerChannelAndSpringClosesAllOwnedChannels() {
        AtomicInteger customizations = new AtomicInteger();
        GrpcConnector[] captured = new GrpcConnector[1];
        runner.withBean(GrpcChannelBuilderCustomizer.class,
                        () -> (name, properties, builder) -> customizations.incrementAndGet())
                .withPropertyValues("connector.sdk.grpc.enabled=true",
                        "connector.sdk.grpc.clients.orders.target=localhost:50051")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    captured[0] = context.getBean(GrpcConnector.class);
                    assertThat(customizations.get()).isEqualTo(1);
                    assertThat(captured[0].isClosed()).isFalse();
                });
        assertThat(captured[0].isClosed()).isTrue();
    }

    @Configuration(proxyBeanMethods = false)
    @EnableGrpcConnector
    static class AnnotationEnabled { }

    @Configuration(proxyBeanMethods = false)
    static class CustomNamedClient {
        private final GrpcConnector connector = mock(GrpcConnector.class);

        CustomNamedClient() {
            org.mockito.Mockito.when(connector.name()).thenReturn("orders");
            org.mockito.Mockito.when(connector.type()).thenReturn("grpc");
        }

        @Bean({"customOrders", "grpcConnector.orders"})
        GrpcConnector customConnector() { return connector; }
    }
}
