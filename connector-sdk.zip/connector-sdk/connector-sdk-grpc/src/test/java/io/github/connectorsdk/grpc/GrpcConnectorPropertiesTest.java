package io.github.connectorsdk.grpc;

import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GrpcConnectorPropertiesTest {
    @Test
    void requiresExplicitPlaintextOptInAndAcceptsSupportedTargets() {
        var client = new GrpcConnectorProperties.Client();
        assertThat(client.isAllowPlaintext()).isFalse();
        for (String target : new String[]{"localhost:50051", "dns:///service.example:443", "[::1]:50051"}) {
            client.setTarget(target);
            client.validate("example");
        }
    }

    @Test
    void rejectsInvalidAddressesPortsAndUnboundedDurations() {
        for (String target : new String[]{"localhost", "http://localhost:80", "localhost:0", "localhost:65536", "user:secret@host:443"}) {
            var client = new GrpcConnectorProperties.Client();
            client.setTarget(target);
            assertThatThrownBy(() -> client.validate("example")).isInstanceOf(IllegalArgumentException.class);
        }
        var client = new GrpcConnectorProperties.Client();
        client.setTarget("localhost:50051");
        client.setRequestTimeout(Duration.ZERO);
        assertThatThrownBy(() -> client.validate("example")).hasMessageContaining("request-timeout");
        client.setRequestTimeout(Duration.ofSeconds(Long.MAX_VALUE));
        assertThatThrownBy(() -> client.validate("example")).hasMessageContaining("duration");
    }
}
