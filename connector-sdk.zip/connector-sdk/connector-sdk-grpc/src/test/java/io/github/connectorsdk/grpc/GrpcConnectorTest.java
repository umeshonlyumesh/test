package io.github.connectorsdk.grpc;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import io.grpc.CallOptions;
import io.grpc.ManagedChannel;
import io.grpc.MethodDescriptor;
import io.grpc.Server;
import io.grpc.ServerServiceDefinition;
import io.grpc.Status;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.stub.ServerCalls;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GrpcConnectorTest {
    private static final MethodDescriptor<String, String> ECHO = method("Echo");
    private static final MethodDescriptor<String, String> FAIL = method("Fail");
    private static final MethodDescriptor<String, String> HOLD = method("Hold");
    private Server server;
    private ManagedChannel channel;
    private GrpcConnector connector;
    private final CountDownLatch holdStarted = new CountDownLatch(1);
    private final AtomicInteger echoCalls = new AtomicInteger();

    @BeforeEach
    void startTransport() throws IOException {
        String serverName = InProcessServerBuilder.generateName();
        server = InProcessServerBuilder.forName(serverName).directExecutor()
                .addService(ServerServiceDefinition.builder("sdk.Test")
                        .addMethod(ECHO, ServerCalls.asyncUnaryCall((request, observer) -> {
                            echoCalls.incrementAndGet();
                            observer.onNext("reply:" + request);
                            observer.onCompleted();
                        }))
                        .addMethod(FAIL, ServerCalls.asyncUnaryCall((request, observer) ->
                                observer.onError(Status.PERMISSION_DENIED.withDescription("secret-server-details").asRuntimeException())))
                        .addMethod(HOLD, ServerCalls.asyncUnaryCall((request, observer) -> holdStarted.countDown()))
                        .build()).build().start();
        channel = InProcessChannelBuilder.forName(serverName).directExecutor().build();
        connector = connector(Duration.ofMillis(150), 2);
    }

    @AfterEach
    void stopTransport() throws InterruptedException {
        connector.close();
        channel.shutdownNow();
        server.shutdownNow();
        assertThat(channel.awaitTermination(2, TimeUnit.SECONDS)).isTrue();
        assertThat(server.awaitTermination(2, TimeUnit.SECONDS)).isTrue();
    }

    @Test
    void reusesChannelForTypedUnaryCallsWithoutDuplicatingSuccessfulRequests() {
        assertThat(connector.unaryCall(ECHO, "one")).isEqualTo("reply:one");
        assertThat(connector.unaryCall(ECHO, "two")).isEqualTo("reply:two");
        assertThat(echoCalls.get()).isEqualTo(2);
        assertThat(connector.name()).isEqualTo("test");
        assertThat(connector.type()).isEqualTo("grpc");
    }

    @Test
    void enforcesDefaultFiniteDeadline() {
        assertError(ConnectorErrorCode.TIMEOUT, () -> connector.unaryCall(HOLD, "request"));
    }

    @Test
    void callerCanShortenDeadlineButCannotRemoveConfiguredDeadline() {
        assertError(ConnectorErrorCode.TIMEOUT, () -> connector.unaryCall(HOLD, "request",
                CallOptions.DEFAULT.withDeadlineAfter(5, TimeUnit.MILLISECONDS)));
        assertError(ConnectorErrorCode.TIMEOUT, () -> connector.unaryCall(HOLD, "request",
                CallOptions.DEFAULT.withDeadlineAfter(1, TimeUnit.DAYS)));
    }

    @Test
    void mapsRemoteFailureWithoutCopyingSensitiveServerDescription() {
        assertThatThrownBy(() -> connector.unaryCall(FAIL, "secret-request"))
                .isInstanceOfSatisfying(ConnectorException.class, error -> {
                    assertThat(error.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR);
                    assertThat(error.connectorType()).isEqualTo("grpc");
                    assertThat(error.connectorName()).isEqualTo("test");
                    assertThat(error.getMessage()).contains("PERMISSION_DENIED")
                            .doesNotContain("secret-server-details", "secret-request");
                    StringWriter stackTrace = new StringWriter();
                    error.printStackTrace(new PrintWriter(stackTrace));
                    assertThat(stackTrace.toString()).doesNotContain("secret-server-details", "secret-request");
                    assertThat(error.getCause()).isInstanceOfSatisfying(io.grpc.StatusRuntimeException.class,
                            cause -> {
                                assertThat(cause.getStatus().getDescription()).isNull();
                                assertThat(cause.getTrailers()).isNull();
                            });
                });
    }

    @Test
    void rejectsStreamingMethodInsteadOfClaimingStreamingSupport() {
        var streaming = ECHO.toBuilder().setType(MethodDescriptor.MethodType.SERVER_STREAMING).build();
        assertThatThrownBy(() -> connector.unaryCall(streaming, "request"))
                .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("unary");
    }

    @Test
    void failsFastWhenConcurrencyLimitIsReached() throws Exception {
        connector = connector(Duration.ofSeconds(1), 1);
        try (var tasks = Executors.newVirtualThreadPerTaskExecutor()) {
            var pending = tasks.submit(() -> connector.unaryCall(HOLD, "first"));
            assertThat(holdStarted.await(2, TimeUnit.SECONDS)).isTrue();
            assertError(ConnectorErrorCode.SATURATED, () -> connector.unaryCall(ECHO, "second"));
            assertThat(echoCalls.get()).isZero();
            connector.close();
            assertThatThrownBy(() -> pending.get(2, TimeUnit.SECONDS)).hasCauseInstanceOf(ConnectorException.class);
        }
    }

    @Test
    void closeIsIdempotentAndRejectsFutureRequests() {
        connector.close();
        connector.close();
        assertThat(connector.isClosed()).isTrue();
        assertThat(channel.isShutdown()).isTrue();
        assertError(ConnectorErrorCode.CLOSED, () -> connector.unaryCall(ECHO, "request"));
    }

    private GrpcConnector connector(Duration timeout, int concurrency) {
        return new GrpcConnector("test", channel, timeout, Duration.ofMillis(20),
                new ConnectorExecutor("grpc", "test", concurrency, InvocationObserver.NONE));
    }

    private static void assertError(ConnectorErrorCode code, Runnable call) {
        assertThatThrownBy(call::run).isInstanceOfSatisfying(ConnectorException.class,
                error -> assertThat(error.errorCode()).isEqualTo(code));
    }

    private static MethodDescriptor<String, String> method(String name) {
        MethodDescriptor.Marshaller<String> marshaller = new MethodDescriptor.Marshaller<>() {
            @Override
            public InputStream stream(String value) {
                return new ByteArrayInputStream(value.getBytes(StandardCharsets.UTF_8));
            }

            @Override
            public String parse(InputStream stream) {
                try {
                    return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
                } catch (IOException exception) {
                    throw new IllegalStateException(exception);
                }
            }
        };
        return MethodDescriptor.<String, String>newBuilder()
                .setType(MethodDescriptor.MethodType.UNARY)
                .setFullMethodName(MethodDescriptor.generateFullMethodName("sdk.Test", name))
                .setRequestMarshaller(marshaller).setResponseMarshaller(marshaller).build();
    }
}
