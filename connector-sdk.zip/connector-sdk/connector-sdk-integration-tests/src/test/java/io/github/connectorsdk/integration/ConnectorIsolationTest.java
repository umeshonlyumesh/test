package io.github.connectorsdk.integration;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.redis.EnableRedisConnector;
import io.github.connectorsdk.redis.RedisConnector;
import io.github.connectorsdk.rabbitmq.RabbitMqConnector;
import io.github.connectorsdk.mq.EnableMqConnector;
import io.github.connectorsdk.mq.MqConnector;
import io.github.connectorsdk.rest.EnableRestConnector;
import io.github.connectorsdk.rest.RestConnector;
import jakarta.jms.ConnectionFactory;
import java.lang.reflect.Proxy;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import static org.assertj.core.api.Assertions.*;

/** Exercises Boot's published AutoConfiguration.imports with every transport on the classpath. */
class ConnectorIsolationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner();

    @Test void fullClasspathWithoutOptInHasNoConnectorBeans() {
        runner.withUserConfiguration(PlainApp.class).run(context -> {
            assertThat(context).hasNotFailed();
            assertThat(context.getBeansOfType(Connector.class)).isEmpty();
            assertThat(context.getBean(ConnectorRegistry.class).connectors()).isEmpty();
        });
    }
    @Test void restAnnotationDoesNotActivateRedisOrMq() {
        runner.withUserConfiguration(RestApp.class)
                .withPropertyValues("connector.sdk.rest.clients.orders.base-url=https://orders.example",
                        "connector.sdk.redis.clients.broken.max-concurrent-calls=0",
                        "connector.sdk.mq.clients.broken.receive-timeout=0ms")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RestConnector.class)
                            .doesNotHaveBean(RedisConnector.class).doesNotHaveBean(MqConnector.class)
                            .doesNotHaveBean(RabbitMqConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(1);
                });
    }
    @Test void allAnnotationsProduceOnlyConfiguredClients() {
        runner.withUserConfiguration(AllApp.class)
                .withBean("testRedisFactory", org.springframework.data.redis.connection.RedisConnectionFactory.class,
                        () -> (org.springframework.data.redis.connection.RedisConnectionFactory) Proxy.newProxyInstance(
                                org.springframework.data.redis.connection.RedisConnectionFactory.class.getClassLoader(),
                                new Class<?>[]{org.springframework.data.redis.connection.RedisConnectionFactory.class},
                                (proxy, method, args) -> { throw new UnsupportedOperationException("Startup must not connect to Redis"); }))
                .withBean("testFactory", ConnectionFactory.class, () -> (ConnectionFactory) Proxy.newProxyInstance(
                        ConnectionFactory.class.getClassLoader(), new Class<?>[]{ConnectionFactory.class},
                        (proxy, method, args) -> { throw new UnsupportedOperationException("Startup must not connect to JMS"); }))
                .withPropertyValues("connector.sdk.rest.clients.orders.base-url=https://orders.example",
                        "connector.sdk.redis.clients.inventory.connection-factory-bean=testRedisFactory",
                        "connector.sdk.mq.clients.events.connection-factory-bean=testFactory",
                        "connector.sdk.mq.clients.events.destination=events")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RestConnector.class)
                            .hasSingleBean(RedisConnector.class).hasSingleBean(MqConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(3);
                });
    }
    @Test void explicitKillSwitchesOverrideEveryAnnotation() {
        runner.withUserConfiguration(AllApp.class).withPropertyValues("connector.sdk.rest.enabled=false",
                        "connector.sdk.redis.enabled=false", "connector.sdk.mq.enabled=false", "connector.sdk.rabbitmq.enabled=false")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context.getBeansOfType(Connector.class)).isEmpty();
                });
    }
    @Test void restStillWorksWithRedisAndMessagingAbsent() {
        runner.withClassLoader(new FilteredClassLoader("org.springframework.data.redis", "org.springframework.amqp", "jakarta.jms", "org.springframework.jms"))
                .withUserConfiguration(RestApp.class)
                .withPropertyValues("connector.sdk.rest.clients.orders.base-url=https://orders.example")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RestConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(1);
                });
    }
    @Test void newConnectorTypeRequiresNoCoreChanges() {
        runner.withUserConfiguration(CustomApp.class).run(context -> {
            assertThat(context).hasNotFailed();
            var local = context.getBean(ConnectorRegistry.class).require("custom", "local", LocalConnector.class);
            assertThat(local.echo("hello")).isEqualTo("hello");
            assertThat(context.getBeansOfType(Connector.class)).hasSize(1);
        });
    }

    @Configuration(proxyBeanMethods = false) @EnableAutoConfiguration static class PlainApp { }
    @Configuration(proxyBeanMethods = false) @EnableAutoConfiguration @EnableRestConnector static class RestApp { }
    @Configuration(proxyBeanMethods = false) @EnableAutoConfiguration @EnableRestConnector @EnableRedisConnector
    @EnableMqConnector static class AllApp { }
    @Configuration(proxyBeanMethods = false) @EnableAutoConfiguration @Import(LocalPlugin.class) static class CustomApp { }
    @Configuration(proxyBeanMethods = false) static class LocalPlugin {
        @Bean LocalConnector localConnector() { return new LocalConnector(); }
    }
    static class LocalConnector implements Connector {
        @Override public String name() { return "local"; }
        @Override public String type() { return "custom"; }
        String echo(String text) { return text; }
    }
}
