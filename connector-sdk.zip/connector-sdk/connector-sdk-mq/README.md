# Jakarta JMS / MQ connector

This adapter supports Jakarta JMS text and byte messages with synchronous send and bounded synchronous receive. Supply a vendor's Jakarta JMS `ConnectionFactory` bean for IBM MQ, Artemis, or another compatible broker. The SDK owns its private `JmsTemplate`; the application owns and configures the factory, credentials, TLS, pooling, reconnection policy, and provider connection/send deadlines.

Add `connector-sdk-mq-spring-boot-starter` and the broker provider's Jakarta client dependency to the application. The module does not transitively install an MQ vendor. Legacy `javax.jms` factories are incompatible with the Jakarta API.

```java
@SpringBootApplication
@EnableMqConnector
public class ConsumerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ConsumerApplication.class, args);
    }
}
```

```yaml
connector:
  sdk:
    mq:
      clients:
        orders:
          connection-factory-bean: ordersConnectionFactory
          destination: ORDERS.REQUEST
          pub-sub-domain: false
          receive-timeout: 2s
          time-to-live: 30s
          max-concurrent-calls: 32
          max-message-bytes: 16777216
```

The factory bean name is required even when only one factory exists. Each client registers `mqConnector.<name>`, suitable for injection with `@Qualifier("mqConnector.orders")` or lookup through `ConnectorRegistry`. An application-defined bean or alias with that name takes precedence. `connector.sdk.mq.enabled=true` also activates the adapter without an annotation. An explicit `enabled=false` overrides the annotation and skips MQ configuration validation and connector creation.

```java
@Service
public class OrderSender {
    private final MqConnector connector;

    public OrderSender(@Qualifier("mqConnector.orders") MqConnector connector) {
        this.connector = connector;
    }

    public void send(String json, String requestId) {
        connector.sendText(json, new MqSendOptions(requestId, Map.of("schemaVersion", 1)));
    }
}
```

`sendBytes(byte[])` copies the payload. `receive()` returns `Optional<MqMessage>` and returns empty after the receive timeout. Text bodies are UTF-8; returned byte arrays and header maps are immutable snapshots. Only scalar JMS properties are accepted; reserved selector keywords and provider property namespaces cannot be set through `MqSendOptions`. ObjectMessage deserialization is unsupported. The body limit applies to send and receive, and received messages have at most 128 properties. Diagnostic summaries omit message identifiers, correlation identifiers, body content, property names, and property values.

Outside an existing caller-managed JMS transaction, receive uses `AUTO_ACKNOWLEDGE`. A received message is acknowledged before application processing, including when subsequent decoding fails. `JmsTemplate` can participate in an existing transaction associated with the supplied factory; the SDK does not start transactions. This API does not provide manual acknowledgement, durable subscriptions, listener containers, dead-letter routing, exactly-once delivery, or automatic retries. Use the broker's transactional listener/container infrastructure for processing with redelivery requirements. Topic receives create transient subscribers and only observe messages sent while subscribed. See [Spring's JmsTemplate contract](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/jms/core/JmsTemplate.html) for transaction participation and connection/session pooling guidance.

`receive-timeout` must be at least one millisecond; zero would mean an indefinite JMS receive and is rejected. `time-to-live=0s` means no expiry; positive TTL values must be at least one millisecond. The timeout bounds the receive wait, while provider connection and send deadlines require factory configuration. Concurrency limits and standardized JMS resource allocation failures use `SATURATED`; the SDK does not queue calls. Other provider failures use `REMOTE_ERROR` with redacted diagnostic causes. Closing a connector rejects new calls with `CLOSED` and lets in-flight operations finish without closing the caller's factory.

The embedded Artemis tests exercise actual queue send/receive, UTF-8 and binary bodies, header propagation, receive timeout, unsupported bodies, size limits, and caller-owned factory reuse after connector closure.
