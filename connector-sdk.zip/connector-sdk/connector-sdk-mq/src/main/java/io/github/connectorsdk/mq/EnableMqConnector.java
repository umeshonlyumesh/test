package io.github.connectorsdk.mq;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

/** Opt in to Jakarta JMS/MQ connector auto-configuration. Explicit enabled=false takes precedence. */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(MqConnectorEnabled.class)
public @interface EnableMqConnector {
}
