package io.github.connectorsdk.mq;

import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import jakarta.jms.BytesMessage;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

/**
 * Concurrent Jakarta JMS queue/topic adapter with synchronous send and bounded receive.
 *
 * <p>Outside an existing caller-managed JMS transaction, receive uses AUTO_ACKNOWLEDGE and is
 * not a reliable manual-acknowledgement consumer API. A message is acknowledged before
 * application processing and may already be acknowledged if decoding fails. JmsTemplate can
 * participate in an existing transaction associated with the supplied factory; this adapter
 * does not start transactions. Use a transactional listener/container for redelivery workloads.
 * Topics use transient subscribers; they do not retain messages sent before a receive begins.</p>
 *
 * <p>The caller owns the ConnectionFactory. Broker connection and send deadlines must be configured
 * on that provider: receive-timeout bounds the receive wait, not connection establishment.
 * No retries, transactions, or background threads are introduced by this adapter.</p>
 */
public final class MqConnector implements Connector {
    private final String name;
    private final String destination;
    private final JmsTemplate template;
    private final ConnectorExecutor executor;
    private final int maxMessageBytes;
    private final AtomicBoolean closed = new AtomicBoolean();

    MqConnector(String name, String destination, JmsTemplate template,
                       ConnectorExecutor executor, int maxMessageBytes) {
        this.name = Objects.requireNonNull(name, "name");
        this.destination = Objects.requireNonNull(destination, "destination");
        this.template = Objects.requireNonNull(template, "template");
        this.executor = Objects.requireNonNull(executor, "executor");
        if (name.isBlank() || destination.isBlank() || maxMessageBytes < 1) {
            throw new IllegalArgumentException("Connector name, destination and positive message limit are required");
        }
        this.maxMessageBytes = maxMessageBytes;
    }

    /** Creates a connector without opening a broker connection or owning the supplied factory. */
    public static MqConnector create(String name, ConnectionFactory connectionFactory,
                                     MqConnectorProperties.Client client, ConnectorExecutor executor) {
        Objects.requireNonNull(connectionFactory, "connectionFactory");
        Objects.requireNonNull(client, "client").validate(name);
        JmsTemplate template = new JmsTemplate(connectionFactory);
        template.setPubSubDomain(client.isPubSubDomain());
        template.setSessionTransacted(false);
        template.setSessionAcknowledgeMode(Session.AUTO_ACKNOWLEDGE);
        template.setReceiveTimeout(client.getReceiveTimeout().toMillis());
        template.setExplicitQosEnabled(true);
        template.setTimeToLive(client.getTimeToLive().toMillis());
        return new MqConnector(name, client.getDestination(), template, executor, client.getMaxMessageBytes());
    }

    @Override public String name() { return name; }
    @Override public String type() { return "mq"; }

    public void sendText(String text) { sendText(text, MqSendOptions.NONE); }

    public void sendText(String text, MqSendOptions options) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(options, "options");
        checkBodySize(text.length());
        checkBodySize(text.getBytes(StandardCharsets.UTF_8).length);
        invoke("send", () -> {
            template.send(destination, session -> {
                TextMessage message = session.createTextMessage(text);
                applyOptions(message, options);
                return message;
            });
            return null;
        });
    }

    public void sendBytes(byte[] body) { sendBytes(body, MqSendOptions.NONE); }

    public void sendBytes(byte[] body, MqSendOptions options) {
        Objects.requireNonNull(body, "body");
        Objects.requireNonNull(options, "options");
        checkBodySize(body.length);
        byte[] snapshot = body.clone();
        invoke("send", () -> {
            template.send(destination, session -> {
                BytesMessage message = session.createBytesMessage();
                message.writeBytes(snapshot);
                applyOptions(message, options);
                return message;
            });
            return null;
        });
    }

    /** Returns empty when the configured positive receive timeout expires without a message. */
    public Optional<MqMessage> receive() {
        return invoke("receive", () -> {
            Message message = template.receive(destination);
            if (message == null) {
                return Optional.empty();
            }
            try {
                return Optional.of(decode(message));
            }
            catch (JMSException exception) {
                throw failure("Unable to decode the received JMS message", exception);
            }
        });
    }

    /** Rejects subsequent calls. In-flight calls finish; the caller's ConnectionFactory remains open. */
    @Override public void close() { closed.set(true); }

    private <T> T invoke(String operation, Supplier<T> action) {
        ensureOpen();
        return executor.execute(operation, () -> {
            ensureOpen();
            try {
                return action.get();
            }
            catch (JmsException exception) {
                if (exception instanceof org.springframework.jms.ResourceAllocationException) {
                    throw new ConnectorException(ConnectorErrorCode.SATURATED, type(), name,
                            "JMS provider resource limit reached", ConnectorException.redactedCause(exception));
                }
                throw failure("JMS operation failed", exception);
            }
        });
    }

    private MqMessage decode(Message message) throws JMSException {
        byte[] body;
        MqMessage.BodyType type;
        if (message instanceof TextMessage textMessage) {
            String text = textMessage.getText();
            if (text != null && text.length() > maxMessageBytes) {
                throw failure("Received JMS message exceeds the configured body limit", null);
            }
            body = text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8);
            if (body.length > maxMessageBytes) {
                throw failure("Received JMS message exceeds the configured body limit", null);
            }
            type = MqMessage.BodyType.TEXT;
        }
        else if (message instanceof BytesMessage bytesMessage) {
            long size = bytesMessage.getBodyLength();
            if (size < 0 || size > maxMessageBytes) {
                throw failure("Received JMS message exceeds the configured body limit", null);
            }
            body = new byte[(int) size];
            int offset = 0;
            byte[] chunk = new byte[Math.min(body.length, 8192)];
            while (offset < body.length) {
                int count = bytesMessage.readBytes(chunk, Math.min(chunk.length, body.length - offset));
                if (count <= 0) {
                    throw failure("Received JMS byte message ended before its declared length", null);
                }
                System.arraycopy(chunk, 0, body, offset, count);
                offset += count;
            }
            type = MqMessage.BodyType.BYTES;
        }
        else {
            // Never invoke getObject on ObjectMessage: Java deserialization is intentionally unsupported.
            throw failure("Only JMS text and byte messages are supported", null);
        }
        Map<String, Object> properties = new LinkedHashMap<>();
        Enumeration<?> names = message.getPropertyNames();
        while (names.hasMoreElements()) {
            if (properties.size() >= 128) {
                throw failure("Received JMS message exceeds the supported property count", null);
            }
            String property = (String) names.nextElement();
            properties.put(property, message.getObjectProperty(property));
        }
        return new MqMessage(body, type, message.getJMSMessageID(), message.getJMSCorrelationID(), properties);
    }

    private static void applyOptions(Message message, MqSendOptions options) throws JMSException {
        if (options.correlationId() != null) {
            message.setJMSCorrelationID(options.correlationId());
        }
        for (Map.Entry<String, Object> entry : options.properties().entrySet()) {
            message.setObjectProperty(entry.getKey(), entry.getValue());
        }
    }

    private void checkBodySize(int size) {
        if (size > maxMessageBytes) {
            throw new IllegalArgumentException("JMS body exceeds the configured message limit");
        }
    }

    private void ensureOpen() {
        if (closed.get()) {
            throw new ConnectorException(ConnectorErrorCode.CLOSED, type(), name, "MQ connector is closed");
        }
    }

    private ConnectorException failure(String message, Throwable cause) {
        return new ConnectorException(ConnectorErrorCode.REMOTE_ERROR, type(), name, message,
                ConnectorException.redactedCause(cause));
    }
}
