package io.github.connectorsdk.mq;

/** Internal activation marker imported by {@link EnableMqConnector}. */
public final class MqConnectorEnabled {
}
