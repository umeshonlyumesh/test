package io.github.connectorsdk.mq;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("connector.sdk.mq")
public class MqConnectorProperties {
    private Boolean enabled;
    private Map<String, Client> clients = new LinkedHashMap<>();

    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public Map<String, Client> getClients() { return clients; }
    public void setClients(Map<String, Client> clients) { this.clients = clients; }

    public void validate() {
        if (clients == null || clients.isEmpty()) {
            throw new IllegalArgumentException("Enabled MQ connector requires connector.sdk.mq.clients");
        }
        clients.forEach((name, client) -> {
            if (name == null || !name.matches("[a-zA-Z][a-zA-Z0-9._-]{0,63}")) {
                throw new IllegalArgumentException("MQ client names must begin with a letter and contain at most 64 letters, digits, '.', '_' or '-'");
            }
            if (client == null) {
                throw new IllegalArgumentException("MQ client '" + name + "' requires configuration");
            }
            client.validate(name);
        });
    }

    public static class Client {
        private String connectionFactoryBean;
        private String destination;
        private boolean pubSubDomain;
        private Duration receiveTimeout = Duration.ofSeconds(5);
        private Duration timeToLive = Duration.ZERO;
        private int maxConcurrentCalls = 32;
        private int maxMessageBytes = 16 * 1024 * 1024;

        public String getConnectionFactoryBean() { return connectionFactoryBean; }
        public void setConnectionFactoryBean(String value) { connectionFactoryBean = value; }
        public String getDestination() { return destination; }
        public void setDestination(String value) { destination = value; }
        public boolean isPubSubDomain() { return pubSubDomain; }
        public void setPubSubDomain(boolean value) { pubSubDomain = value; }
        public Duration getReceiveTimeout() { return receiveTimeout; }
        public void setReceiveTimeout(Duration value) { receiveTimeout = value; }
        public Duration getTimeToLive() { return timeToLive; }
        public void setTimeToLive(Duration value) { timeToLive = value; }
        public int getMaxConcurrentCalls() { return maxConcurrentCalls; }
        public void setMaxConcurrentCalls(int value) { maxConcurrentCalls = value; }
        public int getMaxMessageBytes() { return maxMessageBytes; }
        public void setMaxMessageBytes(int value) { maxMessageBytes = value; }

        public void validate(String name) {
            String prefix = "MQ client '" + name + "': ";
            if (connectionFactoryBean == null || connectionFactoryBean.isBlank()
                    || !connectionFactoryBean.equals(connectionFactoryBean.trim())) {
                throw new IllegalArgumentException(prefix + "connection-factory-bean must explicitly name a caller-owned ConnectionFactory bean");
            }
            if (destination == null || destination.isBlank()) {
                throw new IllegalArgumentException(prefix + "destination must not be blank");
            }
            if (receiveTimeout == null || receiveTimeout.isNegative() || receiveTimeout.isZero()) {
                throw new IllegalArgumentException(prefix + "receive-timeout must be positive");
            }
            try {
                if (receiveTimeout.toMillis() < 1) {
                    throw new IllegalArgumentException(prefix + "receive-timeout must be at least one millisecond");
                }
            }
            catch (ArithmeticException exception) {
                throw new IllegalArgumentException(prefix + "receive-timeout exceeds the supported duration", exception);
            }
            if (timeToLive == null || timeToLive.isNegative()) {
                throw new IllegalArgumentException(prefix + "time-to-live must be non-negative");
            }
            try {
                if (!timeToLive.isZero() && timeToLive.toMillis() < 1) {
                    throw new IllegalArgumentException(prefix + "positive time-to-live must be at least one millisecond");
                }
                timeToLive.toMillis();
            }
            catch (ArithmeticException exception) {
                throw new IllegalArgumentException(prefix + "time-to-live exceeds the supported duration", exception);
            }
            if (maxConcurrentCalls < 1 || maxMessageBytes < 1) {
                throw new IllegalArgumentException(prefix + "max-concurrent-calls and max-message-bytes must be positive");
            }
        }
    }
}
