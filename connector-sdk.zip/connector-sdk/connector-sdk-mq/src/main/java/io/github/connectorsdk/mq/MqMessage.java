package io.github.connectorsdk.mq;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** Received body and headers. Text messages are represented as UTF-8; body arrays are defensively copied. */
public record MqMessage(byte[] body, BodyType bodyType, String messageId, String correlationId,
                        Map<String, Object> properties) {
    public enum BodyType { TEXT, BYTES }

    public MqMessage {
        body = Objects.requireNonNull(body, "body").clone();
        Objects.requireNonNull(bodyType, "bodyType");
        Map<String, Object> snapshot = new LinkedHashMap<>(Objects.requireNonNull(properties, "properties"));
        snapshot.forEach((key, value) -> {
            Objects.requireNonNull(key, "property name");
            if (value != null && !(value instanceof Boolean || value instanceof Byte
                    || value instanceof Short || value instanceof Integer || value instanceof Long
                    || value instanceof Float || value instanceof Double || value instanceof String)) {
                throw new IllegalArgumentException("JMS message properties must contain immutable scalar values");
            }
        });
        properties = Collections.unmodifiableMap(snapshot);
    }

    @Override
    public byte[] body() {
        return body.clone();
    }

    /** Safe diagnostic summary; payloads, property values and message identifiers are omitted. */
    @Override
    public String toString() {
        return "MqMessage[bodyType=" + bodyType + ", bodyBytes=" + body.length
                + ", propertyCount=" + properties.size() + "]";
    }

    /** Decodes the payload as UTF-8; intended for {@link BodyType#TEXT} messages. */
    public String text() {
        if (bodyType != BodyType.TEXT) {
            throw new IllegalStateException("This message has a binary body");
        }
        return new String(body, StandardCharsets.UTF_8);
    }
}
