package io.github.connectorsdk.mq;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/** Immutable outbound headers. Only portable JMS primitive and String property values are accepted. */
public record MqSendOptions(String correlationId, Map<String, Object> properties) {
    public static final MqSendOptions NONE = new MqSendOptions(null, Map.of());
    private static final Set<String> RESERVED = Set.of(
            "NULL", "TRUE", "FALSE", "NOT", "AND", "OR", "BETWEEN", "LIKE", "IN", "IS", "ESCAPE");

    public MqSendOptions {
        Objects.requireNonNull(properties, "properties");
        if (properties.size() > 128) {
            throw new IllegalArgumentException("At most 128 JMS properties are supported");
        }
        Map<String, Object> snapshot = new LinkedHashMap<>();
        properties.forEach((key, value) -> {
            if (!validName(key)) {
                throw new IllegalArgumentException("JMS property names must be non-reserved Java identifiers");
            }
            if (value != null && !(value instanceof Boolean || value instanceof Byte
                    || value instanceof Short || value instanceof Integer || value instanceof Long
                    || value instanceof Float || value instanceof Double || value instanceof String)) {
                throw new IllegalArgumentException("JMS property values must be primitive wrappers or Strings");
            }
            snapshot.put(key, value);
        });
        properties = Collections.unmodifiableMap(snapshot);
    }

    /** Safe diagnostic summary; correlation identifiers and property values are omitted. */
    @Override
    public String toString() {
        return "MqSendOptions[propertyCount=" + properties.size() + "]";
    }

    private static boolean validName(String value) {
        if (value == null || value.isEmpty() || value.startsWith("JMSX") || value.startsWith("JMS_")
                || RESERVED.contains(value)) {
            return false;
        }
        int first = value.codePointAt(0);
        if (!Character.isJavaIdentifierStart(first)) {
            return false;
        }
        for (int offset = Character.charCount(first); offset < value.length();) {
            int codePoint = value.codePointAt(offset);
            if (!Character.isJavaIdentifierPart(codePoint)) {
                return false;
            }
            offset += Character.charCount(codePoint);
        }
        return true;
    }
}
