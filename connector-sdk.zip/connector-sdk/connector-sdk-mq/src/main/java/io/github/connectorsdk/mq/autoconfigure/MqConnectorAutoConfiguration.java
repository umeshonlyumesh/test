package io.github.connectorsdk.mq.autoconfigure;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.mq.MqConnector;
import io.github.connectorsdk.mq.MqConnectorEnabled;
import io.github.connectorsdk.mq.MqConnectorProperties;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.github.connectorsdk.spring.ConnectorBeanValidator;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import jakarta.jms.ConnectionFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.jms.core.JmsTemplate;

@AutoConfiguration(after = ConnectorRuntimeAutoConfiguration.class)
@ConditionalOnClass({JmsTemplate.class, ConnectionFactory.class, ConnectorExecutorFactory.class})
@ConditionalOnProperty(prefix = "connector.sdk.mq", name = "enabled", havingValue = "true", matchIfMissing = true)
@Conditional(MqConnectorAutoConfiguration.EnabledCondition.class)
@EnableConfigurationProperties(MqConnectorProperties.class)
public class MqConnectorAutoConfiguration {
    @Bean
    ConnectorBeanValidator mqConnectorBeanValidator(ConfigurableListableBeanFactory factory, MqConnectorProperties properties) {
        return new ConnectorBeanValidator(factory, properties.getClients().keySet().stream()
                .map(name -> new ConnectorBeanValidator.Expectation("mqConnector." + name, "mq", name, MqConnector.class))
                .toList());
    }

    @Bean
    static BeanDefinitionRegistryPostProcessor mqConnectorBeanRegistrar(Environment environment) {
        MqConnectorProperties properties = Binder.get(environment)
                .bind("connector.sdk.mq", Bindable.of(MqConnectorProperties.class))
                .orElseGet(MqConnectorProperties::new);
        properties.validate();
        return new MqBeanRegistrar(properties);
    }

    static final class EnabledCondition extends AnyNestedCondition {
        EnabledCondition() { super(ConfigurationPhase.REGISTER_BEAN); }

        @ConditionalOnBean(MqConnectorEnabled.class)
        @Conditional(JmsAnnotationConfigurationCondition.class)
        static class AnnotationEnabled { }

        @ConditionalOnProperty(prefix = "connector.sdk.mq", name = "enabled", havingValue = "true")
        static class PropertyEnabled { }
    }

    /** An umbrella MQ annotation may select RabbitMQ alone through its own configured clients. */
    static final class JmsAnnotationConfigurationCondition implements Condition {
        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            return hasClients(context.getEnvironment(), "connector.sdk.mq.clients")
                    || !hasClients(context.getEnvironment(), "connector.sdk.rabbitmq.clients");
        }

        private boolean hasClients(Environment environment, String prefix) {
            return Binder.get(environment).bind(prefix, Bindable.mapOf(String.class, Object.class))
                    .map(clients -> !clients.isEmpty()).orElse(false);
        }
    }

    private static final class MqBeanRegistrar implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware {
        private final MqConnectorProperties properties;
        private ConfigurableListableBeanFactory beanFactory;

        private MqBeanRegistrar(MqConnectorProperties properties) { this.properties = properties; }

        @Override
        public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
            this.beanFactory = (ConfigurableListableBeanFactory) beanFactory;
        }

        @Override
        public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            properties.getClients().forEach((name, client) -> {
                String beanName = "mqConnector." + name;
                if (registry.containsBeanDefinition(beanName) || registry.isAlias(beanName)
                        || beanFactory.containsSingleton(beanName)) {
                    return;
                }
                RootBeanDefinition definition = new RootBeanDefinition(MqConnector.class);
                definition.setInstanceSupplier(() -> createConnector(name, client));
                definition.setDestroyMethodName("close");
                registry.registerBeanDefinition(beanName, definition);
            });
        }

        private MqConnector createConnector(String name, MqConnectorProperties.Client client) {
            ConnectionFactory connectionFactory;
            try {
                connectionFactory = beanFactory.getBean(client.getConnectionFactoryBean(), ConnectionFactory.class);
            }
            catch (BeansException exception) {
                throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "mq", name,
                        "Configured MQ ConnectionFactory bean is missing or has an incompatible type",
                        ConnectorException.redactedCause(exception));
            }
            var executor = beanFactory.getBean(ConnectorExecutorFactory.class)
                    .create("mq", name, client.getMaxConcurrentCalls());
            return MqConnector.create(name, connectionFactory, client, executor);
        }

        @Override
        public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) { }
    }
}
