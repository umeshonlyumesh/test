package io.github.connectorsdk.mq;

import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.mq.autoconfigure.MqConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import jakarta.jms.ConnectionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class MqConnectorAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                    ConnectorSupportAutoConfiguration.class, MqConnectorAutoConfiguration.class))
            .withPropertyValues(
                    "connector.sdk.mq.clients.orders.connection-factory-bean=testConnectionFactory",
                    "connector.sdk.mq.clients.orders.destination=orders",
                    "connector.sdk.mq.clients.orders.receive-timeout=50ms");

    @Test
    void classpathAndConfigurationAloneDoNotActivateMq() {
        runner.withUserConfiguration(FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().doesNotHaveBean(MqConnector.class);
            assertThat(context).doesNotHaveBean(MqConnectorProperties.class);
            verifyNoInteractions(context.getBean(ConnectionFactory.class));
        });
    }

    @Test
    void annotationActivatesNamedConnectorWithoutOpeningABrokerConnection() {
        runner.withUserConfiguration(EnabledConfiguration.class, FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().hasSingleBean(MqConnector.class);
            assertThat(context.getBean("mqConnector.orders", MqConnector.class).name()).isEqualTo("orders");
            verifyNoInteractions(context.getBean(ConnectionFactory.class));
        });
    }

    @Test
    void propertyActivatesMqAndExplicitFactoryNamesSupportMultipleClients() {
        runner.withUserConfiguration(FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.enabled=true",
                        "connector.sdk.mq.clients.invoices.connection-factory-bean=testConnectionFactory",
                        "connector.sdk.mq.clients.invoices.destination=invoices")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context.getBeansOfType(MqConnector.class)).containsOnlyKeys(
                            "mqConnector.orders", "mqConnector.invoices");
                });
    }

    @Test
    void explicitFalseOverridesAnnotationAndSkipsInvalidDisabledConfiguration() {
        runner.withUserConfiguration(EnabledConfiguration.class)
                .withPropertyValues("connector.sdk.mq.enabled=false",
                        "connector.sdk.mq.clients.orders.receive-timeout=0s")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(MqConnector.class)
                        .doesNotHaveBean(MqConnectorProperties.class));
    }

    @Test
    void configuredMissingFactoryFailsAtStartup() {
        runner.withUserConfiguration(EnabledConfiguration.class).run(context -> {
            assertThat(context).hasFailed();
            assertThat(context.getStartupFailure()).hasStackTraceContaining(ConnectorException.class.getName())
                    .hasStackTraceContaining("Configured MQ ConnectionFactory bean is missing");
        });
    }

    @Test
    void neverImplicitlySelectsAnOtherwiseUniqueFactory() {
        runner.withUserConfiguration(EnabledConfiguration.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.clients.orders.connection-factory-bean=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining(
                            "connection-factory-bean must explicitly name");
                });
    }

    @Test
    void zeroReceiveTimeoutFailsInsteadOfCreatingAnUnboundedReceive() {
        runner.withUserConfiguration(EnabledConfiguration.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.clients.orders.receive-timeout=0s")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining("receive-timeout must be positive");
                });
    }

    @Test
    void subMillisecondTimeoutCannotRoundDownToAnUnboundedWait() {
        runner.withUserConfiguration(EnabledConfiguration.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.clients.orders.receive-timeout=1ns")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining("receive-timeout must be at least one millisecond");
                });
    }

    @Test
    void missingOptionalJmsClassesSkipAutoConfigurationWithoutLoadingTheAdapter() {
        runner.withClassLoader(new FilteredClassLoader("jakarta.jms", "org.springframework.jms"))
                .withPropertyValues("connector.sdk.mq.enabled=true")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean("mqConnector.orders")
                        .doesNotHaveBean(MqConnectorProperties.class));
    }

    @Test
    void namedAliasForACallerConnectorTakesPrecedence() {
        runner.withUserConfiguration(AliasConfiguration.class)
                .withPropertyValues("connector.sdk.mq.enabled=true")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(MqConnector.class);
                    assertThat(context.getBean("mqConnector.orders")).isSameAs(context.getBean("customMqConnector"));
                });
    }

    @Configuration(proxyBeanMethods = false)
    @EnableMqConnector
    static class EnabledConfiguration { }

    @Configuration(proxyBeanMethods = false)
    static class FactoryConfiguration {
        @Bean
        ConnectionFactory testConnectionFactory() { return mock(ConnectionFactory.class); }
    }

    @Configuration(proxyBeanMethods = false)
    static class AliasConfiguration {
        @Bean({"customMqConnector", "mqConnector.orders"})
        MqConnector customConnector() {
            MqConnector connector = mock(MqConnector.class);
            when(connector.name()).thenReturn("orders");
            when(connector.type()).thenReturn("mq");
            return connector;
        }
    }
}
