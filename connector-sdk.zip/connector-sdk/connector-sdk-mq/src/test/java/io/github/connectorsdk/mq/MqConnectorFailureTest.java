package io.github.connectorsdk.mq;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import jakarta.jms.JMSSecurityException;
import org.junit.jupiter.api.Test;
import org.springframework.jms.JmsSecurityException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class MqConnectorFailureTest {
    @Test
    void standardizedProviderResourceAllocationFailuresMapToSaturated() {
        JmsTemplate template = mock(JmsTemplate.class);
        when(template.receive("orders")).thenThrow(new org.springframework.jms.ResourceAllocationException(
                new jakarta.jms.ResourceAllocationException("broker-private-allocation-details")));
        var connector = new MqConnector("orders", "orders", template,
                new ConnectorExecutor("mq", "orders", 1, InvocationObserver.NONE), 1024);

        assertThatThrownBy(connector::receive).isInstanceOfSatisfying(ConnectorException.class, failure -> {
            assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.SATURATED);
            assertThat(failure.getMessage()).isEqualTo("JMS provider resource limit reached");
            StringWriter output = new StringWriter();
            failure.printStackTrace(new PrintWriter(output));
            assertThat(output.toString()).doesNotContain("broker-private-allocation-details");
        });
    }

    @Test
    void rawBrokerDiagnosticsCannotEscapeThroughSdkExceptionStacks() {
        JmsTemplate template = mock(JmsTemplate.class);
        doThrow(new JmsSecurityException(new JMSSecurityException("password=broker-secret")))
                .when(template).send(eq("orders"), any(MessageCreator.class));
        var connector = new MqConnector("orders", "orders", template,
                new ConnectorExecutor("mq", "orders", 1, InvocationObserver.NONE), 1024);

        assertThatThrownBy(() -> connector.sendText("payload-secret"))
                .isInstanceOfSatisfying(ConnectorException.class, failure -> {
                    assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR);
                    StringWriter output = new StringWriter();
                    failure.printStackTrace(new PrintWriter(output));
                    assertThat(output.toString()).doesNotContain("broker-secret", "payload-secret");
                    assertThat(failure.getCause().getCause()).isNull();
                });
    }

    @Test
    void closedStateTakesPrecedenceWhenAnInFlightReceiveUsesTheOnlyPermit() throws Exception {
        JmsTemplate template = mock(JmsTemplate.class);
        CountDownLatch entered = new CountDownLatch(1);
        CountDownLatch released = new CountDownLatch(1);
        when(template.receive("orders")).thenAnswer(invocation -> {
            entered.countDown();
            if (!released.await(2, TimeUnit.SECONDS)) {
                throw new IllegalStateException("Receive test did not release its call");
            }
            return null;
        });
        var connector = new MqConnector("orders", "orders", template,
                new ConnectorExecutor("mq", "orders", 1, InvocationObserver.NONE), 1024);
        try (var tasks = Executors.newVirtualThreadPerTaskExecutor()) {
            var pending = tasks.submit(connector::receive);
            try {
                assertThat(entered.await(2, TimeUnit.SECONDS)).isTrue();
                connector.close();
                assertThatThrownBy(connector::receive).isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CLOSED));
            }
            finally {
                released.countDown();
            }
            assertThat(pending.get(2, TimeUnit.SECONDS)).isEqualTo(Optional.empty());
        }
    }
}
