package io.github.connectorsdk.mq;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import jakarta.jms.Session;
import org.apache.activemq.artemis.core.config.impl.ConfigurationImpl;
import org.apache.activemq.artemis.core.server.ActiveMQServer;
import org.apache.activemq.artemis.core.server.ActiveMQServers;
import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jms.core.JmsTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MqConnectorIntegrationTest {
    private ActiveMQServer broker;
    private ActiveMQConnectionFactory connectionFactory;
    private MqConnector connector;
    private JmsTemplate template;

    @BeforeEach
    void startBroker() throws Exception {
        var configuration = new ConfigurationImpl()
                .setPersistenceEnabled(false)
                .setSecurityEnabled(false)
                .addAcceptorConfiguration("in-vm", "vm://0");
        broker = ActiveMQServers.newActiveMQServer(configuration);
        broker.start();
        connectionFactory = new ActiveMQConnectionFactory("vm://0");
        template = new JmsTemplate(connectionFactory);
        template.setReceiveTimeout(50);
        template.setSessionAcknowledgeMode(Session.AUTO_ACKNOWLEDGE);
        var client = new MqConnectorProperties.Client();
        client.setConnectionFactoryBean("testConnectionFactory");
        client.setDestination("orders");
        client.setReceiveTimeout(Duration.ofMillis(50));
        client.setMaxMessageBytes(1024);
        connector = MqConnector.create("orders", connectionFactory, client,
                new ConnectorExecutor("mq", "orders", 4, InvocationObserver.NONE));
    }

    @AfterEach
    void stopBroker() throws Exception {
        if (connector != null) { connector.close(); }
        if (connectionFactory != null) { connectionFactory.close(); }
        if (broker != null) { broker.stop(); }
    }

    @Test
    void sendsAndReceivesUtf8TextWithPortableHeaders() {
        connector.sendText("Grüße 🌍", new MqSendOptions("request-123", Map.of("attempt", 2, "active", true)));

        MqMessage message = connector.receive().orElseThrow();

        assertThat(message.bodyType()).isEqualTo(MqMessage.BodyType.TEXT);
        assertThat(message.text()).isEqualTo("Grüße 🌍");
        assertThat(message.body()).isEqualTo("Grüße 🌍".getBytes(StandardCharsets.UTF_8));
        assertThat(message.correlationId()).isEqualTo("request-123");
        assertThat(message.messageId()).isNotBlank();
        assertThat(message.properties()).containsEntry("attempt", 2).containsEntry("active", true);
        assertThat(connector.receive()).isEmpty();
    }

    @Test
    void receivesBinaryMessagesAndProtectsItsSnapshot() {
        byte[] body = {0, 1, 2, 3};
        connector.sendBytes(body);
        body[0] = 9;

        MqMessage message = connector.receive().orElseThrow();
        byte[] returned = message.body();
        returned[0] = 8;

        assertThat(message.bodyType()).isEqualTo(MqMessage.BodyType.BYTES);
        assertThat(message.body()).containsExactly(new byte[] {0, 1, 2, 3});
        assertThatThrownBy(message::text).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> message.properties().put("mutable", true))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void emptyReceiveReturnsWithinTheConfiguredDeadline() {
        long before = System.nanoTime();

        assertThat(connector.receive()).isEmpty();

        assertThat(Duration.ofNanos(System.nanoTime() - before)).isLessThan(Duration.ofSeconds(2));
    }

    @Test
    void closingConnectorDoesNotCloseCallerConnectionFactory() {
        connector.close();

        assertThatThrownBy(() -> connector.sendText("closed"))
                .isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CLOSED));
        template.convertAndSend("orders", "still usable");
        assertThat(template.receiveAndConvert("orders")).isEqualTo("still usable");
    }

    @Test
    void rejectsUnsupportedInboundMessageTypesWithoutJavaDeserialization() {
        template.send("orders", Session::createMapMessage);

        assertThatThrownBy(connector::receive)
                .isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR))
                .hasMessage("Only JMS text and byte messages are supported");
    }

    @Test
    void enforcesOutboundAndInboundBodyLimits() {
        assertThatThrownBy(() -> connector.sendBytes(new byte[1025]))
                .isInstanceOf(IllegalArgumentException.class);
        template.send("orders", session -> {
            var message = session.createBytesMessage();
            message.writeBytes(new byte[1025]);
            return message;
        });

        assertThatThrownBy(connector::receive)
                .isInstanceOf(ConnectorException.class)
                .hasMessage("Received JMS message exceeds the configured body limit");
    }
}
