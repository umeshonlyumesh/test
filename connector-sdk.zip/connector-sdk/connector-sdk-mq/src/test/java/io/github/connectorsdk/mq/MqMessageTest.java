package io.github.connectorsdk.mq;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MqMessageTest {
    @Test
    void diagnosticSummaryOmitsPayloadPropertiesAndMessageIdentifiers() {
        var message = new MqMessage("body-secret".getBytes(StandardCharsets.UTF_8), MqMessage.BodyType.TEXT,
                "message-id-secret", "correlation-secret", Map.of("authorization", "property-secret"));

        assertThat(message.toString()).isEqualTo("MqMessage[bodyType=TEXT, bodyBytes=11, propertyCount=1]")
                .doesNotContain("body-secret", "property-secret", "authorization", "message-id-secret", "correlation-secret");
    }
}
