package io.github.connectorsdk.mq;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MqSendOptionsTest {
    @Test
    void copiesPropertiesAndAllowsPortableScalarValues() {
        Map<String, Object> properties = new HashMap<>();
        properties.put("attempt", 1);
        properties.put("optional", null);
        var options = new MqSendOptions("request", properties);
        properties.put("attempt", 2);

        assertThat(options.properties()).containsEntry("attempt", 1).containsEntry("optional", null);
        assertThatThrownBy(() -> options.properties().put("attempt", 3))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void rejectsSelectorKeywordsVendorPropertiesAndMutableValues() {
        assertThatThrownBy(() -> new MqSendOptions(null, Map.of("AND", true)))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MqSendOptions(null, Map.of("JMSXGroupID", "a")))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MqSendOptions(null, Map.of("valid", new byte[] {1})))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void diagnosticSummaryDoesNotExposeCorrelationOrPropertyValues() {
        var options = new MqSendOptions("correlation-secret", Map.of("authorization", "property-secret"));

        assertThat(options.toString()).isEqualTo("MqSendOptions[propertyCount=1]")
                .doesNotContain("correlation-secret", "property-secret", "authorization");
    }
}
