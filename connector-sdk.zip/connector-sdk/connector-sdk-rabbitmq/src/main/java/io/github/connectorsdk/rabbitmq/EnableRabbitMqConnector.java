package io.github.connectorsdk.rabbitmq;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

/** Opt in to native RabbitMQ AMQP clients. Explicit enabled=false takes precedence. */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(RabbitMqConnectorEnabled.class)
public @interface EnableRabbitMqConnector {
}
