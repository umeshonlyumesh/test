package io.github.connectorsdk.rabbitmq;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import org.springframework.amqp.AmqpConnectException;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.AmqpResourceNotAvailableException;
import org.springframework.amqp.AmqpTimeoutException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

/**
 * Native RabbitMQ AMQP adapter with bounded receive and optional correlated publisher confirmations.
 *
 * <p>Confirmed mode requires a caller-owned factory with CORRELATED confirms and publisher returns.
 * A positive broker ack plus no mandatory return confirms publication and routing, not processing.
 * Confirm timeout leaves the publish outcome uncertain and never triggers a retry. Connection,
 * channel checkout and socket write timeouts must be configured on the supplied factory.</p>
 *
 * <p>Receive acknowledges before returning the message, including before body/header validation.
 * This is not a manual acknowledgement or reliable listener API. Exchanges, queues, bindings,
 * transactions, consumers, broker recovery and factory lifecycle are the caller's responsibility.</p>
 */
public final class RabbitMqConnector implements Connector {
    private final String name;
    private final String exchange;
    private final String routingKey;
    private final String queue;
    private final RabbitTemplate template;
    private final ConnectorExecutor executor;
    private final long receiveTimeoutMillis;
    private final long confirmTimeoutNanos;
    private final long timeToLiveMillis;
    private final boolean publisherConfirms;
    private final boolean persistent;
    private final int maxMessageBytes;
    private final AtomicBoolean closed = new AtomicBoolean();

    RabbitMqConnector(String name, RabbitTemplate template, RabbitMqConnectorProperties.Client client,
                       ConnectorExecutor executor) {
        this.name = Objects.requireNonNull(name, "name");
        if (name.isBlank()) { throw new IllegalArgumentException("RabbitMQ connector name must not be blank"); }
        Objects.requireNonNull(client, "client").validate(name);
        this.template = Objects.requireNonNull(template, "template");
        this.executor = Objects.requireNonNull(executor, "executor");
        exchange = client.getExchange();
        routingKey = client.effectiveRoutingKey();
        queue = client.getQueue();
        receiveTimeoutMillis = client.getReceiveTimeout().toMillis();
        confirmTimeoutNanos = client.getConfirmTimeout().toNanos();
        timeToLiveMillis = client.getTimeToLive().toMillis();
        publisherConfirms = client.isPublisherConfirms();
        persistent = client.isPersistent();
        maxMessageBytes = client.getMaxMessageBytes();
    }

    /** Builds a private reusable template without opening or owning the caller's broker factory. */
    public static RabbitMqConnector create(String name, ConnectionFactory connectionFactory,
                                            RabbitMqConnectorProperties.Client client,
                                            ConnectorExecutor executor) {
        Objects.requireNonNull(connectionFactory, "connectionFactory");
        Objects.requireNonNull(client, "client").validate(name);
        if (client.isPublisherConfirms() && (!connectionFactory.isPublisherConfirms()
                || connectionFactory.isSimplePublisherConfirms() || !connectionFactory.isPublisherReturns())) {
            throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "rabbitmq", name,
                    "Confirmed RabbitMQ sends require correlated publisher confirms and publisher returns on the configured ConnectionFactory");
        }
        RabbitTemplate template = new SafeRabbitTemplate(connectionFactory);
        template.setChannelTransacted(false);
        template.setMandatory(client.isPublisherConfirms());
        template.setReceiveTimeout(client.getReceiveTimeout().toMillis());
        template.afterPropertiesSet();
        return new RabbitMqConnector(name, template, client, executor);
    }

    @Override public String name() { return name; }
    @Override public String type() { return "rabbitmq"; }

    public RabbitMqPublishResult sendText(String text) { return sendText(text, RabbitMqSendOptions.NONE); }

    public RabbitMqPublishResult sendText(String text, RabbitMqSendOptions options) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(options, "options");
        checkBodySize(text.length());
        byte[] body = text.getBytes(StandardCharsets.UTF_8);
        checkBodySize(body.length);
        return publish(body, "text/plain", StandardCharsets.UTF_8.name(), options);
    }

    public RabbitMqPublishResult sendBytes(byte[] body) { return sendBytes(body, RabbitMqSendOptions.NONE); }

    public RabbitMqPublishResult sendBytes(byte[] body, RabbitMqSendOptions options) {
        Objects.requireNonNull(body, "body");
        Objects.requireNonNull(options, "options");
        checkBodySize(body.length);
        return publish(body.clone(), "application/octet-stream", null, options);
    }

    /** Returns empty after the configured positive receive wait; provider setup may take additional time. */
    public Optional<RabbitMqMessage> receive() {
        ensureOpen();
        if (queue == null) {
            throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, type(), name,
                    "RabbitMQ connector has no receive queue configured");
        }
        return invoke("receive", () -> {
            Message message = template.receive(queue, receiveTimeoutMillis);
            if (message == null) { return Optional.empty(); }
            if (message.getBody().length > maxMessageBytes) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR,
                        "Received RabbitMQ message exceeds the configured body limit", null);
            }
            MessageProperties properties = message.getMessageProperties();
            String contentType = properties.getContentType();
            String encoding = properties.getContentEncoding();
            boolean text = contentType != null && (contentType.startsWith("text/")
                    || contentType.equals("application/json"))
                    && (encoding == null || encoding.equalsIgnoreCase("UTF-8") || encoding.equalsIgnoreCase("UTF8"));
            try {
                return Optional.of(new RabbitMqMessage(message.getBody(), text ? RabbitMqMessage.BodyType.TEXT
                        : RabbitMqMessage.BodyType.BYTES, contentType, encoding, properties.getMessageId(),
                        properties.getCorrelationId(), properties.getHeaders(), Boolean.TRUE.equals(properties.isRedelivered())));
            }
            catch (IllegalArgumentException exception) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR,
                        "Received RabbitMQ message headers are unsupported or exceed the snapshot limits", exception);
            }
        });
    }

    /** Rejects new calls and destroys the private template; the caller's factory remains usable. */
    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) {
            try { template.destroy(); }
            catch (AmqpException exception) {
                throw mapFailure(exception, "RabbitMQ template cleanup failed");
            }
        }
    }

    private RabbitMqPublishResult publish(byte[] body, String contentType, String encoding, RabbitMqSendOptions options) {
        return invoke("send", () -> {
            MessageProperties properties = new MessageProperties();
            properties.setContentType(contentType);
            properties.setContentEncoding(encoding);
            properties.setDeliveryMode(persistent ? MessageDeliveryMode.PERSISTENT : MessageDeliveryMode.NON_PERSISTENT);
            properties.setMessageId(options.messageId() != null ? options.messageId() : UUID.randomUUID().toString());
            properties.setCorrelationId(options.correlationId());
            properties.getHeaders().putAll(options.headers());
            if (timeToLiveMillis > 0) { properties.setExpiration(Long.toString(timeToLiveMillis)); }
            Message message = new SafeMessage(body, properties);
            if (!publisherConfirms) {
                template.send(exchange, routingKey, message);
                return RabbitMqPublishResult.SENT_UNCONFIRMED;
            }
            CorrelationData correlation = new CorrelationData();
            template.send(exchange, routingKey, message, correlation);
            return awaitConfirmation(correlation);
        });
    }

    private RabbitMqPublishResult awaitConfirmation(CorrelationData correlation) {
        try {
            CorrelationData.Confirm confirmation = correlation.getFuture().get(confirmTimeoutNanos, TimeUnit.NANOSECONDS);
            if (correlation.getReturned() != null) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR, "RabbitMQ publication was returned as unroutable", null);
            }
            if (!confirmation.ack()) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR, "RabbitMQ broker rejected the publication", null);
            }
            return RabbitMqPublishResult.CONFIRMED;
        }
        catch (TimeoutException exception) {
            correlation.getFuture().cancel(false);
            throw failure(ConnectorErrorCode.TIMEOUT, "RabbitMQ publisher confirmation timed out; publish outcome is uncertain", exception);
        }
        catch (InterruptedException exception) {
            correlation.getFuture().cancel(false);
            Thread.currentThread().interrupt();
            throw failure(ConnectorErrorCode.INTERRUPTED, "RabbitMQ publisher confirmation was interrupted; publish outcome is uncertain", exception);
        }
        catch (ExecutionException exception) {
            throw mapFailure(exception.getCause(), "RabbitMQ publisher confirmation failed");
        }
    }

    private <T> T invoke(String operation, Supplier<T> action) {
        ensureOpen();
        ensureNotInterrupted();
        return executor.execute(operation, () -> {
            ensureOpen();
            ensureNotInterrupted();
            try { return action.get(); }
            catch (AmqpException exception) { throw mapFailure(exception, "RabbitMQ operation failed"); }
        });
    }

    private ConnectorException mapFailure(Throwable cause, String message) {
        ConnectorErrorCode code = Thread.currentThread().isInterrupted() ? ConnectorErrorCode.INTERRUPTED
                : cause instanceof AmqpConnectException ? ConnectorErrorCode.UNAVAILABLE
                : cause instanceof AmqpTimeoutException ? ConnectorErrorCode.TIMEOUT
                : cause instanceof AmqpResourceNotAvailableException ? ConnectorErrorCode.SATURATED
                : ConnectorErrorCode.REMOTE_ERROR;
        return failure(code, message, cause);
    }

    private ConnectorException failure(ConnectorErrorCode code, String message, Throwable cause) {
        return new ConnectorException(code, type(), name, message, ConnectorException.redactedCause(cause));
    }

    private void checkBodySize(int size) {
        if (size > maxMessageBytes) { throw new IllegalArgumentException("RabbitMQ body exceeds the configured message limit"); }
    }

    private void ensureOpen() {
        if (closed.get()) { throw failure(ConnectorErrorCode.CLOSED, "RabbitMQ connector is closed", null); }
    }

    private void ensureNotInterrupted() {
        if (Thread.currentThread().isInterrupted()) {
            throw failure(ConnectorErrorCode.INTERRUPTED, "RabbitMQ operation interrupted before transport execution", null);
        }
    }

    /** RabbitTemplate otherwise logs received message bodies and properties at DEBUG level. */
    private static final class SafeRabbitTemplate extends RabbitTemplate {
        private SafeRabbitTemplate(ConnectionFactory factory) { super(factory); }

        @Override
        protected void logReceived(String prefix, Message message) {
            // ConnectorExecutor observes logical operation outcomes; avoid transport body dumps.
        }
    }

    /** RabbitTemplate's outbound DEBUG log calls Message.toString; keep that diagnostic safe. */
    private static final class SafeMessage extends Message {
        private static final long serialVersionUID = 1L;
        private SafeMessage(byte[] body, MessageProperties properties) { super(body, properties); }

        @Override public String toString() { return "RabbitMQMessage[bodyBytes=" + getBody().length + "]"; }
    }
}
