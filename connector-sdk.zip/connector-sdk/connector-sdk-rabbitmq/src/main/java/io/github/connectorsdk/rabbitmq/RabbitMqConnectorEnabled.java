package io.github.connectorsdk.rabbitmq;

/** Internal activation marker imported by {@link EnableRabbitMqConnector}. */
public final class RabbitMqConnectorEnabled {
}
