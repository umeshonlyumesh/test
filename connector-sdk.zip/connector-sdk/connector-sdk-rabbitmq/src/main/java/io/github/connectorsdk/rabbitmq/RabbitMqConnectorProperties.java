package io.github.connectorsdk.rabbitmq;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("connector.sdk.rabbitmq")
public class RabbitMqConnectorProperties {
    private Boolean enabled;
    private Map<String, Client> clients = new LinkedHashMap<>();

    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public Map<String, Client> getClients() { return clients; }
    public void setClients(Map<String, Client> clients) { this.clients = clients; }

    public void validate() {
        if (clients == null || clients.isEmpty()) {
            throw new IllegalArgumentException("Enabled RabbitMQ connector requires connector.sdk.rabbitmq.clients");
        }
        clients.forEach((name, client) -> {
            if (name == null || !name.matches("[a-zA-Z][a-zA-Z0-9._-]{0,63}")) {
                throw new IllegalArgumentException("RabbitMQ client names must begin with a letter and contain at most 64 letters, digits, '.', '_' or '-'");
            }
            if (client == null) {
                throw new IllegalArgumentException("RabbitMQ client '" + name + "' requires configuration");
            }
            client.validate(name);
        });
    }

    public static class Client {
        private String connectionFactoryBean;
        private String exchange = "";
        private String routingKey;
        private String queue;
        private Duration receiveTimeout = Duration.ofSeconds(5);
        private Duration confirmTimeout = Duration.ofSeconds(5);
        private Duration timeToLive = Duration.ZERO;
        private boolean publisherConfirms = true;
        private boolean persistent = true;
        private int maxConcurrentCalls = 32;
        private int maxMessageBytes = 16 * 1024 * 1024;

        public String getConnectionFactoryBean() { return connectionFactoryBean; }
        public void setConnectionFactoryBean(String value) { connectionFactoryBean = value; }
        public String getExchange() { return exchange; }
        public void setExchange(String value) { exchange = value; }
        public String getRoutingKey() { return routingKey; }
        public void setRoutingKey(String value) { routingKey = value; }
        public String getQueue() { return queue; }
        public void setQueue(String value) { queue = value; }
        public Duration getReceiveTimeout() { return receiveTimeout; }
        public void setReceiveTimeout(Duration value) { receiveTimeout = value; }
        public Duration getConfirmTimeout() { return confirmTimeout; }
        public void setConfirmTimeout(Duration value) { confirmTimeout = value; }
        public Duration getTimeToLive() { return timeToLive; }
        public void setTimeToLive(Duration value) { timeToLive = value; }
        public boolean isPublisherConfirms() { return publisherConfirms; }
        public void setPublisherConfirms(boolean value) { publisherConfirms = value; }
        public boolean isPersistent() { return persistent; }
        public void setPersistent(boolean value) { persistent = value; }
        public int getMaxConcurrentCalls() { return maxConcurrentCalls; }
        public void setMaxConcurrentCalls(int value) { maxConcurrentCalls = value; }
        public int getMaxMessageBytes() { return maxMessageBytes; }
        public void setMaxMessageBytes(int value) { maxMessageBytes = value; }

        /** Default exchange sends may use the receive queue as their routing key when none is supplied. */
        public String effectiveRoutingKey() {
            return routingKey != null ? routingKey : (exchange.isEmpty() && queue != null ? queue : "");
        }

        public void validate(String name) {
            String prefix = "RabbitMQ client '" + name + "': ";
            if (connectionFactoryBean == null || connectionFactoryBean.isBlank()
                    || !connectionFactoryBean.equals(connectionFactoryBean.trim())) {
                throw new IllegalArgumentException(prefix + "connection-factory-bean must explicitly name a caller-owned AMQP ConnectionFactory bean");
            }
            if (exchange == null) {
                throw new IllegalArgumentException(prefix + "exchange must not be null; use an empty string for the default exchange");
            }
            validateShortString(exchange, prefix + "exchange");
            if (routingKey != null) { validateShortString(routingKey, prefix + "routing-key"); }
            if (queue != null) {
                if (queue.isBlank()) { throw new IllegalArgumentException(prefix + "queue must not be blank when configured"); }
                validateShortString(queue, prefix + "queue");
            }
            if (exchange.isEmpty() && effectiveRoutingKey().isEmpty()) {
                throw new IllegalArgumentException(prefix + "default exchange requires routing-key or queue");
            }
            requirePositiveMillis(receiveTimeout, prefix + "receive-timeout");
            if (confirmTimeout == null || confirmTimeout.isNegative() || confirmTimeout.isZero()) {
                throw new IllegalArgumentException(prefix + "confirm-timeout must be positive");
            }
            try { confirmTimeout.toNanos(); }
            catch (ArithmeticException exception) {
                throw new IllegalArgumentException(prefix + "confirm-timeout exceeds the supported duration", exception);
            }
            if (timeToLive == null || timeToLive.isNegative()) {
                throw new IllegalArgumentException(prefix + "time-to-live must be non-negative");
            }
            if (!timeToLive.isZero()) { requirePositiveMillis(timeToLive, prefix + "time-to-live"); }
            if (maxConcurrentCalls < 1 || maxMessageBytes < 1) {
                throw new IllegalArgumentException(prefix + "max-concurrent-calls and max-message-bytes must be positive");
            }
        }

        private static void validateShortString(String value, String field) {
            if (value.length() > 255 || value.getBytes(StandardCharsets.UTF_8).length > 255) {
                throw new IllegalArgumentException(field + " must fit AMQP's 255-byte short string limit");
            }
        }

        private static void requirePositiveMillis(Duration value, String field) {
            if (value == null || value.isNegative() || value.isZero()) {
                throw new IllegalArgumentException(field + " must be positive");
            }
            try {
                if (value.toMillis() < 1) { throw new IllegalArgumentException(field + " must be at least one millisecond"); }
            }
            catch (ArithmeticException exception) {
                throw new IllegalArgumentException(field + " exceeds the supported duration", exception);
            }
        }
    }
}
