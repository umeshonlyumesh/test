package io.github.connectorsdk.rabbitmq;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.rabbitmq.client.LongString;

/** Defensive AMQP field-table snapshots with finite depth, entry and byte budgets. */
final class RabbitMqHeaders {
    private RabbitMqHeaders() { }

    static Map<String, Object> copy(Map<String, Object> headers) {
        Objects.requireNonNull(headers, "headers");
        return copyMap(headers, new Budget(), 0);
    }

    private static Map<String, Object> copyMap(Map<?, ?> values, Budget budget, int depth) {
        checkDepth(depth);
        Map<String, Object> snapshot = new LinkedHashMap<>();
        values.forEach((key, value) -> {
            if (!(key instanceof String name) || name.isEmpty() || name.length() > 255
                    || name.getBytes(StandardCharsets.UTF_8).length > 255) {
                throw new IllegalArgumentException("AMQP header names must be non-empty strings of at most 255 UTF-8 bytes");
            }
            budget.add(name.getBytes(StandardCharsets.UTF_8).length);
            snapshot.put(name, copyValue(value, budget, depth + 1));
        });
        return Collections.unmodifiableMap(snapshot);
    }

    private static Object copyValue(Object value, Budget budget, int depth) {
        checkDepth(depth);
        budget.addEntry();
        budget.add(16);
        if (value == null || value instanceof Boolean || value instanceof Byte || value instanceof Short
                || value instanceof Integer || value instanceof Long || value instanceof Float
                || value instanceof Double || value instanceof BigDecimal) {
            return value;
        }
        if (value instanceof String text) {
            if (text.length() > 65536) { throw oversized(); }
            budget.add(text.getBytes(StandardCharsets.UTF_8).length);
            return text;
        }
        if (value instanceof byte[] bytes) {
            budget.add(bytes.length);
            return bytes.clone();
        }
        if (value instanceof LongString longString) {
            if (longString.length() > 65536) { throw oversized(); }
            byte[] bytes = longString.getBytes();
            budget.add(bytes.length);
            return bytes.clone();
        }
        if (value instanceof Date date) { return new Date(date.getTime()); }
        if (value instanceof Map<?, ?> map) { return copyMap(map, budget, depth); }
        if (value instanceof List<?> list) {
            List<Object> snapshot = new ArrayList<>();
            list.forEach(item -> snapshot.add(copyValue(item, budget, depth + 1)));
            return Collections.unmodifiableList(snapshot);
        }
        if (value instanceof Object[] array) {
            List<Object> snapshot = new ArrayList<>();
            for (Object item : array) { snapshot.add(copyValue(item, budget, depth + 1)); }
            return Collections.unmodifiableList(snapshot);
        }
        throw new IllegalArgumentException("Unsupported AMQP header value type");
    }

    private static void checkDepth(int depth) {
        if (depth > 8) { throw new IllegalArgumentException("AMQP header tables may be nested at most eight levels"); }
    }

    private static IllegalArgumentException oversized() {
        return new IllegalArgumentException("AMQP header snapshot exceeds its 64 KiB or 1024-entry budget");
    }

    private static final class Budget {
        private long bytes;
        private int entries;
        private void add(int count) {
            bytes += count;
            if (bytes > 65536) { throw oversized(); }
        }
        private void addEntry() { if (++entries > 1024) { throw oversized(); } }
    }
}
