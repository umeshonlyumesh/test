package io.github.connectorsdk.rabbitmq;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;

/** Immutable received message snapshot; text messages created by the SDK use UTF-8. */
public record RabbitMqMessage(byte[] body, BodyType bodyType, String contentType, String contentEncoding,
                               String messageId, String correlationId, Map<String, Object> headers,
                               boolean redelivered) {
    public enum BodyType { TEXT, BYTES }

    public RabbitMqMessage {
        body = Objects.requireNonNull(body, "body").clone();
        Objects.requireNonNull(bodyType, "bodyType");
        headers = RabbitMqHeaders.copy(headers);
    }

    @Override public byte[] body() { return body.clone(); }
    @Override public Map<String, Object> headers() { return RabbitMqHeaders.copy(headers); }

    public String text() {
        if (bodyType != BodyType.TEXT) { throw new IllegalStateException("This message does not have a UTF-8 text body"); }
        return new String(body, StandardCharsets.UTF_8);
    }

    @Override
    public String toString() {
        return "RabbitMqMessage[bodyType=" + bodyType + ", bodyBytes=" + body.length
                + ", headerCount=" + headers.size() + ", redelivered=" + redelivered + "]";
    }
}
