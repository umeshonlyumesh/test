package io.github.connectorsdk.rabbitmq;

/** A publisher confirmation does not imply that an application consumed or processed the message. */
public enum RabbitMqPublishResult {
    /** Broker acknowledged the publication and did not return it as unroutable. */
    CONFIRMED,
    /** Client send completed; broker acceptance and routing have not been confirmed. */
    SENT_UNCONFIRMED
}
