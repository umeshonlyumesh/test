package io.github.connectorsdk.rabbitmq;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Immutable outbound message identifiers and AMQP headers; diagnostic output omits their values. */
public record RabbitMqSendOptions(String messageId, String correlationId, Map<String, Object> headers) {
    public static final RabbitMqSendOptions NONE = new RabbitMqSendOptions(null, null, Map.of());

    public RabbitMqSendOptions {
        validateIdentifier(messageId);
        validateIdentifier(correlationId);
        headers = RabbitMqHeaders.copy(headers);
    }

    public RabbitMqSendOptions(String correlationId, Map<String, Object> headers) {
        this(null, correlationId, headers);
    }

    @Override public Map<String, Object> headers() { return RabbitMqHeaders.copy(headers); }

    @Override public String toString() { return "RabbitMqSendOptions[headerCount=" + headers.size() + "]"; }

    private static void validateIdentifier(String value) {
        if (value != null && (value.length() > 255 || value.getBytes(StandardCharsets.UTF_8).length > 255)) {
            throw new IllegalArgumentException("AMQP message and correlation identifiers must fit 255 UTF-8 bytes");
        }
    }
}
