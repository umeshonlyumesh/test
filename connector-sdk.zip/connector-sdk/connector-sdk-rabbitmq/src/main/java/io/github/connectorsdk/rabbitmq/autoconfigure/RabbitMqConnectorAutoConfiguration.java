package io.github.connectorsdk.rabbitmq.autoconfigure;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.rabbitmq.RabbitMqConnector;
import io.github.connectorsdk.rabbitmq.RabbitMqConnectorEnabled;
import io.github.connectorsdk.rabbitmq.RabbitMqConnectorProperties;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

@AutoConfiguration(after = ConnectorRuntimeAutoConfiguration.class)
@ConditionalOnClass({RabbitTemplate.class, ConnectionFactory.class, ConnectorExecutorFactory.class})
@ConditionalOnProperty(prefix = "connector.sdk.rabbitmq", name = "enabled", havingValue = "true", matchIfMissing = true)
@Conditional(RabbitMqConnectorAutoConfiguration.EnabledCondition.class)
@EnableConfigurationProperties(RabbitMqConnectorProperties.class)
public class RabbitMqConnectorAutoConfiguration {
    @Bean
    static BeanDefinitionRegistryPostProcessor rabbitMqConnectorBeanRegistrar(Environment environment) {
        RabbitMqConnectorProperties properties = Binder.get(environment)
                .bind("connector.sdk.rabbitmq", Bindable.of(RabbitMqConnectorProperties.class))
                .orElseGet(RabbitMqConnectorProperties::new);
        properties.validate();
        return new RabbitMqBeanRegistrar(properties);
    }

    static final class EnabledCondition extends AnyNestedCondition {
        EnabledCondition() { super(ConfigurationPhase.REGISTER_BEAN); }

        @ConditionalOnBean(RabbitMqConnectorEnabled.class)
        static class AnnotationEnabled { }

        @ConditionalOnProperty(prefix = "connector.sdk.rabbitmq", name = "enabled", havingValue = "true")
        static class PropertyEnabled { }

        @ConditionalOnBean(type = "io.github.connectorsdk.mq.MqConnectorEnabled")
        @Conditional(OwnClientsPresent.class)
        static class AnnotationFamilyEnabled { }
    }

    static final class OwnClientsPresent implements Condition {
        @Override
        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            return Binder.get(context.getEnvironment())
                    .bind("connector.sdk.rabbitmq.clients", Bindable.mapOf(String.class, Object.class))
                    .map(clients -> !clients.isEmpty()).orElse(false);
        }
    }

    private static final class RabbitMqBeanRegistrar implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware {
        private final RabbitMqConnectorProperties properties;
        private ConfigurableListableBeanFactory beanFactory;

        private RabbitMqBeanRegistrar(RabbitMqConnectorProperties properties) { this.properties = properties; }

        @Override
        public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
            this.beanFactory = (ConfigurableListableBeanFactory) beanFactory;
        }

        @Override
        public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            properties.getClients().forEach((name, client) -> {
                String beanName = "rabbitMqConnector." + name;
                if (registry.containsBeanDefinition(beanName) || registry.isAlias(beanName)
                        || beanFactory.containsSingleton(beanName)) { return; }
                RootBeanDefinition definition = new RootBeanDefinition(RabbitMqConnector.class);
                definition.setInstanceSupplier(() -> createConnector(name, client));
                definition.setDestroyMethodName("close");
                registry.registerBeanDefinition(beanName, definition);
            });
        }

        private RabbitMqConnector createConnector(String name, RabbitMqConnectorProperties.Client client) {
            ConnectionFactory factory;
            try { factory = beanFactory.getBean(client.getConnectionFactoryBean(), ConnectionFactory.class); }
            catch (BeansException exception) {
                throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "rabbitmq", name,
                        "Configured RabbitMQ ConnectionFactory bean is missing or has an incompatible type",
                        ConnectorException.redactedCause(exception));
            }
            var executor = beanFactory.getBean(ConnectorExecutorFactory.class)
                    .create("rabbitmq", name, client.getMaxConcurrentCalls());
            return RabbitMqConnector.create(name, factory, client, executor);
        }

        @Override public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) { }
    }
}
