package io.github.connectorsdk.rabbitmq;

import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.mq.EnableMqConnector;
import io.github.connectorsdk.mq.MqConnector;
import io.github.connectorsdk.mq.autoconfigure.MqConnectorAutoConfiguration;
import io.github.connectorsdk.rabbitmq.autoconfigure.RabbitMqConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RabbitMqConnectorAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                    ConnectorSupportAutoConfiguration.class, MqConnectorAutoConfiguration.class,
                    RabbitMqConnectorAutoConfiguration.class))
            .withPropertyValues(
                    "connector.sdk.rabbitmq.clients.orders.connection-factory-bean=rabbitConnectionFactory",
                    "connector.sdk.rabbitmq.clients.orders.exchange=events",
                    "connector.sdk.rabbitmq.clients.orders.routing-key=orders.created",
                    "connector.sdk.rabbitmq.clients.orders.queue=orders",
                    "connector.sdk.rabbitmq.clients.orders.receive-timeout=50ms");

    @Test
    void classpathPresenceAndPropertiesDoNotActivateAnUnselectedProvider() {
        runner.withUserConfiguration(FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().doesNotHaveBean(RabbitMqConnector.class)
                    .doesNotHaveBean(MqConnector.class).doesNotHaveBean(RabbitMqConnectorProperties.class);
            verify(context.getBean(ConnectionFactory.class), never()).createConnection();
        });
    }

    @Test
    void rabbitAnnotationCreatesOneNamedClientWithoutOpeningABrokerConnection() {
        runner.withUserConfiguration(RabbitEnabled.class, FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class)
                    .hasBean("rabbitMqConnector.orders").doesNotHaveBean(MqConnector.class);
            assertThat(context.getBean(ConnectorRegistry.class)
                    .require("rabbitmq", "orders", RabbitMqConnector.class))
                    .isSameAs(context.getBean("rabbitMqConnector.orders"));
            verify(context.getBean(ConnectionFactory.class), never()).createConnection();
        });
    }

    @Test
    void propertyCreatesMultipleExplicitlyNamedClients() {
        runner.withUserConfiguration(FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.rabbitmq.enabled=true",
                        "connector.sdk.rabbitmq.clients.billing.connection-factory-bean=rabbitConnectionFactory",
                        "connector.sdk.rabbitmq.clients.billing.queue=billing")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context.getBeansOfType(RabbitMqConnector.class))
                            .containsOnlyKeys("rabbitMqConnector.orders", "rabbitMqConnector.billing");
                });
    }

    @Test
    void explicitFalseOverridesAnnotationAndSkipsInvalidDisabledConfiguration() {
        runner.withUserConfiguration(RabbitEnabled.class)
                .withPropertyValues("connector.sdk.rabbitmq.enabled=false",
                        "connector.sdk.rabbitmq.clients.orders.receive-timeout=0s")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(RabbitMqConnector.class)
                        .doesNotHaveBean(RabbitMqConnectorProperties.class));
    }

    @Test
    void missingFactoryFailsAtStartupWithoutImplicitBeanSelection() {
        runner.withUserConfiguration(RabbitEnabled.class).run(context -> {
            assertThat(context).hasFailed();
            assertThat(context.getStartupFailure()).hasStackTraceContaining("Configured RabbitMQ ConnectionFactory bean is missing");
        });
        runner.withUserConfiguration(RabbitEnabled.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.rabbitmq.clients.orders.connection-factory-bean=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining("connection-factory-bean must explicitly name");
                });
    }

    @Test
    void defaultConfirmedModeRequiresFactoryConfirmAndReturnCapabilities() {
        runner.withUserConfiguration(RabbitEnabled.class)
                .withBean("rabbitConnectionFactory", ConnectionFactory.class, () -> mock(ConnectionFactory.class))
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining(
                            "require correlated publisher confirms and publisher returns");
                });
    }

    @Test
    void explicitUnconfirmedModeWorksWithAnOrdinaryFactory() {
        runner.withUserConfiguration(RabbitEnabled.class)
                .withBean("rabbitConnectionFactory", ConnectionFactory.class, () -> mock(ConnectionFactory.class))
                .withPropertyValues("connector.sdk.rabbitmq.clients.orders.publisher-confirms=false")
                .run(context -> assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class));
    }

    @Test
    void zeroAndSubMillisecondReceiveTimeoutsFailBeforeTransportCreation() {
        for (String timeout : new String[] {"0s", "1ns"}) {
            runner.withUserConfiguration(RabbitEnabled.class, FactoryConfiguration.class)
                    .withPropertyValues("connector.sdk.rabbitmq.clients.orders.receive-timeout=" + timeout)
                    .run(context -> {
                        assertThat(context).hasFailed();
                        assertThat(context.getStartupFailure()).hasStackTraceContaining("receive-timeout must be");
                    });
        }
    }

    @Test
    void absentOptionalAmqpClassesSkipAutoConfiguration() {
        runner.withClassLoader(new FilteredClassLoader("org.springframework.amqp", "com.rabbitmq"))
                .withPropertyValues("connector.sdk.rabbitmq.enabled=true")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean("rabbitMqConnector.orders")
                        .doesNotHaveBean(RabbitMqConnectorProperties.class));
    }

    @Test
    void umbrellaMqAnnotationCanSelectRabbitMqAloneWithoutCreatingJmsBeans() {
        runner.withUserConfiguration(MqEnabled.class, FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class).doesNotHaveBean(MqConnector.class);
            assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(1);
        });
    }

    @Test
    void umbrellaMqAnnotationSelectsJmsAndRabbitMqWhenBothHaveConfiguredClients() {
        runner.withUserConfiguration(MqEnabled.class, FactoryConfiguration.class, JmsFactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.clients.orders.connection-factory-bean=jmsConnectionFactory",
                        "connector.sdk.mq.clients.orders.destination=ORDERS.REQUEST")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class).hasSingleBean(MqConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).hasSize(2);
                });
    }

    @Test
    void providerFalseSwitchesOverrideUmbrellaActivationIndependently() {
        runner.withUserConfiguration(MqEnabled.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.mq.enabled=false")
                .run(context -> assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class)
                        .doesNotHaveBean(MqConnector.class));
        runner.withUserConfiguration(MqEnabled.class)
                .withPropertyValues("connector.sdk.rabbitmq.enabled=false")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(RabbitMqConnector.class)
                        .doesNotHaveBean(MqConnector.class));
    }

    @Test
    void callerBeanAliasTakesPrecedenceOverTheGeneratedNamedClient() {
        runner.withUserConfiguration(CustomClient.class)
                .withPropertyValues("connector.sdk.rabbitmq.enabled=true")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RabbitMqConnector.class);
                    assertThat(context.getBean("rabbitMqConnector.orders")).isSameAs(context.getBean("customRabbit"));
                });
    }

    @Configuration(proxyBeanMethods = false)
    @EnableRabbitMqConnector
    static class RabbitEnabled { }

    @Configuration(proxyBeanMethods = false)
    @EnableMqConnector
    static class MqEnabled { }

    @Configuration(proxyBeanMethods = false)
    static class FactoryConfiguration {
        @Bean
        ConnectionFactory rabbitConnectionFactory() {
            ConnectionFactory factory = mock(ConnectionFactory.class);
            when(factory.isPublisherConfirms()).thenReturn(true);
            when(factory.isPublisherReturns()).thenReturn(true);
            return factory;
        }
    }

    @Configuration(proxyBeanMethods = false)
    static class JmsFactoryConfiguration {
        @Bean
        jakarta.jms.ConnectionFactory jmsConnectionFactory() { return mock(jakarta.jms.ConnectionFactory.class); }
    }

    @Configuration(proxyBeanMethods = false)
    static class CustomClient {
        @Bean({"customRabbit", "rabbitMqConnector.orders"})
        RabbitMqConnector connector() {
            RabbitMqConnector connector = mock(RabbitMqConnector.class);
            when(connector.type()).thenReturn("rabbitmq");
            when(connector.name()).thenReturn("orders");
            return connector;
        }
    }
}
