package io.github.connectorsdk.rabbitmq;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.springframework.amqp.AmqpConnectException;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.AmqpResourceNotAvailableException;
import org.springframework.amqp.AmqpTimeoutException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.ReturnedMessage;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class RabbitMqConnectorTest {
    @Test
    void confirmedTextPublishPreservesUtf8HeadersAndPersistentDelivery() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        acknowledge(template, true);
        var connector = connector(template, client());
        var options = new RabbitMqSendOptions("order-123", "request-456", Map.of("schemaVersion", 1));

        assertThat(connector.sendText("Grüße 🌍", options)).isEqualTo(RabbitMqPublishResult.CONFIRMED);

        ArgumentCaptor<Message> sent = ArgumentCaptor.forClass(Message.class);
        verify(template).send(eq("events"), eq("orders.created"), sent.capture(), any(CorrelationData.class));
        assertThat(sent.getValue().getBody()).isEqualTo("Grüße 🌍".getBytes(StandardCharsets.UTF_8));
        var properties = sent.getValue().getMessageProperties();
        assertThat(properties.getContentType()).isEqualTo("text/plain");
        assertThat(properties.getContentEncoding()).isEqualTo("UTF-8");
        assertThat(properties.getDeliveryMode()).isEqualTo(MessageDeliveryMode.PERSISTENT);
        assertThat(properties.getMessageId()).isEqualTo("order-123");
        assertThat(properties.getCorrelationId()).isEqualTo("request-456");
        assertThat(properties.getHeaders()).containsEntry("schemaVersion", 1);
        assertThat(sent.getValue().toString()).doesNotContain("Grüße", "order-123", "request-456", "schemaVersion");
    }

    @Test
    void unconfirmedSendReportsItsActualGuaranteeAndCopiesBinaryPayload() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        var client = client();
        client.setPublisherConfirms(false);
        client.setTimeToLive(Duration.ofSeconds(30));
        var connector = connector(template, client);
        byte[] payload = {1, 2, 3};

        assertThat(connector.sendBytes(payload)).isEqualTo(RabbitMqPublishResult.SENT_UNCONFIRMED);
        payload[0] = 9;

        ArgumentCaptor<Message> sent = ArgumentCaptor.forClass(Message.class);
        verify(template).send(eq("events"), eq("orders.created"), sent.capture());
        assertThat(sent.getValue().getBody()).containsExactly(new byte[] {1, 2, 3});
        assertThat(sent.getValue().getMessageProperties().getContentType()).isEqualTo("application/octet-stream");
        assertThat(sent.getValue().getMessageProperties().getExpiration()).isEqualTo("30000");
    }

    @Test
    void negativeAcknowledgementDoesNotExposeBrokerReasonOrRetry() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        acknowledge(template, false);
        var connector = connector(template, client());

        assertThatThrownBy(() -> connector.sendText("payload-secret"))
                .isInstanceOfSatisfying(ConnectorException.class, failure -> {
                    assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR);
                    assertThat(stack(failure)).doesNotContain("broker-secret", "payload-secret");
                }).hasMessage("RabbitMQ broker rejected the publication");
        verify(template, times(1)).send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));
    }

    @Test
    void mandatoryReturnIsFailureEvenWhenBrokerAcknowledgesThePublish() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        doAnswer(invocation -> {
            CorrelationData correlation = invocation.getArgument(3);
            correlation.setReturned(new ReturnedMessage(invocation.getArgument(2), 312,
                    "broker-secret", "exchange-secret", "routing-secret"));
            correlation.getFuture().complete(new CorrelationData.Confirm(true, null));
            return null;
        }).when(template).send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));

        assertThatThrownBy(() -> connector(template, client()).sendText("payload-secret"))
                .isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(stack(failure)).doesNotContain("broker-secret", "exchange-secret",
                                "routing-secret", "payload-secret"))
                .hasMessage("RabbitMQ publication was returned as unroutable");
    }

    @Test
    void confirmationWaitIsBoundedAndReportsUncertainOutcomeWithoutRetrying() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        var client = client();
        client.setConfirmTimeout(Duration.ofMillis(10));
        long before = System.nanoTime();

        assertThatThrownBy(() -> connector(template, client).sendText("test"))
                .isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.TIMEOUT))
                .hasMessageContaining("publish outcome is uncertain");

        assertThat(Duration.ofNanos(System.nanoTime() - before)).isLessThan(Duration.ofSeconds(2));
        verify(template, times(1)).send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));
    }

    @Test
    void interruptedConfirmationRestoresInterruptStatusAndDoesNotRepublish() throws Exception {
        RabbitTemplate template = mock(RabbitTemplate.class);
        CountDownLatch published = new CountDownLatch(1);
        AtomicReference<Thread> worker = new AtomicReference<>();
        doAnswer(invocation -> { published.countDown(); return null; }).when(template)
                .send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));
        var connector = connector(template, client());
        try (var tasks = Executors.newVirtualThreadPerTaskExecutor()) {
            var pending = tasks.submit(() -> {
                worker.set(Thread.currentThread());
                try {
                    connector.sendText("test");
                    throw new AssertionError("Expected the confirmation wait to be interrupted");
                }
                catch (ConnectorException failure) {
                    return new InterruptedResult(failure.errorCode(), Thread.currentThread().isInterrupted());
                }
            });
            assertThat(published.await(2, TimeUnit.SECONDS)).isTrue();
            worker.get().interrupt();
            assertThat(pending.get(2, TimeUnit.SECONDS))
                    .isEqualTo(new InterruptedResult(ConnectorErrorCode.INTERRUPTED, true));
        }
        verify(template, times(1)).send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));
    }

    @Test
    void receiveUsesFiniteConfiguredWaitAndReturnsAnImmutableSnapshot() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        byte[] payload = "body-secret".getBytes(StandardCharsets.UTF_8);
        byte[] headerBytes = {1, 2};
        Date headerDate = new Date(1000);
        var properties = new MessageProperties();
        properties.setContentType("text/plain");
        properties.setContentEncoding("UTF-8");
        properties.setCorrelationId("correlation-secret");
        properties.setHeader("blob", headerBytes);
        properties.setHeader("date", headerDate);
        when(template.receive("orders", 50)).thenReturn(new Message(payload, properties));

        var received = connector(template, client()).receive().orElseThrow();
        payload[0] = 0;
        headerBytes[0] = 9;
        headerDate.setTime(2000);
        ((byte[]) received.headers().get("blob"))[0] = 8;
        ((Date) received.headers().get("date")).setTime(3000);

        assertThat(received.text()).isEqualTo("body-secret");
        assertThat((byte[]) received.headers().get("blob")).containsExactly(new byte[] {1, 2});
        assertThat(((Date) received.headers().get("date")).getTime()).isEqualTo(1000);
        assertThat(received.toString()).doesNotContain("body-secret", "correlation-secret", "blob", "date");
        verify(template).receive("orders", 50);
    }

    @Test
    void noMessageReturnsEmptyAndNoQueueFailsBeforeCallingTheTransport() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        assertThat(connector(template, client()).receive()).isEmpty();
        var publisherOnly = client();
        publisherOnly.setQueue(null);

        assertThatThrownBy(() -> connector(template, publisherOnly).receive())
                .isInstanceOfSatisfying(ConnectorException.class,
                        failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CONFIGURATION));
        verify(template, times(1)).receive("orders", 50);
    }

    @Test
    void bodyLimitsApplyBeforePublishAndAfterReceive() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        var connector = connector(template, client());
        assertThatThrownBy(() -> connector.sendBytes(new byte[1025])).isInstanceOf(IllegalArgumentException.class);
        verifyNoInteractions(template);
        when(template.receive("orders", 50)).thenReturn(new Message(new byte[1025], new MessageProperties()));

        assertThatThrownBy(connector::receive).isInstanceOf(ConnectorException.class)
                .hasMessage("Received RabbitMQ message exceeds the configured body limit");
    }

    @ParameterizedTest
    @MethodSource("providerFailures")
    void mapsKnownProviderFailuresAndRedactsDiagnosticStacks(AmqpException providerFailure, ConnectorErrorCode code) {
        RabbitTemplate template = mock(RabbitTemplate.class);
        when(template.receive("orders", 50)).thenThrow(providerFailure);

        assertThatThrownBy(() -> connector(template, client()).receive())
                .isInstanceOfSatisfying(ConnectorException.class, failure -> {
                    assertThat(failure.errorCode()).isEqualTo(code);
                    assertThat(stack(failure)).doesNotContain("broker-secret");
                });
    }

    @Test
    void closeIsIdempotentRejectsNewCallsAndDoesNotResetTheCallerFactory() {
        ConnectionFactory factory = mock(ConnectionFactory.class);
        when(factory.isPublisherConfirms()).thenReturn(true);
        when(factory.isPublisherReturns()).thenReturn(true);
        var connector = RabbitMqConnector.create("orders", factory, client(), executor());
        connector.close();
        connector.close();

        assertThatThrownBy(connector::receive).isInstanceOfSatisfying(ConnectorException.class,
                failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CLOSED));
        verify(factory, never()).createConnection();
        verify(factory, never()).resetConnection();
    }

    @Test
    void closeDestroysTheOwnedTemplateExactlyOnce() {
        RabbitTemplate template = mock(RabbitTemplate.class);
        var connector = connector(template, client());
        connector.close();
        connector.close();
        verify(template, times(1)).destroy();
    }

    static Stream<Arguments> providerFailures() {
        return Stream.of(
                Arguments.of(new AmqpConnectException(new ConnectException("broker-secret")), ConnectorErrorCode.UNAVAILABLE),
                Arguments.of(new AmqpTimeoutException("broker-secret"), ConnectorErrorCode.TIMEOUT),
                Arguments.of(new AmqpResourceNotAvailableException("broker-secret"), ConnectorErrorCode.SATURATED),
                Arguments.of(new AmqpException("broker-secret"), ConnectorErrorCode.REMOTE_ERROR));
    }

    static RabbitMqConnectorProperties.Client client() {
        var client = new RabbitMqConnectorProperties.Client();
        client.setConnectionFactoryBean("rabbitConnectionFactory");
        client.setExchange("events");
        client.setRoutingKey("orders.created");
        client.setQueue("orders");
        client.setReceiveTimeout(Duration.ofMillis(50));
        client.setMaxMessageBytes(1024);
        return client;
    }

    private static RabbitMqConnector connector(RabbitTemplate template, RabbitMqConnectorProperties.Client client) {
        return new RabbitMqConnector("orders", template, client, executor());
    }

    private static ConnectorExecutor executor() {
        return new ConnectorExecutor("rabbitmq", "orders", 2, InvocationObserver.NONE);
    }

    private static void acknowledge(RabbitTemplate template, boolean ack) {
        doAnswer(invocation -> {
            CorrelationData correlation = invocation.getArgument(3);
            correlation.getFuture().complete(new CorrelationData.Confirm(ack, ack ? null : "broker-secret"));
            return null;
        }).when(template).send(any(String.class), any(String.class), any(Message.class), any(CorrelationData.class));
    }

    private static String stack(Throwable failure) {
        StringWriter output = new StringWriter();
        failure.printStackTrace(new PrintWriter(output));
        return output.toString();
    }

    private record InterruptedResult(ConnectorErrorCode code, boolean interrupted) { }
}
