package io.github.connectorsdk.rabbitmq;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RabbitMqModelTest {
    @Test
    void optionsCopyNestedAmqpHeadersAndHideIdentifiersAndValues() {
        byte[] bytes = {1};
        Map<String, Object> nested = new HashMap<>();
        nested.put("blob", bytes);
        List<Object> list = new ArrayList<>();
        list.add(nested);
        var options = new RabbitMqSendOptions("message-secret", "correlation-secret", Map.of("x-death", list));
        bytes[0] = 9;
        nested.put("new", "secret");
        list.clear();

        var copiedList = (List<?>) options.headers().get("x-death");
        var copiedMap = (Map<?, ?>) copiedList.getFirst();
        assertThat((byte[]) copiedMap.get("blob")).containsExactly(new byte[] {1});
        assertThat(copiedMap.containsKey("new")).isFalse();
        assertThatThrownBy(copiedList::clear).isInstanceOf(UnsupportedOperationException.class);
        assertThat(options.toString()).isEqualTo("RabbitMqSendOptions[headerCount=1]")
                .doesNotContain("message-secret", "correlation-secret", "x-death", "blob");
    }

    @Test
    void snapshotsRejectUnsupportedOversizedAndCyclicTables() {
        assertThatThrownBy(() -> new RabbitMqSendOptions(null, Map.of("bad", new Object())))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new RabbitMqSendOptions(null, Map.of("big", new byte[65537])))
                .isInstanceOf(IllegalArgumentException.class);
        Map<String, Object> cyclic = new HashMap<>();
        cyclic.put("self", cyclic);
        assertThatThrownBy(() -> new RabbitMqSendOptions(null, cyclic)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void messageSnapshotsHideContentAndCopyArrays() {
        byte[] bytes = "payload-secret".getBytes(StandardCharsets.UTF_8);
        var message = new RabbitMqMessage(bytes, RabbitMqMessage.BodyType.TEXT, "text/plain", "UTF-8",
                "message-secret", "correlation-secret", Map.of("authorization", "header-secret"), false);
        bytes[0] = 0;
        message.body()[0] = 0;

        assertThat(message.text()).isEqualTo("payload-secret");
        assertThat(message.toString()).doesNotContain("payload-secret", "message-secret", "correlation-secret", "header-secret", "authorization");
    }
}
