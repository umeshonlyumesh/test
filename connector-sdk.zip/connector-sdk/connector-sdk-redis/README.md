# Redis connector

This module provides synchronous binary Redis commands with explicit activation, named clients,
fail-fast concurrency bounds, UTF-8 keys, byte-array values, atomic counter updates and atomic
set-if-absent with expiry. No Java object deserialization is used.

Add `connector-sdk-redis-spring-boot-starter` to a Spring Boot 4 application, or add this module
plus a supported Redis driver. The starter supplies Lettuce. The application owns one or more
`RedisConnectionFactory` beans and their authentication, TLS, topology, network timeouts, pooling,
reconnect policy and shutdown. Standalone, Sentinel and Cluster configurations can use the same
connector API through the caller's factory.

```java
@SpringBootApplication
@EnableRedisConnector
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

```yaml
connector:
  sdk:
    redis:
      clients:
        orders:
          connection-factory-bean: redisConnectionFactory
          key-prefix: "orders:"
          max-concurrent-calls: 32
          max-key-bytes: 1024
          max-payload-bytes: 16777216
```

`connector.sdk.redis.enabled=true` also activates Redis without the annotation. An explicit
`enabled=false` overrides the annotation and skips Redis validation and connector creation.
Classpath presence and client properties alone do not activate it. Injection uses
`@Qualifier("redisConnector.orders") RedisConnector`; the common registry also supports
`registry.require("redis", "orders", RedisConnector.class)`. Multiple clients register separate
named beans. A replacement bean or alias with the configured bean name takes precedence and
must have matching connector type and logical name.

```java
redis.put("id-123", payload, Duration.ofMinutes(10));
Optional<byte[]> cached = redis.get("id-123");
redis.putPersistent("settings", settingsBytes);
boolean created = redis.setIfAbsent("dedup:123", token, Duration.ofMinutes(5));
long next = redis.increment("sequence", 1);
boolean deleted = redis.delete("id-123");
```

TTL is mandatory for `put` and `setIfAbsent`, must be positive and at least one millisecond,
and is rounded down to millisecond precision. `putPersistent` explicitly creates a persistent
value and removes an existing TTL. Atomic `INCRBY` preserves an existing TTL; a new counter
is persistent and requires a decimal integer value if initialized through another client.
`setIfAbsent` uses one Redis `SET` command with `NX` and expiry; this API alone does not provide
a complete distributed lock with ownership-safe release or fencing.

Limits include the UTF-8 prefix in key bytes. Inputs and outputs are copied, and an oversized
fetched value is rejected after the Redis driver receives it. Configure Redis and provider
limits for workloads requiring a wire-level or allocation bound. Keys and payloads are never
placed in SDK error messages or observation tags. Potentially sensitive provider exception
messages and cause chains are redacted before observation or application logging.

`QueryTimeoutException` maps to `TIMEOUT`, resource/connection failures to `UNAVAILABLE`, and
other Spring data failures to `REMOTE_ERROR`. SDK admission saturation maps to `SATURATED`.
The SDK performs no retries: an uncertain write or increment outcome should be reconciled
instead of automatically replayed. Provider reconnect or replay policies remain application
configuration. This API rejects pipelined and queued transaction connections because scalar
return values cannot represent deferred results.

`close()` rejects subsequent operations and leaves in-flight operations to complete using
provider deadlines. It does not close the application connection factory. Spring calls it
automatically on SDK-managed connector beans.

The module contains command-level Mockito tests against a real private `RedisTemplate` plus
Spring context activation, alias, validation and shutdown tests. A real Redis server,
Sentinel, Cluster, TLS, ACL and failover require environment integration testing before release.
