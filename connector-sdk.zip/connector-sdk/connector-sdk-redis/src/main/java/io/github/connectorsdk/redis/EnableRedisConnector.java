package io.github.connectorsdk.redis;

import org.springframework.context.annotation.Import;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Opt in to Redis connector beans. Explicit connector.sdk.redis.enabled=false takes precedence. */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(RedisConnectorEnabled.class)
public @interface EnableRedisConnector { }
