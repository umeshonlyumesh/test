package io.github.connectorsdk.redis;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/**
 * Thread-safe synchronous binary Redis commands. Keys use UTF-8 and values remain byte arrays.
 * The caller owns connection-factory authentication, TLS, topology, timeout and reconnect settings.
 * This connector performs no retries and does not destroy the caller's connection factory.
 * SDK concurrency limits are fail-fast; transport calls are bounded by the provider's timeouts.
 */
public final class RedisConnector implements Connector {
    private final String name;
    private final RedisTemplate<String, byte[]> template;
    private final ConnectorExecutor executor;
    private final String keyPrefix;
    private final int maxKeyBytes;
    private final int maxPayloadBytes;
    private final AtomicBoolean closed = new AtomicBoolean();

    private RedisConnector(String name, RedisTemplate<String, byte[]> template, ConnectorExecutor executor,
                           String keyPrefix, int maxKeyBytes, int maxPayloadBytes) {
        this.name = name;
        this.template = template;
        this.executor = executor;
        this.keyPrefix = keyPrefix;
        this.maxKeyBytes = maxKeyBytes;
        this.maxPayloadBytes = maxPayloadBytes;
    }

    /** Creates the private immutable template configuration without opening a Redis connection. */
    public static RedisConnector create(String name, RedisConnectionFactory connectionFactory,
                                        RedisConnectorProperties.Client properties, ConnectorExecutor executor) {
        if (Objects.requireNonNull(name, "name").isBlank()) {
            throw new IllegalArgumentException("Redis connector name must not be blank");
        }
        Objects.requireNonNull(connectionFactory, "connectionFactory");
        Objects.requireNonNull(properties, "properties").validate(name);
        Objects.requireNonNull(executor, "executor");
        RedisTemplate<String, byte[]> template = new ScalarRedisTemplate();
        template.setConnectionFactory(connectionFactory);
        template.setEnableDefaultSerializer(false);
        template.setDefaultSerializer(RedisSerializer.byteArray());
        template.setEnableTransactionSupport(false);
        template.setKeySerializer(RedisSerializer.string());
        template.setValueSerializer(RedisSerializer.byteArray());
        template.setHashKeySerializer(RedisSerializer.string());
        template.setHashValueSerializer(RedisSerializer.byteArray());
        template.afterPropertiesSet();
        return new RedisConnector(name, template, executor, properties.getKeyPrefix(),
                properties.getMaxKeyBytes(), properties.getMaxPayloadBytes());
    }

    @Override public String name() { return name; }
    @Override public String type() { return "redis"; }

    public Optional<byte[]> get(String key) {
        String physicalKey = physicalKey(key);
        return invoke("get", () -> {
            byte[] result = template.opsForValue().get(physicalKey);
            if (result == null) {
                return Optional.empty();
            }
            if (result.length > maxPayloadBytes) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR, "Redis value exceeds the configured payload limit", null);
            }
            return Optional.of(result.clone());
        });
    }

    /** Atomically sets a value and its expiry. TTL must be positive and at least one millisecond. */
    public void put(String key, byte[] value, Duration ttl) {
        String physicalKey = physicalKey(key);
        byte[] snapshot = snapshot(value);
        Duration expiry = validatedTtl(ttl);
        invoke("put", () -> {
            template.opsForValue().set(physicalKey, snapshot, expiry);
            return null;
        });
    }

    /** Explicit persistent SET. Replaces the value and removes any existing TTL. */
    public void putPersistent(String key, byte[] value) {
        String physicalKey = physicalKey(key);
        byte[] snapshot = snapshot(value);
        invoke("put-persistent", () -> {
            template.opsForValue().set(physicalKey, snapshot);
            return null;
        });
    }

    /** Uses one atomic SET NX with expiry; false means that the key already exists. */
    public boolean setIfAbsent(String key, byte[] value, Duration ttl) {
        String physicalKey = physicalKey(key);
        byte[] snapshot = snapshot(value);
        Duration expiry = validatedTtl(ttl);
        return invoke("set-if-absent", () -> requiredResult(
                template.opsForValue().setIfAbsent(physicalKey, snapshot, expiry)));
    }

    /** Deletes one key; false means that the key did not exist. */
    public boolean delete(String key) {
        String physicalKey = physicalKey(key);
        return invoke("delete", () -> requiredResult(template.delete(physicalKey)));
    }

    public long increment(String key) { return increment(key, 1); }

    /** Atomic INCRBY. New counters are persistent; existing TTLs are preserved by Redis. */
    public long increment(String key, long delta) {
        String physicalKey = physicalKey(key);
        return invoke("increment", () -> requiredResult(template.opsForValue().increment(physicalKey, delta)));
    }

    public boolean isClosed() { return closed.get(); }

    /** Rejects subsequent calls. In-flight calls finish; caller-owned resources stay open. */
    @Override public void close() { closed.set(true); }

    private <T> T invoke(String operation, Supplier<T> action) {
        ensureOpen();
        return executor.execute(operation, () -> {
            ensureOpen();
            try {
                return action.get();
            } catch (DataAccessException exception) {
                ConnectorErrorCode code = Thread.currentThread().isInterrupted() ? ConnectorErrorCode.INTERRUPTED
                        : exception instanceof QueryTimeoutException ? ConnectorErrorCode.TIMEOUT
                        : exception instanceof DataAccessResourceFailureException ? ConnectorErrorCode.UNAVAILABLE
                        : ConnectorErrorCode.REMOTE_ERROR;
                throw failure(code, "Redis operation failed", exception);
            }
        });
    }

    private String physicalKey(String key) {
        ensureOpen();
        Objects.requireNonNull(key, "key");
        if (key.isBlank() || (long) keyPrefix.length() + key.length() > maxKeyBytes
                || !StandardCharsets.UTF_8.newEncoder().canEncode(key)) {
            throw new IllegalArgumentException("Redis key must be nonblank valid UTF-8 within the configured key limit");
        }
        String physicalKey = keyPrefix + key;
        if (physicalKey.getBytes(StandardCharsets.UTF_8).length > maxKeyBytes) {
            throw new IllegalArgumentException("Redis key exceeds the configured key limit including its prefix");
        }
        return physicalKey;
    }

    private byte[] snapshot(byte[] value) {
        Objects.requireNonNull(value, "value");
        if (value.length > maxPayloadBytes) {
            throw new IllegalArgumentException("Redis value exceeds the configured payload limit");
        }
        return value.clone();
    }

    private static Duration validatedTtl(Duration ttl) {
        Objects.requireNonNull(ttl, "ttl");
        if (ttl.isNegative() || ttl.isZero()) {
            throw new IllegalArgumentException("Redis TTL must be positive; use putPersistent for persistent values");
        }
        try {
            long millis = ttl.toMillis();
            if (millis < 1) {
                throw new IllegalArgumentException("Redis TTL must be at least one millisecond");
            }
            return Duration.ofMillis(millis);
        } catch (ArithmeticException exception) {
            throw new IllegalArgumentException("Redis TTL exceeds the supported duration");
        }
    }

    private <T> T requiredResult(T result) {
        if (result == null) {
            throw failure(ConnectorErrorCode.REMOTE_ERROR,
                    "Redis command did not return a result; pipelined or externally queued transactions are unsupported", null);
        }
        return result;
    }

    private void ensureOpen() {
        if (closed.get()) {
            throw failure(ConnectorErrorCode.CLOSED, "Redis connector is closed", null);
        }
    }

    private ConnectorException failure(ConnectorErrorCode code, String message, Throwable cause) {
        return new ConnectorException(code, type(), name, message, ConnectorException.redactedCause(cause));
    }

    private static final class ScalarRedisTemplate extends RedisTemplate<String, byte[]> {
        @Override
        protected RedisConnection preProcessConnection(RedisConnection connection, boolean existingConnection) {
            if (connection.isPipelined() || connection.isQueueing()) {
                throw new InvalidDataAccessApiUsageException(
                        "Redis scalar connector does not support pipelined or queued transaction connections");
            }
            return connection;
        }
    }
}
