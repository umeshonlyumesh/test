package io.github.connectorsdk.redis;

/** Internal marker imported by {@link EnableRedisConnector}. */
public final class RedisConnectorEnabled { }
