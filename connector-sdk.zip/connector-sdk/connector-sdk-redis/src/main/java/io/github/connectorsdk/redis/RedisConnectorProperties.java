package io.github.connectorsdk.redis;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

@ConfigurationProperties("connector.sdk.redis")
public class RedisConnectorProperties {
    private Boolean enabled;
    private Map<String, Client> clients = new LinkedHashMap<>();

    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public Map<String, Client> getClients() { return clients; }
    public void setClients(Map<String, Client> clients) { this.clients = clients; }

    public void validate() {
        if (clients == null || clients.isEmpty()) {
            throw new IllegalArgumentException("Enabled Redis connector requires connector.sdk.redis.clients");
        }
        clients.forEach((name, client) -> {
            if (name == null || !name.matches("[a-zA-Z][a-zA-Z0-9._-]{0,63}")) {
                throw new IllegalArgumentException("Redis client names must begin with a letter and contain at most 64 letters, digits, '.', '_' or '-'");
            }
            if (client == null) {
                throw new IllegalArgumentException("Redis client configuration must not be null");
            }
            client.validate(name);
        });
    }

    public static class Client {
        private String connectionFactoryBean;
        private String keyPrefix = "";
        private int maxConcurrentCalls = 32;
        private int maxKeyBytes = 1024;
        private int maxPayloadBytes = 16 * 1024 * 1024;

        public String getConnectionFactoryBean() { return connectionFactoryBean; }
        public void setConnectionFactoryBean(String value) { connectionFactoryBean = value; }
        public String getKeyPrefix() { return keyPrefix; }
        public void setKeyPrefix(String value) { keyPrefix = value; }
        public int getMaxConcurrentCalls() { return maxConcurrentCalls; }
        public void setMaxConcurrentCalls(int value) { maxConcurrentCalls = value; }
        public int getMaxKeyBytes() { return maxKeyBytes; }
        public void setMaxKeyBytes(int value) { maxKeyBytes = value; }
        public int getMaxPayloadBytes() { return maxPayloadBytes; }
        public void setMaxPayloadBytes(int value) { maxPayloadBytes = value; }

        public void validate(String name) {
            String prefix = "Redis client '" + name + "': ";
            if (connectionFactoryBean == null || connectionFactoryBean.isBlank()
                    || !connectionFactoryBean.equals(connectionFactoryBean.trim())) {
                throw new IllegalArgumentException(prefix + "connection-factory-bean must explicitly name a caller-owned RedisConnectionFactory bean");
            }
            if (maxConcurrentCalls < 1 || maxKeyBytes < 1 || maxPayloadBytes < 1) {
                throw new IllegalArgumentException(prefix + "max-concurrent-calls, max-key-bytes and max-payload-bytes must be positive");
            }
            if (keyPrefix == null || keyPrefix.length() >= maxKeyBytes
                    || !StandardCharsets.UTF_8.newEncoder().canEncode(keyPrefix)
                    || keyPrefix.getBytes(StandardCharsets.UTF_8).length >= maxKeyBytes) {
                throw new IllegalArgumentException(prefix + "key-prefix must be valid UTF-8 and leave room for a nonempty key within max-key-bytes");
            }
        }
    }
}
