package io.github.connectorsdk.redis.autoconfigure;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.redis.RedisConnector;
import io.github.connectorsdk.redis.RedisConnectorEnabled;
import io.github.connectorsdk.redis.RedisConnectorProperties;
import io.github.connectorsdk.spring.ConnectorBeanValidator;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

@AutoConfiguration(after = ConnectorRuntimeAutoConfiguration.class)
@ConditionalOnClass({RedisTemplate.class, RedisConnectionFactory.class, ConnectorExecutorFactory.class})
@ConditionalOnProperty(prefix = "connector.sdk.redis", name = "enabled", havingValue = "true", matchIfMissing = true)
@Conditional(RedisConnectorAutoConfiguration.EnabledCondition.class)
@EnableConfigurationProperties(RedisConnectorProperties.class)
public class RedisConnectorAutoConfiguration {
    @Bean
    ConnectorBeanValidator redisConnectorBeanValidator(ConfigurableListableBeanFactory factory,
                                                       RedisConnectorProperties properties) {
        return new ConnectorBeanValidator(factory, properties.getClients().keySet().stream()
                .map(name -> new ConnectorBeanValidator.Expectation("redisConnector." + name,
                        "redis", name, RedisConnector.class)).toList());
    }

    @Bean
    static BeanDefinitionRegistryPostProcessor redisConnectorBeanRegistrar(Environment environment) {
        RedisConnectorProperties properties = Binder.get(environment)
                .bind("connector.sdk.redis", Bindable.of(RedisConnectorProperties.class))
                .orElseGet(RedisConnectorProperties::new);
        properties.validate();
        return new RedisBeanRegistrar(properties);
    }

    static final class EnabledCondition extends AnyNestedCondition {
        EnabledCondition() { super(ConfigurationPhase.REGISTER_BEAN); }

        @ConditionalOnBean(RedisConnectorEnabled.class)
        static class AnnotationEnabled { }

        @ConditionalOnProperty(prefix = "connector.sdk.redis", name = "enabled", havingValue = "true")
        static class PropertyEnabled { }
    }

    private static final class RedisBeanRegistrar implements BeanDefinitionRegistryPostProcessor, BeanFactoryAware {
        private final RedisConnectorProperties properties;
        private ConfigurableListableBeanFactory beanFactory;

        private RedisBeanRegistrar(RedisConnectorProperties properties) { this.properties = properties; }

        @Override
        public void setBeanFactory(BeanFactory beanFactory) { this.beanFactory = (ConfigurableListableBeanFactory) beanFactory; }

        @Override
        public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            properties.getClients().forEach((name, client) -> {
                String beanName = "redisConnector." + name;
                if (registry.containsBeanDefinition(beanName) || registry.isAlias(beanName)
                        || beanFactory.containsSingleton(beanName)) {
                    return;
                }
                RootBeanDefinition definition = new RootBeanDefinition(RedisConnector.class);
                definition.setInstanceSupplier(() -> createConnector(name, client));
                definition.setDestroyMethodName("close");
                registry.registerBeanDefinition(beanName, definition);
            });
        }

        private RedisConnector createConnector(String name, RedisConnectorProperties.Client client) {
            RedisConnectionFactory connectionFactory;
            try {
                connectionFactory = beanFactory.getBean(client.getConnectionFactoryBean(), RedisConnectionFactory.class);
            } catch (BeansException exception) {
                throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "redis", name,
                        "Configured RedisConnectionFactory bean is missing or has an incompatible type",
                        ConnectorException.redactedCause(exception));
            }
            var executor = beanFactory.getBean(ConnectorExecutorFactory.class)
                    .create("redis", name, client.getMaxConcurrentCalls());
            return RedisConnector.create(name, connectionFactory, client, executor);
        }

        @Override
        public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) { }
    }
}
