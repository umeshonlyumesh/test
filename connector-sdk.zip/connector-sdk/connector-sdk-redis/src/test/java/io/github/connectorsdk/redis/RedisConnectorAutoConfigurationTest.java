package io.github.connectorsdk.redis;

import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.redis.autoconfigure.RedisConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class RedisConnectorAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                    ConnectorSupportAutoConfiguration.class, RedisConnectorAutoConfiguration.class))
            .withPropertyValues("connector.sdk.redis.clients.orders.connection-factory-bean=redisConnectionFactory");

    @Test
    void classpathAndClientPropertiesDoNotActivateRedis() {
        runner.withUserConfiguration(FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().doesNotHaveBean(RedisConnector.class)
                    .doesNotHaveBean(RedisConnectorProperties.class);
            assertThat(context.getBean(ConnectorRegistry.class).connectors()).isEmpty();
            verifyNoInteractions(context.getBean(RedisConnectionFactory.class));
        });
    }

    @Test
    void annotationActivatesNamedConnectorWithoutOpeningConnection() {
        runner.withUserConfiguration(AnnotationEnabled.class, FactoryConfiguration.class).run(context -> {
            assertThat(context).hasNotFailed().hasSingleBean(RedisConnector.class).hasBean("redisConnector.orders");
            RedisConnector connector = context.getBean(RedisConnector.class);
            assertThat(connector.name()).isEqualTo("orders");
            assertThat(context.getBean(ConnectorRegistry.class)
                    .require("redis", "orders", RedisConnector.class)).isSameAs(connector);
            verifyNoInteractions(context.getBean(RedisConnectionFactory.class));
        });
    }

    @Test
    void propertyActivatesMultipleNamedClientsAgainstExplicitFactory() {
        runner.withUserConfiguration(FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.redis.enabled=true",
                        "connector.sdk.redis.clients.billing.connection-factory-bean=redisConnectionFactory")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context.getBeansOfType(RedisConnector.class)).containsOnlyKeys(
                            "redisConnector.orders", "redisConnector.billing");
                    verifyNoInteractions(context.getBean(RedisConnectionFactory.class));
                });
    }

    @Test
    void falseKillSwitchOverridesAnnotationAndSkipsInvalidPropertiesAndMissingFactory() {
        runner.withUserConfiguration(AnnotationEnabled.class)
                .withPropertyValues("connector.sdk.redis.enabled=false",
                        "connector.sdk.redis.clients.orders.max-key-bytes=0")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(RedisConnector.class)
                        .doesNotHaveBean(RedisConnectorProperties.class));
    }

    @Test
    void absentRedisDependencySkipsOptionalAutoConfiguration() {
        runner.withClassLoader(new FilteredClassLoader("org.springframework.data.redis"))
                .withPropertyValues("connector.sdk.redis.enabled=true")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(RedisConnector.class));
    }

    @Test
    void missingOrImplicitFactoryFailsStartup() {
        runner.withUserConfiguration(AnnotationEnabled.class).run(context -> {
            assertThat(context).hasFailed();
            assertThat(context.getStartupFailure()).hasStackTraceContaining(
                    "Configured RedisConnectionFactory bean is missing");
        });
        runner.withUserConfiguration(AnnotationEnabled.class, FactoryConfiguration.class)
                .withPropertyValues("connector.sdk.redis.clients.orders.connection-factory-bean=")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining("must explicitly name");
                });
    }

    @Test
    void customAliasTakesPrecedenceAndIsValidated() {
        runner.withUserConfiguration(AliasConfiguration.class)
                .withPropertyValues("connector.sdk.redis.enabled=true")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RedisConnector.class);
                    assertThat(context.getBean("redisConnector.orders")).isSameAs(
                            context.getBean(AliasConfiguration.class).connector);
                });
    }

    @Test
    void incompatibleCustomBeanIdentityFailsStartup() {
        runner.withUserConfiguration(WrongIdentityConfiguration.class)
                .withPropertyValues("connector.sdk.redis.enabled=true")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasStackTraceContaining("incompatible transport or logical name");
                });
    }

    @Test
    void springClosesConnectorWithoutOpeningOrDestroyingCallerFactory() {
        RedisConnector[] captured = new RedisConnector[1];
        RedisConnectionFactory factory = mock(RedisConnectionFactory.class);
        runner.withBean("redisConnectionFactory", RedisConnectionFactory.class, () -> factory)
                .withPropertyValues("connector.sdk.redis.enabled=true")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    captured[0] = context.getBean(RedisConnector.class);
                    assertThat(captured[0].isClosed()).isFalse();
                });
        assertThat(captured[0].isClosed()).isTrue();
        verifyNoInteractions(factory);
    }

    @Configuration(proxyBeanMethods = false)
    @EnableRedisConnector
    static class AnnotationEnabled { }

    @Configuration(proxyBeanMethods = false)
    static class FactoryConfiguration {
        @Bean RedisConnectionFactory redisConnectionFactory() { return mock(RedisConnectionFactory.class); }
    }

    @Configuration(proxyBeanMethods = false)
    static class AliasConfiguration {
        private final RedisConnector connector = mock(RedisConnector.class);
        AliasConfiguration() {
            when(connector.type()).thenReturn("redis");
            when(connector.name()).thenReturn("orders");
        }
        @Bean({"customOrders", "redisConnector.orders"}) RedisConnector customConnector() { return connector; }
    }

    @Configuration(proxyBeanMethods = false)
    static class WrongIdentityConfiguration {
        @Bean("redisConnector.orders") RedisConnector customConnector() {
            RedisConnector connector = mock(RedisConnector.class);
            when(connector.type()).thenReturn("redis");
            when(connector.name()).thenReturn("wrong");
            return connector;
        }
    }
}
