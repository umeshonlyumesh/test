package io.github.connectorsdk.redis;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RedisConnectorPropertiesTest {
    @Test
    void rejectsEmptyConfigurationInvalidNamesAndNonpositiveBounds() {
        var properties = new RedisConnectorProperties();
        assertThatThrownBy(properties::validate).hasMessageContaining("requires");
        var client = new RedisConnectorProperties.Client();
        client.setConnectionFactoryBean("factory");
        properties.getClients().put("bad name", client);
        assertThatThrownBy(properties::validate).hasMessageContaining("client names");
        properties.getClients().clear();
        properties.getClients().put("orders", client);
        client.setMaxPayloadBytes(0);
        assertThatThrownBy(properties::validate).hasMessageContaining("must be positive");
    }

    @Test
    void prefixLimitUsesUtf8BytesAndReservesSpaceForAKey() {
        var client = new RedisConnectorProperties.Client();
        client.setConnectionFactoryBean("factory");
        client.setMaxKeyBytes(4);
        client.setKeyPrefix("éé");
        assertThatThrownBy(() -> client.validate("orders")).hasMessageContaining("leave room");
        client.setKeyPrefix("\ud800");
        assertThatThrownBy(() -> client.validate("orders")).hasMessageContaining("valid UTF-8");
    }
}
