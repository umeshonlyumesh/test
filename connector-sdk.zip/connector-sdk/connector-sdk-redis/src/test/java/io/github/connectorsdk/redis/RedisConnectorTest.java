package io.github.connectorsdk.redis;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.invocation.Invocation;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisKeyCommands;
import org.springframework.data.redis.connection.SetCondition;
import org.springframework.data.redis.core.types.Expiration;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.RETURNS_DEFAULTS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mockingDetails;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

class RedisConnectorTest {
    private RedisConnectionFactory factory;
    private RedisConnection connection;
    private RedisKeyCommands keys;
    private RedisConnector connector;
    private RedisConnectorProperties.Client properties;
    private byte[] returnedValue;
    private boolean setResult = true;

    @BeforeEach
    void createConnector() {
        factory = mock(RedisConnectionFactory.class);
        connection = mock(RedisConnection.class, invocation -> switch (invocation.getMethod().getName()) {
            case "get" -> returnedValue;
            case "set" -> setResult;
            case "incrBy" -> 42L;
            default -> RETURNS_DEFAULTS.answer(invocation);
        });
        keys = mock(RedisKeyCommands.class);
        when(connection.keyCommands()).thenReturn(keys);
        when(factory.getConnection()).thenReturn(connection);
        properties = new RedisConnectorProperties.Client();
        properties.setConnectionFactoryBean("factory");
        properties.setKeyPrefix("orders:");
        connector = RedisConnector.create("orders", factory, properties,
                new ConnectorExecutor("redis", "orders", 1, InvocationObserver.NONE));
    }

    @Test
    void creationDoesNotOpenConnectionAndCloseDoesNotDestroyFactory() {
        verifyNoInteractions(factory);
        connector.close();
        connector.close();
        assertThat(connector.isClosed()).isTrue();
        assertError(ConnectorErrorCode.CLOSED, () -> connector.get("one"));
        verifyNoInteractions(factory);
    }

    @Test
    void getPreservesMissingAndEmptyValuesAndCopiesReturnedBytes() {
        assertThat(connector.get("missing")).isEmpty();
        returnedValue = new byte[0];
        assertThat(connector.get("empty")).hasValueSatisfying(value -> assertThat(value).isEmpty());
        returnedValue = new byte[]{1, 2, 3};
        byte[] result = connector.get("present").orElseThrow();
        assertThat(result).isNotSameAs(returnedValue).containsExactly(1, 2, 3);
        result[0] = 9;
        assertThat(returnedValue).containsExactly(1, 2, 3);
        List<Invocation> gets = commands("get");
        assertThat((byte[]) gets.get(2).getArgument(0)).isEqualTo(bytes("orders:present"));
    }

    @Test
    void putUsesOneSetWithExpiryAndDefensiveCopyAndNoNativeObjectSerialization() {
        byte[] value = {0, 1, 2};
        connector.put("one", value, Duration.ofMillis(1500));
        List<Invocation> sets = commands("set");
        assertThat(sets).hasSize(1);
        Object[] arguments = sets.getFirst().getArguments();
        assertThat((byte[]) arguments[0]).isEqualTo(bytes("orders:one"));
        assertThat((byte[]) arguments[1]).isNotSameAs(value).containsExactly(0, 1, 2);
        assertThat(arguments[2]).isInstanceOfSatisfying(SetCondition.class,
                condition -> assertThat(condition.getKeyCondition()).isEqualTo(SetCondition.upsert().getKeyCondition()));
        assertThat(arguments[3]).isInstanceOfSatisfying(Expiration.class,
                expiration -> assertThat(expiration.getExpirationTimeInMilliseconds()).isEqualTo(1500));
        value[0] = 9;
        assertThat((byte[]) arguments[1]).containsExactly(0, 1, 2);
        assertThat(commands("pExpire")).isEmpty();
    }

    @Test
    void persistentPutIsExplicitSetWithoutExpiry() {
        connector.putPersistent("one", bytes("persistent"));
        assertThat(commands("set")).hasSize(1);
        assertThat(commands("set").getFirst().getArguments()).hasSize(2);
    }

    @Test
    void setIfAbsentUsesOneAtomicNxCommandWithExpiry() {
        assertThat(connector.setIfAbsent("lock", bytes("token"), Duration.ofSeconds(5))).isTrue();
        setResult = false;
        assertThat(connector.setIfAbsent("lock", bytes("other"), Duration.ofSeconds(5))).isFalse();
        assertThat(commands("set")).hasSize(2);
        Object[] arguments = commands("set").getFirst().getArguments();
        assertThat(arguments[2]).isInstanceOfSatisfying(SetCondition.class,
                condition -> assertThat(condition.getKeyCondition()).isEqualTo(SetCondition.ifAbsent().getKeyCondition()));
        assertThat(arguments[3]).isInstanceOfSatisfying(Expiration.class,
                expiration -> assertThat(expiration.getExpirationTimeInMilliseconds()).isEqualTo(5000));
        assertThat(commands("setNX")).isEmpty();
        assertThat(commands("pExpire")).isEmpty();
    }

    @Test
    void incrementSendsAtomicIncrbyWithoutReadModifyWrite() {
        assertThat(connector.increment("counter", 7)).isEqualTo(42);
        assertThat(commands("incrBy")).hasSize(1);
        Object[] arguments = commands("incrBy").getFirst().getArguments();
        assertThat((byte[]) arguments[0]).isEqualTo(bytes("orders:counter"));
        assertThat(arguments[1]).isEqualTo(7L);
        assertThat(commands("get")).isEmpty();
        assertThat(commands("set")).isEmpty();
    }

    @Test
    void deleteUsesOneKeyCommandAndReportsAbsence() {
        when(keys.del(any(byte[][].class))).thenReturn(1L, 0L);
        assertThat(connector.delete("one")).isTrue();
        assertThat(connector.delete("one")).isFalse();
    }

    @Test
    void rejectsInvalidTtlKeysAndLargeValuesBeforeGettingConnection() {
        for (Duration ttl : new Duration[]{Duration.ZERO, Duration.ofMillis(-1), Duration.ofNanos(1), Duration.ofSeconds(Long.MAX_VALUE)}) {
            assertThatThrownBy(() -> connector.put("one", new byte[0], ttl)).isInstanceOf(IllegalArgumentException.class);
        }
        properties.setMaxKeyBytes(12);
        properties.setMaxPayloadBytes(2);
        connector = RedisConnector.create("orders", factory, properties,
                new ConnectorExecutor("redis", "orders", 1, InvocationObserver.NONE));
        assertThatThrownBy(() -> connector.get("long-key")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> connector.get("\ud800")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> connector.putPersistent("one", new byte[3])).isInstanceOf(IllegalArgumentException.class);
        verifyNoInteractions(factory);
    }

    @Test
    void rejectsOversizedFetchedValueWithoutReturningIt() {
        properties.setMaxPayloadBytes(2);
        connector = RedisConnector.create("orders", factory, properties,
                new ConnectorExecutor("redis", "orders", 1, InvocationObserver.NONE));
        returnedValue = new byte[3];
        assertError(ConnectorErrorCode.REMOTE_ERROR, () -> connector.get("one"));
    }

    @Test
    void mapsTimeoutAndConnectionFailureAndRedactsEntireExceptionStack() {
        doThrow(new QueryTimeoutException("password=secret")).when(connection).get(any(byte[].class));
        assertError(ConnectorErrorCode.TIMEOUT, () -> connector.get("one"));
        doThrow(new RedisConnectionFailureException("password=secret")).when(connection).get(any(byte[].class));
        assertThatThrownBy(() -> connector.get("one")).isInstanceOfSatisfying(ConnectorException.class, exception -> {
            assertThat(exception.errorCode()).isEqualTo(ConnectorErrorCode.UNAVAILABLE);
            StringWriter trace = new StringWriter();
            exception.printStackTrace(new PrintWriter(trace));
            assertThat(trace.toString()).doesNotContain("password=secret");
        });
    }

    @Test
    void rejectsQueuedAndPipelinedConnectionsBeforeCommands() {
        when(connection.isPipelined()).thenReturn(true);
        assertError(ConnectorErrorCode.REMOTE_ERROR, () -> connector.putPersistent("one", new byte[0]));
        assertThat(commands("set")).isEmpty();
        when(connection.isPipelined()).thenReturn(false);
        when(connection.isQueueing()).thenReturn(true);
        assertError(ConnectorErrorCode.REMOTE_ERROR, () -> connector.get("one"));
        assertThat(commands("get")).isEmpty();
    }

    @Test
    void boundedConcurrencyFailsFastAndClosedTakesPrecedence() throws Exception {
        CountDownLatch started = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        when(connection.get(any(byte[].class))).thenAnswer(invocation -> {
            started.countDown();
            if (!release.await(2, TimeUnit.SECONDS)) {
                throw new AssertionError("Pending Redis call was not released");
            }
            return new byte[0];
        });
        try (var tasks = Executors.newVirtualThreadPerTaskExecutor()) {
            var first = tasks.submit(() -> connector.get("one"));
            try {
                assertThat(started.await(1, TimeUnit.SECONDS)).isTrue();
                assertError(ConnectorErrorCode.SATURATED, () -> connector.get("two"));
                connector.close();
                assertError(ConnectorErrorCode.CLOSED, () -> connector.get("three"));
            } finally {
                release.countDown();
            }
            assertThat(first.get(1, TimeUnit.SECONDS)).isPresent();
        }
        verify(factory).getConnection();
        verifyNoMoreInteractions(factory);
    }

    private List<Invocation> commands(String name) {
        return mockingDetails(connection).getInvocations().stream()
                .filter(invocation -> invocation.getMethod().getName().equals(name)).toList();
    }

    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }

    private static void assertError(ConnectorErrorCode code, Runnable invocation) {
        assertThatThrownBy(invocation::run).isInstanceOfSatisfying(ConnectorException.class,
                exception -> assertThat(exception.errorCode()).isEqualTo(code));
    }
}
