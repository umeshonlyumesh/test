# REST connector authentication and TLS

REST authentication is configured per named client. TLS client certificates can be combined with any supported HTTP authentication mode. The default is HTTPS, no HTTP authentication and no redirects. `allow-insecure=true` permits HTTP for the resource and OAuth token endpoint; use it only for controlled local tests.

```java
@SpringBootApplication
@EnableRestConnector
public class Application { }
```

## Basic authentication

```yaml
connector:
  sdk:
    rest:
      clients:
        orders:
          base-url: https://orders.example/api/
          request-timeout: 5s
          auth:
            type: BASIC
            username: ${ORDERS_USERNAME}
            password: ${ORDERS_PASSWORD}
```

Basic encodes username/password with UTF-8. The server must support that encoding. Credentials remain in process memory and are never included in SDK diagnostic output. Usernames may not contain a colon; credentials may not contain control characters.

## Bearer tokens and JWT

```yaml
connector:
  sdk:
    rest:
      clients:
        orders:
          base-url: https://orders.example/api/
          auth:
            type: BEARER
            token: ${ORDERS_ACCESS_TOKEN}
```

The configured token is sent as `Authorization: Bearer ...`. A JWT is treated as an opaque bearer token: the connector does not issue JWTs, trust decoded claims or verify the resource server's authorization decisions. A static configured token has no automatic rotation. Use OAuth client credentials or the credentials-provider SPI when tokens must be acquired or rotated at runtime.

## OAuth 2.0 client credentials

```yaml
connector:
  sdk:
    rest:
      clients:
        orders:
          base-url: https://orders.example/api/
          connect-timeout: 2s
          request-timeout: 8s
          auth:
            type: OAUTH2_CLIENT_CREDENTIALS
            token-url: https://identity.example/oauth2/token
            client-id: ${ORDERS_CLIENT_ID}
            client-secret: ${ORDERS_CLIENT_SECRET}
            scopes: [orders.read, orders.write]
            client-authentication: CLIENT_SECRET_BASIC
            token-request-timeout: 3s
            refresh-skew: 30s
```

The SDK sends the standard `client_credentials` grant. `CLIENT_SECRET_BASIC` is the default; `CLIENT_SECRET_POST` is also supported for providers requiring form-body credentials. ID and secret encoding for OAuth Basic follows form encoding before base64. The built-in provider requires a JSON response containing a valid bearer `access_token`, `token_type: Bearer` and a positive integer `expires_in`. Token responses are limited to 64 KiB and redirects are rejected.

Token acquisition begins on the first call, with no token endpoint request at application startup. Each client caches its own token until expiry minus the configured skew; skew is capped at half the token lifetime to avoid immediate renewal for short-lived tokens. Concurrent expiry refreshes share one token request. Waiting for refresh and fetching its complete body use a finite deadline. Acquisition receives the remaining REST call budget and is also capped by `token-request-timeout`. The data call then uses the remaining elapsed budget, including authentication and response-body transfer.

There is no implicit retry after a token endpoint failure or a resource `401`. A caller must decide whether replaying an operation is safe. Authorization-code, password, refresh-token grants, discovery, interactive login and `private_key_jwt` client assertions are outside the built-in client-credentials implementation; integrate an appropriate token library through the SPI for those flows.

## Mutual TLS through Spring Boot SSL bundles

```yaml
spring:
  ssl:
    bundle:
      jks:
        orders-mtls:
          keystore:
            location: ${ORDERS_KEYSTORE_LOCATION}
            password: ${ORDERS_KEYSTORE_PASSWORD}
            type: PKCS12
          truststore:
            location: ${ORDERS_TRUSTSTORE_LOCATION}
            password: ${ORDERS_TRUSTSTORE_PASSWORD}
            type: PKCS12

connector:
  sdk:
    rest:
      clients:
        orders:
          base-url: https://orders.example/api/
          ssl-bundle: orders-mtls
          auth:
            type: OAUTH2_CLIENT_CREDENTIALS
            token-url: https://identity.example/oauth2/token
            client-id: ${ORDERS_CLIENT_ID}
            client-secret: ${ORDERS_CLIENT_SECRET}
```

The named SSL bundle supplies trust material, client key material and TLS options. The same bundle is applied to the resource client and built-in OAuth token client. Hostname verification remains enabled. A missing bundle fails startup; a bundle requires an HTTPS resource URL. Configured bundle settings are applied after general client customizers so their key/trust material is retained.

An SSL bundle containing only trust material provides server TLS validation; mutual TLS additionally requires client key/certificate material and a server configured to authenticate the client. This release snapshots the bundle during connector construction. Recreate the connector or restart the application after certificate rotation; bundle file reload does not update already-created JDK clients.

Programmatic callers using `ssl-bundle` must resolve the bundle themselves, apply `RestSslBundleCustomizer` to their client customization list and use the explicit authentication-strategy constructor. Boot-managed connectors resolve bundles automatically.

## Dynamic credentials and custom request processing

Implement a thread-safe `RestCredentialsProvider` bean for a named client. The provider returns a complete Authorization value and is consulted on every invocation. Use `auth.type: NONE` when the provider owns the entire authentication flow. A matching provider replaces the built-in strategy; multiple matching providers fail startup. The caller owns provider lifecycle.

```java
@Bean
RestCredentialsProvider ordersCredentials(TokenService tokens) {
    return new RestCredentialsProvider() {
        public boolean supports(String clientName) {
            return "orders".equals(clientName);
        }
        public String authorizationHeader(String clientName) {
            return "Bearer " + tokens.currentToken();
        }
        public String authorizationHeader(String clientName, Duration remainingBudget) {
            return "Bearer " + tokens.currentToken(remainingBudget);
        }
    };
}
```

`TokenService` is the application's token integration. Implement the budget-aware overload when acquisition performs I/O. The SDK passes a deadline budget but cannot forcibly interrupt arbitrary provider code or request customizers that ignore it. Providers must bound remote acquisition themselves, never return a blank header and never log credentials.

`RestRequestCustomizer` beans add per-request behavior; `RestClientCustomizer` beans configure the reusable JDK client. Both receive the logical client name so they can restrict changes to intended clients. Configured authentication is applied last and replaces any caller-supplied Authorization header. With no configured or provider authentication, explicit per-request Authorization headers remain available.

Local tests exercise Basic, opaque JWT bearer, OAuth single-flight/expiry/deadlines/redaction, and real mutual TLS using generated certificates. Deployment qualification still requires the actual identity provider, TLS chain, audience/scope rules, proxies, credential storage and certificate-rotation procedure.
