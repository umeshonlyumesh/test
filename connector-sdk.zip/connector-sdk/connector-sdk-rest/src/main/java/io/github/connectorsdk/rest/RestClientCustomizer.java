package io.github.connectorsdk.rest;

import java.net.http.HttpClient;

/** Configure per-client SSLContext, proxy, authentication or executor before construction. */
@FunctionalInterface
public interface RestClientCustomizer {
    void customize(String clientName, HttpClient.Builder builder);
}
