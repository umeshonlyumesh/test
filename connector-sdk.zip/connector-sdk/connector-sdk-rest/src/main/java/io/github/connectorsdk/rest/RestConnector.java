package io.github.connectorsdk.rest;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.rest.auth.RestAuthentication;
import io.github.connectorsdk.rest.auth.RestAuthenticationFactory;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Thread-safe HTTP connector with pooled transport, overall deadline and bounded response body. */
public final class RestConnector implements Connector {
    private final String name;
    private final URI baseUrl;
    private final Duration requestTimeout;
    private final Duration shutdownTimeout;
    private final int maxResponseBytes;
    private final HttpClient client;
    private final ConnectorExecutor executor;
    private final List<RestRequestCustomizer> requestCustomizers;
    private final RestAuthentication authentication;
    private final AtomicBoolean closed = new AtomicBoolean();

    public RestConnector(String name, RestConnectorProperties.Client properties,
                         ConnectorExecutor executor, List<RestClientCustomizer> customizers) {
        this(name, properties, executor, customizers, List.of(), directAuthentication(name, properties, customizers));
    }

    public RestConnector(String name, RestConnectorProperties.Client properties,
                         ConnectorExecutor executor, List<RestClientCustomizer> customizers,
                         List<RestRequestCustomizer> requestCustomizers) {
        this(name, properties, executor, customizers, requestCustomizers, directAuthentication(name, properties, customizers));
    }

    /** Explicit strategy constructor used by Boot and advanced callers. The connector owns authentication. */
    public RestConnector(String name, RestConnectorProperties.Client properties,
                         ConnectorExecutor executor, List<RestClientCustomizer> customizers,
                         List<RestRequestCustomizer> requestCustomizers, RestAuthentication authentication) {
        Objects.requireNonNull(properties, "properties").validate(name);
        this.name = name;
        this.executor = Objects.requireNonNull(executor, "executor");
        this.requestCustomizers = List.copyOf(requestCustomizers);
        this.authentication = Objects.requireNonNull(authentication, "authentication");
        String url = properties.getBaseUrl().toString();
        this.baseUrl = URI.create(url.endsWith("/") ? url : url + "/");
        this.requestTimeout = properties.getRequestTimeout();
        this.shutdownTimeout = properties.getShutdownTimeout();
        this.maxResponseBytes = properties.getMaxResponseBytes();
        try {
            var builder = HttpClient.newBuilder().connectTimeout(properties.getConnectTimeout());
            List.copyOf(customizers).forEach(customizer -> customizer.customize(name, builder));
            // Credentials must not be forwarded by automatic cross-origin redirects.
            this.client = builder.followRedirects(HttpClient.Redirect.NEVER).build();
        }
        catch (RuntimeException | Error failure) {
            try { authentication.close(); } catch (RuntimeException | Error ignored) { }
            throw failure;
        }
    }
    @Override public String name() { return name; }
    @Override public String type() { return "rest"; }

    public RestResponse exchange(RestRequest request) {
        Objects.requireNonNull(request, "request");
        if (closed.get()) { throw failure(ConnectorErrorCode.CLOSED, "REST connector is closed", null); }
        String operation = switch (request.method()) {
            case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS", "TRACE" -> request.method();
            default -> "OTHER";
        };
        return executor.execute(operation, () -> doExchange(request));
    }

    private RestResponse doExchange(RestRequest request) {
        if (closed.get()) { throw failure(ConnectorErrorCode.CLOSED, "REST connector is closed", null); }
        long started = System.nanoTime();
        URI target = resolve(request.path());
        HttpRequest httpRequest;
        try {
            var builder = HttpRequest.newBuilder(target).timeout(requestTimeout);
            request.headers().forEach(builder::header);
            requestCustomizers.forEach(customizer -> customizer.customize(name, builder));
            // Configured authentication takes precedence over caller Authorization headers.
            authentication.customize(name, builder, Duration.ofNanos(remaining(started)));
            builder.timeout(Duration.ofNanos(remaining(started)));
            var body = request.body();
            httpRequest = builder.method(request.method(), body.length == 0
                    ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body)).build();
        } catch (IllegalArgumentException ex) {
            throw failure(ConnectorErrorCode.CONFIGURATION, "Invalid REST request headers or method", null);
        } catch (ConnectorException ex) {
            throw ex;
        } catch (RuntimeException ex) {
            throw failure(ConnectorErrorCode.UNAVAILABLE, "REST request customization failed", ex);
        }
        CompletableFuture<HttpResponse<byte[]>> future = null;
        try {
            future = client.sendAsync(httpRequest, ignored -> new LimitedBodySubscriber(maxResponseBytes));
            // The future completes after the bounded body subscriber, covering slow bodies as well as headers.
            var response = future.get(remaining(started), TimeUnit.NANOSECONDS);
            return new RestResponse(response.statusCode(), response.headers().map(), response.body());
        } catch (InterruptedException ex) {
            if (future != null) { future.cancel(true); }
            Thread.currentThread().interrupt();
            throw failure(ConnectorErrorCode.INTERRUPTED, "REST call interrupted", ex);
        } catch (TimeoutException ex) {
            if (future != null) { future.cancel(true); }
            throw failure(ConnectorErrorCode.TIMEOUT, "REST call exceeded its deadline", ex);
        } catch (ExecutionException ex) {
            Throwable cause = ex.getCause();
            while (cause instanceof java.util.concurrent.CompletionException && cause.getCause() != null) {
                cause = cause.getCause();
            }
            ConnectorErrorCode code = cause instanceof HttpTimeoutException ? ConnectorErrorCode.TIMEOUT
                    : cause instanceof LimitedBodySubscriber.ResponseTooLargeException ? ConnectorErrorCode.REMOTE_ERROR
                    : ConnectorErrorCode.UNAVAILABLE;
            throw failure(code, code == ConnectorErrorCode.REMOTE_ERROR
                    ? "REST response exceeds configured byte limit" : "REST transport failed", cause);
        } catch (IllegalStateException ex) {
            throw failure(closed.get() ? ConnectorErrorCode.CLOSED : ConnectorErrorCode.UNAVAILABLE,
                    "REST transport is unavailable", ex);
        } finally {
            if (future != null && !future.isDone()) { future.cancel(true); }
        }
    }

    private long remaining(long started) {
        long value = requestTimeout.toNanos() - (System.nanoTime() - started);
        if (value <= 0) { throw failure(ConnectorErrorCode.TIMEOUT, "REST call exceeded its deadline", null); }
        return value;
    }

    private static RestAuthentication directAuthentication(String name, RestConnectorProperties.Client properties,
                                                           List<RestClientCustomizer> customizers) {
        if (Objects.requireNonNull(properties, "properties").getSslBundle() != null) {
            throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "rest", name,
                    "REST ssl-bundle requires Boot-managed construction or an explicit SSL-bundle strategy");
        }
        return RestAuthenticationFactory.build(name, properties, List.of(), customizers);
    }

    private URI resolve(String path) {
        try {
            var relative = URI.create(path);
            if (relative.isAbsolute() || relative.getRawAuthority() != null || relative.getFragment() != null) {
                throw new IllegalArgumentException();
            }
            // Leading slash means same-origin root path; relative paths append to the configured base path.
            var target = baseUrl.resolve(relative);
            if (!Objects.equals(baseUrl.getScheme(), target.getScheme())
                    || !Objects.equals(baseUrl.getRawAuthority(), target.getRawAuthority())) {
                throw new IllegalArgumentException();
            }
            return target;
        } catch (IllegalArgumentException ex) {
            throw failure(ConnectorErrorCode.CONFIGURATION, "REST path must be relative and remain on the configured origin", null);
        }
    }

    private ConnectorException failure(ConnectorErrorCode code, String message, Throwable cause) {
        return new ConnectorException(code, type(), name, message, ConnectorException.redactedCause(cause));
    }

    @Override public void close() {
        if (!closed.compareAndSet(false, true)) { return; }
        try {
            authentication.close();
        } finally {
            client.shutdown();
            try {
                if (!client.awaitTermination(shutdownTimeout)) { client.shutdownNow(); }
            } catch (InterruptedException ex) {
                client.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
