package io.github.connectorsdk.rest;

/** Internal activation marker. Has no transport resources. */
public final class RestConnectorMarker { }
