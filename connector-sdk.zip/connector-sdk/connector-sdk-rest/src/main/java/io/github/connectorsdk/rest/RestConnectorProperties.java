package io.github.connectorsdk.rest;

import java.net.URI;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("connector.sdk.rest")
public class RestConnectorProperties {
    private boolean enabled;
    private Map<String, Client> clients = new LinkedHashMap<>();
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public Map<String, Client> getClients() { return clients; }
    public void setClients(Map<String, Client> clients) { this.clients = clients; }

    public static class Client {
        private URI baseUrl;
        private boolean allowInsecure;
        private Duration connectTimeout = Duration.ofSeconds(2);
        private Duration requestTimeout = Duration.ofSeconds(5);
        private Duration shutdownTimeout = Duration.ofSeconds(5);
        private int maxResponseBytes = 8 * 1024 * 1024;
        private int maxConcurrentCalls = 64;
        private String sslBundle;
        private Auth auth = new Auth();
        public URI getBaseUrl() { return baseUrl; }
        public void setBaseUrl(URI baseUrl) { this.baseUrl = baseUrl; }
        public boolean isAllowInsecure() { return allowInsecure; }
        public void setAllowInsecure(boolean allowInsecure) { this.allowInsecure = allowInsecure; }
        public Duration getConnectTimeout() { return connectTimeout; }
        public void setConnectTimeout(Duration value) { connectTimeout = value; }
        public Duration getRequestTimeout() { return requestTimeout; }
        public void setRequestTimeout(Duration value) { requestTimeout = value; }
        public Duration getShutdownTimeout() { return shutdownTimeout; }
        public void setShutdownTimeout(Duration value) { shutdownTimeout = value; }
        public int getMaxResponseBytes() { return maxResponseBytes; }
        public void setMaxResponseBytes(int value) { maxResponseBytes = value; }
        public int getMaxConcurrentCalls() { return maxConcurrentCalls; }
        public void setMaxConcurrentCalls(int value) { maxConcurrentCalls = value; }
        public String getSslBundle() { return sslBundle; }
        public void setSslBundle(String sslBundle) { this.sslBundle = sslBundle; }
        public Auth getAuth() { return auth; }
        public void setAuth(Auth auth) { this.auth = auth; }

        public void validate(String name) {
            if (name == null || !name.matches("[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}")) {
                throw new IllegalArgumentException("REST client names must contain 1-64 letters, digits, underscores or hyphens");
            }
            if (baseUrl == null || baseUrl.getHost() == null || baseUrl.getUserInfo() != null
                    || baseUrl.getQuery() != null || baseUrl.getFragment() != null
                    || !("https".equalsIgnoreCase(baseUrl.getScheme())
                         || (allowInsecure && "http".equalsIgnoreCase(baseUrl.getScheme())))) {
                throw new IllegalArgumentException("REST base-url must be an HTTPS URL without user info, query or fragment; HTTP requires allow-insecure=true");
            }
            positive(connectTimeout, "connect-timeout");
            positive(requestTimeout, "request-timeout");
            positive(shutdownTimeout, "shutdown-timeout");
            if (maxResponseBytes < 1 || maxConcurrentCalls < 1) {
                throw new IllegalArgumentException("REST response size and concurrency limits must be positive");
            }
            if (sslBundle != null && (sslBundle.isBlank() || !"https".equalsIgnoreCase(baseUrl.getScheme()))) {
                throw new IllegalArgumentException("REST ssl-bundle requires a non-blank bundle name and HTTPS base-url");
            }
            if (auth == null) { throw new IllegalArgumentException("REST auth settings are required"); }
            auth.validate(allowInsecure);
        }
        private static void positive(Duration value, String field) {
            if (value == null || value.isZero() || value.isNegative()) {
                throw new IllegalArgumentException("REST " + field + " must be positive");
            }
            try { value.toNanos(); } catch (ArithmeticException ex) {
                throw new IllegalArgumentException("REST " + field + " is too large");
            }
        }
    }

    /** Credentials should be supplied through environment placeholders or a secret-store provider. */
    public static class Auth {
        public enum Type { NONE, BASIC, BEARER, OAUTH2_CLIENT_CREDENTIALS }
        public enum ClientAuthentication { CLIENT_SECRET_BASIC, CLIENT_SECRET_POST }

        private Type type = Type.NONE;
        private String username;
        private String password;
        private String token;
        private URI tokenUrl;
        private String clientId;
        private String clientSecret;
        private List<String> scopes = List.of();
        private Duration tokenRequestTimeout = Duration.ofSeconds(5);
        private Duration refreshSkew = Duration.ofSeconds(30);
        private ClientAuthentication clientAuthentication = ClientAuthentication.CLIENT_SECRET_BASIC;
        public Type getType() { return type; }
        public void setType(Type type) { this.type = type; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getToken() { return token; }
        public void setToken(String token) { this.token = token; }
        public URI getTokenUrl() { return tokenUrl; }
        public void setTokenUrl(URI tokenUrl) { this.tokenUrl = tokenUrl; }
        public String getClientId() { return clientId; }
        public void setClientId(String clientId) { this.clientId = clientId; }
        public String getClientSecret() { return clientSecret; }
        public void setClientSecret(String clientSecret) { this.clientSecret = clientSecret; }
        public List<String> getScopes() { return scopes; }
        public void setScopes(List<String> scopes) { this.scopes = scopes; }
        public Duration getTokenRequestTimeout() { return tokenRequestTimeout; }
        public void setTokenRequestTimeout(Duration tokenRequestTimeout) { this.tokenRequestTimeout = tokenRequestTimeout; }
        public Duration getRefreshSkew() { return refreshSkew; }
        public void setRefreshSkew(Duration refreshSkew) { this.refreshSkew = refreshSkew; }
        public ClientAuthentication getClientAuthentication() { return clientAuthentication; }
        public void setClientAuthentication(ClientAuthentication value) { this.clientAuthentication = value; }

        public void validate(boolean allowInsecure) {
            if (type == null) { throw new IllegalArgumentException("REST auth type is required"); }
            switch (type) {
                case NONE -> { }
                case BASIC -> {
                    required(username, "username"); required(password, "password");
                    if (username.contains(":")) { throw new IllegalArgumentException("REST Basic username must not contain a colon"); }
                }
                case BEARER -> {
                    required(token, "token");
                    if (!token.matches("[A-Za-z0-9\\-._~+/]+=*")) {
                        throw new IllegalArgumentException("REST bearer token must follow the HTTP bearer token syntax");
                    }
                }
                case OAUTH2_CLIENT_CREDENTIALS -> {
                    required(clientId, "client-id"); required(clientSecret, "client-secret");
                    if (tokenUrl == null || tokenUrl.getHost() == null || tokenUrl.getUserInfo() != null
                            || tokenUrl.getFragment() != null || tokenUrl.getQuery() != null
                            || !("https".equalsIgnoreCase(tokenUrl.getScheme())
                            || (allowInsecure && "http".equalsIgnoreCase(tokenUrl.getScheme())))) {
                        throw new IllegalArgumentException("REST OAuth token-url must be HTTPS without user info, query or fragment; HTTP requires allow-insecure=true");
                    }
                    Client.positive(tokenRequestTimeout, "auth.token-request-timeout");
                    if (refreshSkew == null || refreshSkew.isNegative()) {
                        throw new IllegalArgumentException("REST OAuth refresh-skew must not be negative");
                    }
                    try { refreshSkew.toNanos(); } catch (ArithmeticException failure) {
                        throw new IllegalArgumentException("REST OAuth refresh-skew is too large");
                    }
                    if (clientAuthentication == null || scopes == null
                            || scopes.stream().anyMatch(scope -> scope == null || !scope.matches("[\\x21\\x23-\\x5B\\x5D-\\x7E]+"))) {
                        throw new IllegalArgumentException("REST OAuth client authentication and valid scope values are required");
                    }
                }
            }
        }

        private static void required(String value, String field) {
            if (value == null || value.isBlank() || value.length() > 16384
                    || value.chars().anyMatch(character -> character < 32 || character == 127)) {
                throw new IllegalArgumentException("REST auth " + field + " must be present, bounded and contain no control characters");
            }
        }
        @Override public String toString() { return "RestAuth[type=" + type + ", credentials=redacted]"; }
    }
}
