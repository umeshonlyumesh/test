package io.github.connectorsdk.rest;

import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/** Transport request. JSON/protobuf serialization remains a caller responsibility. */
public record RestRequest(String method, String path, Map<String, String> headers, byte[] body) {
    public RestRequest {
        method = Objects.requireNonNull(method, "method").toUpperCase(Locale.ROOT);
        if (!method.matches("[A-Z]+") || method.equals("CONNECT")) {
            throw new IllegalArgumentException("Unsupported HTTP method");
        }
        Objects.requireNonNull(path, "path");
        headers = Map.copyOf(Objects.requireNonNull(headers, "headers"));
        body = Objects.requireNonNull(body, "body").clone();
    }

    @Override public byte[] body() { return body.clone(); }

    /** Deliberately excludes payloads, paths and credentials from diagnostic output. */
    @Override public String toString() { return "RestRequest[method=" + method + ", bodyBytes=" + body.length + "]"; }

    public static RestRequest get(String path) { return new RestRequest("GET", path, Map.of(), new byte[0]); }
}
