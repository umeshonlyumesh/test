package io.github.connectorsdk.rest;

import java.net.http.HttpRequest;

/** Thread-safe per-request extension. Never log builders, headers or credentials. */
@FunctionalInterface
public interface RestRequestCustomizer {
    void customize(String clientName, HttpRequest.Builder builder);
}
