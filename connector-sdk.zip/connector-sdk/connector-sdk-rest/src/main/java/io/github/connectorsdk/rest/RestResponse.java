package io.github.connectorsdk.rest;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Immutable response, including non-2xx statuses for caller-defined business handling. */
public record RestResponse(int statusCode, Map<String, List<String>> headers, byte[] body) {
    public RestResponse {
        var copied = new LinkedHashMap<String, List<String>>();
        Objects.requireNonNull(headers, "headers").forEach((key, value) -> copied.put(key, List.copyOf(value)));
        headers = Map.copyOf(copied);
        body = Objects.requireNonNull(body, "body").clone();
    }
    @Override public byte[] body() { return body.clone(); }
    public String bodyUtf8() { return new String(body, StandardCharsets.UTF_8); }
    public boolean successful() { return statusCode >= 200 && statusCode < 300; }
    @Override public String toString() { return "RestResponse[statusCode=" + statusCode + ", bodyBytes=" + body.length + "]"; }
}
