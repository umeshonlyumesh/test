package io.github.connectorsdk.rest.auth;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.rest.RestClientCustomizer;
import io.github.connectorsdk.rest.RestConnectorProperties;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Flow;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import tools.jackson.databind.json.JsonMapper;

/** Standard RFC 6749 client_credentials token acquisition with a bounded, single-flight cache. */
final class OAuth2ClientCredentialsAuthentication implements RestAuthentication {
    private static final int MAX_TOKEN_RESPONSE_BYTES = 65536;
    private static final JsonMapper JSON = JsonMapper.builder().build();
    private final String name;
    private final URI tokenUrl;
    private final String requestBody;
    private final String authorization;
    private final long timeoutNanos;
    private final long skewNanos;
    private final Duration shutdownTimeout;
    private final HttpClient client;
    private final ReentrantLock refresh = new ReentrantLock();
    private final AtomicBoolean closed = new AtomicBoolean();
    private volatile CachedToken cached;

    OAuth2ClientCredentialsAuthentication(String name, RestConnectorProperties.Client settings,
                                          List<RestClientCustomizer> customizers) {
        this.name = name;
        var auth = settings.getAuth();
        tokenUrl = auth.getTokenUrl();
        timeoutNanos = Math.min(auth.getTokenRequestTimeout().toNanos(), settings.getRequestTimeout().toNanos());
        skewNanos = auth.getRefreshSkew().toNanos();
        shutdownTimeout = settings.getShutdownTimeout();
        String body = "grant_type=client_credentials";
        if (!auth.getScopes().isEmpty()) { body += "&scope=" + encode(String.join(" ", auth.getScopes())); }
        if (auth.getClientAuthentication() == RestConnectorProperties.Auth.ClientAuthentication.CLIENT_SECRET_POST) {
            body += "&client_id=" + encode(auth.getClientId()) + "&client_secret=" + encode(auth.getClientSecret());
            authorization = null;
        }
        else {
            // OAuth Basic credentials use form-encoded ID/secret before base64 (RFC 6749 section 2.3.1).
            authorization = "Basic " + Base64.getEncoder().encodeToString(
                    (encode(auth.getClientId()) + ":" + encode(auth.getClientSecret())).getBytes(StandardCharsets.UTF_8));
        }
        requestBody = body;
        var builder = HttpClient.newBuilder().connectTimeout(settings.getConnectTimeout());
        customizers.forEach(customizer -> customizer.customize(name, builder));
        client = builder.followRedirects(HttpClient.Redirect.NEVER).build();
    }

    @Override public void customize(String clientName, HttpRequest.Builder builder) {
        customize(clientName, builder, Duration.ofNanos(timeoutNanos));
    }

    @Override public void customize(String clientName, HttpRequest.Builder builder, Duration remainingBudget) {
        builder.setHeader("Authorization", "Bearer " + accessToken(Math.min(timeoutNanos, remainingBudget.toNanos())));
    }

    private String accessToken(long budgetNanos) {
        if (budgetNanos <= 0) { throw failure(ConnectorErrorCode.TIMEOUT, "OAuth token acquisition exceeded its deadline", null); }
        ensureOpen();
        CachedToken token = cached;
        if (token != null && token.valid()) { return token.value; }
        long started = System.nanoTime();
        boolean locked = false;
        try {
            locked = refresh.tryLock(budgetNanos, TimeUnit.NANOSECONDS);
            if (!locked) { throw failure(ConnectorErrorCode.TIMEOUT, "OAuth token refresh wait exceeded its deadline", null); }
            ensureOpen();
            token = cached;
            if (token == null || !token.valid()) {
                token = fetchToken(started, budgetNanos);
                ensureOpen();
                cached = token;
            }
            return token.value;
        }
        catch (InterruptedException failure) {
            Thread.currentThread().interrupt();
            throw failure(ConnectorErrorCode.INTERRUPTED, "OAuth token acquisition interrupted", failure);
        }
        finally {
            if (locked) { refresh.unlock(); }
        }
    }

    private CachedToken fetchToken(long started, long budgetNanos) {
        long remaining = remaining(started, budgetNanos);
        long issuedAt = System.nanoTime();
        var request = HttpRequest.newBuilder(tokenUrl).timeout(Duration.ofNanos(remaining))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("Accept", "application/json");
        if (authorization != null) { request.header("Authorization", authorization); }
        var tokenRequest = request.POST(HttpRequest.BodyPublishers.ofString(requestBody, StandardCharsets.UTF_8)).build();
        CompletableFuture<HttpResponse<byte[]>> future = null;
        try {
            future = client.sendAsync(tokenRequest, ignored -> new TokenBodySubscriber());
            var response = future.get(remaining(started, budgetNanos), TimeUnit.NANOSECONDS);
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR, "OAuth token endpoint rejected the request", null);
            }
            try {
                var json = JSON.readTree(response.body());
                var value = json == null ? null : json.get("access_token");
                var type = json == null ? null : json.get("token_type");
                var lifetime = json == null ? null : json.get("expires_in");
                if (value == null || !value.isString() || value.stringValue().isBlank()
                        || !value.stringValue().matches("[A-Za-z0-9\\-._~+/]+=*")
                        || type == null || !type.isString() || !"Bearer".equalsIgnoreCase(type.stringValue())
                        || lifetime == null || !lifetime.isIntegralNumber() || !lifetime.canConvertToLong()) {
                    throw failure(ConnectorErrorCode.REMOTE_ERROR, "OAuth token response is missing valid bearer token or expiry fields", null);
                }
                long seconds = lifetime.longValue();
                if (seconds < 1) { throw failure(ConnectorErrorCode.REMOTE_ERROR, "OAuth token response has an invalid expiry", null); }
                long lifetimeNanos = Math.multiplyExact(seconds, TimeUnit.SECONDS.toNanos(1));
                long usableNanos = lifetimeNanos - Math.min(skewNanos, lifetimeNanos / 2);
                if (System.nanoTime() - issuedAt >= usableNanos) {
                    throw failure(ConnectorErrorCode.REMOTE_ERROR, "OAuth token expired before acquisition completed", null);
                }
                return new CachedToken(value.stringValue(), issuedAt, usableNanos);
            }
            catch (ConnectorException failure) { throw failure; }
            catch (RuntimeException failure) {
                throw failure(ConnectorErrorCode.REMOTE_ERROR, "OAuth token endpoint returned an invalid JSON response", failure);
            }
        }
        catch (InterruptedException failure) {
            if (future != null) { future.cancel(true); }
            Thread.currentThread().interrupt();
            throw failure(ConnectorErrorCode.INTERRUPTED, "OAuth token acquisition interrupted", failure);
        }
        catch (TimeoutException failure) {
            if (future != null) { future.cancel(true); }
            throw failure(ConnectorErrorCode.TIMEOUT, "OAuth token endpoint exceeded its deadline", failure);
        }
        catch (ExecutionException failure) {
            Throwable cause = failure.getCause();
            while (cause instanceof java.util.concurrent.CompletionException && cause.getCause() != null) {
                cause = cause.getCause();
            }
            ConnectorErrorCode code = cause instanceof HttpTimeoutException ? ConnectorErrorCode.TIMEOUT
                    : cause instanceof TokenResponseTooLargeException ? ConnectorErrorCode.REMOTE_ERROR : ConnectorErrorCode.UNAVAILABLE;
            throw failure(code,
                    "OAuth token acquisition failed", cause);
        }
        catch (IllegalStateException failure) {
            throw failure(closed.get() ? ConnectorErrorCode.CLOSED : ConnectorErrorCode.UNAVAILABLE,
                    "OAuth token transport is unavailable", failure);
        }
        finally {
            if (future != null && !future.isDone()) { future.cancel(true); }
        }
    }

    private long remaining(long started, long budgetNanos) {
        long remaining = budgetNanos - (System.nanoTime() - started);
        if (remaining <= 0) { throw failure(ConnectorErrorCode.TIMEOUT, "OAuth token acquisition exceeded its deadline", null); }
        return remaining;
    }

    private void ensureOpen() {
        if (closed.get()) { throw failure(ConnectorErrorCode.CLOSED, "REST authentication is closed", null); }
    }

    private ConnectorException failure(ConnectorErrorCode code, String message, Throwable cause) {
        return RestAuthenticationFactory.failure(name, code, message, cause);
    }

    @Override public void close() {
        if (!closed.compareAndSet(false, true)) { return; }
        cached = null;
        client.shutdownNow();
        try { client.awaitTermination(shutdownTimeout); }
        catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    @Override public String toString() { return "OAuth2ClientCredentialsAuthentication[credentials=redacted]"; }

    private static String encode(String value) { return URLEncoder.encode(value, StandardCharsets.UTF_8); }

    private static final class CachedToken {
        private final String value;
        private final long issuedAt;
        private final long usableNanos;
        private CachedToken(String value, long issuedAt, long usableNanos) {
            this.value = value; this.issuedAt = issuedAt; this.usableNanos = usableNanos;
        }
        private boolean valid() { return System.nanoTime() - issuedAt < usableNanos; }
        @Override public String toString() { return "CachedToken[redacted]"; }
    }

    private static final class TokenBodySubscriber implements HttpResponse.BodySubscriber<byte[]> {
        private final java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
        private final CompletableFuture<byte[]> result = new CompletableFuture<>();
        private Flow.Subscription subscription;
        @Override public CompletionStage<byte[]> getBody() { return result; }
        @Override public void onSubscribe(Flow.Subscription value) {
            if (subscription != null) { value.cancel(); return; }
            subscription = value; value.request(1);
        }
        @Override public void onNext(List<ByteBuffer> buffers) {
            if (result.isDone()) { return; }
            for (ByteBuffer buffer : buffers) {
                if (buffer.remaining() > MAX_TOKEN_RESPONSE_BYTES - bytes.size()) {
                    subscription.cancel();
                    result.completeExceptionally(new TokenResponseTooLargeException());
                    return;
                }
                byte[] part = new byte[buffer.remaining()]; buffer.get(part); bytes.writeBytes(part);
            }
            subscription.request(1);
        }
        @Override public void onError(Throwable error) { result.completeExceptionally(error); }
        @Override public void onComplete() { result.complete(bytes.toByteArray()); }
    }

    private static final class TokenResponseTooLargeException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        private TokenResponseTooLargeException() { super("OAuth token response exceeds configured safety limit"); }
    }
}
