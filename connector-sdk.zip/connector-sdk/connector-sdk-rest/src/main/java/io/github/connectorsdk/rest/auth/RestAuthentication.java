package io.github.connectorsdk.rest.auth;

import io.github.connectorsdk.rest.RestRequestCustomizer;

/** Per-connector authentication strategy. Only SDK-created resources belong to its lifecycle. */
public interface RestAuthentication extends RestRequestCustomizer, AutoCloseable {
    RestAuthentication NONE = (clientName, request) -> { };

    /** Budget-aware hook. Custom strategies must honor this deadline when acquiring credentials. */
    default void customize(String clientName, java.net.http.HttpRequest.Builder request,
                           java.time.Duration remainingBudget) {
        customize(clientName, request);
    }

    @Override default void close() { }
}
