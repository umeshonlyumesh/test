package io.github.connectorsdk.rest.auth;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.rest.RestClientCustomizer;
import io.github.connectorsdk.rest.RestConnectorProperties;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

/** Builds authentication without contacting token endpoints during startup. */
public final class RestAuthenticationFactory {
    private RestAuthenticationFactory() { }

    public static RestAuthentication build(String name, RestConnectorProperties.Client settings,
                                           List<RestCredentialsProvider> providers,
                                           List<RestClientCustomizer> tokenClientCustomizers) {
        Objects.requireNonNull(settings, "settings").validate(name);
        List<RestCredentialsProvider> matching;
        try {
            matching = List.copyOf(providers).stream().filter(provider -> provider.supports(name)).toList();
        } catch (RuntimeException exception) {
            throw failure(name, ConnectorErrorCode.CONFIGURATION, "REST credentials provider selection failed", exception);
        }
        if (matching.size() > 1) {
            throw failure(name, ConnectorErrorCode.CONFIGURATION, "Multiple REST credentials providers match this client", null);
        }
        if (!matching.isEmpty()) {
            RestCredentialsProvider provider = matching.getFirst();
            java.time.Duration configuredBudget = settings.getRequestTimeout();
            return new RestAuthentication() {
                @Override public void customize(String clientName, java.net.http.HttpRequest.Builder builder) {
                    customize(clientName, builder, configuredBudget);
                }

                @Override public void customize(String clientName, java.net.http.HttpRequest.Builder builder,
                                                java.time.Duration remainingBudget) {
                    String header;
                    try {
                        header = provider.authorizationHeader(name, remainingBudget);
                    }
                    catch (RuntimeException exception) {
                        throw failure(name, ConnectorErrorCode.UNAVAILABLE, "REST credentials acquisition failed", exception);
                    }
                    if (header == null || header.isBlank() || header.length() > 65536
                            || header.chars().anyMatch(character -> character < 32 || character == 127)) {
                        throw failure(name, ConnectorErrorCode.CONFIGURATION, "REST credentials provider returned an invalid authorization value", null);
                    }
                    builder.setHeader("Authorization", header);
                }
            };
        }
        var auth = settings.getAuth();
        return switch (auth.getType()) {
            case NONE -> RestAuthentication.NONE;
            case BASIC -> {
                String value = "Basic " + Base64.getEncoder().encodeToString(
                        (auth.getUsername() + ":" + auth.getPassword()).getBytes(StandardCharsets.UTF_8));
                yield (clientName, builder) -> builder.setHeader("Authorization", value);
            }
            case BEARER -> {
                String value = "Bearer " + auth.getToken();
                yield (clientName, builder) -> builder.setHeader("Authorization", value);
            }
            case OAUTH2_CLIENT_CREDENTIALS -> new OAuth2ClientCredentialsAuthentication(name, settings,
                    List.copyOf(tokenClientCustomizers));
        };
    }

    static ConnectorException failure(String name, ConnectorErrorCode code, String message, Throwable cause) {
        return new ConnectorException(code, "rest", name, message, ConnectorException.redactedCause(cause));
    }
}
