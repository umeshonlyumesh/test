package io.github.connectorsdk.rest.auth;

/**
 * Thread-safe caller-owned credentials strategy for rotation, secret stores or other OAuth flows.
 * Providers must enforce their own finite acquisition deadlines and must never log credentials.
 */
public interface RestCredentialsProvider {
    boolean supports(String clientName);

    /** Returns a complete Authorization value, for example {@code Bearer <token>}. */
    String authorizationHeader(String clientName);

    /** Override to enforce the remaining REST call budget during remote credential acquisition. */
    default String authorizationHeader(String clientName, java.time.Duration remainingBudget) {
        return authorizationHeader(clientName);
    }
}
