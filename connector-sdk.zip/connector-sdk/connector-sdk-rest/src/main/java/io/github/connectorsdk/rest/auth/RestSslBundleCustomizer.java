package io.github.connectorsdk.rest.auth;

import io.github.connectorsdk.rest.RestClientCustomizer;
import java.net.http.HttpClient;
import javax.net.ssl.SSLParameters;
import org.springframework.boot.ssl.SslBundle;

/** Applies key/trust material and TLS options from a Boot SSL bundle, including client certificates. */
public final class RestSslBundleCustomizer implements RestClientCustomizer {
    private final SslBundle bundle;

    public RestSslBundleCustomizer(SslBundle bundle) {
        this.bundle = java.util.Objects.requireNonNull(bundle, "bundle");
    }

    @Override public void customize(String clientName, HttpClient.Builder builder) {
        var context = bundle.createSslContext();
        SSLParameters parameters = context.getDefaultSSLParameters();
        var options = bundle.getOptions();
        if (options.getCiphers() != null) { parameters.setCipherSuites(options.getCiphers()); }
        if (options.getEnabledProtocols() != null) { parameters.setProtocols(options.getEnabledProtocols()); }
        parameters.setEndpointIdentificationAlgorithm("HTTPS");
        builder.sslContext(context).sslParameters(parameters);
    }
}
