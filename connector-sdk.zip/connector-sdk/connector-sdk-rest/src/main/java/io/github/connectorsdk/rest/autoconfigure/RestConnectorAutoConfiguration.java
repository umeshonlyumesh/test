package io.github.connectorsdk.rest.autoconfigure;

import io.github.connectorsdk.rest.RestClientCustomizer;
import io.github.connectorsdk.rest.RestConnector;
import io.github.connectorsdk.rest.RestConnectorMarker;
import io.github.connectorsdk.rest.RestConnectorProperties;
import io.github.connectorsdk.rest.RestRequestCustomizer;
import io.github.connectorsdk.rest.auth.RestAuthenticationFactory;
import io.github.connectorsdk.rest.auth.RestCredentialsProvider;
import io.github.connectorsdk.rest.auth.RestSslBundleCustomizer;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.github.connectorsdk.spring.ConnectorBeanValidator;
import java.util.Objects;
import java.util.ArrayList;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.ConfigurationCondition;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

@AutoConfiguration(afterName = "io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration")
@Conditional(RestConnectorAutoConfiguration.Enabled.class)
@EnableConfigurationProperties(RestConnectorProperties.class)
public class RestConnectorAutoConfiguration {
    @Bean
    ConnectorBeanValidator restConnectorBeanValidator(ConfigurableListableBeanFactory factory, RestConnectorProperties properties) {
        return new ConnectorBeanValidator(factory, properties.getClients().keySet().stream()
                .map(name -> new ConnectorBeanValidator.Expectation("restConnector." + name, "rest", name, RestConnector.class))
                .toList());
    }

    @Bean
    static BeanDefinitionRegistryPostProcessor restConnectorDefinitions(Environment environment) {
        return new Definitions(environment);
    }

    static final class Enabled extends SpringBootCondition implements ConfigurationCondition {
        @Override public ConfigurationPhase getConfigurationPhase() { return ConfigurationPhase.REGISTER_BEAN; }
        @Override public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
            Boolean enabled = context.getEnvironment().getProperty("connector.sdk.rest.enabled", Boolean.class);
            boolean marker = context.getBeanFactory() != null
                    && context.getBeanFactory().getBeanNamesForType(RestConnectorMarker.class, false, false).length > 0;
            boolean matches = enabled != null ? enabled : marker;
            return new ConditionOutcome(matches, "REST requires @EnableRestConnector or enabled=true; explicit false disables it");
        }
    }

    private static final class Definitions implements BeanDefinitionRegistryPostProcessor {
        private final Environment environment;
        Definitions(Environment environment) { this.environment = environment; }
        @Override public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
            var properties = Binder.get(environment).bind("connector.sdk.rest", RestConnectorProperties.class)
                    .orElseGet(RestConnectorProperties::new);
            if (properties.getClients() == null || properties.getClients().isEmpty()) {
                throw new IllegalArgumentException("Enabled REST connector requires at least one connector.sdk.rest.clients entry");
            }
            if (!(registry instanceof ConfigurableListableBeanFactory factory)) {
                throw new IllegalStateException("REST registration requires a configurable bean factory");
            }
            properties.getClients().forEach((name, settings) -> {
                Objects.requireNonNull(settings, "REST client settings").validate(name);
                String beanName = "restConnector." + name;
                if (registry.containsBeanDefinition(beanName) || registry.isAlias(beanName) || factory.containsSingleton(beanName)) { return; }
                var definition = new RootBeanDefinition(RestConnector.class);
                definition.setInstanceSupplier(() -> createConnector(name, settings, factory));
                definition.setDestroyMethodName("close");
                registry.registerBeanDefinition(beanName, definition);
            });
        }
        private RestConnector createConnector(String name, RestConnectorProperties.Client settings,
                                              ConfigurableListableBeanFactory factory) {
            var customizers = new ArrayList<>(factory.getBeanProvider(RestClientCustomizer.class).orderedStream().toList());
            if (settings.getSslBundle() != null) {
                try {
                    SslBundles bundles = factory.getBeanProvider(SslBundles.class).getIfUnique();
                    if (bundles == null) {
                        throw new IllegalStateException("A unique SslBundles bean is required");
                    }
                    // Apply configured TLS material last so unrelated customizers cannot discard it.
                    customizers.add(new RestSslBundleCustomizer(bundles.getBundle(settings.getSslBundle())));
                }
                catch (RuntimeException failure) {
                    throw new ConnectorException(ConnectorErrorCode.CONFIGURATION, "rest", name,
                            "Configured REST SSL bundle is missing or unavailable", ConnectorException.redactedCause(failure));
                }
            }
            var executor = factory.getBean(ConnectorExecutorFactory.class).create("rest", name, settings.getMaxConcurrentCalls());
            var requestCustomizers = factory.getBeanProvider(RestRequestCustomizer.class).orderedStream().toList();
            var authentication = RestAuthenticationFactory.build(name, settings,
                    factory.getBeanProvider(RestCredentialsProvider.class).orderedStream().toList(), customizers);
            return new RestConnector(name, settings, executor, customizers, requestCustomizers, authentication);
        }
        @Override public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) { }
    }
}
