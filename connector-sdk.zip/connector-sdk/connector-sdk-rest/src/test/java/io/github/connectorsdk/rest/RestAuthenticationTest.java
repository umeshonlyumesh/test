package io.github.connectorsdk.rest;

import com.sun.net.httpserver.HttpServer;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import io.github.connectorsdk.rest.auth.RestAuthenticationFactory;
import io.github.connectorsdk.rest.auth.RestCredentialsProvider;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

class RestAuthenticationTest {
    private HttpServer server;
    private java.util.concurrent.ExecutorService workers;
    private final List<RestConnector> clients = new ArrayList<>();
    private final AtomicInteger resourceCalls = new AtomicInteger();

    @BeforeEach void start() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        workers = Executors.newVirtualThreadPerTaskExecutor();
        server.setExecutor(workers);
        server.createContext("/api", exchange -> {
            resourceCalls.incrementAndGet();
            String header = exchange.getRequestHeaders().getFirst("Authorization");
            byte[] body = String.valueOf(header).getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        server.start();
    }

    @AfterEach void stop() {
        clients.forEach(RestConnector::close);
        server.stop(0);
        workers.shutdownNow();
    }

    @Test void basicUsesConfiguredCredentialsAndOverridesRequestAuthorization() {
        var settings = settings();
        settings.getAuth().setType(RestConnectorProperties.Auth.Type.BASIC);
        settings.getAuth().setUsername("sdk-user");
        settings.getAuth().setPassword("private-password");
        String expected = "Basic " + Base64.getEncoder().encodeToString("sdk-user:private-password".getBytes(StandardCharsets.UTF_8));
        var response = client(settings).exchange(new RestRequest("GET", "api", Map.of("authorization", "Bearer caller-value"), new byte[0]));
        assertThat(response.bodyUtf8()).isEqualTo(expected);
        assertThat(settings.getAuth().toString()).doesNotContain("sdk-user", "private-password");
    }

    @Test void bearerAcceptsOpaqueJwtWithoutIssuingOrDecodingIt() {
        var settings = settings();
        settings.getAuth().setType(RestConnectorProperties.Auth.Type.BEARER);
        settings.getAuth().setToken("eyJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJzZGstYXBpIn0.signature");
        assertThat(client(settings).exchange(RestRequest.get("api")).bodyUtf8())
                .isEqualTo("Bearer " + settings.getAuth().getToken());
    }

    @Test void oauthCachesAndSingleFlightsConcurrentRefreshWithoutStartupRequests() throws Exception {
        AtomicInteger tokens = new AtomicInteger();
        AtomicReference<String> authorization = new AtomicReference<>();
        AtomicReference<String> form = new AtomicReference<>();
        server.createContext("/token", exchange -> {
            authorization.set(exchange.getRequestHeaders().getFirst("Authorization"));
            form.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            tokens.incrementAndGet();
            try { Thread.sleep(100); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            byte[] body = "{\"access_token\":\"shared-token\",\"token_type\":\"Bearer\",\"expires_in\":60}".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        var settings = oauthSettings();
        settings.getAuth().setScopes(List.of("read:items", "write:items"));
        var client = client(settings);
        assertThat(tokens).hasValue(0);
        CountDownLatch begin = new CountDownLatch(1);
        List<java.util.concurrent.Future<String>> results = new ArrayList<>();
        try (var callers = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int index = 0; index < 12; index++) {
                results.add(callers.submit(() -> { begin.await(); return client.exchange(RestRequest.get("api")).bodyUtf8(); }));
            }
            begin.countDown();
            for (var result : results) { assertThat(result.get(4, TimeUnit.SECONDS)).isEqualTo("Bearer shared-token"); }
        }
        assertThat(tokens).hasValue(1);
        assertThat(client.exchange(RestRequest.get("api")).bodyUtf8()).isEqualTo("Bearer shared-token");
        assertThat(tokens).hasValue(1);
        String basic = encode(settings.getAuth().getClientId()) + ":" + encode(settings.getAuth().getClientSecret());
        assertThat(authorization.get()).isEqualTo("Basic " + Base64.getEncoder().encodeToString(basic.getBytes(StandardCharsets.UTF_8)));
        assertThat(form.get()).isEqualTo("grant_type=client_credentials&scope=read%3Aitems+write%3Aitems");
    }

    @Test void oauthRefreshesExpiredTokensAndSupportsClientSecretPost() throws Exception {
        AtomicInteger tokens = new AtomicInteger();
        AtomicReference<String> form = new AtomicReference<>();
        AtomicReference<String> authorization = new AtomicReference<>();
        server.createContext("/token", exchange -> {
            authorization.set(exchange.getRequestHeaders().getFirst("Authorization"));
            form.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            String json = "{\"access_token\":\"token-" + tokens.incrementAndGet() + "\",\"token_type\":\"Bearer\",\"expires_in\":1}";
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        var settings = oauthSettings();
        settings.getAuth().setClientAuthentication(RestConnectorProperties.Auth.ClientAuthentication.CLIENT_SECRET_POST);
        settings.getAuth().setRefreshSkew(Duration.ofMillis(100));
        var client = client(settings);
        assertThat(client.exchange(RestRequest.get("api")).bodyUtf8()).isEqualTo("Bearer token-1");
        Thread.sleep(1100);
        assertThat(client.exchange(RestRequest.get("api")).bodyUtf8()).isEqualTo("Bearer token-2");
        assertThat(tokens).hasValue(2);
        assertThat(authorization.get()).isNull();
        assertThat(form.get()).contains("client_id=" + encode(settings.getAuth().getClientId()),
                "client_secret=" + encode(settings.getAuth().getClientSecret()));
    }

    @Test void oauthErrorsNeverExposeTokenBodyOrClientSecretInStackTraces() {
        server.createContext("/token", exchange -> {
            byte[] body = "{\"access_token\":\"token-secret\",\"message\":credential-secret broken-json".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        var client = client(oauthSettings());
        assertThatThrownBy(() -> client.exchange(RestRequest.get("api"))).isInstanceOfSatisfying(ConnectorException.class, failure -> {
            assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR);
            StringWriter stack = new StringWriter(); failure.printStackTrace(new PrintWriter(stack));
            assertThat(stack.toString()).doesNotContain("token-secret", "credential-secret", "client-secret");
        });
        assertThat(resourceCalls).hasValue(0);
    }

    @Test void tokenEndpointDeadlinePreventsSendingUnauthenticatedResourceRequest() {
        server.createContext("/token", exchange -> {
            try { Thread.sleep(500); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            exchange.sendResponseHeaders(200, -1); exchange.close();
        });
        var settings = oauthSettings(); settings.getAuth().setTokenRequestTimeout(Duration.ofMillis(150));
        long began = System.nanoTime();
        assertThatThrownBy(() -> client(settings).exchange(RestRequest.get("api")))
                .isInstanceOfSatisfying(ConnectorException.class, failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.TIMEOUT));
        assertThat(Duration.ofNanos(System.nanoTime() - began)).isLessThan(Duration.ofSeconds(2));
        assertThat(resourceCalls).hasValue(0);
    }

    @Test void rejectsOversizeTokenResponse() {
        server.createContext("/token", exchange -> {
            byte[] body = new byte[70000]; exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        assertThatThrownBy(() -> client(oauthSettings()).exchange(RestRequest.get("api")))
                .isInstanceOfSatisfying(ConnectorException.class, failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR));
    }

    @Test void oauthUsesRemainingDeadlineAfterEarlierRequestCustomization() {
        server.createContext("/token", exchange -> {
            try { Thread.sleep(700); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            byte[] body = "{\"access_token\":\"late-token\",\"token_type\":\"Bearer\",\"expires_in\":60}".getBytes(StandardCharsets.UTF_8);
            try {
                exchange.sendResponseHeaders(200, body.length);
                try (var output = exchange.getResponseBody()) { output.write(body); }
            } catch (java.io.IOException ignored) { /* Expected token deadline cancellation. */ }
        });
        var settings = oauthSettings(); settings.setRequestTimeout(Duration.ofMillis(600));
        RestRequestCustomizer preparation = (name, builder) -> {
            try { Thread.sleep(400); }
            catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw new IllegalStateException(interrupted); }
        };
        var client = new RestConnector("test", settings, executor(), List.of(), List.of(preparation));
        clients.add(client);
        long began = System.nanoTime();
        assertThatThrownBy(() -> client.exchange(RestRequest.get("api")))
                .isInstanceOfSatisfying(ConnectorException.class, failure -> assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.TIMEOUT));
        assertThat(Duration.ofNanos(System.nanoTime() - began)).isLessThan(Duration.ofMillis(850));
        assertThat(resourceCalls).hasValue(0);
    }

    @Test void dynamicCredentialsProviderRunsForEachCallAndRedactsFailures() {
        AtomicInteger issued = new AtomicInteger();
        RestCredentialsProvider provider = new RestCredentialsProvider() {
            @Override public boolean supports(String name) { return "test".equals(name); }
            @Override public String authorizationHeader(String name) {
                int count = issued.incrementAndGet();
                if (count == 3) { throw new IllegalStateException("secret-store-password"); }
                return "Bearer rotated-" + count;
            }
        };
        var settings = settings();
        var auth = RestAuthenticationFactory.build("test", settings, List.of(provider), List.of());
        var client = new RestConnector("test", settings, executor(), List.of(), List.of(), auth);
        clients.add(client);
        assertThat(client.exchange(RestRequest.get("api")).bodyUtf8()).isEqualTo("Bearer rotated-1");
        assertThat(client.exchange(RestRequest.get("api")).bodyUtf8()).isEqualTo("Bearer rotated-2");
        assertThatThrownBy(() -> client.exchange(RestRequest.get("api"))).isInstanceOfSatisfying(ConnectorException.class, failure -> {
            StringWriter stack = new StringWriter(); failure.printStackTrace(new PrintWriter(stack));
            assertThat(stack.toString()).doesNotContain("secret-store-password");
        });
    }

    @Test void rejectsInvalidCredentialSettingsAtConstruction() {
        var settings = settings(); settings.getAuth().setType(RestConnectorProperties.Auth.Type.BASIC);
        settings.getAuth().setUsername("user");
        assertThatThrownBy(() -> client(settings)).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("password");
        settings.getAuth().setType(RestConnectorProperties.Auth.Type.BEARER); settings.getAuth().setToken("token\r\nInjected:secret");
        assertThatThrownBy(() -> client(settings)).isInstanceOf(IllegalArgumentException.class).hasMessageNotContaining("secret");
        var oauth = oauthSettings(); oauth.setAllowInsecure(false); oauth.setBaseUrl(URI.create("https://secure.example"));
        assertThatThrownBy(() -> client(oauth)).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("token-url");
        settings.getAuth().setType(RestConnectorProperties.Auth.Type.BASIC);
        settings.getAuth().setPassword("password\u0000value");
        assertThatThrownBy(() -> client(settings)).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("control characters");
    }

    private RestConnectorProperties.Client settings() {
        var settings = new RestConnectorProperties.Client();
        settings.setBaseUrl(URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/"));
        settings.setAllowInsecure(true); settings.setRequestTimeout(Duration.ofSeconds(3));
        return settings;
    }
    private RestConnectorProperties.Client oauthSettings() {
        var settings = settings(); var auth = settings.getAuth();
        auth.setType(RestConnectorProperties.Auth.Type.OAUTH2_CLIENT_CREDENTIALS);
        auth.setTokenUrl(settings.getBaseUrl().resolve("token"));
        auth.setClientId("client:id+value"); auth.setClientSecret("client-secret+value");
        return settings;
    }
    private RestConnector client(RestConnectorProperties.Client settings) {
        var client = new RestConnector("test", settings, executor(), List.of()); clients.add(client); return client;
    }
    private static ConnectorExecutor executor() { return new ConnectorExecutor("rest", "test", 32, InvocationObserver.NONE); }
    private static String encode(String value) { return URLEncoder.encode(value, StandardCharsets.UTF_8); }
}
