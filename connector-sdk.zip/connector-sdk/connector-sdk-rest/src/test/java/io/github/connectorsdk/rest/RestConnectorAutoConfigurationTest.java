package io.github.connectorsdk.rest;

import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.rest.autoconfigure.RestConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import java.net.URI;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import static org.assertj.core.api.Assertions.*;

class RestConnectorAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(
            ConnectorRuntimeAutoConfiguration.class, RestConnectorAutoConfiguration.class, ConnectorSupportAutoConfiguration.class));

    @Test void dependencyAloneCreatesNoConnector() {
        runner.withPropertyValues("connector.sdk.rest.clients.orders.base-url=not-a-uri")
                .run(context -> {
                    assertThat(context).hasNotFailed().doesNotHaveBean(RestConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).connectors()).isEmpty();
                });
    }
    @Test void annotationEnablesNamedBeanAndRegistry() {
        runner.withUserConfiguration(EnabledApp.class)
                .withPropertyValues("connector.sdk.rest.clients.orders.base-url=https://orders.example/api")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RestConnector.class);
                    assertThat(context.getBean(ConnectorRegistry.class).require("rest", "orders", RestConnector.class))
                            .isSameAs(context.getBean("restConnector.orders"));
                });
    }
    @Test void propertyEnablesMultipleClients() {
        runner.withPropertyValues("connector.sdk.rest.enabled=true",
                        "connector.sdk.rest.clients.orders.base-url=https://orders.example",
                        "connector.sdk.rest.clients.billing.base-url=https://billing.example")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasBean("restConnector.orders").hasBean("restConnector.billing");
                    assertThat(context.getBeansOfType(RestConnector.class)).hasSize(2);
                });
    }
    @Test void falsePropertyOverridesAnnotation() {
        runner.withUserConfiguration(EnabledApp.class).withPropertyValues("connector.sdk.rest.enabled=false")
                .run(context -> assertThat(context).hasNotFailed().doesNotHaveBean(RestConnector.class));
    }
    @Test void missingConfigurationFailsImmediately() {
        runner.withUserConfiguration(EnabledApp.class).run(context -> {
            assertThat(context).hasFailed();
            assertThat(context.getStartupFailure()).hasMessageContaining("at least one");
        });
    }
    @Test void rejectsInsecureOrUnboundedSettings() {
        runner.withPropertyValues("connector.sdk.rest.enabled=true", "connector.sdk.rest.clients.orders.base-url=http://orders.example")
                .run(context -> assertThat(context).hasFailed());
        runner.withPropertyValues("connector.sdk.rest.enabled=true", "connector.sdk.rest.clients.orders.base-url=https://orders.example",
                        "connector.sdk.rest.clients.orders.request-timeout=0s")
                .run(context -> assertThat(context).hasFailed());
    }
    @Test void customBeanAliasWinsAndRetainsConfiguredIdentity() {
        runner.withUserConfiguration(CustomApp.class).withPropertyValues("connector.sdk.rest.enabled=true",
                        "connector.sdk.rest.clients.orders.base-url=https://orders.example")
                .run(context -> {
                    assertThat(context).hasNotFailed().hasSingleBean(RestConnector.class);
                    assertThat(context.getBean(RestConnector.class).name()).isEqualTo("orders");
                });
    }
    @Test void replacementWithWrongIdentityFailsStartup() {
        runner.withUserConfiguration(WrongIdentityApp.class).withPropertyValues("connector.sdk.rest.enabled=true",
                        "connector.sdk.rest.clients.orders.base-url=https://orders.example")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasMessageContaining("logical name");
                });
    }
    @Test void replacementWithWrongCapabilityFailsStartup() {
        runner.withUserConfiguration(WrongCapabilityApp.class).withPropertyValues("connector.sdk.rest.enabled=true",
                        "connector.sdk.rest.clients.orders.base-url=https://orders.example")
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).hasMessageContaining("incompatible capability");
                });
    }
    @Configuration(proxyBeanMethods = false) @EnableRestConnector static class EnabledApp { }
    @Configuration(proxyBeanMethods = false) static class CustomApp {
        @Bean({"customOrders", "restConnector.orders"}) RestConnector orders(io.github.connectorsdk.spring.ConnectorExecutorFactory factory) {
            var settings = new RestConnectorProperties.Client();
            settings.setBaseUrl(URI.create("https://custom.example"));
            return new RestConnector("orders", settings, factory.create("rest", "orders", 2), List.of());
        }
    }
    @Configuration(proxyBeanMethods = false) static class WrongIdentityApp {
        @Bean("restConnector.orders") RestConnector orders(io.github.connectorsdk.spring.ConnectorExecutorFactory factory) {
            var settings = new RestConnectorProperties.Client();
            settings.setBaseUrl(URI.create("https://custom.example"));
            return new RestConnector("billing", settings, factory.create("rest", "billing", 2), List.of());
        }
    }
    @Configuration(proxyBeanMethods = false) static class WrongCapabilityApp {
        @Bean("restConnector.orders") String wrong() { return "This is not a REST connector"; }
    }
}
