package io.github.connectorsdk.rest;

import com.sun.net.httpserver.HttpServer;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObserver;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

class RestConnectorTest {
    private HttpServer server;
    private java.util.concurrent.ExecutorService serverExecutor;
    private final List<RestConnector> clients = new ArrayList<>();

    @BeforeEach void start() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        serverExecutor = Executors.newVirtualThreadPerTaskExecutor();
        server.setExecutor(serverExecutor);
        server.start();
    }
    @AfterEach void stop() {
        clients.forEach(RestConnector::close);
        server.stop(0);
        serverExecutor.shutdownNow();
    }

    @Test void exchangesBytesAndAppendsRelativePath() {
        server.createContext("/api/items", exchange -> {
            byte[] body = exchange.getRequestBody().readAllBytes();
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(201, body.length);
            try (var stream = exchange.getResponseBody()) { stream.write(body); }
        });
        RestConnector client = client(Duration.ofSeconds(3), 1024);
        byte[] data = "{\"name\":\"café\"}".getBytes(StandardCharsets.UTF_8);
        var response = client.exchange(new RestRequest("post", "items", Map.of("Content-Type", "application/json"), data));
        assertThat(response.statusCode()).isEqualTo(201);
        assertThat(response.successful()).isTrue();
        assertThat(response.body()).isEqualTo(data);
        assertThat(response.bodyUtf8()).contains("café");
    }

    @Test void retainsBusinessStatusAndNeverFollowsRedirects() {
        server.createContext("/api/status", exchange -> {
            exchange.getResponseHeaders().add("Location", "https://other.example/private");
            exchange.sendResponseHeaders(302, -1);
            exchange.close();
        });
        var response = client(Duration.ofSeconds(3), 1024).exchange(RestRequest.get("status"));
        assertThat(response.statusCode()).isEqualTo(302);
        assertThat(response.successful()).isFalse();
    }

    @Test void cancelsOversizeResponse() {
        server.createContext("/api/large", exchange -> {
            exchange.sendResponseHeaders(200, 128);
            try (var stream = exchange.getResponseBody()) { stream.write(new byte[128]); }
        });
        assertThatThrownBy(() -> client(Duration.ofSeconds(3), 16).exchange(RestRequest.get("large")))
                .isInstanceOfSatisfying(ConnectorException.class, failure ->
                        assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.REMOTE_ERROR));
    }

    @Test void deadlineIncludesStalledResponseBody() {
        server.createContext("/api/slow-body", exchange -> {
            exchange.sendResponseHeaders(200, 8);
            try (var stream = exchange.getResponseBody()) {
                stream.write(1);
                stream.flush();
                try { Thread.sleep(1200); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                stream.write(new byte[7]);
            } catch (java.io.IOException ignored) { /* Expected cancellation from client. */ }
        });
        long start = System.nanoTime();
        assertThatThrownBy(() -> client(Duration.ofMillis(300), 1024).exchange(RestRequest.get("slow-body")))
                .isInstanceOfSatisfying(ConnectorException.class, failure ->
                        assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.TIMEOUT));
        assertThat(Duration.ofNanos(System.nanoTime() - start)).isLessThan(Duration.ofSeconds(2));
    }

    @Test void rejectsAbsoluteAndProtocolRelativePathsWithoutLeakingSecrets() {
        var client = client(Duration.ofSeconds(1), 1024);
        for (String path : List.of("https://other.example/?token=secret", "//other.example/private", "items#fragment")) {
            assertThatThrownBy(() -> client.exchange(RestRequest.get(path)))
                    .isInstanceOfSatisfying(ConnectorException.class, failure -> {
                        assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CONFIGURATION);
                        assertThat(failure.getMessage()).doesNotContain("secret", "other.example");
                    });
        }
    }

    @Test void shutdownIsIdempotentAndCallsFailClosed() {
        var client = client(Duration.ofSeconds(1), 1024);
        client.close();
        client.close();
        assertThatThrownBy(() -> client.exchange(RestRequest.get("items")))
                .isInstanceOfSatisfying(ConnectorException.class, failure ->
                        assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CLOSED));
    }

    @Test void interruptionCancelsCallAndPreservesInterruptStatus() throws Exception {
        var entered = new CountDownLatch(1);
        server.createContext("/api/wait", exchange -> {
            entered.countDown();
            try { Thread.sleep(1500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            exchange.close();
        });
        var client = client(Duration.ofSeconds(3), 1024);
        var failure = new java.util.concurrent.atomic.AtomicReference<ConnectorException>();
        var interrupted = new java.util.concurrent.atomic.AtomicBoolean();
        Thread caller = Thread.ofVirtual().start(() -> {
            try { client.exchange(RestRequest.get("wait")); }
            catch (ConnectorException ex) { failure.set(ex); interrupted.set(Thread.currentThread().isInterrupted()); }
        });
        assertThat(entered.await(2, TimeUnit.SECONDS)).isTrue();
        caller.interrupt();
        caller.join(2000);
        assertThat(caller.isAlive()).isFalse();
        assertThat(failure.get().errorCode()).isEqualTo(ConnectorErrorCode.INTERRUPTED);
        assertThat(interrupted).isTrue();
    }

    @Test void requestResponseCopiesProtectPayloadAndHeaders() {
        byte[] payload = {1, 2};
        var request = new RestRequest("POST", "private?token=secret", Map.of("Authorization", "secret"), payload);
        var response = new RestResponse(200, Map.of("Authorization", List.of("secret")), payload);
        payload[0] = 9;
        request.body()[0] = 8;
        response.body()[0] = 8;
        assertThat(request.body()).containsExactly(1, 2);
        assertThat(response.body()).containsExactly(1, 2);
        assertThat(request.toString()).doesNotContain("secret", "private");
        assertThat(response.toString()).doesNotContain("secret");
    }

    private RestConnector client(Duration timeout, int maxBytes) {
        var settings = new RestConnectorProperties.Client();
        settings.setBaseUrl(URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/api/"));
        settings.setAllowInsecure(true);
        settings.setRequestTimeout(timeout);
        settings.setMaxResponseBytes(maxBytes);
        var connector = new RestConnector("test", settings, new ConnectorExecutor("rest", "test", 4, InvocationObserver.NONE), List.of());
        clients.add(connector);
        return connector;
    }
}
