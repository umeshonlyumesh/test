package io.github.connectorsdk.rest;

import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsExchange;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;
import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.rest.autoconfigure.RestConnectorAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorRuntimeAutoConfiguration;
import io.github.connectorsdk.spring.autoconfigure.ConnectorSupportAutoConfiguration;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.ssl.DefaultSslBundleRegistry;
import org.springframework.boot.ssl.SslBundle;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.boot.ssl.SslStoreBundle;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import static org.assertj.core.api.Assertions.*;

/** Uses real local TLS with generated server/client certificates; no network services are required. */
class RestMutualTlsTest {
    private static final String PASSWORD = "test-store-password";
    @TempDir static Path temporary;
    private static KeyStore serverKeys;
    private static KeyStore clientKeys;
    private static KeyStore serverTrust;
    private static KeyStore clientTrust;
    private HttpsServer server;
    private java.util.concurrent.ExecutorService workers;
    private SslBundles bundles;
    private final AtomicInteger tokens = new AtomicInteger();

    @BeforeAll static void certificates() throws Exception {
        Path serverFile = temporary.resolve("server.p12");
        Path clientFile = temporary.resolve("client.p12");
        keytool(serverFile, "server", "CN=localhost", "SAN=dns:localhost", "EKU=serverAuth");
        keytool(clientFile, "client", "CN=sdk-client", "EKU=clientAuth");
        serverKeys = load(serverFile); clientKeys = load(clientFile);
        serverTrust = KeyStore.getInstance("PKCS12"); serverTrust.load(null, null);
        serverTrust.setCertificateEntry("client", clientKeys.getCertificate("client"));
        clientTrust = KeyStore.getInstance("PKCS12"); clientTrust.load(null, null);
        clientTrust.setCertificateEntry("server", serverKeys.getCertificate("server"));
    }

    @BeforeEach void start() throws Exception {
        var serverContext = SslBundle.of(SslStoreBundle.of(serverKeys, PASSWORD, serverTrust)).createSslContext();
        server = HttpsServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setHttpsConfigurator(new HttpsConfigurator(serverContext) {
            @Override public void configure(HttpsParameters parameters) {
                var ssl = serverContext.getDefaultSSLParameters(); ssl.setNeedClientAuth(true);
                parameters.setSSLParameters(ssl);
            }
        });
        workers = Executors.newVirtualThreadPerTaskExecutor(); server.setExecutor(workers);
        server.createContext("/api", exchange -> {
            String principal = ((HttpsExchange) exchange).getSSLSession().getPeerPrincipal().getName();
            String authorization = exchange.getRequestHeaders().getFirst("Authorization");
            byte[] body = (principal + "|" + authorization).getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        server.createContext("/token", exchange -> {
            tokens.incrementAndGet(); exchange.getRequestBody().readAllBytes();
            byte[] body = "{\"access_token\":\"mutual-token\",\"token_type\":\"Bearer\",\"expires_in\":60}".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, body.length);
            try (var output = exchange.getResponseBody()) { output.write(body); }
        });
        server.start();
        bundles = new DefaultSslBundleRegistry("mutual", SslBundle.of(SslStoreBundle.of(clientKeys, PASSWORD, clientTrust)));
    }

    @AfterEach void stop() { server.stop(0); workers.shutdownNow(); }

    @Test void configuredBundlePresentsClientCertificateWithBasicAuthentication() {
        runner("localhost").withPropertyValues("connector.sdk.rest.clients.orders.auth.type=BASIC",
                        "connector.sdk.rest.clients.orders.auth.username=sdk-user",
                        "connector.sdk.rest.clients.orders.auth.password=test-password")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    var response = context.getBean(RestConnector.class).exchange(RestRequest.get("api"));
                    assertThat(response.bodyUtf8()).startsWith("CN=sdk-client|Basic ");
                });
    }

    @Test void oauthTokenEndpointAndResourceBothUseTheConfiguredClientCertificate() {
        runner("localhost").withPropertyValues("connector.sdk.rest.clients.orders.auth.type=OAUTH2_CLIENT_CREDENTIALS",
                        "connector.sdk.rest.clients.orders.auth.token-url=https://localhost:" + server.getAddress().getPort() + "/token",
                        "connector.sdk.rest.clients.orders.auth.client-id=sdk-client",
                        "connector.sdk.rest.clients.orders.auth.client-secret=test-client-secret")
                .run(context -> {
                    assertThat(context).hasNotFailed(); assertThat(tokens).hasValue(0);
                    var response = context.getBean(RestConnector.class).exchange(RestRequest.get("api"));
                    assertThat(response.bodyUtf8()).isEqualTo("CN=sdk-client|Bearer mutual-token");
                    assertThat(tokens).hasValue(1);
                });
    }

    @Test void configuredTrustNeverDisablesHostnameVerification() {
        // The server certificate has DNS:localhost, deliberately no IP SAN.
        runner("127.0.0.1").run(context -> {
            assertThat(context).hasNotFailed();
            assertThatThrownBy(() -> context.getBean(RestConnector.class).exchange(RestRequest.get("api")))
                    .isInstanceOf(ConnectorException.class);
        });
    }

    @Test void missingSslBundleFailsStartup() {
        runner("localhost").withPropertyValues("connector.sdk.rest.clients.orders.ssl-bundle=missing").run(context -> {
            assertThat(context).hasFailed();
            assertThat(context.getStartupFailure()).hasStackTraceContaining("Configured REST SSL bundle is missing or unavailable");
        });
    }

    private ApplicationContextRunner runner(String host) {
        return new ApplicationContextRunner().withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                        RestConnectorAutoConfiguration.class, ConnectorSupportAutoConfiguration.class))
                .withBean(SslBundles.class, () -> bundles)
                .withPropertyValues("connector.sdk.rest.enabled=true",
                        "connector.sdk.rest.clients.orders.base-url=https://" + host + ":" + server.getAddress().getPort() + "/",
                        "connector.sdk.rest.clients.orders.ssl-bundle=mutual",
                        "connector.sdk.rest.clients.orders.request-timeout=5s");
    }

    private static KeyStore load(Path file) throws Exception {
        var store = KeyStore.getInstance("PKCS12");
        try (var input = Files.newInputStream(file)) { store.load(input, PASSWORD.toCharArray()); }
        return store;
    }

    private static void keytool(Path file, String alias, String distinguishedName, String... extensions) throws Exception {
        boolean windows = System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT).contains("win");
        Path executable = Path.of(System.getProperty("java.home"), "bin", windows ? "keytool.exe" : "keytool");
        List<String> arguments = new ArrayList<>(List.of(executable.toString(), "-genkeypair", "-alias", alias,
                "-keyalg", "EC", "-groupname", "secp256r1", "-dname", distinguishedName,
                "-validity", "2", "-storetype", "PKCS12", "-keystore", file.toString(),
                "-storepass", PASSWORD, "-keypass", PASSWORD, "-noprompt"));
        for (String extension : extensions) { arguments.add("-ext"); arguments.add(extension); }
        Path log = temporary.resolve(alias + "-keytool.log");
        var process = new ProcessBuilder(arguments).redirectErrorStream(true).redirectOutput(log.toFile()).start();
        if (!process.waitFor(30, TimeUnit.SECONDS)) {
            process.destroyForcibly(); throw new IllegalStateException("Local certificate generation timed out");
        }
        assertThat(process.exitValue()).withFailMessage(Files.readString(log)).isZero();
    }
}
