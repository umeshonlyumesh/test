package io.github.connectorsdk.spring;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;

import java.util.List;
import java.util.Objects;

/**
 * Validates the protocol capability and identity of configured named connector beans.
 *
 * <p>An enabled adapter should register one validator with its configured expectations. Checks
 * run after ordinary singleton creation, resolve aliases and fail application startup if a
 * caller's replacement is incompatible. Disabled adapters should not register this bean.</p>
 */
public final class ConnectorBeanValidator implements SmartInitializingSingleton {
    private final BeanFactory beanFactory;
    private final List<Expectation> expectations;

    public ConnectorBeanValidator(BeanFactory beanFactory, List<Expectation> expectations) {
        this.beanFactory = Objects.requireNonNull(beanFactory, "beanFactory");
        this.expectations = List.copyOf(Objects.requireNonNull(expectations, "expectations"));
    }

    @Override
    public void afterSingletonsInstantiated() {
        for (Expectation expectation : expectations) {
            Connector connector;
            try {
                connector = beanFactory.getBean(expectation.beanName(), expectation.expectedClass());
            }
            catch (BeansException failure) {
                throw failure(expectation, "Configured connector bean is missing or has an incompatible capability",
                        failure);
            }
            if (!expectation.type().equals(connector.type()) || !expectation.name().equals(connector.name())) {
                throw failure(expectation, "Configured connector bean has an incompatible transport or logical name", null);
            }
        }
    }

    private static ConnectorException failure(Expectation expectation, String message, Throwable cause) {
        return new ConnectorException(ConnectorErrorCode.CONFIGURATION, expectation.type(), expectation.name(),
                message, ConnectorException.redactedCause(cause));
    }

    /** One configured bean's name, protocol identity and required implementation capability. */
    public record Expectation(String beanName, String type, String name,
                              Class<? extends Connector> expectedClass) {
        public Expectation {
            requireIdentifier(beanName, "beanName");
            requireIdentifier(type, "type");
            requireIdentifier(name, "name");
            Objects.requireNonNull(expectedClass, "expectedClass");
        }

        private static void requireIdentifier(String value, String field) {
            if (Objects.requireNonNull(value, field).isBlank()) {
                throw new IllegalArgumentException(field + " must not be blank");
            }
        }
    }
}
