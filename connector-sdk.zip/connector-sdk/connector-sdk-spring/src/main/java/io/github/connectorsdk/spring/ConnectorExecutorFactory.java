package io.github.connectorsdk.spring;

import io.github.connectorsdk.core.ConnectorException;
import io.github.connectorsdk.core.ConnectorExecutor;
import io.github.connectorsdk.core.InvocationObservation;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationRegistry;

import java.util.Objects;

/**
 * Creates independent concurrency limits with Micrometer observation integration.
 *
 * <p>The stable observation name is {@code connector.invocation}. Tags contain only configured
 * connector identities and transport-defined operations. Endpoint addresses and payloads are
 * never recorded. Keep configured names bounded to avoid excessive metric cardinality.</p>
 */
public class ConnectorExecutorFactory {
    private final ObservationRegistry observationRegistry;

    public ConnectorExecutorFactory(ObservationRegistry observationRegistry) {
        this.observationRegistry = Objects.requireNonNull(observationRegistry, "observationRegistry");
    }

    public ConnectorExecutor create(String type, String name, int maxConcurrency) {
        return new ConnectorExecutor(type, name, maxConcurrency, this::start);
    }

    private InvocationObservation start(String type, String name, String operation) {
        Observation.Scope previousScope = observationRegistry.getCurrentObservationScope();
        Observation observation = Observation.createNotStarted("connector.invocation", observationRegistry)
                .lowCardinalityKeyValue("connector.type", type)
                .lowCardinalityKeyValue("connector.name", name)
                .lowCardinalityKeyValue("connector.operation", operation);
        Observation.Scope scope;
        try {
            observation.start();
            scope = observation.openScope();
        }
        catch (RuntimeException | Error failure) {
            try {
                observationRegistry.setCurrentObservationScope(previousScope);
                observation.stop();
            }
            catch (RuntimeException | Error ignored) {
                // Keep the original observation failure; the core executor isolates it.
            }
            throw failure;
        }
        return failure -> {
            try {
                observation.lowCardinalityKeyValue("outcome", failure == null ? "success" : "error");
                if (failure != null) {
                    observation.lowCardinalityKeyValue("error.code", failure instanceof ConnectorException connectorFailure
                            ? connectorFailure.errorCode().name() : "UNEXPECTED");
                    observation.error(failure);
                }
            }
            finally {
                try {
                    scope.close();
                }
                finally {
                    try {
                        // A failing onScopeClosed callback must not leave this invocation current.
                        observationRegistry.setCurrentObservationScope(previousScope);
                    }
                    finally {
                        observation.stop();
                    }
                }
            }
        };
    }
}
