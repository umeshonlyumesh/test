package io.github.connectorsdk.spring.autoconfigure;

import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.micrometer.observation.ObservationRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

/** Lightweight runtime infrastructure. This configuration never creates a transport connector. */
@AutoConfiguration(beforeName = {
        "io.github.connectorsdk.rest.autoconfigure.RestConnectorAutoConfiguration",
        "io.github.connectorsdk.grpc.autoconfigure.GrpcConnectorAutoConfiguration",
        "io.github.connectorsdk.mq.autoconfigure.MqConnectorAutoConfiguration"
})
public class ConnectorRuntimeAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    ConnectorExecutorFactory connectorExecutorFactory(ObjectProvider<ObservationRegistry> observations) {
        return new ConnectorExecutorFactory(observations.getIfUnique(() -> ObservationRegistry.NOOP));
    }
}
