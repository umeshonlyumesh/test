package io.github.connectorsdk.spring.autoconfigure;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

/** Registry assembled at bean creation after named connector definitions have been registered. */
@AutoConfiguration(afterName = {
        "io.github.connectorsdk.rest.autoconfigure.RestConnectorAutoConfiguration",
        "io.github.connectorsdk.grpc.autoconfigure.GrpcConnectorAutoConfiguration",
        "io.github.connectorsdk.mq.autoconfigure.MqConnectorAutoConfiguration"
})
public class ConnectorSupportAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    ConnectorRegistry connectorRegistry(ObjectProvider<Connector> connectors) {
        return new ConnectorRegistry(connectors.orderedStream().toList());
    }
}
