package io.github.connectorsdk.spring;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

class ConnectorBeanValidatorTest {
    private static final ConnectorBeanValidator.Expectation ORDERS = new ConnectorBeanValidator.Expectation(
            "restConnector.orders", "rest", "orders", SampleConnector.class);

    @Test
    void acceptsCallerReplacementThroughAnAlias() {
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
        SampleConnector callerConnector = new SampleConnector("rest", "orders");
        factory.registerSingleton("callerClient", callerConnector);
        factory.registerAlias("callerClient", "restConnector.orders");

        new ConnectorBeanValidator(factory, List.of(ORDERS)).afterSingletonsInstantiated();
        assertThat(factory.getBean("restConnector.orders")).isSameAs(callerConnector);
    }

    @Test
    void rejectsMatchingBeanNameWithWrongLogicalIdentity() {
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
        factory.registerSingleton("restConnector.orders", new SampleConnector("rest", "different-client"));

        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> new ConnectorBeanValidator(factory, List.of(ORDERS)).afterSingletonsInstantiated())
                .satisfies(failure -> {
                    assertThat(failure.errorCode()).isEqualTo(ConnectorErrorCode.CONFIGURATION);
                    assertThat(failure.connectorType()).isEqualTo("rest");
                    assertThat(failure.connectorName()).isEqualTo("orders");
                })
                .withMessageContaining("incompatible transport or logical name");
    }

    @Test
    void rejectsMatchingBeanNameWithWrongTransport() {
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
        factory.registerSingleton("restConnector.orders", new SampleConnector("mq", "orders"));

        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> new ConnectorBeanValidator(factory, List.of(ORDERS)).afterSingletonsInstantiated())
                .withMessageContaining("incompatible transport or logical name");
    }

    @Test
    void rejectsMatchingIdentityWithWrongProtocolCapability() {
        DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
        factory.registerSingleton("restConnector.orders", new OtherConnector("rest", "orders"));

        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> new ConnectorBeanValidator(factory, List.of(ORDERS)).afterSingletonsInstantiated())
                .withMessageContaining("incompatible capability")
                .satisfies(failure -> {
                    assertThat(failure.getCause()).isNotNull();
                    assertThat(failure.getCause().getCause()).isNull();
                    assertThat(failure.getCause().getSuppressed()).isEmpty();
                });
    }

    @Test
    void rejectsMissingConfiguredBean() {
        assertThatExceptionOfType(ConnectorException.class)
                .isThrownBy(() -> new ConnectorBeanValidator(new DefaultListableBeanFactory(), List.of(ORDERS))
                        .afterSingletonsInstantiated())
                .withMessageContaining("missing or has an incompatible capability");
    }

    @Test
    void invalidReplacementFailsActualApplicationStartup() {
        new ApplicationContextRunner()
                .withUserConfiguration(ValidationConfiguration.class)
                .withBean("restConnector.orders", SampleConnector.class,
                        () -> new SampleConnector("rest", "wrong-name"))
                .run(context -> {
                    assertThat(context).hasFailed();
                    assertThat(context.getStartupFailure()).isInstanceOf(ConnectorException.class);
                });
    }

    @Configuration(proxyBeanMethods = false)
    static class ValidationConfiguration {
        @Bean
        ConnectorBeanValidator configuredConnectorValidation(BeanFactory factory) {
            return new ConnectorBeanValidator(factory, List.of(ORDERS));
        }
    }

    private record SampleConnector(String type, String name) implements Connector { }

    private record OtherConnector(String type, String name) implements Connector { }
}
