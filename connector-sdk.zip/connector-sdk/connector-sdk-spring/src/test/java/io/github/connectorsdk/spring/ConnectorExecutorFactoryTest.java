package io.github.connectorsdk.spring;

import io.github.connectorsdk.core.ConnectorErrorCode;
import io.github.connectorsdk.core.ConnectorException;
import io.micrometer.observation.Observation;
import io.micrometer.observation.ObservationHandler;
import io.micrometer.observation.ObservationRegistry;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ConnectorExecutorFactoryTest {

    @Test
    void recordsSafeTagsAndRestoresObservationScopeOnSuccessAndFailure() {
        ObservationRegistry registry = ObservationRegistry.create();
        RecordingHandler handler = new RecordingHandler();
        registry.observationConfig().observationHandler(handler);
        var executor = new ConnectorExecutorFactory(registry).create("rest", "orders", 2);

        assertThat(executor.execute("get", () -> {
            assertThat(registry.getCurrentObservation()).isNotNull();
            return "ok";
        })).isEqualTo("ok");
        assertThat(registry.getCurrentObservation()).isNull();

        ConnectorException original = new ConnectorException(ConnectorErrorCode.TIMEOUT,
                "rest", "orders", "Connector request timed out");
        assertThatThrownBy(() -> executor.execute("get", () -> { throw original; })).isSameAs(original);
        assertThat(registry.getCurrentObservation()).isNull();
        assertThat(handler.stopped).hasSize(2);
        Observation.Context success = handler.stopped.getFirst();
        assertThat(success.getName()).isEqualTo("connector.invocation");
        assertThat(success.getLowCardinalityKeyValue("connector.type").getValue()).isEqualTo("rest");
        assertThat(success.getLowCardinalityKeyValue("connector.name").getValue()).isEqualTo("orders");
        assertThat(success.getLowCardinalityKeyValue("connector.operation").getValue()).isEqualTo("get");
        assertThat(success.getLowCardinalityKeyValue("outcome").getValue()).isEqualTo("success");
        assertThat(success.getHighCardinalityKeyValues()).isEmpty();
        Observation.Context failure = handler.stopped.getLast();
        assertThat(failure.getError()).isSameAs(original);
        assertThat(failure.getLowCardinalityKeyValue("error.code").getValue()).isEqualTo("TIMEOUT");
    }

    @Test
    void observationHandlersCannotMaskTransportFailureOrLeakScope() {
        ObservationRegistry registry = ObservationRegistry.create();
        registry.observationConfig().observationHandler(new ObservationHandler<Observation.Context>() {
            @Override
            public void onError(Observation.Context context) {
                throw new IllegalStateException("broken error handler");
            }

            @Override
            public void onStop(Observation.Context context) {
                throw new IllegalStateException("broken stop handler");
            }

            @Override
            public boolean supportsContext(Observation.Context context) {
                return true;
            }
        });
        var executor = new ConnectorExecutorFactory(registry).create("grpc", "orders", 1);
        RuntimeException original = new IllegalStateException("transport failed");

        assertThatThrownBy(() -> executor.execute("call", () -> { throw original; })).isSameAs(original);
        assertThat(registry.getCurrentObservation()).isNull();
        assertThat(executor.execute("call", () -> "ok")).isEqualTo("ok");
        assertThat(registry.getCurrentObservation()).isNull();
    }

    @Test
    void noopRegistryRequiresNoHandlersOrExporter() {
        var executor = new ConnectorExecutorFactory(ObservationRegistry.NOOP).create("mq", "orders", 1);
        assertThat(executor.execute("send", () -> "ok")).isEqualTo("ok");
    }

    @Test
    void failingScopeOpenHandlerRestoresCallerObservation() {
        assertCallerScopeRestored(true);
    }

    @Test
    void failingScopeCloseHandlerRestoresCallerObservation() {
        assertCallerScopeRestored(false);
    }

    private static void assertCallerScopeRestored(boolean failWhenOpening) {
        ObservationRegistry registry = ObservationRegistry.create();
        registry.observationConfig().observationHandler(new ObservationHandler<Observation.Context>() {
            @Override
            public void onScopeOpened(Observation.Context context) {
                if (failWhenOpening && "connector.invocation".equals(context.getName())) {
                    throw new IllegalStateException("broken scope open handler");
                }
            }

            @Override
            public void onScopeClosed(Observation.Context context) {
                if (!failWhenOpening && "connector.invocation".equals(context.getName())) {
                    throw new IllegalStateException("broken scope close handler");
                }
            }

            @Override
            public boolean supportsContext(Observation.Context context) {
                return true;
            }
        });
        Observation parent = Observation.start("caller", registry);
        try (Observation.Scope ignored = parent.openScope()) {
            var executor = new ConnectorExecutorFactory(registry).create("rest", "orders", 1);
            assertThat(executor.execute("get", () -> "ok")).isEqualTo("ok");
            assertThat(registry.getCurrentObservation()).isSameAs(parent);
            assertThat(executor.execute("get", () -> "ok again")).isEqualTo("ok again");
            assertThat(registry.getCurrentObservation()).isSameAs(parent);
        }
        finally {
            parent.stop();
        }
        assertThat(registry.getCurrentObservation()).isNull();
    }

    private static final class RecordingHandler implements ObservationHandler<Observation.Context> {
        private final List<Observation.Context> stopped = new ArrayList<>();

        @Override
        public void onStop(Observation.Context context) {
            stopped.add(context);
        }

        @Override
        public boolean supportsContext(Observation.Context context) {
            return true;
        }
    }
}
