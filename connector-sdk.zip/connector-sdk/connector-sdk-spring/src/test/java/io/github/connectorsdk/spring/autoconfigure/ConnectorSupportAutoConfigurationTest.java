package io.github.connectorsdk.spring.autoconfigure;

import io.github.connectorsdk.core.Connector;
import io.github.connectorsdk.core.ConnectorRegistry;
import io.github.connectorsdk.spring.ConnectorExecutorFactory;
import io.micrometer.observation.ObservationRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ConnectorSupportAutoConfigurationTest {
    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ConnectorRuntimeAutoConfiguration.class,
                    ConnectorSupportAutoConfiguration.class));

    @Test
    void unenabledApplicationGetsOnlyLightweightInfrastructure() {
        runner.run(context -> {
            assertThat(context).hasSingleBean(ConnectorExecutorFactory.class).hasSingleBean(ConnectorRegistry.class);
            assertThat(context).doesNotHaveBean(Connector.class);
            assertThat(context.getBean(ConnectorRegistry.class).connectors()).isEmpty();
            assertThat(context.getBean(ConnectorExecutorFactory.class).create("rest", "orders", 1)
                    .execute("get", () -> "ok")).isEqualTo("ok");
        });
    }

    @Test
    void includesConnectorDefinitionsRegisteredByLatePostProcessors() {
        runner.withUserConfiguration(LateConnectorRegistration.class).run(context -> {
            assertThat(context).hasNotFailed();
            ConnectorRegistry registry = context.getBean(ConnectorRegistry.class);
            assertThat(registry.connectors()).hasSize(1);
            assertThat(registry.require("custom", "orders", Connector.class))
                    .isSameAs(context.getBean("customConnector.orders"));
        });
    }

    @Test
    void callerCanReplaceInfrastructureBeans() {
        ConnectorRegistry registry = new ConnectorRegistry(List.of());
        ConnectorExecutorFactory factory = new ConnectorExecutorFactory(ObservationRegistry.NOOP);
        runner.withBean(ConnectorRegistry.class, () -> registry)
                .withBean(ConnectorExecutorFactory.class, () -> factory)
                .run(context -> {
                    assertThat(context).hasSingleBean(ConnectorRegistry.class).hasSingleBean(ConnectorExecutorFactory.class);
                    assertThat(context.getBean(ConnectorRegistry.class)).isSameAs(registry);
                    assertThat(context.getBean(ConnectorExecutorFactory.class)).isSameAs(factory);
                });
    }

    @Configuration(proxyBeanMethods = false)
    static class LateConnectorRegistration {
        @Bean
        static BeanDefinitionRegistryPostProcessor customConnectorRegistration() {
            return new BeanDefinitionRegistryPostProcessor() {
                @Override
                public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
                    registry.registerBeanDefinition("customConnector.orders",
                            new RootBeanDefinition(SampleConnector.class, SampleConnector::new));
                }

                @Override
                public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
                }
            };
        }
    }

    static class SampleConnector implements Connector {
        @Override
        public String name() {
            return "orders";
        }

        @Override
        public String type() {
            return "custom";
        }
    }
}
