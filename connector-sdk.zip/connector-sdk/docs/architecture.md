# Connector SDK architecture

This SDK targets Java 21 and Spring Boot 4. Its extension boundary is a small, framework-independent connector contract, with transport adapters and Spring Boot integration in separate Maven modules. REST, unary gRPC and Jakarta JMS/MQ are implemented. SQS is an extension plan described below; there is no SQS client in this release.

## Module boundaries

| Module | Responsibility | Depends on |
| --- | --- | --- |
| `connector-sdk-core` | Connector identity/lifecycle, immutable registry, error categories, concurrency limits, observation hooks | JDK only at runtime |
| `connector-sdk-spring` | Runtime factory, registry auto-configuration, Micrometer observation bridge | Core, Spring Boot and Micrometer |
| `connector-sdk-rest` | Named HTTP clients, request/response contracts, configuration and opt-in annotation | Core/Spring support and JDK HTTP client |
| `connector-sdk-grpc` | Named channels, bounded synchronous unary RPCs, configuration and opt-in annotation | Core/Spring support and gRPC Java |
| `connector-sdk-mq` | Named synchronous Jakarta JMS queue/topic adapters, configuration and opt-in annotation | Core/Spring support and Spring JMS |
| `connector-sdk-*-spring-boot-starter` | Convenient dependency bundles for individual transports | One adapter and its runtime dependencies |
| `connector-sdk-bom` | Consistent versions for SDK modules and starters | Maven metadata |

Applications select the transport starters they need. A REST application does not need to bring in gRPC or a JMS provider. The MQ adapter accepts a caller-owned Jakarta JMS `ConnectionFactory`; it does not select a broker implementation for the application.

## Patterns used and their purpose

**Ports and adapters:** `Connector` is the common port for identity and lifecycle. Its methods are `name()`, `type()` and `close()`. Each adapter exposes operations appropriate to its protocol: HTTP exchange, unary RPC, or JMS send/receive. A common `execute(Object)` contract would discard protocol types and delivery semantics, so operations remain typed on their respective adapters.

**Registry:** `ConnectorRegistry` creates an immutable snapshot keyed by `(transport type, configured name)`. `rest/orders` and `mq/orders` can coexist. Duplicate identity within one transport fails at startup. Typed lookup verifies the requested capability and gives an explanatory configuration failure if the connector is missing or incompatible.

```java
RestConnector orders = registry.require("rest", "orders", RestConnector.class);
RestResponse response = orders.exchange(RestRequest.get("v1/orders"));
```

**Factory and strategy:** `ConnectorExecutorFactory` creates an executor for each configured client. `InvocationObserver` is a framework-independent strategy for telemetry; the default does nothing. The Spring factory connects the strategy to Micrometer and uses `ObservationRegistry.NOOP` when no unique observation registry is available. Applications can replace the factory bean without modifying adapters.

**Bulkhead:** each `ConnectorExecutor` owns a semaphore. A call that cannot acquire a permit fails immediately with `SATURATED`; there is no unbounded waiting queue. Permits are released in `finally` on both successful and failed transport calls. Different connector instances have independent limits.

**Conditional auto-configuration:** annotations and properties express transport selection. Each enabled adapter registers named bean definitions through a `BeanDefinitionRegistryPostProcessor`. Instance suppliers construct connectors through the runtime factory and ordered customizers. Spring owns SDK bean destruction and invokes `close()`.

**Composition:** transport customizers and the executor are composed into adapter construction. There is no shared transport superclass or central protocol switch that must be edited whenever a new connector is introduced.

## Startup and bean selection

The annotations are `@EnableRestConnector`, `@EnableGrpcConnector` and `@EnableMqConnector`. The corresponding `connector.sdk.<transport>.enabled=true` property also enables an adapter. Explicit `enabled=false` takes precedence over annotation enablement. Being present on the classpath alone does not enable a transport.

An enabled transport must have at least one valid `clients` entry. Settings are bound and validated before its named connector definitions are registered. A configured name produces a bean such as `restConnector.orders`, `grpcConnector.catalog` or `mqConnector.events`. The registry provides an alternative to injecting each bean by qualifier.

`ConnectorRuntimeAutoConfiguration` contributes the lightweight executor factory. `ConnectorSupportAutoConfiguration` contributes the registry. These infrastructure beans may exist with no transport enabled; the registry is then empty. A disabled adapter contributes no SDK transport connector or transport client resource.

The registry uses an `ObjectProvider<Connector>` at bean creation rather than an early `@ConditionalOnBean(Connector.class)` check. This is necessary because adapter definitions are registered by post-processors after configuration conditions have been evaluated. All post-processors finish before regular singletons are instantiated, so the registry sees the dynamically registered definitions. It does not own connector lifecycle or close connectors independently of Spring.

Existing infrastructure beans take precedence through `@ConditionalOnMissingBean`. Adapter registration also backs off when a configured connector bean name or alias has already been provided. A replacement bean must retain the intended connector identity and protocol capability. The shared `ConnectorBeanValidator` resolves configured names and aliases after singleton creation and fails startup on missing beans, wrong protocol capabilities or mismatched identities. The registry independently validates duplicate identities.

## Invocation, telemetry and failures

An invocation starts its observation, tries to acquire a concurrency permit, performs the transport operation, releases the permit and completes the observation. Rejected calls are also observable. Observer failures do not change the transport result or leak a permit. The Micrometer bridge restores the caller's observation scope even if scope callbacks throw.

The observation name is `connector.invocation`. Low-cardinality tags are `connector.type`, `connector.name`, `connector.operation` and `outcome`; failures also carry `error.code`. Names and operations must be bounded logical identifiers. URLs, queue destinations, credentials, request bodies and response bodies are not metric tags. A caller can add additional tracing through the available transport customization APIs, but must preserve the same privacy discipline.

The stable error categories are:

| Code | Application meaning |
| --- | --- |
| `CONFIGURATION` | Invalid connector setup or incompatible lookup |
| `UNAVAILABLE` | Transport connectivity or service availability failure |
| `TIMEOUT` | Configured call deadline elapsed |
| `REMOTE_ERROR` | Remote or protocol failure requiring transport-specific handling |
| `SATURATED` | Local concurrency limit or mapped remote resource exhaustion |
| `INTERRUPTED` | Caller interruption during transport work |
| `CLOSED` | Operation attempted after connector shutdown |

Error categories are a small common vocabulary, not a promise that different transports have identical retryability. An HTTP response, including a non-2xx status, is returned as `RestResponse` for application-defined handling. A gRPC status failure is mapped to `ConnectorException`, with its safe status code retained. JMS failures use `REMOTE_ERROR`; a provider-specific failure does not reliably disclose whether the broker accepted a message before the failure.

SDK adapter messages use fixed descriptions. `ConnectorException.redactedCause(Throwable)` retains the original exception class name and stack, but removes the original message, nested causes and suppressed exceptions. REST and MQ use this helper for potentially sensitive transport diagnostics; gRPC retains a status-code-only cause. This protects both stack traces and observation exporters. Public `ConnectorException` constructors deliberately preserve a caller-supplied cause: custom adapters must choose whether and how to redact it.

There is no SDK retry loop or circuit breaker in this release. A retry can repeat a successful side effect when an acknowledgement or response was lost. Applications should classify operations and make idempotency decisions explicitly. Transport providers may have their own retry behavior; configure and document that behavior before rollout.

## Current transport scope

| Transport | Implemented behavior | Operational boundary |
| --- | --- | --- |
| REST | Reused JDK HTTP client, connection timeout, whole-call deadline, bounded response body, same-origin relative paths, redirects disabled | Serialization and interpretation of non-2xx responses belong to the caller; custom authentication and TLS use the client customizer |
| gRPC | Reused managed channel, unary RPC, bounded deadline, inbound message limit, mapped statuses | Streaming APIs are outside this release; call options may shorten the deadline and provide credentials |
| MQ | Jakarta JMS text/byte send and bounded synchronous receive, queue or transient topic, configurable body limits | Caller owns the factory and provider connection/send deadlines; receive uses `AUTO_ACKNOWLEDGE` and is not a reliable processing/redelivery consumer |

REST and gRPC own their transport resources and close them with finite shutdown waits. MQ marks the connector closed but leaves the supplied `ConnectionFactory` open. In-flight MQ work follows provider behavior. Use a transactional listener/container for JMS workflows requiring acknowledgement after business processing, redelivery or durable topic subscriptions.

Java 21 virtual threads can be used by consuming applications for blocking calls. They do not increase downstream capacity; configured concurrency limits remain necessary. Connector concurrency limits constrain active SDK operations, not all transport pools or all processes in a deployment.

## Adding SQS without changing the core

Add `connector-sdk-sqs` and `connector-sdk-sqs-spring-boot-starter`, with their versions in the SDK BOM. The new adapter may depend on AWS SDK for Java 2.x without adding AWS dependencies to core, Spring support, REST, gRPC or MQ. No change to `Connector`, `ConnectorRegistry` or `ConnectorExecutor` is needed.

Follow this extension contract:

1. Implement `Connector` with stable type `sqs` and a validated logical name. Expose SQS-specific typed operations such as send, receive, delete and change visibility. Preserve receipt handles, FIFO group/deduplication fields and message attributes in the API. Hide message bodies and receipt handles from diagnostic `toString()` methods.
2. Bind `SqsConnectorProperties` under `connector.sdk.sqs`, with a `clients` map. Validate region, queue identity, finite deadlines, positive concurrency, body limits and polling settings before registering beans. Keep credentials out of ordinary configuration objects and use an explicit credentials-provider integration or the AWS default provider chain.
3. Add `@EnableSqsConnector` and a marker. Evaluate marker/property selection at `REGISTER_BEAN`; explicit `enabled=false` must win. Reuse the annotation-or-property behavior of the existing adapters.
4. Register `sqsConnector.<name>` definitions through a static registrar bean. Defer actual AWS client construction to the instance supplier, and reuse `ConnectorExecutorFactory.create("sqs", name, maxConcurrency)`. Register a `ConnectorBeanValidator` only when SQS is enabled, with an expectation for each configured name, to validate caller replacements and aliases. Use bounded operation labels such as `send`, `receive`, `delete` and `changeVisibility`.
5. Mark the SQS auto-configuration after `ConnectorRuntimeAutoConfiguration` and before `ConnectorSupportAutoConfiguration`. List it in the new module's `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`. This ordering is declared by the new adapter; the existing support code needs no protocol switch or new class reference.
6. Define resource ownership explicitly. Close SDK-created AWS clients; leave caller-supplied clients open unless ownership was explicitly transferred. Make connector close idempotent and reject later operations with `CLOSED`.
7. Map safe AWS error categories to `ConnectorErrorCode`, retaining approved service error codes through a dedicated exception if needed. Redact diagnostic causes before forwarding them to observations. Treat receipt handles, credentials, payloads and raw provider messages as sensitive.
8. Add context tests for disabled behavior, annotation/property enablement, explicit false, multiple named clients, user overrides and coexistence with current adapters. Add meaningful tests for deadlines, saturation, error redaction, acknowledgement semantics and ownership. Qualify IAM, real endpoint/TLS behavior and throttling in an AWS staging environment before production deployment.

The SQS adapter must preserve delivery semantics rather than treating receive as acknowledgement. Standard queues can deliver duplicates and messages out of order, so consuming applications need idempotent processing. Delete a message only after processing succeeds, and expose visibility renewal for long work. These requirements follow the [SQS standard queue contract](https://docs.aws.amazon.com/en_gb/AWSSimpleQueueService/latest/SQSDeveloperGuide/standard-queues.html) and [visibility timeout behavior](https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-visibility-timeout.html).

Set the HTTP request timeout above the configured long-poll wait, with a bounded margin; SQS long polling supports waits up to 20 seconds. Keep total API call and attempt deadlines explicit. AWS clients retry by default, so configure a deliberate retry strategy rather than introducing an unnoticed second retry layer. See [SQS polling behavior](https://docs.aws.amazon.com/en_gb/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-short-and-long-polling.html), [AWS Java timeouts](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/timeouts.html) and [AWS Java retry behavior](https://docs.aws.amazon.com/sdk-for-java/latest/developer-guide/retry-strategy.html).

## Release qualification

This architecture provides production-oriented controls and testable extension points. Production qualification still depends on the deployed transport providers, authentication, certificates, network conditions, load profile and application delivery requirements. Validate those conditions and the checks in [production.md](production.md) before treating a release as ready for a specific environment.

Future capabilities should be added as explicit APIs with matching tests: reliable background consumers, streaming RPC, asynchronous transport calls, health/readiness probes, circuit breakers and policy-driven retries are separate features. An asynchronous adapter needs an executor that holds its permit until the returned stage completes; wrapping only stage creation with the synchronous `execute` method would release the permit too early.
