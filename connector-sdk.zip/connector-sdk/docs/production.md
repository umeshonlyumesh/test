# Deployment qualification and release

The project supplies concrete transport implementations and automated verification. Release acceptance also depends on the caller’s endpoints, broker, identity infrastructure and operational requirements. This is version `0.1.0-SNAPSHOT`; the default scope is REST with authentication/mTLS, JMS for IBM MQ and ActiveMQ, native RabbitMQ, and binary Redis operations. gRPC is deferred behind an optional Maven profile.

## Operational contract

| Area | SDK behavior | Calling application responsibility |
| --- | --- | --- |
| Activation | Annotation or enabled flag, explicit false kill switch, startup validation | Include only needed starters; define unique configured names |
| Capacity | Per-client fail-fast concurrency cap | Set caps from measured throughput and latency; handle SATURATED |
| Deadlines | REST token/body budget; positive JMS/Rabbit receive wait; bounded Rabbit confirm wait | Set total business budget; configure broker connection/send and Redis connect/command timeouts |
| Authentication | REST mTLS SSL bundles, Basic, Bearer/JWT, client credentials and custom providers; caller MQ/Redis factories | Refresh credentials, least privilege, trust stores and certificate rotation; recreate REST clients for bundle changes |
| Payloads | Bounded REST bytes, inbound gRPC message bytes, JMS text/byte limits | Validate business schemas; outbound request limits; broker-level size limits |
| Errors | Common error codes and redacted transport cause details | Classify business HTTP statuses; map codes to service response policies |
| Retries | No SDK retry loop; gRPC policy retries disabled | Decide idempotency, retry budget, backoff/jitter and reconciliation |
| Delivery | HTTP responses, JMS send semantics, Rabbit correlated confirms/returns, atomic Redis scalar commands | Outbox, deduplication, redelivery, uncertain writes and dead-letter policy where needed |
| Lifecycle | HTTP/channel bounded graceful shutdown; MQ marks closed | Close caller-owned factories/executors and coordinate inflight app work |
| Telemetry | Micrometer observations, bounded logical labels, no payload logging | Add registry/exporter, dashboards, alerts and sampling policy |

The default JMS receive path uses AUTO_ACKNOWLEDGE outside an existing caller-managed transaction. A message can be acknowledged before business processing or decoding finishes. For guaranteed processing, use a provider-appropriate transactional listener or a distinct consumer capability with explicit acknowledgement. Transient topic subscribers do not retain earlier messages. JMS send/receive can participate in an existing compatible Spring/JTA transaction; this SDK does not start one.

## Tests for the actual deployment

Run real endpoint tests in an isolated environment with the application’s chosen client libraries. For IBM MQ, use the exact Jakarta-compatible client, broker version, TLS configuration and failover setup that production will use. Confirm provider behavior under broker restart, network partition, authentication failure, expired certificate and send outcome ambiguity. Artemis unit integration is evidence for portable JMS behavior, not certification of an IBM MQ installation.

Measure p50/p95/p99 latency, concurrency saturation and memory use at normal and overload traffic. REST response bounds apply to SDK accumulation, not arbitrary remote headers or outbound payload memory; broker/client layers may already buffer inbound messages and Redis values. Bound these in transport/provider infrastructure as well. Include stalled HTTP/token bodies, concurrent credential refresh, expired certificates, large payloads, provider connect/send hangs, Rabbit nack/returns, Redis uncertain increments, pool exhaustion and shutdown during calls.

Choose circuit breakers and retry rules at the business capability boundary. A REST 500 or a timed-out send can leave the remote operation committed. An SDK error is not proof that no side effect occurred. Add an idempotency key, transactional outbox or reconciliation process where duplicate actions matter. Do not retry all exceptions indiscriminately.

Keep secrets in your approved credential provider rather than checked-in YAML. REST customizers should retain platform hostname/certificate verification. gRPC customizers should use approved roots and credentials. Pin trust and network egress policy where needed; same-origin path checks do not prevent an application-configured host from resolving to an unintended address. Application-provided customizers and connector implementations are trusted extension code and can alter transport security behavior.

Validate Actuator metrics and tracing in the caller with real exporters. The SDK’s `connector.invocation` observation is infrastructure, not a preconfigured monitoring platform. Registry discovery is local and does not probe remote health. Startup success checks configuration and resources, not remote service reachability. Decide which dependencies should affect readiness; avoid making every remote dependency a liveness requirement.

## Publishing

Before a stable release, assign organization coordinates and artifact licensing, document support and compatibility policy, run the CI matrix, review dependencies/security advisories, and configure your artifact repository and signing credentials outside source control. `-Prelease` produces source/Javadoc jars. There is no configured publishing destination and no artifacts are published automatically.

Use semantic versioning for public capability APIs and configuration keys. Keep provider APIs isolated in their module so adding SQS does not force AWS dependencies into REST consumers. Maintain binary compatibility checks and a consumer compilation suite when you establish a stable release baseline. Native-image/AOT compatibility and live configuration reload are not qualified in this version.
