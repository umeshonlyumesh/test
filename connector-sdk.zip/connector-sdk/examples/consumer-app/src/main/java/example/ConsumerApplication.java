package example;

import io.github.connectorsdk.rest.EnableRestConnector;
import io.github.connectorsdk.rest.RestConnector;
import io.github.connectorsdk.rest.RestRequest;
import io.github.connectorsdk.rest.RestResponse;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;

@SpringBootApplication
@EnableRestConnector
public class ConsumerApplication {
    public static void main(String[] args) { SpringApplication.run(ConsumerApplication.class, args); }

    @Service
    public static class CatalogClient {
        private final RestConnector catalog;
        public CatalogClient(@Qualifier("restConnector.catalog") RestConnector catalog) { this.catalog = catalog; }
        public RestResponse getProduct(String productId) {
            if (!productId.matches("[a-zA-Z0-9_-]+")) { throw new IllegalArgumentException("Invalid product identifier"); }
            return catalog.exchange(RestRequest.get("products/" + productId));
        }
    }
}
