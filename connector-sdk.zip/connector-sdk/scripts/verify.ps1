param([switch]$Offline, [switch]$UseTcpSelectorFallback)
$ErrorActionPreference = 'Stop'
$sdkProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$sdkOldOptions = $env:JAVA_TOOL_OPTIONS
Push-Location -LiteralPath $sdkProjectRoot
try {
    if ($UseTcpSelectorFallback) {
        # A missing socket directory makes the Windows JDK use its internal TCP pipe fallback.
        $sdkSocketPath = Join-Path $sdkProjectRoot '.build\nio-tcp-only'
        $env:JAVA_TOOL_OPTIONS = ($sdkOldOptions + ' "-Djdk.net.unixdomain.tmpdir=' + $sdkSocketPath + '"').Trim()
    }
    $sdkMavenArguments = @('-B', '-ntp', 'clean', 'verify')
    if ($Offline) { $sdkMavenArguments += '-o' }
    & '.\mvnw.cmd' @sdkMavenArguments
    $sdkExitCode = $LASTEXITCODE
} finally {
    $env:JAVA_TOOL_OPTIONS = $sdkOldOptions
    Pop-Location
}
exit $sdkExitCode
