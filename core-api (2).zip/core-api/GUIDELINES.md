# Project Guidelines - Trusit Core API Architecture

## 1. Executive Summary & Objective
This project implements a high-performance, enterprise-grade Core API that orchestrates multiple independent SDKs. The primary goal is to support **parallel development** across distributed teams by enforcing a **Decoupled Distributed Repository Pattern**.

### Core Philosophy:
- **Component Isolation:** Each SDK is an independent project with its own versioning and lifecycle.
- **Contract-First:** All communication is governed by the Abstraction Layer (SPI).
- **Scalability:** Optimized for synchronous, blocking operations using Java 21 Virtual Threads.
- **Standardization:** Shared infrastructure ensures consistent security (mTLS), logging, and error handling.

---

## 2. Technical Standards

### 2.1 Core Technology Stack
- **Language:** Java 21 (LTS) - Utilizing Records, Sealed Classes, and Pattern Matching.
- **Framework:** Spring Boot 4.0.5 (Jakarta EE 10+).
- **HTTP Client:** Spring `RestClient` with `JdkClientHttpRequestFactory`.
- **Build System:** Apache Maven 3.9.x.

### 4.2 Architectural Constraints
- **Zero-Field Injection:** Strictly use **Constructor Injection** to ensure bean immutability and testability.
- **Statelessness:** SDKs must remain stateless. Request-scoped data belongs in the `StandardRequest` context.
- **Thread Model:** Virtual Threads must be enabled via `spring.threads.virtual.enabled=true`.
- **mTLS Enforcement:** All downstream calls must use the `RestClientFactory` for unified certificate handling.

---

## 3. SDK Implementation Workflow (Developer Guide)

To onboard a new SDK (e.g., `trusit-sdk-kyc`):

### 1. Project Initialization
Create a new folder/repository and configure the `pom.xml`:
```xml
<parent>
    <groupId>com.trusit.sdk</groupId>
    <artifactId>trusit-sdk-parent</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</parent>
<artifactId>trusit-sdk-kyc</artifactId>
```

### 2. Implementation Steps
1.  **Define Request/Response:** Create DTOs in `com.trusit.sdk.kyc.model`.
2.  **Define Properties:** Create `KycSdkProperties` with `@ConfigurationProperties(prefix = "sdk.kyc")`.
3.  **Implement Handler:** Create `KycSdkHandler` implementing `SdkHandler`.
    ```java
    @Component
    public class KycSdkHandler implements SdkHandler {
        @Override
        public boolean supports(String op, String subOp) {
            return "KYC".equalsIgnoreCase(op);
        }
        @Override
        public StandardResponse handle(StandardRequest request) { ... }
    }
    ```
4.  **Enable Auto-Configuration:**
    - Create `KycSdkAutoConfiguration`.
    - Register in `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`.

### 3. Orchestrator Integration
Add the new SDK dependency to `trusit-orchestrator/pom.xml`. The `SdkRegistry` will automatically discover the new handler.

---

## 4. Communication & Data Flow

### 4.1 Request Normalization
1.  `CoreApiController` receives raw JSON.
2.  Data is mapped to a `StandardRequest` (Generic payload + Metadata).
3.  `OrchestrationService` queries the `SdkRegistry`.

### 4.2 Strategy Discovery
The `SdkRegistry` iterates through all beans implementing `SdkHandler`. The first bean returning `true` for `supports(op, subOp)` is selected. **Ambiguity is an error.**

### 4.3 Response Standardization
All SDKs must return a `StandardResponse`, ensuring the Orchestrator maintains a consistent API contract with external consumers.

---

## 5. Configuration & Environment Management

SDK properties are managed in the Orchestrator's `application.properties` but scoped via prefixes.

```properties
# --- KYC SDK (New Example) ---
sdk.kyc.base-url=https://kyc-provider.com/api
sdk.kyc.connect-timeout=3000
sdk.kyc.read-timeout=5000
sdk.kyc.mtls.enabled=true
sdk.kyc.mtls.key-store-path=certs/kyc-client.p12
sdk.kyc.mtls.key-store-password=${KYC_KEYSTORE_PASSWORD}
```

---

## 6. Connectivity & Security (mTLS)

### 6.1 The RestClientFactory
Every SDK **must** use the factory in `trusit-common`. This ensures:
- Consistent TLS 1.3 handshakes.
- Unified timeout behavior.
- Automatic correlation ID propagation.

### 6.2 Error Handling & Resilience
- **SDK Level:** Catch all exceptions; map to `StandardResponse` with a clear `errorCode`.
- **Orchestrator Level:** Global exception handler manages timeouts and circuit breaker fallbacks.

---

## 7. Observability & Logging

- **MDC Propagation:** The `correlationId` must be logged in every downstream request.
- **Log Masking:** Use `LogMasker` for PII (e.g., SSN, Email).
- **AOP Performance Metrics:** `LoggingAspect` provides automatic timing for every SDK execution.

---

## 8. Quality Gate (Definition of Done)

1.  **Independence:** No direct dependencies between `trusit-sdk-a` and `trusit-sdk-b`.
2.  **Coverage:** 80% Unit Test coverage (JaCoCo).
3.  **Clean Code:** Zero field-level `@Autowired` warnings.
4.  **Auto-Discovery:** SDK correctly registered via Spring Boot Auto-Configuration.
5.  **Auditability:** Every log line includes a `correlationId`.

---

## 9. Anti-Patterns (The "Wall of Shame")
- ❌ **Aggregator POMs:** Never add `<modules>` to the root.
- ❌ **Hardcoded If/Else:** Never route requests via manual conditional logic.
- ❌ **Shared States:** SDKs must be stateless singleton beans.
- ❌ **SPI Leakage:** Internal SDK models must never leak into the SPI layer.
