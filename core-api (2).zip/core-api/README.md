# Trusit Core API Orchestrator

## Project Overview
This project implements a Core API that orchestrates requests and delegates to multiple SDK modules (Fraud, Deposit, Enrichment, Alert). It follows an SPI-based architecture for extensibility and loose coupling.

## Module Structure
- `trusit-core-api-parent`: Maven aggregator.
- `trusit-common`: Shared models (`StandardRequest`, `StandardResponse`).
- `trusit-sdk-spi`: Shared interface (`SdkHandler`) for SDK implementations.
- `trusit-orchestrator`: Spring Boot application, REST API, orchestration logic, and global exception handling.
- `trusit-sdk-fraud`: Fraud detection implementation.
- `trusit-sdk-deposit`: Deposit processing implementation.
- `trusit-sdk-enrichment`: Data enrichment implementation.
- `trusit-sdk-alert`: Alert notification implementation.

## Architecture & Request Flow
1. Client sends a request to `POST /api/v1/process`.
2. `CoreApiController` receives and validates the `StandardRequest`.
3. `OrchestrationService` extracts/generates a `correlationId`.
4. `SdkRegistry` finds the appropriate `SdkHandler` based on the `operationType` and `subOperationType`.
5. The resolved `SdkHandler` (e.g., `FraudSdkHandler`) processes the request.
    - Each SDK maps the generic `StandardRequest` to its own internal request model (e.g., `FraudRequest`).
    - The SDK executes its business logic and returns an internal response model (e.g., `FraudResponse`).
    - The SDK maps its internal response back to the `StandardResponse` required by the Core API.
6. `LoggingAspect` records the execution time and masks sensitive data.
7. `StandardResponse` is returned to the client.

## SDK Model Isolation
To ensure loose coupling, every SDK defines its own request and response models within its own package (e.g., `com.trusit.sdk.fraud.model`). This allows SDKs to evolve their internal data structures without affecting the `trusit-orchestrator` or other SDKs.

## How to Build and Run Locally

### Prerequisites
- **Java 21**: The project is built using Java 21 features.
  - **Virtual Threads**: Enabled for high-throughput concurrency.
  - **Records**: Used for immutable data models.
  - **Pattern Matching**: Utilized in `switch` and `instanceof` for clean logic.
  - **Sequenced Collections**: Used for deterministic handler ordering.
- **Maven 3.9+**: For building the multi-module project.
- **Git**: To clone the repository.

### Steps to Build and Run

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd core-api
   ```

2. **Build the entire project**:
   This command compiles all modules, installs them to the local Maven repository, and skips tests for a faster first build.
   ```bash
   ./mvnw clean install -DskipTests
   ```

3. **Run the Core API application**:
   Navigate to the `trusit-orchestrator` module or run it from the root using the project list (`-pl`) flag:
   ```bash
   ./mvnw -pl trusit-orchestrator spring-boot:run
   ```
   The application will start on port `8080` by default.

4. **Verify the application is running**:
   You can check the health or perform a test request.
   ```bash
   curl -X POST http://localhost:8080/api/v1/process \
        -H "Content-Type: application/json" \
        -d '{"requestId": "REQ-123", "operationType": "FRAUD", "payload": {"amount": 1000}}'
   ```

### Running Tests
To run unit tests for all modules:
```bash
./mvnw test
```

## How to Add a New SDK
1. Create a new Maven module (e.g., `alert-sdk`).
2. Add dependency to the `spi` and `common` modules.
3. Implement the `SdkHandler` interface.
4. Add the new module to the `parent` pom.xml.
5. Add the new SDK as a dependency to the `core-api` module.

## Using SDKs as Reusable Dependencies
The SDK modules are now published as Spring Boot auto-configurations. Any team can consume them by adding the dependency; the `SdkHandler` beans are registered automatically via Spring Boot’s auto-configuration.

### 1) Add Dependency
Add the SDK you want to use to your project’s `pom.xml`:

```xml
<dependency>
  <groupId>com.trusit.core.api</groupId>
  <artifactId>trusit-sdk-fraud</artifactId>
  <version>0.0.1-SNAPSHOT</version>
</dependency>
```

Similarly for other SDKs:

```xml
<dependency>
  <groupId>com.trusit.core.api</groupId>
  <artifactId>trusit-sdk-deposit</artifactId>
  <version>0.0.1-SNAPSHOT</version>
</dependency>
<dependency>
  <groupId>com.trusit.core.api</groupId>
  <artifactId>trusit-sdk-enrichment</artifactId>
  <version>0.0.1-SNAPSHOT</version>
</dependency>
```

No component scanning or manual bean registration is required. The modules declare `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports` and will auto-register their `SdkHandler` implementations when on the classpath.

### 2) Configuration (where applicable)
Some SDKs provide configuration properties. For example, `fraud-sdk` exposes properties under the `sdk.fraud.*` prefix:

```properties
sdk.fraud.baseUrl=http://fraud-service:8081
sdk.fraud.connectTimeout=3000
sdk.fraud.readTimeout=3000
```

### 3) Overriding Defaults
All auto-configured beans are guarded with `@ConditionalOnMissingBean`, so you can override them by defining a bean of the same type in your application context.

- Example: If you need a custom `FraudSdkHandler`, declare your own `@Bean FraudSdkHandler` and it will replace the default one from the SDK.

### 4) Using the Handlers
Once on the classpath, `SdkHandler` beans will be available in the Spring context. You can:
- Inject them directly (e.g., `List<SdkHandler>`), or
- Use the provided `SdkRegistry` pattern (as done in this project) to resolve the appropriate handler by `operation`/`subOperation`.

## Configuration Example
SDK properties can be configured in `application.properties`:
```properties
sdk.fraud.baseUrl=http://fraud-service:8081
sdk.fraud.connectTimeout=3000
sdk.fraud.readTimeout=3000
```
