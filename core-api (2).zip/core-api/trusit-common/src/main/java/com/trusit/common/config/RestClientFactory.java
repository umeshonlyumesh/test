package com.trusit.common.config;

import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.time.Duration;

public class RestClientFactory {

    public static RestClient createMtlsEnabledClient(String baseUrl, MtlsProperties mP, int connectTimeout, int readTimeout) {
        RestClient.Builder builder = RestClient.builder()
                .baseUrl(baseUrl);

        if (mP != null && mP.isEnabled()) {
            builder.requestFactory(createMtlsRequestFactory(mP, connectTimeout, readTimeout));
        } else {
            JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory();
            factory.setReadTimeout(Duration.ofMillis(readTimeout));
            builder.requestFactory(factory);
        }

        return builder.build();
    }

    private static ClientHttpRequestFactory createMtlsRequestFactory(MtlsProperties mP, int connectTimeout, int readTimeout) {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");

            // KeyStore for mTLS (Client Certificate)
            KeyStore keyStore = KeyStore.getInstance(mP.getKeyStoreType());
            try (InputStream is = Files.newInputStream(Paths.get(mP.getKeyStorePath()))) {
                keyStore.load(is, mP.getKeyStorePassword().toCharArray());
            }

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, mP.getKeyPassword() != null ? mP.getKeyPassword().toCharArray() : mP.getKeyStorePassword().toCharArray());

            // TrustStore (Server CA Certificate)
            KeyStore trustStore = KeyStore.getInstance(mP.getTrustStoreType());
            try (InputStream is = Files.newInputStream(Paths.get(mP.getTrustStorePath()))) {
                trustStore.load(is, mP.getTrustStorePassword().toCharArray());
            }

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);

            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            java.net.http.HttpClient httpClient = java.net.http.HttpClient.newBuilder()
                    .sslContext(sslContext)
                    .connectTimeout(Duration.ofMillis(connectTimeout))
                    .build();

            JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpClient);
            factory.setReadTimeout(Duration.ofMillis(readTimeout));
            return factory;

        } catch (Exception e) {
            throw new RuntimeException("Failed to create mTLS RestClient", e);
        }
    }

    public static class MtlsProperties {
        private boolean enabled;
        private String keyStorePath;
        private String keyStorePassword;
        private String keyPassword;
        private String keyStoreType = "PKCS12";
        private String trustStorePath;
        private String trustStorePassword;
        private String trustStoreType = "PKCS12";

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public String getKeyStorePath() { return keyStorePath; }
        public void setKeyStorePath(String keyStorePath) { this.keyStorePath = keyStorePath; }
        public String getKeyStorePassword() { return keyStorePassword; }
        public void setKeyStorePassword(String keyStorePassword) { this.keyStorePassword = keyStorePassword; }
        public String getKeyPassword() { return keyPassword; }
        public void setKeyPassword(String keyPassword) { this.keyPassword = keyPassword; }
        public String getKeyStoreType() { return keyStoreType; }
        public void setKeyStoreType(String keyStoreType) { this.keyStoreType = keyStoreType; }
        public String getTrustStorePath() { return trustStorePath; }
        public void setTrustStorePath(String trustStorePath) { this.trustStorePath = trustStorePath; }
        public String getTrustStorePassword() { return trustStorePassword; }
        public void setTrustStorePassword(String trustStorePassword) { this.trustStorePassword = trustStorePassword; }
        public String getTrustStoreType() { return trustStoreType; }
        public void setTrustStoreType(String trustStoreType) { this.trustStoreType = trustStoreType; }
    }
}
