package com.trusit.common.model;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.trusit.common.util.LogMasker;
import jakarta.validation.constraints.NotBlank;
import java.util.HashMap;
import java.util.Map;

public record StandardRequest(
        String requestId,
        @NotBlank(message = "OperationType is mandatory")
        String operationType,
        String subOperationType,
        String channel,
        String userId,
        String timestamp,
        Map<String, Object> additionalData
) {
    public StandardRequest(
            @JsonProperty("requestId") String requestId,
            @JsonProperty("operationType") String operationType,
            @JsonProperty("subOperationType") String subOperationType,
            @JsonProperty("channel") String channel,
            @JsonProperty("userId") String userId,
            @JsonProperty("timestamp") String timestamp,
            @JsonProperty("additionalData") Map<String, Object> additionalData) {
        this.requestId = requestId;
        this.operationType = operationType;
        this.subOperationType = subOperationType;
        this.channel = channel;
        this.userId = userId;
        this.timestamp = timestamp;
        this.additionalData = additionalData != null ? additionalData : new java.util.HashMap<>();
    }

    public static StandardRequest fromJson(Map<String, Object> allData) {
        if (allData == null) return new StandardRequest(null, null, null, null, null, null, new java.util.HashMap<>());
        
        java.util.Map<String, Object> copy = new java.util.HashMap<>(allData);
        String requestId = (String) copy.remove("requestId");
        String operationType = (String) copy.remove("operationType");
        String subOperationType = (String) copy.remove("subOperationType");
        String channel = (String) copy.remove("channel");
        String userId = (String) copy.remove("userId");
        String timestamp = (String) copy.remove("timestamp");
        return new StandardRequest(requestId, operationType, subOperationType, channel, userId, timestamp, copy);
    }

    public static StandardRequestBuilder builder() {
        return new StandardRequestBuilder();
    }

    public Object getPayload(String key) {
        return additionalData != null ? additionalData.get(key) : null;
    }

    @Override
    public String toString() {
        return "StandardRequest[" +
                "requestId=" + requestId +
                ", operationType=" + operationType +
                ", subOperationType=" + subOperationType +
                ", channel=" + channel +
                ", userId=" + userId +
                ", timestamp=" + timestamp +
                ", additionalData=" + LogMasker.maskMap(additionalData) +
                ']';
    }

    public static class StandardRequestBuilder {
        private String requestId;
        private String operationType;
        private String subOperationType;
        private String channel;
        private String userId;
        private String timestamp;
        private Map<String, Object> additionalData = new HashMap<>();

        StandardRequestBuilder() {}

        public StandardRequestBuilder requestId(String requestId) { this.requestId = requestId; return this; }
        public StandardRequestBuilder operationType(String operationType) { this.operationType = operationType; return this; }
        public StandardRequestBuilder subOperationType(String subOperationType) { this.subOperationType = subOperationType; return this; }
        public StandardRequestBuilder channel(String channel) { this.channel = channel; return this; }
        public StandardRequestBuilder userId(String userId) { this.userId = userId; return this; }
        public StandardRequestBuilder timestamp(String timestamp) { this.timestamp = timestamp; return this; }
        public StandardRequestBuilder additionalData(Map<String, Object> additionalData) { this.additionalData = additionalData; return this; }

        public StandardRequest build() {
            return new StandardRequest(requestId, operationType, subOperationType, channel, userId, timestamp, additionalData);
        }
    }
}
