package com.trusit.common.model;

import java.time.LocalDateTime;

public record StandardResponse<T>(
        String status,
        String message,
        T data,
        String correlationId,
        LocalDateTime timestamp
) {
    public StandardResponse {
        if (timestamp == null) {
            timestamp = LocalDateTime.now();
        }
    }

    public static <T> StandardResponseBuilder<T> builder() {
        return new StandardResponseBuilder<>();
    }

    public static class StandardResponseBuilder<T> {
        private String status;
        private String message;
        private T data;
        private String correlationId;
        private LocalDateTime timestamp;

        StandardResponseBuilder() {}

        public StandardResponseBuilder<T> status(String status) { this.status = status; return this; }
        public StandardResponseBuilder<T> message(String message) { this.message = message; return this; }
        public StandardResponseBuilder<T> data(T data) { this.data = data; return this; }
        public StandardResponseBuilder<T> correlationId(String correlationId) { this.correlationId = correlationId; return this; }
        public StandardResponseBuilder<T> timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }

        public StandardResponse<T> build() {
            return new StandardResponse<>(status, message, data, correlationId, timestamp);
        }
    }
}
