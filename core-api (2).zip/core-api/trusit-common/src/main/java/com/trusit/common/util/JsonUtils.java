package com.trusit.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class JsonUtils {
    private static final Logger log = LoggerFactory.getLogger(JsonUtils.class);
    private static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule())
            .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

    public static String toJson(Object object) {
        if (object == null) return "null";
        try {
            return mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error("Error converting object to JSON: {}", e.getMessage());
            return "Error: " + e.getMessage();
        }
    }

    public static String toMaskedJson(Object object) {
        if (object == null) return "null";
        try {
            // First convert to Map to apply masking easily if it's not already a map
            // For complex objects, we might need a more sophisticated approach, 
            // but for our DTOs, this should work.
            Map<String, Object> map;
            if (object instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> tempMap = (Map<String, Object>) object;
                map = tempMap;
            } else {
                map = mapper.convertValue(object, HashMap.class);
            }
            
            Map<String, Object> maskedMap = LogMasker.maskMap(map);
            return toJson(maskedMap);
        } catch (Exception e) {
            log.error("Error converting object to masked JSON: {}", e.getMessage());
            return "Error: " + e.getMessage();
        }
    }
}
