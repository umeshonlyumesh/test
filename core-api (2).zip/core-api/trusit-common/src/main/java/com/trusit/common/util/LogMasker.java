package com.trusit.common.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class LogMasker {
    private static final Set<String> SENSITIVE_FIELDS = Set.of(
            "accountNumber", "ssn", "phone", "email", "recipient", "routingNumber", "customerId"
    );

    public static String sanitize(String value) {
        if (value == null) return null;
        return value.replaceAll("[\r\n]", "_");
    }

    public static String mask(String value) {
        if (value == null || value.length() <= 4) {
            return "****";
        }
        return value.substring(0, 2) + "****" + value.substring(value.length() - 2);
    }

    public static Map<String, Object> maskMap(Map<String, Object> map) {
        if (map == null) return null;
        Map<String, Object> maskedMap = new HashMap<>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (SENSITIVE_FIELDS.contains(key) && value instanceof String) {
                maskedMap.put(key, mask((String) value));
            } else if (value instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> nestedMap = (Map<String, Object>) value;
                maskedMap.put(key, maskMap(nestedMap));
            } else {
                maskedMap.put(key, value);
            }
        }
        return maskedMap;
    }
}
