# MDC Context (Orchestrator)

This MDC setup is orchestrator-only and used for logging correlation.

Detailed usage examples:
- `MDC_USAGE_GUIDE.md`

## Request ID rule

Request ID is taken from the core request (`requestId`) and is not generated.
If `requestId` is null, MDC key is removed.
If `requestId` is blank/empty, MDC key is removed.

## Core flow

- `MdcFilter` clears MDC at ingress.
- `MdcFilter` sets MDC from `/api/v1/process` request body.
- `LoggingAspect` performs logging only.
- `GlobalExceptionHandler` reads request ID from `MdcContext`.

## Async

`MdcAsyncExecutionConfig` configures task decorator propagation for `@Async`.

## Listener entry points (Kafka/MQ/JMS/Rabbit)

Preferred when you have `StandardRequest`:

- `MdcListenerSupport.runListenerWithCoreRequest(...)`
- `MdcListenerSupport.callListenerWithCoreRequest(...)`
