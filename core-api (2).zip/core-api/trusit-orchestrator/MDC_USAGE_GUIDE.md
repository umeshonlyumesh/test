# MDC Usage Guide (Orchestrator)

This guide shows how to use orchestrator MDC utilities for sync, async, listeners, and error handling.

## Rules

- MDC is used for logging correlation.
- `requestId` comes from core request/message data.
- No request-id generation is done by `MdcContext`.
- If `requestId` is null, MDC key is removed.
- If `requestId` is empty, empty value is preserved.

## 1. Sync flow (Core API request)

`MdcFilter` clears MDC at request start.
For `POST /api/v1/process` JSON request, `MdcFilter` extracts:
- `requestId`
- `operationType`
and sets MDC before controller/aspect/service logs.

```java
if (isCoreProcessJsonRequest(request)) {
    var wrappedRequest = new ReReadableRequest(request);
    MdcContext.putCoreRequestContext(toCoreRequest(wrappedRequest.body()));
    filterChain.doFilter(wrappedRequest, response);
}
```

## 2. Async flow (`@Async` / Executor)

`MdcAsyncExecutionConfig` already sets task decorator:

```java
executor.setTaskDecorator(MdcContext.taskDecorator());
```

For manual executor usage:

```java
ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
executor.setTaskDecorator(MdcContext.taskDecorator());
executor.initialize();
executor.execute(() -> service.run());
```

## 3. Listener flow (Kafka/MQ/JMS/Rabbit)

### 3.1 If listener payload is `StandardRequest` (preferred)

```java
@KafkaListener(topics = "core-topic")
public void consume(StandardRequest payload) {
    MdcListenerSupport.runListenerWithCoreRequest(payload, () -> {
        log.info("Consumed message");
        handler.process(payload);
    });
}
```

### 3.2 If request-id is in headers map

```java
public void onMessage(Map<String, Object> headers, String body) {
    MdcListenerSupport.runListenerWithMessageHeaders(headers, "kafka-consume", () -> {
        log.info("Consumed with header-based requestId");
        process(body);
    });
}
```

### 3.3 If header access is through an API (not map)

```java
public void onMessage(Message message) {
    MdcListenerSupport.runListenerWithHeaderReader(
            name -> message.getHeader(name),
            "mq-consume",
            () -> {
                log.info("Consumed with header reader");
                process(message.getPayload());
            }
    );
}
```

## 4. Error handler usage

Read current request-id directly from MDC helper:

```java
@ExceptionHandler(Exception.class)
public ResponseEntity<StandardResponse<Object>> handle(Exception ex) {
    String requestId = MdcContext.currentRequestId();
    log.error("Unhandled exception", ex);
    return ResponseEntity.internalServerError().body(
            StandardResponse.builder()
                    .status("INTERNAL_SERVER_ERROR")
                    .message(ex.getMessage())
                    .correlationId(requestId)
                    .build()
    );
}
```

## 5. HTTP ingress filter

`MdcFilter` does both:
- clears MDC at request start to avoid stale thread-local values
- restores previous context at request end

```java
try (MdcContext.MdcScope ignored = MdcContext.openMdcScope(null, null)) {
    filterChain.doFilter(request, response);
}
```

## 6. Logging pattern

Ensure logger pattern uses:

- `%X{requestId}`
- `%X{operationType}`
