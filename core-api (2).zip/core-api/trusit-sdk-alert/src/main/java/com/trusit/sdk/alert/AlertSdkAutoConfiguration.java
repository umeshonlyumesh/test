package com.trusit.sdk.alert;

import com.trusit.common.config.RestClientFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@AutoConfiguration
@EnableConfigurationProperties(AlertSdkProperties.class)
public class AlertSdkAutoConfiguration {

    @Bean(name = "alertRestClient")
    @ConditionalOnMissingBean(name = "alertRestClient")
    public RestClient alertRestClient(AlertSdkProperties properties) {
        return RestClientFactory.createMtlsEnabledClient(
                properties.getBaseUrl(),
                properties.getMtls(),
                properties.getConnectTimeout(),
                properties.getReadTimeout()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public AlertSdkHandler alertSdkHandler(RestClient alertRestClient) {
        return new AlertSdkHandler(alertRestClient);
    }
}
