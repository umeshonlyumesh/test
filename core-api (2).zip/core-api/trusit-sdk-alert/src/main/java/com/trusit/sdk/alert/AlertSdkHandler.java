package com.trusit.sdk.alert;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.sdk.alert.model.AlertRequest;
import com.trusit.sdk.alert.model.AlertResponse;
import com.trusit.sdk.spi.SdkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClient;

import java.util.Map;
import java.util.UUID;

public class AlertSdkHandler implements SdkHandler {
    private static final Logger log = LoggerFactory.getLogger(AlertSdkHandler.class);
    private final RestClient restClient;

    public AlertSdkHandler(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public boolean supports(String operationType, String subOperationType) {
        return "ALERT".equalsIgnoreCase(operationType);
    }

    @Override
    public StandardResponse<Object> process(StandardRequest request) {
        log.info("Alert SDK processing request");

        @SuppressWarnings("unchecked")
        Map<String, Object> alertData = (Map<String, Object>) request.getPayload("alert");
        AlertRequest alertRequest = new AlertRequest(alertData);

        AlertResponse alertResponse = sendAlert(alertRequest);

        return StandardResponse.builder()
                .status("SUCCESS")
                .message("Alert processed")
                .data(alertResponse)
                .build();
    }

    private AlertResponse sendAlert(AlertRequest request) {
        log.debug("Sending alert: {}", request);
        return new AlertResponse("SENT", "ALT-" + UUID.randomUUID().toString().substring(0, 8));
    }
}
