package com.trusit.sdk.alert;

import com.trusit.common.config.RestClientFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.Objects;

@ConfigurationProperties(prefix = "sdk.alert")
public class AlertSdkProperties {
    private String baseUrl = "http://localhost:8084";
    private int connectTimeout = 5000;
    private int readTimeout = 5000;
    private RestClientFactory.MtlsProperties mtls = new RestClientFactory.MtlsProperties();

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public int getConnectTimeout() { return connectTimeout; }
    public void setConnectTimeout(int connectTimeout) { this.connectTimeout = connectTimeout; }
    public int getReadTimeout() { return readTimeout; }
    public void setReadTimeout(int readTimeout) { this.readTimeout = readTimeout; }
    public RestClientFactory.MtlsProperties getMtls() { return mtls; }
    public void setMtls(RestClientFactory.MtlsProperties mtls) { this.mtls = mtls; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AlertSdkProperties that = (AlertSdkProperties) o;
        return connectTimeout == that.connectTimeout && readTimeout == that.readTimeout && Objects.equals(baseUrl, that.baseUrl) && Objects.equals(mtls, that.mtls);
    }

    @Override
    public int hashCode() {
        return Objects.hash(baseUrl, connectTimeout, readTimeout, mtls);
    }

    @Override
    public String toString() {
        return "AlertSdkProperties{" +
                "baseUrl='" + baseUrl + '\'' +
                ", connectTimeout=" + connectTimeout +
                ", readTimeout=" + readTimeout +
                ", mtls=" + mtls +
                '}';
    }
}
