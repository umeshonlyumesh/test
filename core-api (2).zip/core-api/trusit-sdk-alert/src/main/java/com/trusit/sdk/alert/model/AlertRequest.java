package com.trusit.sdk.alert.model;

import com.trusit.common.util.LogMasker;
import java.util.Map;

public record AlertRequest(
        String alertType,
        String message,
        String channel,
        String recipient
) {
    public AlertRequest(Map<String, Object> data) {
        this(
            data != null ? (String) data.get("alertType") : null,
            data != null ? (String) data.get("message") : null,
            data != null ? (String) data.get("channel") : null,
            data != null ? (String) data.get("recipient") : null
        );
    }

    @Override
    public String toString() {
        return "AlertRequest[" +
                "alertType=" + alertType +
                ", message=" + message +
                ", channel=" + channel +
                ", recipient=" + LogMasker.mask(recipient) +
                ']';
    }
}
