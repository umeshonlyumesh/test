package com.trusit.sdk.alert.model;

public class AlertResponse {
    private String status;
    private String alertId;

    public AlertResponse() {}

    public AlertResponse(String status, String alertId) {
        this.status = status;
        this.alertId = alertId;
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getAlertId() { return alertId; }
    public void setAlertId(String alertId) { this.alertId = alertId; }

    @Override
    public String toString() {
        return "AlertResponse{" + "status='" + status + '\'' + ", alertId='" + alertId + '\'' + '}';
    }
}
