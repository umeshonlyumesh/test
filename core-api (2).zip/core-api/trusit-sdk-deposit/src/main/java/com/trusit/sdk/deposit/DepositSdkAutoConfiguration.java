package com.trusit.sdk.deposit;

import com.trusit.common.config.RestClientFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@AutoConfiguration
@EnableConfigurationProperties(DepositSdkProperties.class)
public class DepositSdkAutoConfiguration {

    @Bean(name = "depositRestClient")
    @ConditionalOnMissingBean(name = "depositRestClient")
    public RestClient depositRestClient(DepositSdkProperties properties) {
        return RestClientFactory.createMtlsEnabledClient(
                properties.getBaseUrl(),
                properties.getMtls(),
                properties.getConnectTimeout(),
                properties.getReadTimeout()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public DepositSdkHandler depositSdkHandler(RestClient depositRestClient) {
        return new DepositSdkHandler(depositRestClient);
    }
}
