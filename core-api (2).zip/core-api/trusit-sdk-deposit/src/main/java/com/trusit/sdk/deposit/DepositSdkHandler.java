package com.trusit.sdk.deposit;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.sdk.deposit.model.DepositRequest;
import com.trusit.sdk.deposit.model.DepositResponse;
import com.trusit.sdk.spi.SdkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClient;

import java.util.Map;

public class DepositSdkHandler implements SdkHandler {
    private static final Logger log = LoggerFactory.getLogger(DepositSdkHandler.class);
    private final RestClient restClient;

    public DepositSdkHandler(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public boolean supports(String operationType, String subOperationType) {
        return "DEPOSIT".equalsIgnoreCase(operationType);
    }

    @Override
    public StandardResponse<Object> process(StandardRequest request) {
        log.info("Deposit SDK processing request");

        @SuppressWarnings("unchecked")
        Map<String, Object> depositData = (Map<String, Object>) request.getPayload("deposit");
        DepositRequest depositRequest = new DepositRequest(depositData);

        DepositResponse depositResponse = initiateDeposit(depositRequest);

        return StandardResponse.builder()
                .status("SUCCESS")
                .message("Deposit request initiated")
                .data(depositResponse)
                .build();
    }

    private DepositResponse initiateDeposit(DepositRequest request) {
        log.debug("Initiating deposit for: {}", request);
        return new DepositResponse("DEP-" + System.currentTimeMillis(), "PENDING");
    }
}
