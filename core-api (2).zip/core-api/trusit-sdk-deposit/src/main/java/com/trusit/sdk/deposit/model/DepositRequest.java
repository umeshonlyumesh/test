package com.trusit.sdk.deposit.model;

import com.trusit.common.util.LogMasker;
import java.util.Map;

public record DepositRequest(
        String accountNumber,
        String routingNumber,
        Double amount,
        String depositType,
        String branchCode
) {
    public DepositRequest(Map<String, Object> data) {
        this(
            data != null ? (String) data.get("accountNumber") : null,
            data != null ? (String) data.get("routingNumber") : null,
            data != null && data.get("amount") instanceof Number n ? n.doubleValue() : null,
            data != null ? (String) data.get("depositType") : null,
            data != null ? (String) data.get("branchCode") : null
        );
    }

    @Override
    public String toString() {
        return "DepositRequest[" +
                "accountNumber=" + LogMasker.mask(accountNumber) +
                ", routingNumber=" + LogMasker.mask(routingNumber) +
                ", amount=" + amount +
                ", depositType=" + depositType +
                ", branchCode=" + branchCode +
                ']';
    }
}
