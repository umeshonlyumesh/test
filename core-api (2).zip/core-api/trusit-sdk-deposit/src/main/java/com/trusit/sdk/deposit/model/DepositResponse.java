package com.trusit.sdk.deposit.model;

public record DepositResponse(String transactionId, String status) {
}
