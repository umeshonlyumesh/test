package com.trusit.sdk.enrichment;

import com.trusit.common.config.RestClientFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@AutoConfiguration
@EnableConfigurationProperties(EnrichmentSdkProperties.class)
public class EnrichmentSdkAutoConfiguration {

    @Bean(name = "enrichmentRestClient")
    @ConditionalOnMissingBean(name = "enrichmentRestClient")
    public RestClient enrichmentRestClient(EnrichmentSdkProperties properties) {
        return RestClientFactory.createMtlsEnabledClient(
                properties.getBaseUrl(),
                properties.getMtls(),
                properties.getConnectTimeout(),
                properties.getReadTimeout()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public EnrichmentSdkHandler enrichmentSdkHandler(RestClient enrichmentRestClient) {
        return new EnrichmentSdkHandler(enrichmentRestClient);
    }
}
