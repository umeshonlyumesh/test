package com.trusit.sdk.enrichment;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.sdk.enrichment.model.EnrichmentRequest;
import com.trusit.sdk.enrichment.model.EnrichmentResponse;
import com.trusit.sdk.spi.SdkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClient;

import java.util.Map;

public class EnrichmentSdkHandler implements SdkHandler {
    private static final Logger log = LoggerFactory.getLogger(EnrichmentSdkHandler.class);
    private final RestClient restClient;

    public EnrichmentSdkHandler(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public boolean supports(String operationType, String subOperationType) {
        return "ENRICHMENT".equalsIgnoreCase(operationType);
    }

    @Override
    public StandardResponse<Object> process(StandardRequest request) {
        log.info("Enrichment SDK processing request");

        @SuppressWarnings("unchecked")
        Map<String, Object> cifData = (Map<String, Object>) request.getPayload("cif");
        EnrichmentRequest enrichmentRequest = new EnrichmentRequest(cifData);

        EnrichmentResponse enrichmentResponse = enrichData(enrichmentRequest);

        return StandardResponse.builder()
                .status("SUCCESS")
                .message("Enrichment completed")
                .data(enrichmentResponse)
                .build();
    }

    private EnrichmentResponse enrichData(EnrichmentRequest request) {
        log.debug("Enriching data for: {}", request);
        return new EnrichmentResponse(System.currentTimeMillis(), "Sample enrichment data");
    }
}
