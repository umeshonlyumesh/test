package com.trusit.sdk.enrichment.model;

import com.trusit.common.util.LogMasker;
import java.util.Map;

public record EnrichmentRequest(
        String customerId,
        String firstName,
        String lastName,
        String email,
        String phone
) {
    public EnrichmentRequest(Map<String, Object> data) {
        this(
            data != null ? (String) data.get("customerId") : null,
            data != null ? (String) data.get("firstName") : null,
            data != null ? (String) data.get("lastName") : null,
            data != null ? (String) data.get("email") : null,
            data != null ? (String) data.get("phone") : null
        );
    }

    @Override
    public String toString() {
        return "EnrichmentRequest[" +
                "customerId=" + LogMasker.mask(customerId) +
                ", firstName=" + firstName +
                ", lastName=" + lastName +
                ", email=" + LogMasker.mask(email) +
                ", phone=" + LogMasker.mask(phone) +
                ']';
    }
}
