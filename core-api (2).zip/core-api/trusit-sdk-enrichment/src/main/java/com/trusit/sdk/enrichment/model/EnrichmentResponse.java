package com.trusit.sdk.enrichment.model;

public record EnrichmentResponse(long enrichedAt, String extendedData) {
}
