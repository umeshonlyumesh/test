package com.trusit.sdk.fraud;

import com.trusit.common.config.RestClientFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClient;

@AutoConfiguration
@EnableConfigurationProperties(FraudSdkProperties.class)
public class FraudSdkAutoConfiguration {

    @Bean(name = "fraudRestClient")
    @ConditionalOnMissingBean(name = "fraudRestClient")
    public RestClient fraudRestClient(FraudSdkProperties properties) {
        return RestClientFactory.createMtlsEnabledClient(
                properties.getBaseUrl(),
                properties.getMtls(),
                properties.getConnectTimeout(),
                properties.getReadTimeout()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public FraudSdkHandler fraudSdkHandler(RestClient fraudRestClient) {
        return new FraudSdkHandler(fraudRestClient);
    }
}
