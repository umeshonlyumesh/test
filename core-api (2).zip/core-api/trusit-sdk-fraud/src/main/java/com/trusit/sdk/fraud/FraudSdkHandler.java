package com.trusit.sdk.fraud;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.sdk.fraud.model.FraudRequest;
import com.trusit.sdk.fraud.model.FraudResponse;
import com.trusit.sdk.spi.SdkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestClient;

import java.util.Map;

public class FraudSdkHandler implements SdkHandler {
    private static final Logger log = LoggerFactory.getLogger(FraudSdkHandler.class);
    private final RestClient restClient;

    public FraudSdkHandler(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public boolean supports(String operationType, String subOperationType) {
        return "FRAUD".equalsIgnoreCase(operationType);
    }

    @Override
    public StandardResponse<Object> process(StandardRequest request) {
        log.info("Fraud SDK processing request");

        // Use Record Pattern (though StandardRequest is simple, we could extract fields if needed)
        // For now, let's just use the Record's components directly for mapping
        @SuppressWarnings("unchecked")
        Map<String, Object> fraudData = (Map<String, Object>) request.getPayload("fraud");
        FraudRequest fraudRequest = new FraudRequest(fraudData);
        
        // Process using SDK internal logic/models
        FraudResponse fraudResponse = performFraudCheck(fraudRequest);

        // Map back to StandardResponse for Core API
        return StandardResponse.builder()
                .status("SUCCESS")
                .message("Fraud check completed")
                .data(fraudResponse)
                .build();
    }

    private FraudResponse performFraudCheck(FraudRequest request) {
        log.debug("Performing fraud check for: {}", request);
        // Mock business logic
        return new FraudResponse(0.15, "CLEAN");
    }
}
