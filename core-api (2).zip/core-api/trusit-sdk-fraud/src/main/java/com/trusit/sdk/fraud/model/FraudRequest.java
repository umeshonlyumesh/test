package com.trusit.sdk.fraud.model;

import com.trusit.common.util.LogMasker;
import java.util.Map;

public record FraudRequest(
        String transactionId,
        Double amount,
        String currency,
        String accountNumber,
        String deviceId,
        String ipAddress
) {
    public FraudRequest(Map<String, Object> data) {
        this(
            data != null ? (String) data.get("transactionId") : null,
            data != null && data.get("amount") instanceof Number n ? n.doubleValue() : null,
            data != null ? (String) data.get("currency") : null,
            data != null ? (String) data.get("accountNumber") : null,
            data != null ? (String) data.get("deviceId") : null,
            data != null ? (String) data.get("ipAddress") : null
        );
    }

    @Override
    public String toString() {
        return "FraudRequest[" +
                "transactionId=" + transactionId +
                ", amount=" + amount +
                ", currency=" + currency +
                ", accountNumber=" + LogMasker.mask(accountNumber) +
                ", deviceId=" + deviceId +
                ", ipAddress=" + ipAddress +
                ']';
    }
}
