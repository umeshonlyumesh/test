package com.trusit.sdk.fraud.model;

public record FraudResponse(double riskScore, String status) {
}
