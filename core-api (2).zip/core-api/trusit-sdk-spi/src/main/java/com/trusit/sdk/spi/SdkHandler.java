package com.trusit.sdk.spi;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;

/**
 * SPI contract for SDK modules.
 */
public interface SdkHandler {
    
    /**
     * Checks if this handler supports the given operation type and sub-operation type.
     */
    boolean supports(String operationType, String subOperationType);

    /**
     * Processes the incoming request.
     */
    StandardResponse<Object> process(StandardRequest request);
}
