# Project Guidelines - Core API with SDK-based Architecture

## 1. Objective
This repository contains a multi-module Java 21 / Spring Boot 3.5.x project implementing a Core API that orchestrates multiple SDK modules such as Fraud, Deposit, and Enrichment.

The architecture must be extensible, loosely coupled, testable, and production-grade.

---

## 2. High-Level Architecture

### 2.1 Core Principles
- **Orchestration Layer:** The `trusit-orchestrator` module handles incoming REST requests, validates them, and delegates processing to the correct SDK.
- **SPI-Driven Integration:** SDKs must implement the `SdkHandler` interface from the `trusit-sdk-spi` module.
- **Loose Coupling:** The orchestrator discovers SDKs via Spring's bean discovery. It does not have hardcoded references to SDK implementation classes.
- **Type-Safe Configuration:** Each SDK defines its own `@ConfigurationProperties` class, allowing independent configuration (base URL, timeouts, mTLS) in the orchestrator's `application.properties`.
- **Centralized HTTP Factory:** A shared `RestClientFactory` in the `trusit-common` module ensures consistent creation of `RestClient` instances with mTLS support.

### 2.2 Project Module Structure
- `trusit-parent` (Root POM): Manages shared dependencies and versions.
- `trusit-common`: Shared utilities (JSON, Log masking) and the `RestClientFactory`.
- `trusit-sdk-spi`: Defines the `SdkHandler` interface and core request/response models.
- `trusit-orchestrator`: The Spring Boot application containing controllers, the registry, and global exception handling.
- `trusit-sdk-fraud`, `trusit-sdk-deposit`, `trusit-sdk-enrichment`, `trusit-sdk-alert`: Individual SDK implementations.

---

## 3. Detailed Module Specifications

### 3.1 `trusit-sdk-spi`
The contract between the orchestrator and the SDKs.
- **Interface:** `SdkHandler`
  - `boolean supports(String operation, String subOperation)`: Determines if the handler can process a specific request.
  - `StandardResponse process(StandardRequest request)`: The execution logic.
- **Models:** `StandardRequest` and `StandardResponse` (Shared across all SDKs for orchestration).

### 3.2 `trusit-common`
Shared infrastructure.
- **`RestClientFactory`**: Static factory method `createMtlsEnabledClient(String baseUrl, MtlsProperties mP, int connectTimeout, int readTimeout)`.
- **`MtlsProperties`**: Nested static class to hold mTLS settings (keyStorePath, passwords, etc.).
- **`JsonUtils` / `LogMasker`**: Common utilities for data transformation and security.

### 3.3 SDK Modules (`trusit-sdk-*`)
Each SDK must be self-contained.
1. **Properties:** `XxxSdkProperties` with `@ConfigurationProperties(prefix = "sdk.xxx")`.
2. **Handler:** `XxxSdkHandler` implementing `SdkHandler`.
3. **Auto-Configuration:** `XxxSdkAutoConfiguration` that:
    - Enables properties.
    - Creates a named `RestClient` bean (e.g., `xxxRestClient`).
    - Creates the `XxxSdkHandler` bean using the named `RestClient`.
4. **Registration:** Add the configuration class to `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`.

### 3.4 `trusit-orchestrator`
The brain of the system.
- **`SdkRegistry`**: Injects `List<SdkHandler>` and provides a `getHandler(operation, subOperation)` method.
- **`OrchestrationService`**: Coordinates the flow: Registry -> Handler -> Response.
- **`LoggingAspect`**: Uses AOP to log execution time for all `SdkHandler.process` calls.

---

## 4. Coding Standards & Patterns

### Allowed
- `core-api` -> `spi`, `common`
- `fraud-sdk` -> `spi`, `common`
- `deposit-sdk` -> `spi`, `common`
- `enrichment-sdk` -> `spi`, `common`

### Not Allowed
- `spi` must not depend on SDKs
- `common` must not depend on SDKs
- `core-api` must not directly depend on SDK-specific implementation logic unless via Spring auto-configuration/runtime bean discovery
- SDKs must not depend on `core-api`

### Goal
Avoid circular dependencies completely.

---

## 4. Coding Standards

- Use Java 21
- Use Spring Boot 3.5.x
- Use constructor injection only
- Do not use field injection
- Do not use static mutable shared state
- Prefer interfaces for extension points
- Keep methods focused and small
- Use meaningful class and method names
- Use packages consistently by responsibility

---

## 5. Package Structure Standards

Each module should follow a clear structure like:

com.company.project.<module>
- config
- controller
- service
- orchestration
- registry
- client
- properties
- model
- exception
- util

SDK modules may contain:
- handler
- client
- mapper
- properties
- config

---

## 6. Project Setup & Configuration

### 6.1 Root `pom.xml`
The root `pom.xml` must manage common dependencies like Spring Boot starters, Jackson, and Lombok. It should also define the `<modules>` list.

### 6.2 Application Configuration (`application.properties`)
All SDK configurations must live in the orchestrator's `application.properties`.
```properties
# Orchestrator Config
server.port=8080
spring.threads.virtual.enabled=true

# Fraud SDK Config
sdk.fraud.base-url=http://localhost:8081
sdk.fraud.connect-timeout=5000
sdk.fraud.read-timeout=5000
sdk.fraud.mtls.enabled=false

# Deposit SDK Config (Different settings)
sdk.deposit.base-url=http://localhost:8082
sdk.deposit.mtls.enabled=true
sdk.deposit.mtls.key-store-path=certs/deposit-keystore.p12
```

---

## 7. Registry & Strategy Pattern

### 7.1 The Registry
The orchestrator must use a `List<SdkHandler>` in its registry to find the correct SDK at runtime.
```java
@Component
public class SdkRegistry {
    private final List<SdkHandler> handlers;

    public SdkRegistry(List<SdkHandler> handlers) {
        this.handlers = handlers;
    }

    public SdkHandler getHandler(String operation, String subOperation) {
        return handlers.stream()
                .filter(h -> h.supports(operation, subOperation))
                .findFirst()
                .orElseThrow(() -> new HandlerNotFoundException("No handler found for: " + operation));
    }
}
```

---

## 8. HTTP Client Best Practices

### 8.1 Shared `RestClientFactory`
The factory method should be robust and handle mTLS correctly.
- If `mtls.enabled` is true, use `SSLContext` to load `KeyStore` and `TrustStore`.
- Use `JdkClientHttpRequestFactory` for timeout management.
- Ensure the `RestClient` is built with a custom `requestFactory` when mTLS is required.

---

## 9. REST API Specification

### Endpoint
Core API should expose a single orchestration endpoint initially:
- `POST /api/v1/process`

### Request
The request should include:
- `operation`
- `subOperation` (optional if needed)
- `payload`
- request metadata if applicable

### Response
Return a standardized response wrapper:
- `status`
- `message`
- `data`
- `correlationId`
- `timestamp`

### Validation
- Validate mandatory fields using Jakarta Validation
- Reject invalid requests with structured error responses

---

## 9. Error Handling Rules

- Use a global exception handler with `@RestControllerAdvice`
- Define custom exceptions such as:
    - `ValidationException`
    - `HandlerNotFoundException`
    - `DownstreamServiceException`
    - `SdkProcessingException`

Error response must be standardized and must not expose sensitive internals.

Include:
- error code
- message
- timestamp
- correlation id
- path

---

## 10. Logging Rules

- Use SLF4J
- Include correlation id in logs using MDC if possible
- Log request start and completion at orchestration level
- Log SDK execution time using AOP
- Do not log secrets, passwords, tokens, or full sensitive payloads
- Sanitize logs if needed

---

## 11. Configuration Rules

- Each SDK must own its own configuration properties
- Use `@ConfigurationProperties`
- Example:
    - `sdk.fraud.*`
    - `sdk.deposit.*`
    - `sdk.enrichment.*`

Each SDK should define:
- base URL
- connect timeout
- read timeout
- SSL placeholders
- feature flags if needed

Do not hardcode environment values in Java code.

---

## 12. HTTP Client Rules

- Use Spring `RestClient`
- Avoid `WebClient` unless explicitly required
- Each SDK may have its own configured `RestClient` bean or a shared factory with SDK-specific properties
- Design must support mTLS configuration placeholders
- Centralize reusable HTTP error handling behavior

Handle:
- 4xx
- 5xx
- connection timeout
- read timeout
- SSL-related failures
- unknown transport exceptions

---

## 13. SDK Implementation Rules

Each SDK should:
- implement the SPI interface
- declare which operation/subOperation it supports
- isolate downstream integration logic in a client class
- keep DTOs private to the SDK unless truly shared
- map downstream responses into a standard response model

SDK should not know controller details.

---

## 14. Auto-Configuration Rules

- Each SDK should provide Spring configuration to register its beans
- Prefer auto-configuration so the core project remains lightweight
- Bean registration must be conditional where appropriate
- Keep configuration clean and modular

---

## 15. Testing Rules

Minimum required tests:
- controller test
- registry/factory test
- handler resolution test
- one unit test for each SDK handler
- one unit test for each downstream client error handling path
- one test for global exception handler

Testing stack:
- JUnit 5
- Mockito
- Spring Boot Test only where needed

Avoid overcomplicated tests.

---

## 16. README Requirements

The repository must include a `README.md` with:
- project overview
- module structure
- architecture explanation
- request flow
- how to run locally
- how to add a new SDK
- configuration example
- testing instructions

---

## 17. Output Expectations for AI Code Generation

When generating code:
- show complete project tree first
- generate all required files
- do not skip imports
- do not provide pseudocode
- keep code compile-friendly
- explain only where needed
- prefer correctness and structure over unnecessary cleverness

---

## 18. Future Extensibility

The architecture should make it easy to add future SDKs like:
- alert-sdk
- posting-sdk
- balance-sdk

Adding a new SDK should follow these 5 steps:
1. **Module Creation:** Create `trusit-sdk-<name>` as a child module of the parent.
2. **Properties:** Define `XxxSdkProperties` with `@ConfigurationProperties(prefix = "sdk.<name>")`.
3. **Handler Implementation:** Implement `SdkHandler` from `trusit-sdk-spi`.
4. **Auto-Configuration:** Create `XxxSdkAutoConfiguration` to register the handler and its `RestClient` bean.
5. **Spring Discovery:** Register the configuration class in `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`.

---

## 19. Anti-Patterns to Avoid

Do not:
- Hardcode routing `if/else` logic in `OrchestrationService` or controllers.
- Make any SDK depend on the `trusit-orchestrator` module.
- Use `@Autowired` on fields; use constructor injection instead.
- Skip defining custom properties for each SDK.
- Manually register SDK beans in the `Orchestrator` application class; use Spring's auto-configuration (Discovery) instead.

---

## 20. Definition of Done (Replication Checklist)

The project is considered complete if an AI or developer can:
1. Build the project using `mvn clean install` from the root.
2. Add a new SDK by only adding a module and configuring properties in `application.properties`.
3. Run the orchestrator and see it discover all SDKs via logs.
4. Call `POST /api/v1/process` and get a valid response from any registered SDK.
5. See execution times in the logs for every SDK call (AOP Timing).