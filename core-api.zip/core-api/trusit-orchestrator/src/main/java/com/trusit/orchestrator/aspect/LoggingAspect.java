package com.trusit.orchestrator.aspect;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.common.util.JsonUtils;
import com.trusit.common.util.LogMasker;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);
    private static final String REQUEST_ID_KEY = "requestId";

    @Pointcut("execution(* com.trusit.orchestrator.controller.CoreApiController.process(..))")
    public void coreApiEntryPoint() {}

    @Pointcut("execution(* com.trusit.sdk.spi.SdkHandler.process(..))")
    public void sdkHandlerProcess() {}

    @Around("coreApiEntryPoint()")
    public Object logCoreApi(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        StandardRequest request = (args.length > 0 && args[0] instanceof StandardRequest sr) ? sr : null;
        if (request == null && args.length > 0 && args[0] instanceof java.util.Map map) {
            request = StandardRequest.fromJson((java.util.Map<String, Object>) map);
        }

        String requestId = (request != null && request.requestId() != null) ? LogMasker.sanitize(request.requestId()) : "N/A";
        MDC.put(REQUEST_ID_KEY, requestId);

        try {
            if (request != null) {
                log.info("Core Request Received: operationType={}, subOperationType={}, userId={}", 
                        LogMasker.sanitize(request.operationType()), 
                        LogMasker.sanitize(request.subOperationType()), 
                        LogMasker.sanitize(request.userId()));
                log.debug("Full Core Request: {}", JsonUtils.toMaskedJson(request));
            }

            Object response = joinPoint.proceed();

            if (response instanceof StandardResponse<?> standardResponse) {
                log.info("Core Response Sent: status={}, message={}", 
                        standardResponse.status(), 
                        LogMasker.sanitize(standardResponse.message()));
                log.debug("Full Core Response: {}", JsonUtils.toMaskedJson(standardResponse));
            }

            return response;
        } finally {
            MDC.remove(REQUEST_ID_KEY);
        }
    }

    @Around("sdkHandlerProcess()")
    public Object logSdkExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        String sdkName = joinPoint.getTarget().getClass().getSimpleName();
        Object[] args = joinPoint.getArgs();
        StandardRequest request = (args.length > 0 && args[0] instanceof StandardRequest sr) ? sr : null;

        try {
            if (request != null) {
                log.info("SDK [{}] Request: operationType={}", sdkName, LogMasker.sanitize(request.operationType()));
                log.debug("SDK [{}] Full Request Payload: {}", sdkName, JsonUtils.toMaskedJson(request.additionalData()));
            }

            Object response = joinPoint.proceed();

            if (response instanceof StandardResponse<?> standardResponse) {
                log.info("SDK [{}] Response: status={}", sdkName, standardResponse.status());
                log.debug("SDK [{}] Full Response Data: {}", sdkName, JsonUtils.toMaskedJson(standardResponse.data()));
            }

            return response;
        } finally {
            long executionTime = System.currentTimeMillis() - start;
            log.info("SDK [{}] execution time: {} ms", sdkName, executionTime);
        }
    }
}
