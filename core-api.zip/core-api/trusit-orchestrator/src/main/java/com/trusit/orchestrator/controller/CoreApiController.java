package com.trusit.orchestrator.controller;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.orchestrator.service.OrchestrationService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class CoreApiController {
    private static final Logger log = LoggerFactory.getLogger(CoreApiController.class);

    private final OrchestrationService orchestrationService;

    public CoreApiController(OrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    @PostMapping("/process")
    public StandardResponse<Object> process(@RequestBody Map<String, Object> requestMap) {
        log.info("Received request map: {}", requestMap);
        StandardRequest request = StandardRequest.fromJson(requestMap);
        log.info("Mapped to StandardRequest: {}", request);
        StandardResponse<Object> response = orchestrationService.processRequest(request);
        return response;
    }
}
