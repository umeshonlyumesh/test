package com.trusit.orchestrator.service;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.orchestrator.registry.SdkRegistry;
import com.trusit.sdk.spi.SdkHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class OrchestrationService {
    private static final Logger log = LoggerFactory.getLogger(OrchestrationService.class);

    private final SdkRegistry sdkRegistry;

    public OrchestrationService(SdkRegistry sdkRegistry) {
        this.sdkRegistry = sdkRegistry;
    }

    public StandardResponse<Object> processRequest(StandardRequest request) {
        String correlationId = switch (request.requestId()) {
            case String s when !s.isBlank() -> s;
            default -> UUID.randomUUID().toString();
        };

        SdkHandler handler = sdkRegistry.getHandler(request.operationType(), request.subOperationType());
        
        StandardResponse<Object> sdkResponse = handler.process(request);
        
        return StandardResponse.<Object>builder()
                .status(sdkResponse.status())
                .message(sdkResponse.message())
                .data(sdkResponse.data())
                .correlationId(correlationId)
                .timestamp(sdkResponse.timestamp())
                .build();
    }
}
