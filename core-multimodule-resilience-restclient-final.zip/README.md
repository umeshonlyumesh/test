# core-multimodule-resilience-restclient (Option B)

Complete multi-module example including SDK projects.

## Build
```bash
mvn clean install
```

## Run Core API
```bash
mvn -pl core-api -am spring-boot:run
```

## Call
```bash
curl -X POST http://localhost:8080/integration/v1.0 \
  -H "Content-Type: application/json" \
  -d '{"operationType":"FraudCheck","payload":"C123"}'
```
