# core-api

This is the runnable Spring Boot service.

## Run
```bash
mvn -pl core-api -am spring-boot:run
```

## Test endpoints
```bash
curl -X POST http://localhost:8080/integration/v1.0 \
  -H "Content-Type: application/json" \
  -d '{"operationType":"FraudCheck","payload":"C123"}'
```
