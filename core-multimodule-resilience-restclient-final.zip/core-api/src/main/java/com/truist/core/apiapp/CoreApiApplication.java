package com.truist.core.apiapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Core API Spring Boot application.
 */
@SpringBootApplication(scanBasePackages = "com.truist.core")
public class CoreApiApplication {

  /**
   * Starts the Core API.
   *
   * @param args arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(CoreApiApplication.class, args);
  }
}
