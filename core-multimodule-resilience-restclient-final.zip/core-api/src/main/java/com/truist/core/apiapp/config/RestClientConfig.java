package com.truist.core.apiapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * Provides a shared {@link RestClient} bean used by all SDK modules.
 */
@Configuration
public class RestClientConfig {

  /**
   * Creates a RestClient with per-attempt connect/read timeouts.
   *
   * @param builder RestClient builder
   * @param connectTimeoutMs connect timeout
   * @param readTimeoutMs read/response timeout
   * @return RestClient
   */
  @Bean
  public RestClient restClient(
      RestClient.Builder builder,
      @Value("${coreHttp.timeouts.connectTimeoutMs:500}") int connectTimeoutMs,
      @Value("${coreHttp.timeouts.readTimeoutMs:1500}") int readTimeoutMs
  ) {
    SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(connectTimeoutMs);
    factory.setReadTimeout(readTimeoutMs);
    return builder.requestFactory(factory).build();
  }
}
