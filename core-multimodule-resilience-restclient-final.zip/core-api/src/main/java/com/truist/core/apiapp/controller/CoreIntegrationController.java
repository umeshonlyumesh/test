package com.truist.core.apiapp.controller;

import com.truist.core.apiapp.model.CoreIntegrationRequest;
import com.truist.core.apiapp.model.CoreIntegrationResponse;
import com.truist.core.apiapp.service.OrchestrationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Routes to SDK executors by operation type.
 */
@RestController
@RequestMapping("/integration/v1.0")
public class CoreIntegrationController {

  private final OrchestrationService orchestrationService;

  /** @param orchestrationService service */
  public CoreIntegrationController(OrchestrationService orchestrationService) {
    this.orchestrationService = orchestrationService;
  }

  /** @param request request @return response */
  @PostMapping
  public ResponseEntity<CoreIntegrationResponse> handle(@Valid @RequestBody CoreIntegrationRequest request) {
    return ResponseEntity.ok(orchestrationService.orchestrate(request));
  }
}
