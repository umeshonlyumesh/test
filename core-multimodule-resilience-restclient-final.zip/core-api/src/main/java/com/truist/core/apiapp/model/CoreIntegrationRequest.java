package com.truist.core.apiapp.model;

import jakarta.validation.constraints.NotBlank;

/** Request payload for integration endpoint. */
public record CoreIntegrationRequest(@NotBlank String operationType, String payload) {}
