package com.truist.core.apiapp.model;

import java.time.Instant;
import java.util.Map;

/** Response payload for integration endpoint. */
public record CoreIntegrationResponse(
    String operationType,
    String status,
    String message,
    Map<String, Object> data,
    Instant timestamp
) {}
