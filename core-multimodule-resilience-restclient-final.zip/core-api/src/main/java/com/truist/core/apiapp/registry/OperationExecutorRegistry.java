package com.truist.core.apiapp.registry;

import com.truist.core.apiapp.resilience.ResilienceProperties;
import com.truist.core.apiapp.resilience.ResilientOperationExecutor;
import com.truist.core.spi.OperationExecutor;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryRegistry;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Registry for all OperationExecutor beans (from SDK modules).
 */
@Component
public class OperationExecutorRegistry {

  private final Map<String, OperationExecutor<?, ?>> raw;
  private final Map<String, OperationExecutor<?, ?>> cache = new ConcurrentHashMap<>();
  private final ResilienceProperties props;
  private final CircuitBreakerRegistry cbRegistry;
  private final RetryRegistry retryRegistry;

  /** @param executors executors @param props props @param cbRegistry cb @param retryRegistry retry */
  public OperationExecutorRegistry(
      List<OperationExecutor<?, ?>> executors,
      ResilienceProperties props,
      CircuitBreakerRegistry cbRegistry,
      RetryRegistry retryRegistry
  ) {
    this.raw = executors.stream().collect(Collectors.toMap(OperationExecutor::getOperationName, e -> e));
    this.props = props;
    this.cbRegistry = cbRegistry;
    this.retryRegistry = retryRegistry;
  }

  /** @param op operation @return executor */
  @SuppressWarnings("unchecked")
  public <RQ, RS> OperationExecutor<RQ, RS> getExecutor(String op) {
    OperationExecutor<RQ, RS> base = (OperationExecutor<RQ, RS>) raw.get(op);
    if (base == null) return null;

    return (OperationExecutor<RQ, RS>) cache.computeIfAbsent(op, k -> {
      var p = props.policyFor(k);
      if (!p.isRetryEnabled() && !p.isCbEnabled()) return base;
      return new ResilientOperationExecutor<>(k, base, p, cbRegistry, retryRegistry);
    });
  }
}
