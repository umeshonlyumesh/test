package com.truist.core.apiapp.resilience;

import org.springframework.web.client.HttpStatusCodeException;

import java.io.IOException;
import java.net.SocketTimeoutException;

/**
 * Retry predicate for Resilience4j Retry.
 */
public final class ErrorClassifier {

  /** @param t throwable @return true if retryable */
  public boolean isRetryable(Throwable t) {
    Throwable root = rootCause(t);
    if (root instanceof SocketTimeoutException) return true;
    if (root instanceof IOException) return true;

    if (root instanceof HttpStatusCodeException ex) {
      int code = ex.getStatusCode().value();
      return code == 429 || code == 502 || code == 503 || code == 504;
    }
    return false;
  }

  /** @param t throwable @return root cause */
  public Throwable rootCause(Throwable t) {
    Throwable cur = t;
    while (cur.getCause() != null && cur.getCause() != cur) cur = cur.getCause();
    return cur;
  }
}
