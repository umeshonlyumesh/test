package com.truist.core.apiapp.resilience;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * Flag-based resilience settings per operation.
 */
@Configuration
@ConfigurationProperties(prefix = "core.resilience")
public class ResilienceProperties {

  private Map<String, OperationPolicy> operations = new HashMap<>();

  /** @return operations map */
  public Map<String, OperationPolicy> getOperations() {
    return operations;
  }

  /** @param operations operations map */
  public void setOperations(Map<String, OperationPolicy> operations) {
    this.operations = operations;
  }

  /** @param op operation @return policy */
  public OperationPolicy policyFor(String op) {
    return operations.getOrDefault(op, OperationPolicy.defaults());
  }

  /** Operation policy. */
  public static class OperationPolicy {
    private boolean retryEnabled = true;
    private boolean cbEnabled = true;
    private int maxAttempts = 2;

    /** @return defaults */
    public static OperationPolicy defaults() {
      return new OperationPolicy();
    }

    /** @return retry enabled */
    public boolean isRetryEnabled() { return retryEnabled; }

    /** @param retryEnabled retry enabled */
    public void setRetryEnabled(boolean retryEnabled) { this.retryEnabled = retryEnabled; }

    /** @return CB enabled */
    public boolean isCbEnabled() { return cbEnabled; }

    /** @param cbEnabled cb enabled */
    public void setCbEnabled(boolean cbEnabled) { this.cbEnabled = cbEnabled; }

    /** @return max attempts */
    public int getMaxAttempts() { return maxAttempts; }

    /** @param maxAttempts max attempts */
    public void setMaxAttempts(int maxAttempts) { this.maxAttempts = Math.max(1, maxAttempts); }
  }
}
