package com.truist.core.apiapp.resilience;

import com.truist.core.spi.OperationExecutor;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;

import java.util.function.Supplier;

/**
 * Applies CircuitBreaker and Retry around a synchronous {@link OperationExecutor}.
 *
 * <p>Option B: no TimeLimiter and no extra threads. Use HTTP client timeouts.
 */
public final class ResilientOperationExecutor<RQ, RS> implements OperationExecutor<RQ, RS> {

  private final String op;
  private final OperationExecutor<RQ, RS> delegate;
  private final ResilienceProperties.OperationPolicy policy;
  private final CircuitBreakerRegistry cbRegistry;
  private final RetryRegistry retryRegistry;
  private final ErrorClassifier classifier = new ErrorClassifier();

  /** @param op op @param delegate delegate @param policy policy @param cbRegistry cb @param retryRegistry retry */
  public ResilientOperationExecutor(
      String op,
      OperationExecutor<RQ, RS> delegate,
      ResilienceProperties.OperationPolicy policy,
      CircuitBreakerRegistry cbRegistry,
      RetryRegistry retryRegistry
  ) {
    this.op = op;
    this.delegate = delegate;
    this.policy = policy;
    this.cbRegistry = cbRegistry;
    this.retryRegistry = retryRegistry;
  }

  /** {@inheritDoc} */
  @Override public String getOperationName() { return delegate.getOperationName(); }

  /** {@inheritDoc} */
  @Override
  public RS execute(RQ request) {
    Supplier<RS> supplier = () -> delegate.execute(request);

    // Inner-most: CircuitBreaker around the actual call
    if (policy.isCbEnabled()) {
      CircuitBreaker cb = cbRegistry.circuitBreaker(op);
      supplier = CircuitBreaker.decorateSupplier(cb, supplier);
    }

    // Outer-most: Retry re-invokes the decorated supplier on retryable errors
    if (policy.isRetryEnabled()) {
      Retry retry = buildRetry(op, policy.getMaxAttempts());
      supplier = Retry.decorateSupplier(retry, supplier);
    }

    return supplier.get();
  }

    if (policy.isRetryEnabled()) {
      Retry retry = buildRetry(op, policy.getMaxAttempts());
      dec = dec.withRetry(retry);
    }

    return dec.decorate().get();
  }

  private Retry buildRetry(String op, int maxAttempts) {
    RetryConfig base = retryRegistry.retry(op).getRetryConfig();
    RetryConfig cfg = RetryConfig.custom()
        .maxAttempts(Math.max(1, maxAttempts))
        .waitDuration(base.getWaitDuration())
        .intervalFunction(base.getIntervalFunction())
        .retryOnException(classifier::isRetryable)
        .failAfterMaxAttempts(true)
        .build();
    return Retry.of(op + "_decorated", cfg);
  }
}
