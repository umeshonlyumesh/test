package com.truist.core.apiapp.service;

import com.truist.core.apiapp.model.CoreIntegrationRequest;
import com.truist.core.apiapp.model.CoreIntegrationResponse;
import com.truist.core.apiapp.registry.OperationExecutorRegistry;
import com.truist.core.spi.OperationExecutor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;

/**
 * Orchestrator/router.
 */
@Service
public class OrchestrationService {

  private final OperationExecutorRegistry registry;

  /** @param registry registry */
  public OrchestrationService(OperationExecutorRegistry registry) {
    this.registry = registry;
  }

  /** @param request request @return response */
  @SuppressWarnings("unchecked")
  public CoreIntegrationResponse orchestrate(CoreIntegrationRequest request) {
    OperationExecutor<Object, Object> executor =
        (OperationExecutor<Object, Object>) registry.getExecutor(request.operationType());

    if (executor == null) {
      return new CoreIntegrationResponse(
          request.operationType(), "FAILED",
          "No executor found for operationType=" + request.operationType(),
          Map.of(), Instant.now()
      );
    }

    Object result = executor.execute(request.payload());
    return new CoreIntegrationResponse(
        request.operationType(), "SUCCESS", "OK",
        Map.of("result", result), Instant.now()
    );
  }
}
