package com.truist.core.sdk.enrichment;

import com.truist.core.spi.OperationExecutor;
import org.springframework.stereotype.Component;

/**
 * Executor for Enrichment operation.
 */
@Component
public class EnrichmentExecutor implements OperationExecutor<String, String> {

  private final EnrichmentSdkClient client;

  /**
   * Creates the executor.
   *
   * @param client SDK client
   */
  public EnrichmentExecutor(EnrichmentSdkClient client) {
    this.client = client;
  }

  /** {@inheritDoc} */
  @Override
  public String getOperationName() {
    return "Enrichment";
  }

  /** {@inheritDoc} */
  @Override
  public String execute(String request) {
    var resp = client.enrich(new EnrichmentSdkClient.EnrichmentRequest(request == null ? "UNKNOWN" : request));
    return "status=" + resp.status() + ", details=" + resp.details();
  }
}
