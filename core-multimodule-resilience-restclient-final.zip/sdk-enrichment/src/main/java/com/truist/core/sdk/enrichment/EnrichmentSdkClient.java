package com.truist.core.sdk.enrichment;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Enrichment SDK client.
 */
@Component
public class EnrichmentSdkClient {

  private final RestClient restClient;

  /**
   * Creates the client.
   *
   * @param restClient RestClient provided by Core API
   */
  public EnrichmentSdkClient(RestClient restClient) {
    this.restClient = restClient;
  }

  /**
   * Performs enrichment.
   *
   * @param request request
   * @return response
   */
  public EnrichmentResponse enrich(EnrichmentRequest request) {
    return new EnrichmentResponse("OK", "Enriched payload for id=" + request.id());
  }

  /** @param id id */
  public record EnrichmentRequest(String id) {}

  /** @param status status @param details details */
  public record EnrichmentResponse(String status, String details) {}
}
