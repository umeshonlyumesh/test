package com.truist.core.sdk.fraud;

import com.truist.core.spi.OperationExecutor;
import org.springframework.stereotype.Component;

import java.util.Random;

/**
 * Executor for FraudCheck operation.
 */
@Component
public class FraudCheckExecutor implements OperationExecutor<String, String> {

  private final FraudSdkClient client;
  private final Random random = new Random();

  /**
   * Creates the executor.
   *
   * @param client Fraud SDK client
   */
  public FraudCheckExecutor(FraudSdkClient client) {
    this.client = client;
  }

  /** {@inheritDoc} */
  @Override
  public String getOperationName() {
    return "FraudCheck";
  }

  /**
   * Executes fraud check.
   *
   * @param request payload
   * @return result
   */
  @Override
  public String execute(String request) {
    if (random.nextInt(10) < 3) {
      throw new RuntimeException("Transient Fraud dependency failure (demo)");
    }
    var resp = client.check(new FraudSdkClient.FraudRequest(request == null ? "UNKNOWN" : request));
    return "decision=" + resp.decision() + ", details=" + resp.details();
  }
}
