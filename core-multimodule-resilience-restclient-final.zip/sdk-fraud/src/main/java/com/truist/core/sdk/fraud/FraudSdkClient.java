package com.truist.core.sdk.fraud;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Fraud SDK client.
 *
 * <p>This class represents the "SDK" that encapsulates downstream HTTP calls.
 */
@Component
public class FraudSdkClient {

  private final RestClient restClient;

  /**
   * Creates a Fraud SDK client.
   *
   * @param restClient Spring Boot provided RestClient bean (configured in Core API)
   */
  public FraudSdkClient(RestClient restClient) {
    this.restClient = restClient;
  }

  /**
   * Performs a fraud check.
   *
   * <p>Demo implementation returns a synthetic response. Replace with a real RestClient call.
   *
   * @param request fraud request
   * @return fraud response
   */
  public FraudResponse check(FraudRequest request) {
    return new FraudResponse("APPROVE", "Fraud check completed for customerId=" + request.customerId());
  }

  /** @param customerId customer id */
  public record FraudRequest(String customerId) {}

  /** @param decision decision @param details details */
  public record FraudResponse(String decision, String details) {}
}
