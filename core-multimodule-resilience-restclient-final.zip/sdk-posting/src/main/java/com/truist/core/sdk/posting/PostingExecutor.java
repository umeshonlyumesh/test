package com.truist.core.sdk.posting;

import com.truist.core.spi.OperationExecutor;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Executor for Posting operation.
 */
@Component
public class PostingExecutor implements OperationExecutor<String, String> {

  private final PostingSdkClient client;

  /**
   * Creates the executor.
   *
   * @param client SDK client
   */
  public PostingExecutor(PostingSdkClient client) {
    this.client = client;
  }

  /** {@inheritDoc} */
  @Override
  public String getOperationName() {
    return "Posting";
  }

  /** {@inheritDoc} */
  @Override
  public String execute(String request) {
    String idem = UUID.randomUUID().toString();
    var resp = client.post(new PostingSdkClient.PostingRequest(request == null ? "UNKNOWN" : request, 10.0), idem);
    return "status=" + resp.status() + ", details=" + resp.details();
  }
}
