package com.truist.core.sdk.posting;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Posting SDK client.
 *
 * <p>Side-effecting operation. Retry should be disabled by default.
 */
@Component
public class PostingSdkClient {

  private final RestClient restClient;

  /**
   * Creates the client.
   *
   * @param restClient RestClient provided by Core API
   */
  public PostingSdkClient(RestClient restClient) {
    this.restClient = restClient;
  }

  /**
   * Performs a posting.
   *
   * @param request request
   * @param idempotencyKey idempotency key
   * @return response
   */
  public PostingResponse post(PostingRequest request, String idempotencyKey) {
    return new PostingResponse("POSTED", "Posted id=" + request.txnId() + " with key=" + idempotencyKey);
  }

  /** @param txnId txn id @param amount amount */
  public record PostingRequest(String txnId, double amount) {}

  /** @param status status @param details details */
  public record PostingResponse(String status, String details) {}
}
