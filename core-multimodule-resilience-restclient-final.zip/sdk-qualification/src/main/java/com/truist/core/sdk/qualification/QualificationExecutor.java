package com.truist.core.sdk.qualification;

import com.truist.core.spi.OperationExecutor;
import org.springframework.stereotype.Component;

/**
 * Executor for Qualification operation.
 */
@Component
public class QualificationExecutor implements OperationExecutor<String, String> {

  private final QualificationSdkClient client;

  /**
   * Creates the executor.
   *
   * @param client SDK client
   */
  public QualificationExecutor(QualificationSdkClient client) {
    this.client = client;
  }

  /** {@inheritDoc} */
  @Override
  public String getOperationName() {
    return "Qualification";
  }

  /** {@inheritDoc} */
  @Override
  public String execute(String request) {
    var resp = client.qualify(new QualificationSdkClient.QualificationRequest(request == null ? "UNKNOWN" : request));
    return "qualified=" + resp.qualified() + ", reason=" + resp.reason();
  }
}
