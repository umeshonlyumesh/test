package com.truist.core.sdk.qualification;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/**
 * Qualification SDK client.
 */
@Component
public class QualificationSdkClient {

  private final RestClient restClient;

  /**
   * Creates the client.
   *
   * @param restClient RestClient provided by Core API
   */
  public QualificationSdkClient(RestClient restClient) {
    this.restClient = restClient;
  }

  /**
   * Performs qualification.
   *
   * @param request request
   * @return response
   */
  public QualificationResponse qualify(QualificationRequest request) {
    return new QualificationResponse(true, "Qualified for id=" + request.id());
  }

  /** @param id id */
  public record QualificationRequest(String id) {}

  /** @param qualified qualified @param reason reason */
  public record QualificationResponse(boolean qualified, String reason) {}
}
