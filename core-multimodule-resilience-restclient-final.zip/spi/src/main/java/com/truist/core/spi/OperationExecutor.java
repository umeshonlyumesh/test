package com.truist.core.spi;

/**
 * Contract implemented by each SDK "executor" in your architecture.
 *
 * <p>Each SDK module provides one or more implementations. The Core API uses
 * {@code OperationExecutorRegistry} to look up the correct executor and invoke it.
 *
 * @param <RQ> request type
 * @param <RS> response type
 */
public interface OperationExecutor<RQ, RS> {

  /**
   * Returns the operation name used as the registry key.
   *
   * <p>Example values: {@code "FraudCheck"}, {@code "Enrichment"}, {@code "Qualification"}, {@code "Posting"}.
   *
   * @return operation name
   */
  String getOperationName();

  /**
   * Executes the operation synchronously.
   *
   * @param request request payload
   * @return response payload
   */
  RS execute(RQ request);
}
