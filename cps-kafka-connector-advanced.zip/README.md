# cps-kafka-connector-starter (advanced)

## Added features
- Pause/resume per partition (KafkaConsumer.pause/resume)
- Adaptive backpressure (EWMA latency -> computed watermarks)
- Micrometer metrics (Actuator /metrics + /prometheus)
- Structured concurrency (Java 21 StructuredTaskScope for handler ownership)
- Unit + integration tests (Testcontainers Kafka)

## How to see Micrometer metrics (not logs)
Run your Spring Boot app and open:
- /actuator/metrics
- /actuator/metrics/robust.kafka.records.processed
- /actuator/prometheus

Prometheus scrapes /actuator/prometheus and Grafana visualizes it.
