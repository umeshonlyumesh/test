package com.truist.cps.kafka.annotation;

import java.lang.annotation.*;

/**
 * Marks a method as a Kafka record handler managed by this starter.
 *
 * <h3>Required method signature</h3>
 * <pre>{@code
 * @KafkaConsumerListener(topic="payments", groupId="payments-group")
 * public void onMessage(ConsumerRecord<String, Object> record) { ... }
 * }</pre>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface KafkaConsumerListener {
  String topic();
  String groupId();
}
