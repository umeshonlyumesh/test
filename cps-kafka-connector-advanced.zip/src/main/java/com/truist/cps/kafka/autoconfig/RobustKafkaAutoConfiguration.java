package com.truist.cps.kafka.autoconfig;

import com.truist.cps.kafka.config.RobustKafkaProperties;
import com.truist.cps.kafka.consumer.KafkaConsumerRunner;
import com.truist.cps.kafka.dlq.ProducerClient;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

/**
 * Auto-configuration for the robust Kafka consumer starter.
 */
@AutoConfiguration
@EnableConfigurationProperties(RobustKafkaProperties.class)
@ConditionalOnProperty(prefix = "robust.kafka", name = "enabled", havingValue = "true", matchIfMissing = true)
public class RobustKafkaAutoConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public ProducerClient producerClient() {
    return (topic, key, value) -> System.err.printf("DLQ_LOG_ONLY | topic=%s key=%s value=%s%n", topic, key, value);
  }

  @Bean
  @ConditionalOnMissingBean
  public KafkaConsumerRunner kafkaConsumerRunner(ApplicationContext ctx,
                                                 Environment env,
                                                 RobustKafkaProperties props,
                                                 MeterRegistry registry,
                                                 ProducerClient producerClient) {
    return new KafkaConsumerRunner(ctx, env, props, registry, producerClient);
  }
}
