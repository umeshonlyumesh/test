package com.truist.cps.kafka.backpressure;

import com.truist.cps.kafka.config.RobustKafkaProperties;

/**
 * Adaptive backpressure controller using EWMA latency to compute pause/resume thresholds.
 */
public final class AdaptiveBackpressureController {
  private final RobustKafkaProperties.Backpressure cfg;
  private final double alpha = 0.2;
  private volatile double ewmaLatencyNanos = 5_000_000.0;
  private volatile long lastDecisionAtMs = 0;

  public AdaptiveBackpressureController(RobustKafkaProperties.Backpressure cfg) {
    this.cfg = cfg;
  }

  public void recordLatencyNanos(long nanos) {
    ewmaLatencyNanos = (alpha * nanos) + ((1 - alpha) * ewmaLatencyNanos);
  }

  public int highWatermark() {
    double avgMs = Math.max(0.1, ewmaLatencyNanos / 1_000_000.0);
    int computed = (int) Math.ceil(cfg.getTargetBacklogMs() / avgMs);
    return Math.max(cfg.getMinHighWatermark(), computed);
  }

  public int lowWatermark() {
    return Math.max(1, highWatermark() / 2);
  }

  public boolean canDecide(long nowMs) {
    if (nowMs - lastDecisionAtMs < cfg.getPauseCooldownMs()) return false;
    lastDecisionAtMs = nowMs;
    return true;
  }
}
