package com.truist.cps.kafka.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Global configuration for the robust consumer engine.
 */
@ConfigurationProperties(prefix = "robust.kafka")
public class RobustKafkaProperties {

  private boolean enabled = true;
  private int maxRetries = 3;
  private long pollTimeoutMs = 500;
  private long commitIntervalMs = 1000;
  private String keyDeserializer = "org.apache.kafka.common.serialization.StringDeserializer";
  private String valueDeserializer = "com.truist.cps.kafka.serdes.SafeKafkaAvroDeserializer";
  private String autoOffsetReset = "earliest";
  private final Backpressure backpressure = new Backpressure();

  public boolean isEnabled() { return enabled; }
  public void setEnabled(boolean enabled) { this.enabled = enabled; }

  public int getMaxRetries() { return maxRetries; }
  public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }

  public long getPollTimeoutMs() { return pollTimeoutMs; }
  public void setPollTimeoutMs(long pollTimeoutMs) { this.pollTimeoutMs = pollTimeoutMs; }

  public long getCommitIntervalMs() { return commitIntervalMs; }
  public void setCommitIntervalMs(long commitIntervalMs) { this.commitIntervalMs = commitIntervalMs; }

  public String getKeyDeserializer() { return keyDeserializer; }
  public void setKeyDeserializer(String keyDeserializer) { this.keyDeserializer = keyDeserializer; }

  public String getValueDeserializer() { return valueDeserializer; }
  public void setValueDeserializer(String valueDeserializer) { this.valueDeserializer = valueDeserializer; }

  public String getAutoOffsetReset() { return autoOffsetReset; }
  public void setAutoOffsetReset(String autoOffsetReset) { this.autoOffsetReset = autoOffsetReset; }

  public Backpressure getBackpressure() { return backpressure; }

  public static class Backpressure {
    private boolean enabled = true;
    private long targetBacklogMs = 2000;
    private int minHighWatermark = 100;
    private long pauseCooldownMs = 500;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public long getTargetBacklogMs() { return targetBacklogMs; }
    public void setTargetBacklogMs(long targetBacklogMs) { this.targetBacklogMs = targetBacklogMs; }

    public int getMinHighWatermark() { return minHighWatermark; }
    public void setMinHighWatermark(int minHighWatermark) { this.minHighWatermark = minHighWatermark; }

    public long getPauseCooldownMs() { return pauseCooldownMs; }
    public void setPauseCooldownMs(long pauseCooldownMs) { this.pauseCooldownMs = pauseCooldownMs; }
  }
}
