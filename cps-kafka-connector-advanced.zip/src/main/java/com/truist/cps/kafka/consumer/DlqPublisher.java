package com.truist.cps.kafka.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Publishes poison records to a DLQ sink.
 */
@FunctionalInterface
public interface DlqPublisher<V> {
  void publish(ConsumerRecord<String, V> record, Exception cause);
}
