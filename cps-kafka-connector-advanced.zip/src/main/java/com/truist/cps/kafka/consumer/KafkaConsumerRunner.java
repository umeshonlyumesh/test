package com.truist.cps.kafka.consumer;

import com.truist.cps.kafka.annotation.KafkaConsumerListener;
import com.truist.cps.kafka.config.RobustKafkaProperties;
import com.truist.cps.kafka.dlq.KafkaDlqPublisher;
import com.truist.cps.kafka.dlq.ProducerClient;
import com.truist.cps.kafka.metrics.RobustKafkaMetrics;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.SmartLifecycle;
import org.springframework.core.env.Environment;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Discovers @KafkaConsumerListener methods and starts RobustKafkaConsumer instances.
 */
public final class KafkaConsumerRunner implements SmartLifecycle {

  private final ApplicationContext ctx;
  private final Environment env;
  private final RobustKafkaProperties props;
  private final MeterRegistry registry;
  private final ProducerClient producerClient;

  private final List<RobustKafkaConsumer<Object>> consumers = new CopyOnWriteArrayList<>();
  private volatile boolean running = false;

  public KafkaConsumerRunner(ApplicationContext ctx,
                             Environment env,
                             RobustKafkaProperties props,
                             MeterRegistry registry,
                             ProducerClient producerClient) {
    this.ctx = ctx;
    this.env = env;
    this.props = props;
    this.registry = registry;
    this.producerClient = producerClient;
  }

  @Override
  public void start() {
    if (running || !props.isEnabled()) return;

    for (String beanName : ctx.getBeanDefinitionNames()) {
      Object bean = ctx.getBean(beanName);
      scanBean(bean);
    }

    consumers.forEach(RobustKafkaConsumer::start);
    running = true;
  }

  @Override
  public void stop() {
    consumers.forEach(RobustKafkaConsumer::stop);
    running = false;
  }

  @Override public boolean isRunning() { return running; }
  @Override public boolean isAutoStartup() { return true; }
  @Override public int getPhase() { return 0; }
  @Override public void stop(Runnable callback) { stop(); callback.run(); }

  private void scanBean(Object bean) {
    ReflectionUtils.doWithMethods(bean.getClass(), method -> {
      KafkaConsumerListener ann = method.getAnnotation(KafkaConsumerListener.class);
      if (ann == null) return;

      validateSignature(method);
      method.setAccessible(true);

      String topic = env.resolvePlaceholders(ann.topic());
      String groupId = env.resolvePlaceholders(ann.groupId());

      Properties cp = buildConsumerProps(groupId);
      KafkaConsumer<String, Object> kc = new KafkaConsumer<>(cp);

      String dlqTopic = env.getProperty("robust.kafka.dlq.topic", topic + ".DLQ");
      var dlq = new KafkaDlqPublisher<>(producerClient, dlqTopic);
      var metrics = new RobustKafkaMetrics(registry, topic, groupId);

      RecordProcessor<Object> processor = (ConsumerRecord<String, Object> rec) -> invoke(bean, method, rec);

      consumers.add(new RobustKafkaConsumer<>(kc, topic, groupId, processor, dlq, props, metrics));
    });
  }

  private void invoke(Object bean, Method method, ConsumerRecord<String, Object> rec) throws Exception {
    try {
      method.invoke(bean, rec);
    } catch (InvocationTargetException ite) {
      Throwable real = ite.getTargetException();
      if (real instanceof Exception e) throw e;
      throw new RuntimeException(real);
    } catch (IllegalAccessException iae) {
      throw new RuntimeException("Cannot access listener method: " + method, iae);
    }
  }

  private void validateSignature(Method method) {
    if (method.getParameterCount() != 1 ||
        !ConsumerRecord.class.isAssignableFrom(method.getParameterTypes()[0])) {
      throw new IllegalStateException("@KafkaConsumerListener method must accept exactly one ConsumerRecord parameter: " + method);
    }
  }

  private Properties buildConsumerProps(String groupId) {
    Properties p = new Properties();
    p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, env.getProperty("kafka.bootstrap.servers", "localhost:9092"));
    p.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
    p.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
    p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, props.getAutoOffsetReset());

    p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, props.getKeyDeserializer());
    p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, props.getValueDeserializer());

    String sr = env.getProperty("kafka.schema.registry.url");
    if (sr != null) p.put("schema.registry.url", sr);

    return p;
  }
}
