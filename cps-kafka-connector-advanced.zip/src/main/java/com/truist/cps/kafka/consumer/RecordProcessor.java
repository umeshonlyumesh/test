package com.truist.cps.kafka.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * User hook to process a single Kafka record.
 */
@FunctionalInterface
public interface RecordProcessor<V> {
  void process(ConsumerRecord<String, V> record) throws Exception;
}
