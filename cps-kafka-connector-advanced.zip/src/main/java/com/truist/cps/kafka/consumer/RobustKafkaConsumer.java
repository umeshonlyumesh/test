package com.truist.cps.kafka.consumer;

import com.truist.cps.kafka.backpressure.AdaptiveBackpressureController;
import com.truist.cps.kafka.config.RobustKafkaProperties;
import com.truist.cps.kafka.metrics.RobustKafkaMetrics;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Robust consumer engine with:
 * ordered processing per partition, manual commits, DLQ, bad-payload skipping,
 * per-partition pause/resume, adaptive backpressure, and Java 21 structured concurrency.
 */
public final class RobustKafkaConsumer<V> {

  private final KafkaConsumer<String, V> consumer;
  private final String topic;
  private final String groupId;
  private final RecordProcessor<V> processor;
  private final DlqPublisher<V> dlq;
  private final RobustKafkaProperties props;
  private final RobustKafkaMetrics metrics;

  private final AdaptiveBackpressureController bp;

  private final ExecutorService pollExecutor;
  private final ExecutorService workerPool;

  private final AtomicBoolean running = new AtomicBoolean(false);

  private final Map<TopicPartition, Long> lastSuccess = new ConcurrentHashMap<>();
  private final Map<TopicPartition, Map<Long, Integer>> retries = new ConcurrentHashMap<>();
  private final Map<TopicPartition, ArrayDeque<ConsumerRecord<String, V>>> queues = new ConcurrentHashMap<>();
  private final Set<TopicPartition> paused = ConcurrentHashMap.newKeySet();

  private volatile long lastCommitAtMs = 0;

  public RobustKafkaConsumer(KafkaConsumer<String, V> consumer,
                            String topic,
                            String groupId,
                            RecordProcessor<V> processor,
                            DlqPublisher<V> dlq,
                            RobustKafkaProperties props,
                            RobustKafkaMetrics metrics) {
    this.consumer = Objects.requireNonNull(consumer);
    this.topic = Objects.requireNonNull(topic);
    this.groupId = Objects.requireNonNull(groupId);
    this.processor = Objects.requireNonNull(processor);
    this.dlq = Objects.requireNonNull(dlq);
    this.props = Objects.requireNonNull(props);
    this.metrics = Objects.requireNonNull(metrics);
    this.bp = new AdaptiveBackpressureController(props.getBackpressure());

    this.pollExecutor = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "robust-kafka-poll-" + topic + "-" + groupId);
      t.setDaemon(true);
      return t;
    });

    this.workerPool = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("robust-kafka-worker-" + topic + "-" + groupId + "-", 0).factory()
    );
  }

  public void start() {
    if (!running.compareAndSet(false, true)) return;
    pollExecutor.submit(this::pollLoop);
  }

  public void stop() {
    if (!running.compareAndSet(true, false)) return;
    consumer.wakeup();
    pollExecutor.shutdown();
    workerPool.shutdown();
  }

  private void pollLoop() {
    try {
      consumer.subscribe(List.of(topic), new ConsumerRebalanceListener() {
        @Override public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
          commitNow();
          for (TopicPartition tp : partitions) {
            queues.remove(tp);
            paused.remove(tp);
            lastSuccess.remove(tp);
            retries.remove(tp);
          }
        }
        @Override public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
          for (TopicPartition tp : partitions) queues.putIfAbsent(tp, new ArrayDeque<>());
        }
      });

      while (running.get()) {
        metrics.pollTimer.record(() -> {
          ConsumerRecords<String, V> polled = consumer.poll(Duration.ofMillis(props.getPollTimeoutMs()));
          enqueue(polled);
          processQueues();
          adaptivePauseResume();
          commitMaybe();
          updateGauges();
        });
      }
    } catch (WakeupException ignore) {
    } finally {
      try { commitNow(); } catch (Exception ignore) {}
      try { consumer.close(); } catch (Exception ignore) {}
    }
  }

  private void enqueue(ConsumerRecords<String, V> records) {
    for (TopicPartition tp : records.partitions()) {
      ArrayDeque<ConsumerRecord<String, V>> q = queues.computeIfAbsent(tp, k -> new ArrayDeque<>());
      for (ConsumerRecord<String, V> r : records.records(tp)) q.addLast(r);
    }
  }

  private void processQueues() {
    for (var e : queues.entrySet()) {
      TopicPartition tp = e.getKey();
      ArrayDeque<ConsumerRecord<String, V>> q = e.getValue();
      if (q.isEmpty() || paused.contains(tp)) continue;

      ConsumerRecord<String, V> r = q.peekFirst();
      if (r == null) continue;

      boolean ok = processOne(tp, r);
      if (ok) q.removeFirst();
    }
  }

  private boolean processOne(TopicPartition tp, ConsumerRecord<String, V> r) {
    if (r.value() == null) {
      metrics.badPayload.increment();
      markSuccess(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;
    }

    metrics.incInflight();
    long start = System.nanoTime();

    try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
      var t = scope.fork(() -> { processor.process(r); return null; });
      scope.join();
      scope.throwIfFailed();
      t.get();

      long nanos = System.nanoTime() - start;
      metrics.processTimer.record(nanos, TimeUnit.NANOSECONDS);
      bp.recordLatencyNanos(nanos);

      metrics.processed.increment();
      markSuccess(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;

    } catch (Exception ex) {
      metrics.failed.increment();
      return handleFailure(tp, r, ex);
    } finally {
      metrics.decInflight();
    }
  }

  private boolean handleFailure(TopicPartition tp, ConsumerRecord<String, V> r, Exception ex) {
    int attempt = retries.computeIfAbsent(tp, k -> new ConcurrentHashMap<>())
        .merge(r.offset(), 1, Integer::sum);

    if (attempt <= props.getMaxRetries()) return false;

    dlq.publish(r, ex);
    metrics.dlq.increment();
    markSuccess(tp, r.offset());
    clearRetry(tp, r.offset());
    return true;
  }

  private void adaptivePauseResume() {
    if (!props.getBackpressure().isEnabled()) return;
    long now = System.currentTimeMillis();
    if (!bp.canDecide(now)) return;

    long backlog = totalBacklog();
    int hi = bp.highWatermark();
    int lo = bp.lowWatermark();

    if (backlog >= hi) {
      List<TopicPartition> candidates = new ArrayList<>(queues.keySet());
      candidates.sort((a, b) -> Integer.compare(sizeOf(b), sizeOf(a)));
      for (TopicPartition tp : candidates) {
        if (paused.add(tp)) consumer.pause(List.of(tp));
        if (totalBacklog() < hi) break;
      }
    } else if (backlog <= lo) {
      if (!paused.isEmpty()) {
        consumer.resume(new ArrayList<>(paused));
        paused.clear();
      }
    }
    metrics.setPausedPartitions(paused.size());
  }

  private int sizeOf(TopicPartition tp) {
    ArrayDeque<?> q = queues.get(tp);
    return q == null ? 0 : q.size();
  }

  private long totalBacklog() {
    long s = 0;
    for (ArrayDeque<?> q : queues.values()) s += q.size();
    return s;
  }

  private void commitMaybe() {
    long now = System.currentTimeMillis();
    if (now - lastCommitAtMs < props.getCommitIntervalMs()) return;
    commitNow();
    lastCommitAtMs = now;
  }

  private void commitNow() {
    if (lastSuccess.isEmpty()) return;
    Map<TopicPartition, OffsetAndMetadata> offsets = new HashMap<>();
    lastSuccess.forEach((tp, off) -> offsets.put(tp, new OffsetAndMetadata(off + 1)));
    consumer.commitSync(offsets);
  }

  private void updateGauges() {
    metrics.setBacklog(totalBacklog());
    metrics.setPausedPartitions(paused.size());
  }

  private void markSuccess(TopicPartition tp, long offset) { lastSuccess.put(tp, offset); }
  private void clearRetry(TopicPartition tp, long offset) {
    Map<Long, Integer> m = retries.get(tp);
    if (m != null) m.remove(offset);
  }
}
