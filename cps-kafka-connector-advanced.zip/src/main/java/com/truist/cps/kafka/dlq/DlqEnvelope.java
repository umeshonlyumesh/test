package com.truist.cps.kafka.dlq;

import java.time.Instant;

/**
 * DLQ payload that preserves original coordinates and failure reason.
 */
public record DlqEnvelope(
    String originalTopic,
    int originalPartition,
    long originalOffset,
    String originalKey,
    String errorClass,
    String errorMessage,
    Instant failedAt,
    Object payload
) {}
