package com.truist.cps.kafka.dlq;

import com.truist.cps.kafka.consumer.DlqPublisher;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.time.Instant;

/**
 * Publishes poison records to a Kafka DLQ topic as a DlqEnvelope.
 */
public final class KafkaDlqPublisher<V> implements DlqPublisher<V> {
  private final ProducerClient producer;
  private final String dlqTopic;

  public KafkaDlqPublisher(ProducerClient producer, String dlqTopic) {
    this.producer = producer;
    this.dlqTopic = dlqTopic;
  }

  @Override
  public void publish(ConsumerRecord<String, V> record, Exception cause) {
    DlqEnvelope env = new DlqEnvelope(
        record.topic(),
        record.partition(),
        record.offset(),
        record.key(),
        cause.getClass().getName(),
        cause.getMessage() == null ? "" : cause.getMessage(),
        Instant.now(),
        record.value()
    );
    producer.send(dlqTopic, record.key(), env);
  }
}
