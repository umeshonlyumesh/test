package com.truist.cps.kafka.dlq;

/**
 * Minimal producer abstraction for DLQ publishing.
 */
public interface ProducerClient {
  void send(String topic, String key, Object value);
}
