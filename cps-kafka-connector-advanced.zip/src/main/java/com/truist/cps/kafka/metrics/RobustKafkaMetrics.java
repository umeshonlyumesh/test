package com.truist.cps.kafka.metrics;

import io.micrometer.core.instrument.*;
import io.micrometer.core.instrument.binder.BaseUnits;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Micrometer meters for one consumer (topic+group).
 */
public final class RobustKafkaMetrics {
  public final Timer pollTimer;
  public final Timer processTimer;
  public final Counter processed;
  public final Counter failed;
  public final Counter badPayload;
  public final Counter dlq;

  private final AtomicLong backlog = new AtomicLong(0);
  private final AtomicInteger inflight = new AtomicInteger(0);
  private final AtomicInteger pausedPartitions = new AtomicInteger(0);

  public RobustKafkaMetrics(MeterRegistry registry, String topic, String groupId) {
    Tags tags = Tags.of("topic", topic, "group", groupId);

    pollTimer = Timer.builder("robust.kafka.poll.duration").tags(tags).register(registry);
    processTimer = Timer.builder("robust.kafka.process.duration").tags(tags).register(registry);

    processed = Counter.builder("robust.kafka.records.processed").tags(tags).register(registry);
    failed = Counter.builder("robust.kafka.records.failed").tags(tags).register(registry);
    badPayload = Counter.builder("robust.kafka.records.bad_payload").tags(tags).register(registry);
    dlq = Counter.builder("robust.kafka.records.dlq").tags(tags).register(registry);

    Gauge.builder("robust.kafka.backlog", backlog, AtomicLong::get).baseUnit(BaseUnits.OBJECTS).tags(tags).register(registry);
    Gauge.builder("robust.kafka.inflight", inflight, AtomicInteger::get).baseUnit(BaseUnits.OBJECTS).tags(tags).register(registry);
    Gauge.builder("robust.kafka.paused.partitions", pausedPartitions, AtomicInteger::get).baseUnit(BaseUnits.OBJECTS).tags(tags).register(registry);
  }

  public void setBacklog(long v) { backlog.set(v); }
  public void incInflight() { inflight.incrementAndGet(); }
  public void decInflight() { inflight.decrementAndGet(); }
  public void setPausedPartitions(int v) { pausedPartitions.set(v); }
}
