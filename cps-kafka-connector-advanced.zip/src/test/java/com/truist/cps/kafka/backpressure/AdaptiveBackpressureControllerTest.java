package com.truist.cps.kafka.backpressure;

import com.truist.cps.kafka.config.RobustKafkaProperties;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdaptiveBackpressureControllerTest {

  @Test
  void watermarksRespectMinimum() {
    var cfg = new RobustKafkaProperties.Backpressure();
    cfg.setMinHighWatermark(100);
    cfg.setTargetBacklogMs(2000);

    var c = new AdaptiveBackpressureController(cfg);
    c.recordLatencyNanos(100_000); // 0.1ms
    assertTrue(c.highWatermark() >= 100);
    assertTrue(c.lowWatermark() >= 1);
  }

  @Test
  void cooldownWorks() {
    var cfg = new RobustKafkaProperties.Backpressure();
    cfg.setPauseCooldownMs(500);
    var c = new AdaptiveBackpressureController(cfg);

    assertTrue(c.canDecide(1000));
    assertFalse(c.canDecide(1200));
    assertTrue(c.canDecide(2000));
  }
}
