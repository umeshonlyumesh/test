package com.truist.cps.kafka.integration;

import com.truist.cps.kafka.annotation.KafkaConsumerListener;
import com.truist.cps.kafka.dlq.ProducerClient;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@Testcontainers
@SpringBootTest(classes = RobustKafkaConsumerIntegrationTest.TestApp.class)
class RobustKafkaConsumerIntegrationTest {

  @Container
  static KafkaContainer kafka = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.1"));

  static final CountDownLatch latch = new CountDownLatch(3);

  @DynamicPropertySource
  static void props(DynamicPropertyRegistry r) {
    r.add("kafka.bootstrap.servers", () -> kafka.getBootstrapServers());
    r.add("robust.kafka.value.deserializer", () -> "org.apache.kafka.common.serialization.StringDeserializer");
    r.add("robust.kafka.key.deserializer", () -> "org.apache.kafka.common.serialization.StringDeserializer");
    r.add("robust.kafka.enabled", () -> "true");
    r.add("robust.kafka.poll-timeout-ms", () -> "200");
    r.add("robust.kafka.commit-interval-ms", () -> "200");
    r.add("robust.kafka.max-retries", () -> "1");
    r.add("robust.kafka.backpressure.enabled", () -> "false");
  }

  @Test
  void consumesRecords() throws Exception {
    String topic = "it-topic";

    Properties p = new Properties();
    p.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getBootstrapServers());
    p.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
    p.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

    try (KafkaProducer<String, String> producer = new KafkaProducer<>(p)) {
      producer.send(new ProducerRecord<>(topic, "k1", "v1")).get();
      producer.send(new ProducerRecord<>(topic, "k2", "v2")).get();
      producer.send(new ProducerRecord<>(topic, "k3", "v3")).get();
    }

    assertTrue(latch.await(15, TimeUnit.SECONDS), "did not consume all records");
  }

  @SpringBootApplication(scanBasePackages = "com.truist.cps.kafka")
  static class TestApp {
    @Bean ProducerClient producerClient() { return (t, k, v) -> {}; }

    @Bean Listener listener() { return new Listener(); }
  }

  static class Listener {
    @KafkaConsumerListener(topic = "it-topic", groupId = "it-group")
    public void onMessage(org.apache.kafka.clients.consumer.ConsumerRecord<String, Object> record) {
      latch.countDown();
    }
  }
}
