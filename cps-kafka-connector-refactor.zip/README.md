# cps-kafka-connector-refactor

Custom annotation-based Kafka consumer using core kafka-clients (NO Spring Kafka).

## Features
- `@KafkaConsumerListener(topic, groupId)`
- Spring Boot AutoConfiguration (Boot 3) via `AutoConfiguration.imports`
- Robust consumer:
  - single poll/commit thread (platform thread)
  - virtual threads for processing
  - per-partition ordering
  - manual commit per partition
  - bad payload (Avro deserialize failure) => log + commit+continue
  - processing failure => retry N times; then DLQ placeholder; commit+continue

## Run demo
```bash
mvn clean spring-boot:run
```
