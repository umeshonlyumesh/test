package com.truist.cps.kafka.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface KafkaConsumerListener {
  String topic();
  String groupId();
}
