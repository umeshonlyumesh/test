package com.truist.cps.kafka.autoconfig;

import com.truist.cps.kafka.consumer.KafkaConsumerRunner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@AutoConfiguration
public class RobustKafkaAutoConfiguration {

  @Bean
  public KafkaConsumerRunner kafkaConsumerRunner(ApplicationContext ctx, Environment env) {
    return new KafkaConsumerRunner(ctx, env);
  }
}
