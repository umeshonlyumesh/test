package com.truist.cps.kafka.consumer;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RobustKafkaConsumer<V> {

  private final KafkaConsumer<String, V> consumer;
  private final String topic;
  private final RecordProcessor<V> processor;
  private final DlqPublisher<V> dlq;

  private final int maxRetries;
  private final long pollTimeoutMs;

  private final AtomicBoolean running = new AtomicBoolean(false);

  private final Map<TopicPartition, Long> lastSuccess = new ConcurrentHashMap<>();
  private final Map<TopicPartition, Map<Long, Integer>> retries = new ConcurrentHashMap<>();

  private final ExecutorService pollExecutor;
  private final ExecutorService workerPool;

  public RobustKafkaConsumer(KafkaConsumer<String, V> consumer,
                            String topic,
                            RecordProcessor<V> processor,
                            DlqPublisher<V> dlq,
                            int maxRetries,
                            long pollTimeoutMs) {

    this.consumer = Objects.requireNonNull(consumer, "consumer");
    this.topic = Objects.requireNonNull(topic, "topic");
    this.processor = Objects.requireNonNull(processor, "processor");
    this.dlq = Objects.requireNonNull(dlq, "dlq");
    this.maxRetries = maxRetries;
    this.pollTimeoutMs = pollTimeoutMs;

    this.pollExecutor = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "robust-kafka-poll-" + this.topic);
      t.setDaemon(true);
      return t;
    });

    this.workerPool = Executors.newThreadPerTaskExecutor(
        Thread.ofVirtual().name("robust-kafka-worker-" + this.topic + "-", 0).factory()
    );
  }

  public void start() {
    if (!running.compareAndSet(false, true)) return;
    pollExecutor.submit(this::pollLoop);
  }

  public void stop() {
    if (!running.compareAndSet(true, false)) return;
    consumer.wakeup();
    pollExecutor.shutdown();
    workerPool.shutdown();
  }

  public boolean isRunning() {
    return running.get();
  }

  private void pollLoop() {
    try {
      consumer.subscribe(List.of(topic), new ConsumerRebalanceListener() {
        @Override
        public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
          commit();
        }

        @Override
        public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
        }
      });

      while (running.get()) {
        ConsumerRecords<String, V> records = consumer.poll(Duration.ofMillis(pollTimeoutMs));
        if (records.isEmpty()) continue;

        for (TopicPartition tp : records.partitions()) {
          for (ConsumerRecord<String, V> r : records.records(tp)) {
            boolean ok = processOne(tp, r);
            if (!ok) break;
          }
        }

        commit();
      }
    } catch (WakeupException ignore) {
    } finally {
      try { commit(); } catch (Exception ignore) {}
      try { consumer.close(); } catch (Exception ignore) {}
    }
  }

  private boolean processOne(TopicPartition tp, ConsumerRecord<String, V> r) {
    if (r.value() == null) {
      System.err.printf("BAD_PAYLOAD | topic=%s partition=%d offset=%d%n",
          r.topic(), r.partition(), r.offset());
      lastSuccess.put(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;
    }

    try {
      Future<?> f = workerPool.submit(() -> {
        try {
          processor.process(r);
        } catch (Exception e) {
          throw new CompletionException(e);
        }
      });

      f.get();
      lastSuccess.put(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;

    } catch (ExecutionException ee) {
      Throwable cause = ee.getCause();
      if (cause instanceof CompletionException ce && ce.getCause() != null) {
        cause = ce.getCause();
      }
      return handleFailure(tp, r, cause);

    } catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
      return handleFailure(tp, r, ie);
    }
  }

  private boolean handleFailure(TopicPartition tp, ConsumerRecord<String, V> r, Throwable t) {
    int attempt = incRetry(tp, r.offset());

    if (attempt <= maxRetries) {
      System.err.printf("PROCESSING_FAILED_RETRY | topic=%s partition=%d offset=%d attempt=%d error=%s%n",
          r.topic(), r.partition(), r.offset(), attempt, t.toString());
      return false;
    }

    System.err.printf("POISON_TO_DLQ | topic=%s partition=%d offset=%d attempts=%d error=%s%n",
        r.topic(), r.partition(), r.offset(), attempt, t.toString());

    dlq.publish(r, (t instanceof Exception e) ? e : new RuntimeException(t));

    lastSuccess.put(tp, r.offset());
    clearRetry(tp, r.offset());
    return true;
  }

  private void commit() {
    if (lastSuccess.isEmpty()) return;

    Map<TopicPartition, OffsetAndMetadata> map = new HashMap<>();
    lastSuccess.forEach((tp, off) -> map.put(tp, new OffsetAndMetadata(off + 1)));
    consumer.commitSync(map);
  }

  private int incRetry(TopicPartition tp, long offset) {
    return retries.computeIfAbsent(tp, k -> new ConcurrentHashMap<>())
        .merge(offset, 1, Integer::sum);
  }

  private void clearRetry(TopicPartition tp, long offset) {
    Map<Long, Integer> m = retries.get(tp);
    if (m != null) m.remove(offset);
  }

  @FunctionalInterface
  public interface RecordProcessor<V> {
    void process(ConsumerRecord<String, V> record) throws Exception;
  }

  @FunctionalInterface
  public interface DlqPublisher<V> {
    void publish(ConsumerRecord<String, V> record, Exception cause);
  }
}
