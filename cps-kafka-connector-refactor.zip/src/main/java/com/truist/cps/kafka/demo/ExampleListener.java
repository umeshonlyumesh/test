package com.truist.cps.kafka.demo;

import com.truist.cps.kafka.annotation.KafkaConsumerListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Component;

@Component
public class ExampleListener {

  @KafkaConsumerListener(topic = "payments-topic", groupId = "payments-group")
  public void onMessage(ConsumerRecord<String, Object> record) {
    System.out.printf("RECEIVED | topic=%s partition=%d offset=%d value=%s%n",
        record.topic(), record.partition(), record.offset(), record.value());
  }
}
