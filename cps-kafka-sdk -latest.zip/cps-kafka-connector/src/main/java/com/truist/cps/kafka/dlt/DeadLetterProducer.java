package com.truist.cps.kafka.dlt;

import com.truist.cps.kafka.metrics.SdkKafkaMetrics;
import com.truist.cps.kafka.config.KafkaSdkProperties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Objects;

/**
 * Publishes failed consumer records to a dead-letter topic (DLT), enriching the outgoing message with
 * diagnostic headers (error type, original topic/partition/offset).
 * <p>
 * This utility is designed to be used as a recoverer for Spring Kafka's {@code DefaultErrorHandler} so that after
 * retries are exhausted (or for not-retryable exceptions) the record is sent to DLT and the consumer
 * offset can be committed.
 */
public class DeadLetterProducer {

    private static final Logger log = LoggerFactory.getLogger(DeadLetterProducer.class);

    private final KafkaTemplate<Object, Object> template;
    private final DltTopicResolver resolver;

    private final SdkKafkaMetrics metrics;

    private final KafkaSdkProperties props;

    /**
     * Create a DLT publisher.
     *
     * @param template KafkaTemplate used for publishing (required)
     * @param resolver destination resolver (required)
     */
    public DeadLetterProducer(KafkaTemplate<Object, Object> template, DltTopicResolver resolver, SdkKafkaMetrics metrics, KafkaSdkProperties props) {
        this.template = Objects.requireNonNull(template, "template");
        this.resolver = Objects.requireNonNull(resolver, "resolver");
        this.metrics = Objects.requireNonNull(metrics, "metrics");
        this.props = Objects.requireNonNull(props, "props");
    }

    /**
     * Publish the given failed record to a DLT topic.
     *
     * @param record the record that failed processing (required)
     * @param exception the exception that caused the failure (required)
     */
    public void publish(ConsumerRecord<?, ?> record, Exception exception) {
        Objects.requireNonNull(record, "record");
        Objects.requireNonNull(exception, "exception");

        String dltTopic = resolver.resolveTopic(record, exception);
        if (dltTopic == null || dltTopic.isBlank()) {
            throw new IllegalStateException("DLT topic resolver returned blank topic");
        }

        Headers headers = buildHeaders(record, exception);

        ProducerRecord<Object, Object> out = new ProducerRecord<>(
                dltTopic,
                record.partition(),
                record.key(),
                record.value(),
                headers
        );

        // Fire-and-forget; DefaultErrorHandler will commit recovered offsets after this returns.
        var future = template.send(out);

        if (props.isDltSyncSend()) {
            try {
                future.get(props.getDltSendTimeoutMs(), java.util.concurrent.TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                // If DLT publish fails in sync mode, rethrow to avoid committing offset.
                throw new RuntimeException("DLT publish failed", e);
            }
        }

        metrics.incrementDlt();

        log.warn("Published to DLT topic={} originalTopic={} partition={} offset={} error={}",
                dltTopic, record.topic(), record.partition(), record.offset(),
                exception.getClass().getSimpleName());
    }

    /**
     * Build diagnostic headers for the DLT record.
     *
     * @param record original record
     * @param exception failure
     * @return headers to attach to the DLT record
     */
    protected Headers buildHeaders(ConsumerRecord<?, ?> record, Exception exception) {
        RecordHeaders headers = new RecordHeaders();

        put(headers, DeadLetterHeaders.X_ERROR_CLASS, exception.getClass().getName());
        put(headers, DeadLetterHeaders.X_ERROR_MESSAGE, safeMessage(exception));
        put(headers, DeadLetterHeaders.X_ORIGINAL_TOPIC, record.topic());
        put(headers, DeadLetterHeaders.X_ORIGINAL_PARTITION, Integer.toString(record.partition()));
        put(headers, DeadLetterHeaders.X_ORIGINAL_OFFSET, Long.toString(record.offset()));
        put(headers, DeadLetterHeaders.X_DLT_TIMESTAMP, Long.toString(Instant.now().toEpochMilli()));

        // Preserve existing headers.
        if (record.headers() != null) {
            record.headers().forEach(headers::add);
        }

        return headers;
    }

    private static void put(Headers headers, String key, String value) {
        if (value == null) return;
        headers.add(key, value.getBytes(StandardCharsets.UTF_8));
    }

    private static String safeMessage(Exception ex) {
        String msg = ex.getMessage();
        if (msg == null) return "";
        return msg.length() > 1024 ? msg.substring(0, 1024) : msg;
    }
}
