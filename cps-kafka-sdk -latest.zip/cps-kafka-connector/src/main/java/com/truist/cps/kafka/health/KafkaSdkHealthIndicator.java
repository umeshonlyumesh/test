package com.truist.cps.kafka.health;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Actuator {@link HealthIndicator} for the Kafka SDK.
 * <p>
 * Responsibility:
 * <ul>
 *   <li>Performs a lightweight broker reachability check using Kafka {@link Admin}.</li>
 *   <li>Reports UP/DOWN with diagnostic details suitable for monitoring.</li>
 * </ul>
 * <p>
 * Notes:
 * <ul>
 *   <li>This health check does not validate topic existence or consumer lag.</li>
 *   <li>It uses the same bootstrap servers and SSL configuration as the SDK.</li>
 * </ul>
 */
public class KafkaSdkHealthIndicator implements HealthIndicator {

    private static final Logger log = LoggerFactory.getLogger(KafkaSdkHealthIndicator.class);

    private final KafkaSdkProperties props;

    /**
     * Create the indicator.
     *
     * @param props SDK properties (required)
     */
    public KafkaSdkHealthIndicator(KafkaSdkProperties props) {
        this.props = Objects.requireNonNull(props, "props");
    }

    @Override
    public Health health() {
        String bootstrap = props.getBootstrapServers();
        if (bootstrap == null || bootstrap.isBlank()) {
            return Health.unknown()
                    .withDetail("reason", "kafka.sdk.bootstrap-servers is not configured")
                    .build();
        }

        Map<String, Object> cfg = new HashMap<>();
        cfg.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);

        KafkaSdkProperties.SslProperties ssl = props.getSsl();
        if (ssl != null && ssl.isEnabled()) {
            cfg.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
            put(cfg, "ssl.truststore.location", ssl.getTruststoreLocation());
            put(cfg, "ssl.truststore.password", ssl.getTruststorePassword());
            put(cfg, "ssl.keystore.location", ssl.getKeystoreLocation());
            put(cfg, "ssl.keystore.password", ssl.getKeystorePassword());
            put(cfg, "ssl.key.password", ssl.getKeyPassword());
        }

        long timeoutMs = props.getHealthTimeoutMs() != null ? props.getHealthTimeoutMs() : 2000L;

        try (Admin admin = Admin.create(cfg)) {
            String clusterId = admin.describeCluster().clusterId().get(timeoutMs, TimeUnit.MILLISECONDS);
            int nodeCount = admin.describeCluster().nodes().get(timeoutMs, TimeUnit.MILLISECONDS).size();

            return Health.up()
                    .withDetail("bootstrapServers", bootstrap)
                    .withDetail("clusterId", clusterId)
                    .withDetail("nodeCount", nodeCount)
                    .build();
        } catch (Exception e) {
            log.warn("Kafka SDK health check failed: {}", e.toString());
            return Health.down(e)
                    .withDetail("bootstrapServers", bootstrap)
                    .build();
        }
    }

    private static void put(Map<String, Object> cfg, String key, String value) {
        if (value != null && !value.isBlank()) {
            cfg.put(key, value);
        }
    }
}
