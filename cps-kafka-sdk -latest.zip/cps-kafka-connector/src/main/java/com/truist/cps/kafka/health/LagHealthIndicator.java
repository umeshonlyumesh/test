package com.truist.cps.kafka.health;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.metrics.SdkLagStateTracker;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

import java.util.Comparator;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Reports DOWN when consumer lag exceeds the configured threshold for N consecutive intervals.
 */
public class LagHealthIndicator implements HealthIndicator {

    private final KafkaSdkProperties props;
    private final SdkLagStateTracker tracker;

    public LagHealthIndicator(KafkaSdkProperties props, SdkLagStateTracker tracker) {
        this.props = Objects.requireNonNull(props, "props");
        this.tracker = Objects.requireNonNull(tracker, "tracker");
    }

    @Override
    public Health health() {
        if (props.getLagHealthEnabled() == null || !props.getLagHealthEnabled()) {
            return Health.unknown().withDetail("reason", "lagHealthEnabled=false").build();
        }
        long threshold = props.getLagHealthThreshold() == null ? 10000L : props.getLagHealthThreshold();
        int consecutive = props.getLagHealthConsecutiveIntervals() == null ? 3 : props.getLagHealthConsecutiveIntervals();

        Map<SdkLagStateTracker.LagKey, Long> snap = tracker.snapshotLag();
        if (snap.isEmpty()) {
            return Health.unknown().withDetail("reason", "no lag data yet (enable lag-metrics-enabled)").build();
        }

        // find worst lag
        var worst = snap.entrySet().stream().max(Map.Entry.comparingByValue()).orElse(null);
        if (worst == null) {
            return Health.unknown().build();
        }

        SdkLagStateTracker.LagKey k = worst.getKey();
        long worstLag = worst.getValue() == null ? 0L : worst.getValue();
        int cons = tracker.consecutiveAbove(k.groupId, k.topic, k.partition);

        Health.Builder b = (worstLag > threshold && cons >= consecutive) ? Health.down() : Health.up();

        b.withDetail("threshold", threshold)
         .withDetail("consecutiveRequired", consecutive)
         .withDetail("worstKey", k.toString())
         .withDetail("worstLag", worstLag)
         .withDetail("worstConsecutive", cons);

        // include top 10 lags for troubleshooting
        b.withDetail("topLag", snap.entrySet().stream()
                .sorted((a, c) -> Long.compare(c.getValue(), a.getValue()))
                .limit(10)
                .collect(Collectors.toMap(e -> e.getKey().toString(), Map.Entry::getValue, (x,y)->x, java.util.LinkedHashMap::new)));

        return b.build();
    }
}
