# Security Notes

## Fixed: CVE-2026-1225 / GHSA-qqpg-mvqg-649v (logback)

The demo client and SDK depend on Logback via Spring Boot starters (transitive).
We pin Logback to **1.5.25** (patched) using:
- `<logback.version>1.5.25</logback.version>` and
- dependencyManagement overrides for `logback-core` and `logback-classic`.

References:
- Logback release notes for 1.5.25 (fixes CVE-2026-1225)  
- GitHub advisory GHSA-qqpg-mvqg-649v (aliases CVE-2026-1225)  
