# CPS Kafka SDK (Spring Kafka based)

This module provides:
- `SdkKafkaProducer` (wrapper over `KafkaTemplate<String,Object>`)
- `sdkKafkaListenerContainerFactory` with MANUAL ack + pauseImmediate + error handler
- `SdkConsumerManager` to pause/resume listeners by id
- Auto-configuration via `AutoConfiguration.imports`

## Client usage

### 1) Add dependency
```xml
<dependency>
  <groupId>com.truist.cps.kafka</groupId>
  <artifactId>cps-kafka-connector</artifactId>
  <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### 2) Configure
```yaml
kafka:
  sdk:
    bootstrap-servers: "localhost:9092"
    group-id: "demo-group"
    client-id: "demo-app"
    format: "json"
    concurrency: 1
    poll-timeout-ms: 2000
    idle-between-polls-ms: 0
    missing-topics-fatal: false
```

### 3) Listener
```java
@KafkaListener(
  id = "demoListener",
  topics = "\${app.topic}",
  containerFactory = "sdkKafkaListenerContainerFactory"
)
public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {
  try {
    // process
    ack.acknowledge(); // commit on success
  } catch (Exception e) {
    // do not ack -> offset not committed
    throw e;
  }
}
```

### 4) Pause/Resume
```java
@RestController
@RequiredArgsConstructor
class ControlController {
  private final SdkConsumerManager manager;

  @PostMapping("/pause/{id}") void pause(@PathVariable String id){ manager.pause(id); }
  @PostMapping("/resume/{id}") void resume(@PathVariable String id){ manager.resume(id); }
}
```

## Notes
- This SDK intentionally does not commit on failure; your listener controls commits via `Acknowledgment`.
- Avro support is stubbed (logs a warning) unless you add Confluent serializers/deserializers.


## Poison payload handling
- SDK configures `ErrorHandlingDeserializer` so deserialization/schema errors are routed to the error handler.
- The default error handler **skips poison records and commits the offset** (so they don't block the consumer).
- For non-poison exceptions, the handler retries with backoff; after retries are exhausted it **does not commit** and fails fast.

## Configurable DLT topic name resolver

You can control where dead-lettered records go:

- `kafka.sdk.dlt-topic`: fixed DLT topic (overrides suffix-based naming)
- `kafka.sdk.dlt-topic-suffix`: suffix appended to original topic when fixed topic is not set (default `.DLT`)

Example (fixed topic):

```yaml
kafka:
  sdk:
    dlt-enabled: true
    dlt-topic: "payment-events.DLT"
```

## Dead-letter enrichment headers

When DLT is enabled, the SDK adds diagnostic headers to the DLT message:

- `x-error-class`, `x-error-message`
- `x-original-topic`, `x-original-partition`, `x-original-offset`
- `x-dlt-timestamp`

## Retry configuration

Retry is performed by Spring Kafka's `DefaultErrorHandler` using exponential backoff.

```yaml
kafka:
  sdk:
    retry:
      enabled: true
      initial-backoff-ms: 1000
      backoff-multiplier: 2.0
      max-backoff-ms: 60000
      max-elapsed-ms: 300000
```

## Per-exception retry policy

- `kafka.sdk.not-retryable-exceptions`: list of fully-qualified exception class names that should *not* be retried
- `kafka.sdk.retryable-exceptions`: list of fully-qualified exception class names that are explicitly retryable

If `retryable-exceptions` is empty, all exceptions not listed in `not-retryable-exceptions` are treated as retryable.

```yaml
kafka:
  sdk:
    not-retryable-exceptions:
      - "java.lang.IllegalArgumentException"
      - "org.springframework.kafka.support.serializer.DeserializationException"
    retryable-exceptions:
      - "java.net.SocketTimeoutException"
      - "java.io.IOException"
```

## Metrics

If Micrometer is present and a `MeterRegistry` bean exists, the SDK emits:

- `kafka.sdk.retry.count`
- `kafka.sdk.dlt.count`
- `kafka.sdk.poison.skip.count`

If Micrometer is absent, metrics are no-op.

## Actuator health and monitoring

The SDK can expose an actuator health indicator (requires `spring-boot-starter-actuator` in the application).

### Recommended: add actuator in your client application
```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

### SDK health indicator
When actuator is present, the SDK registers a `HealthIndicator` named `sdkKafkaHealthIndicator`.
It checks broker reachability via Kafka `AdminClient`.

```yaml
kafka:
  sdk:
    health-enabled: true
    health-timeout-ms: 2000
```

Expose endpoints (example):
```yaml
management:
  endpoint:
    health:
      show-details: "when_authorized"
  endpoints:
    web:
      exposure:
        include: "health,info,metrics,prometheus"
```

## Production hardening features (SDK)

### Safe structured logging + MDC correlation
- Adds MDC fields: `kafka.topic`, `kafka.partition`, `kafka.offset`, `corrId` (from allowlisted headers).
- Debug log includes safe key (hashed by default) and allowlisted headers.

Configure:
```yaml
kafka:
  sdk:
    logging:
      log-keys: true
      key-hash: true
      log-headers: true
      header-allowlist: ["traceparent","x-correlation-id","x-request-id"]
      log-payload: false
      max-field-len: 256
```

### Retry logging throttle
Retry logs are throttled to attempts 1,2,4,8,... to avoid log storms.

### Auto-pause on repeated failures (optional)
Protect downstream dependencies by pausing the container when failures spike, then auto-resuming.

```yaml
kafka:
  sdk:
    auto-pause:
      enabled: true
      failure-threshold: 10
      window-seconds: 30
      pause-seconds: 60
```

### Stronger DLT guarantees (optional)
Make DLT publishing synchronous (wait for broker ack). If the DLT publish fails, the SDK will NOT commit the offset.

```yaml
kafka:
  sdk:
    dlt-enabled: true
    dlt-sync-send: true
    dlt-send-timeout-ms: 5000
```

### Listener state endpoint (Actuator)
When actuator is enabled and exposed:
- `/actuator/sdkKafkaListenerState` shows listener running/paused state.

## Consumer lag gauge (AdminClient)

Enable consumer lag metrics (per topic-partition + groupId) using Kafka `AdminClient`.

```yaml
kafka:
  sdk:
    lag-metrics-enabled: true
    lag-metrics-interval-seconds: 30
```

Metric emitted (Micrometer):
- `kafka.sdk.consumer.lag{groupId,topic,partition}`

## Configurable header redaction policy

Logging supports two header modes:

- `ALLOWLIST` (default, safest): only log allowlisted headers
- `BLOCKLIST`: log all headers except blocklisted headers

Also supports prefix-based redaction: any header name starting with a configured prefix will have its value replaced with `***REDACTED***`.

```yaml
kafka:
  sdk:
    logging:
      header-redaction-mode: ALLOWLIST
      header-allowlist: ["traceparent","x-correlation-id","x-request-id"]
      header-blocklist: ["authorization","cookie","set-cookie"]
      header-prefix-redact: ["x-secret-","x-token-"]
```

## Lag health indicator + notifications

### Lag health indicator
Reports `/actuator/health` as DOWN when lag is above threshold for N consecutive intervals.

```yaml
kafka:
  sdk:
    lag-metrics-enabled: true
    lag-metrics-interval-seconds: 30

    lag-health-enabled: true
    lag-health-threshold: 10000
    lag-health-consecutive-intervals: 3
```

### Email notifications (optional)
When lag health is DOWN, the SDK can send an email alert (with cooldown).

Client application must configure SMTP via `spring.mail.*` and include actuator endpoints exposure.

```yaml
kafka:
  sdk:
    lag-alert-notifications:
      enabled: true
      to: ["ops-team@yourcompany.com"]
      from: "kafka-alerts@yourcompany.com"
      subject: "[Kafka SDK] Lag alert {groupId} {topic}-{partition}"
      cooldown-minutes: 30
```

SMTP example:
```yaml
spring:
  mail:
    host: smtp.yourcompany.com
    port: 587
    username: your-user
    password: your-pass
    properties:
      mail.smtp.auth: true
      mail.smtp.starttls.enable: true
```

Security note: Do not expose actuator publicly; protect with auth and least privilege.

### Microsoft Teams notifications (optional)

You can send lag alerts to Microsoft Teams using an Incoming Webhook.

```yaml
kafka:
  sdk:
    lag-alert-notifications:
      enabled: true
      teams-webhook-url: "https://outlook.office.com/webhook/XXXX"
      cooldown-minutes: 30
```

No additional dependencies are required beyond Spring Web (already present).
