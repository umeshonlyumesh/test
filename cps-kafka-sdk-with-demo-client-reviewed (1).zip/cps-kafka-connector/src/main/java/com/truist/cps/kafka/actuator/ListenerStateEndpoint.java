package com.truist.cps.kafka.actuator;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.time.Instant;
import java.util.*;

/**
 * Actuator endpoint exposing runtime state of Kafka listener containers managed by the SDK.
 * <p>
 * Endpoint id: {@code sdkKafkaListenerState}
 */
@Endpoint(id = "sdkKafkaListenerState")
public class ListenerStateEndpoint {

    private final KafkaListenerEndpointRegistry registry;

    public ListenerStateEndpoint(KafkaListenerEndpointRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    @ReadOperation
    public Map<String, Object> state() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("timestamp", Instant.now().toString());

        List<Map<String, Object>> listeners = new ArrayList<>();
        for (MessageListenerContainer c : registry.getListenerContainers()) {
            Map<String, Object> one = new LinkedHashMap<>();
            one.put("listenerId", c.getListenerId());
            one.put("running", c.isRunning());
            one.put("pauseRequested", c.isPauseRequested());
            one.put("containerGroup", c.getGroupId());
            listeners.add(one);
        }
        out.put("listeners", listeners);
        return out;
    }
}
