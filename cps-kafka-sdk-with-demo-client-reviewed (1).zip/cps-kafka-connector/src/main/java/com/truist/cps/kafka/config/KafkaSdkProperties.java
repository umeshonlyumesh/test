package com.truist.cps.kafka.config;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.util.List;

/**
 * Top-level configuration properties for the CPS Kafka SDK.
 *
 * <p>All properties are under the prefix {@code kafka.sdk}.</p>
 *
 * <p>This class intentionally keeps configuration concerns in one place so that:
 * <ul>
 *   <li>SDK auto-configuration can be fully driven by configuration</li>
 *   <li>Clients can override individual beans if needed</li>
 *   <li>Operational behavior (retry, DLT, logging, lag health) is explicit and reviewable</li>
 * </ul>
 * </p>
 */
@Data
@NoArgsConstructor
@Validated
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {

    /** Comma-separated bootstrap servers (e.g., {@code host1:9092,host2:9092}). */
    @NotBlank
    private String bootstrapServers;

    /** Default consumer group id used by the SDK consumer factory (if listener does not override groupId). */
    @NotBlank
    private String groupId;

    /** Logical client id prefix; SDK appends {@code -producer}/{@code -consumer}. */
    @NotBlank
    private String clientId = "cps-kafka";

    /** Message format: {@code json} or {@code avro}. */
    @NotBlank
    private String format = "json";

    /** Confluent Schema Registry URL (required when {@code format=avro}). */
    private String schemaRegistryUrl;

    /** SSL / mTLS settings for Kafka brokers + schema registry. */
    private SslProperties ssl = new SslProperties();

    /** If true, missing topics do not fail startup (helpful for lower env). */
    private boolean missingTopicsFatal = false;

    /** Concurrency for listener containers created with the SDK container factory. */
    @Min(1) @Max(64)
    private int concurrency = 1;

    /** Idle between polls (ms). */
    @Min(0)
    private long idleBetweenPollsMs = 0;

    /** Poll timeout (ms). */
    @Min(50)
    private long pollTimeoutMs = 2000;

    /** {@code max.poll.records}. */
    @Min(1) @Max(5000)
    private int maxPollRecords = 100;

    /** {@code max.poll.interval.ms}. */
    @Min(1000)
    private int maxPollIntervalMs = 300000;

    /** {@code auto.offset.reset}. */
    @NotBlank
    private String autoOffsetReset = "earliest";

    /** Producer {@code delivery.timeout.ms}. */
    @Min(1000)
    private int producerDeliveryTimeoutMs = 120000;

    /** Producer {@code acks} ("all" recommended). */
    @NotBlank
    private String producerAcks = "all";

    /** Producer {@code retries}. Use {@link Integer#MAX_VALUE} for "retry until delivery timeout". */
    @Min(0)
    private int producerRetries = Integer.MAX_VALUE;

    /** Enable idempotence. */
    private boolean enableIdempotence = true;

    /** {@code max.in.flight.requests.per.connection} (keep <= 5 with idempotence). */
    @Min(1) @Max(5)
    private int maxInFlightRequestsPerConnection = 5;

    // -------------------------
    // Retry configuration
    // -------------------------

    /**
     * Retry configuration applied by the SDK error handler.
     *
     * <p>The SDK uses retry/backoff for retryable exceptions. When retries are exhausted,
     * the record can be published to DLT (if enabled) and then the offset is committed.</p>
     */
    private RetryProperties retry = new RetryProperties();

    /**
     * Fully-qualified exception class names that are considered NOT retryable (poison).
     * These are handled immediately by the recoverer (DLT/skip).
     */
    private List<String> notRetryableExceptions = List.of(
            "org.apache.kafka.common.errors.SerializationException",
            "org.springframework.kafka.support.serializer.DeserializationException",
            "org.apache.kafka.common.errors.RecordTooLargeException",
            "java.lang.IllegalArgumentException"
    );

    /**
     * Fully-qualified exception class names that are considered retryable.
     * Exceptions not listed in {@code notRetryableExceptions} are treated as retryable.
     */
    private List<String> retryableExceptions = List.of();

    // -------------------------
    // Dead-letter (DLT/DLQ) configuration
    // -------------------------

    /** Enable publishing failed records to a dead-letter topic (DLT/DLQ). */
    private boolean dltEnabled = true;

    /**
     * Fixed DLT topic. If set, all dead-lettered records go to this topic.
     * If empty, SDK uses original topic + {@link #dltTopicSuffix}.
     */
    private String dltTopic;

    /** DLT topic suffix appended to original topic when {@link #dltTopic} is not set. */
    @NotBlank
    private String dltTopicSuffix = ".DLT";

    /**
     * Send timeout in milliseconds when publishing to DLT.
     * This prevents threads from hanging forever on DLT publish.
     */
    @Min(100) @Max(300000)
    private int dltSendTimeoutMs = 5000;

    /**
     * If true, the SDK will publish to DLT synchronously (blocking send) and only then commit offsets.
     * If false, it sends asynchronously (higher throughput, less strict guarantee).
     */
    private boolean dltSyncSend = true;

    // -------------------------
    // Logging / redaction configuration
    // -------------------------

    /** Structured logging and header redaction configuration. */
    private LoggingProperties logging = new LoggingProperties();

    // -------------------------
    // Auto pause / circuit-breaker configuration
    // -------------------------

    /** Auto-pause configuration (pause consumer on failure storms). */
    private AutoPauseProperties autoPause = new AutoPauseProperties();

    // -------------------------
    // Health / lag metrics / notifications
    // -------------------------

    /** Enable SDK health indicators. */
    private boolean healthEnabled = true;

    /** Health check timeout (ms). */
    @Min(100) @Max(60000)
    private int healthTimeoutMs = 2000;

    /** Enable consumer lag gauges (AdminClient based). */
    private boolean lagMetricsEnabled = false;

    /** Lag sampling interval (seconds). */
    @Min(5) @Max(3600)
    private int lagMetricsIntervalSeconds = 30;

    /** Enable lag health indicator (DOWN if backlog persists). */
    private boolean lagHealthEnabled = false;

    /** Lag threshold; if lag > threshold for N intervals, health becomes DOWN. */
    @Min(0)
    private long lagHealthThreshold = 10000;

    /** Number of consecutive intervals lag must exceed threshold to mark health DOWN. */
    @Min(1) @Max(100)
    private int lagHealthConsecutiveIntervals = 3;

    /** Notification configuration for lag alerts (email / Teams). */
    private LagAlertNotificationProperties lagAlertNotifications = new LagAlertNotificationProperties();

    // -------------------------
    // Nested property objects
    // -------------------------

    /** Retry policy settings. */
    @Data
    @NoArgsConstructor
    public static class RetryProperties {
        /** Enable retries. */
        private boolean enabled = true;

        /** Initial backoff in ms. */
        @Min(0) @Max(600000)
        private long initialBackoffMs = 1000;

        /** Exponential multiplier. */
        @Min(1) @Max(100)
        private double backoffMultiplier = 2.0;

        /** Maximum backoff in ms. */
        @Min(0) @Max(600000)
        private long maxBackoffMs = 60000;

        /** Max elapsed time across retries (ms). 0 = unlimited (not recommended). */
        @Min(0) @Max(3600000)
        private long maxElapsedMs = 5 * 60_000;
    }

    /** Logging and header redaction policy. */
    @Data
    @NoArgsConstructor
    public static class LoggingProperties {

        /** Log key. */
        private boolean logKeys = true;

        /** If true, hash keys before logging to avoid leaking PII. */
        private boolean keyHash = true;

        /** Log headers. */
        private boolean logHeaders = true;

        /** Whether to log payload. Strongly recommended false in prod for PII. */
        private boolean logPayload = false;

        /** Maximum length for any logged field. */
        @Min(16) @Max(4096)
        private int maxFieldLen = 256;

        /**
         * Redaction mode:
         * <ul>
         *   <li>ALLOWLIST - only allowed headers are logged</li>
         *   <li>BLOCKLIST - all headers logged except blocked ones</li>
         * </ul>
         */
        @NotBlank
        private String headerRedactionMode = "ALLOWLIST";

        /** Header allowlist used when mode is ALLOWLIST. */
        private List<String> headerAllowlist = List.of("traceparent", "x-correlation-id", "x-request-id");

        /** Header blocklist used when mode is BLOCKLIST. */
        private List<String> headerBlocklist = List.of("authorization", "cookie", "set-cookie");

        /** Header name prefixes to redact regardless of mode. */
        private List<String> headerPrefixRedact = List.of("x-secret-", "x-token-");
    }

    /** Automatic pause settings. */
    @Data
    @NoArgsConstructor
    public static class AutoPauseProperties {
        /** Enable auto pause. */
        private boolean enabled = false;

        /** Number of failures in window required to pause. */
        @Min(1) @Max(100000)
        private int failureThreshold = 10;

        /** Window in seconds for failure counting. */
        @Min(1) @Max(3600)
        private int windowSeconds = 30;

        /** Pause duration in seconds. */
        @Min(1) @Max(86400)
        private int pauseSeconds = 60;
    }

    /** Lag alert notification properties. */
    @Data
    @NoArgsConstructor
    public static class LagAlertNotificationProperties {

        /** Enable notifications. */
        private boolean enabled = false;

        /** Email recipients. */
        private List<String> to = List.of();

        /** Email sender (from). */
        private String from;

        /** Email subject template. Supported variables: {groupId} {topic} {partition}. */
        private String subject = "[Kafka SDK] Lag alert {groupId} {topic}-{partition}";

        /** Cooldown minutes between notifications for the same partition key. */
        @Min(0) @Max(1440)
        private int cooldownMinutes = 30;

        /** Microsoft Teams incoming webhook URL. */
        private String teamsWebhookUrl;
    }
}
