package com.truist.cps.kafka.dlt;

/**
 * Standard header names added by {@link DeadLetterProducer}.
 * <p>
 * These headers help downstream processors, operators and replay jobs understand
 * why a record was dead-lettered and where it came from.
 */
public final class DeadLetterHeaders {

    private DeadLetterHeaders() {}

    /** Fully qualified exception class name that triggered dead-lettering. */
    public static final String X_ERROR_CLASS = "x-error-class";

    /** Exception message (bounded). */
    public static final String X_ERROR_MESSAGE = "x-error-message";

    /** Original topic name. */
    public static final String X_ORIGINAL_TOPIC = "x-original-topic";

    /** Original partition. */
    public static final String X_ORIGINAL_PARTITION = "x-original-partition";

    /** Original offset. */
    public static final String X_ORIGINAL_OFFSET = "x-original-offset";

    /** Timestamp (epoch millis) when record was dead-lettered. */
    public static final String X_DLT_TIMESTAMP = "x-dlt-timestamp";
}
