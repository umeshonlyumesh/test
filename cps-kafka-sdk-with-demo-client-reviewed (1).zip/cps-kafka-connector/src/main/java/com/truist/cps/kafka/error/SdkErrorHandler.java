package com.truist.cps.kafka.error;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.metrics.SdkKafkaMetrics;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.kafka.listener.RetryListener;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.util.backoff.BackOff;

import java.time.Instant;
import java.util.Objects;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Production-grade {@link DefaultErrorHandler} with:
 * <ul>
 *   <li>Retry attempt logging with throttling.</li>
 *   <li>Optional automatic pause/resume when failures spike.</li>
 * </ul>
 */
public class SdkErrorHandler extends DefaultErrorHandler {

    private static final Logger log = LoggerFactory.getLogger(SdkErrorHandler.class);

    private final KafkaSdkProperties props;
    private final SdkKafkaMetrics metrics;

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "sdk-kafka-autopause");
        t.setDaemon(true);
        return t;
    });

    private final AtomicInteger windowFailures = new AtomicInteger(0);
    private final AtomicLong windowStartMs = new AtomicLong(System.currentTimeMillis());

    public SdkErrorHandler(KafkaSdkProperties props, SdkKafkaMetrics metrics, java.util.function.BiConsumer<ConsumerRecord<?, ?>, Exception> recoverer, BackOff backOff) {
        super((rec, ex) -> recoverer.accept(rec, ex), backOff);
        this.props = Objects.requireNonNull(props, "props");
        this.metrics = Objects.requireNonNull(metrics, "metrics");

        // Retry metrics + throttled logs
        setRetryListeners(new RetryListener() {
            @Override
            public void failedDelivery(ConsumerRecord<?, ?> record, Exception ex, int deliveryAttempt) {
                if (deliveryAttempt > 1) {
                    metrics.incrementRetry();
                }
                // throttle: log attempts 1,2,4,8,... and final attempts are handled by recoverer logging
                if (deliveryAttempt == 1 || (deliveryAttempt & (deliveryAttempt - 1)) == 0) {
                    log.warn("Retry attempt={} topic={} partition={} offset={} ex={}",
                            deliveryAttempt, record.topic(), record.partition(), record.offset(),
                            ex.getClass().getSimpleName());
                }
            }
        });
    }

    @Override
    public void handleOtherException(Exception thrownException, Consumer<?, ?> consumer, MessageListenerContainer container, boolean batchListener) {
        maybeAutoPause(container, thrownException);
        super.handleOtherException(thrownException, consumer, container, batchListener);
    }

    @Override
    public boolean handleOne(Exception thrownException, ConsumerRecord<?, ?> record, Consumer<?, ?> consumer, MessageListenerContainer container) {
        maybeAutoPause(container, thrownException);
        return super.handleOne(thrownException, record, consumer, container);
    }

    private void maybeAutoPause(MessageListenerContainer container, Exception ex) {
        KafkaSdkProperties.AutoPauseProperties ap = props.getAutoPause();
        if (ap == null || !ap.isEnabled() || container == null) return;

        long now = System.currentTimeMillis();
        long start = windowStartMs.get();
        if (now - start > ap.getWindowSeconds() * 1000L) {
            windowStartMs.set(now);
            windowFailures.set(0);
        }

        int fails = windowFailures.incrementAndGet();
        if (fails >= ap.getFailureThreshold() && !container.isPauseRequested()) {
            log.error("Auto-pausing listenerId={} for {}s due to {} failures within {}s window; lastError={}",
                    container.getListenerId(), ap.getPauseSeconds(), fails, ap.getWindowSeconds(),
                    ex.getClass().getSimpleName());
            container.pause();

            scheduler.schedule(() -> {
                try {
                    log.warn("Auto-resuming listenerId={} after cooldown", container.getListenerId());
                    container.resume();
                    windowStartMs.set(System.currentTimeMillis());
                    windowFailures.set(0);
                } catch (Exception e) {
                    log.warn("Auto-resume failed for listenerId={}: {}", container.getListenerId(), e.toString());
                }
            }, ap.getPauseSeconds(), TimeUnit.SECONDS);
        }
    }
}
