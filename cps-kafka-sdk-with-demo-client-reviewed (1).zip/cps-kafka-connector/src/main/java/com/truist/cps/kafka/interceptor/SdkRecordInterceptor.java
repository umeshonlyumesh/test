package com.truist.cps.kafka.interceptor;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.logging.SdkLogSanitizer;
import com.truist.cps.kafka.logging.SdkMdc;
import com.truist.cps.kafka.metrics.SdkListenerStateTracker;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.listener.ConsumerAwareRecordInterceptor;

import java.util.*;

/**
 * Intercepts records to apply consistent logging and MDC correlation.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Populate MDC with topic/partition/offset and correlation header fields.</li>
 *   <li>Track last-seen timestamps for observability.</li>
 *   <li>Optionally log safe record context (no payload by default).</li>
 * </ul>
 */
public class SdkRecordInterceptor implements ConsumerAwareRecordInterceptor<Object, Object> {

    private static final Logger log = LoggerFactory.getLogger(SdkRecordInterceptor.class);

    private static final List<String> MDC_KEYS = List.of("kafka.topic", "kafka.partition", "kafka.offset", "corrId");

    private final KafkaSdkProperties props;
    private final SdkListenerStateTracker tracker;

    public SdkRecordInterceptor(KafkaSdkProperties props, SdkListenerStateTracker tracker) {
        this.props = Objects.requireNonNull(props, "props");
        this.tracker = Objects.requireNonNull(tracker, "tracker");
    }

    @Override
    public ConsumerRecord<Object, Object> intercept(ConsumerRecord<Object, Object> record, Consumer<Object, Object> consumer) {
        if (record == null) return null;

        String listenerId = consumer == null ? "unknown" : "unknown"; // listener id not available here reliably
        tracker.markSeen(listenerId);

        KafkaSdkProperties.LoggingProperties lc = props.getLogging();

        String key = SdkLogSanitizer.key(record.key(), lc);
        Map<String, String> hdrs = SdkLogSanitizer.headers(record.headers(), lc);

        String corr = hdrs.getOrDefault("x-correlation-id", hdrs.getOrDefault("x-request-id", null));

        Map<String, String> mdc = new HashMap<>();
        mdc.put("kafka.topic", record.topic());
        mdc.put("kafka.partition", Integer.toString(record.partition()));
        mdc.put("kafka.offset", Long.toString(record.offset()));
        if (corr != null && !corr.isBlank()) mdc.put("corrId", corr);

        SdkMdc.putAll(mdc);

        // Lightweight log line (safe)
        if (log.isDebugEnabled()) {
            log.debug("Received record topic={} partition={} offset={} key={} headers={}",
                    record.topic(), record.partition(), record.offset(), key, hdrs);
        }

        return record;
    }

    @Override
    public void success(ConsumerRecord<Object, Object> record, Consumer<Object, Object> consumer) {
        // on successful listener invocation (not commit)
        // best-effort: mark processed
        tracker.markProcessed("unknown");
        SdkMdc.clearKeys(MDC_KEYS);
    }

    @Override
    public void failure(ConsumerRecord<Object, Object> record, Exception exception, Consumer<Object, Object> consumer) {
        SdkMdc.clearKeys(MDC_KEYS);
    }

    @Override
    public void afterRecord(ConsumerRecord<Object, Object> record, Consumer<Object, Object> consumer) {
        // ensure cleanup
        SdkMdc.clearKeys(MDC_KEYS);
    }
}
