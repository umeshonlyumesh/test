package com.truist.cps.kafka.logging;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.config.KafkaSdkProperties.HeaderRedactionMode;
import org.apache.kafka.common.header.Header;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/**
 * Sanitizes Kafka record fields for safe production logging.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Redact or hash sensitive fields (keys) to avoid PII leakage.</li>
 *   <li>Log only allowlisted headers.</li>
 *   <li>Bound log field sizes to prevent log flooding.</li>
 * </ul>
 */
public final class SdkLogSanitizer {

    private SdkLogSanitizer() {}

    /** Create a sanitized representation of the record key. */
    public static String key(Object key, KafkaSdkProperties.LoggingProperties cfg) {
        if (!cfg.isLogKeys() || key == null) return null;
        String s = String.valueOf(key);
        if (cfg.isKeyHash()) {
            return "sha256:" + sha256Hex(s);
        }
        return truncate(s, cfg.getMaxFieldLen());
    }

    /** Create a sanitized representation of the record value (payload). Disabled by default. */
    public static String payload(Object value, KafkaSdkProperties.LoggingProperties cfg) {
        if (!cfg.isLogPayload() || value == null) return null;
        return truncate(String.valueOf(value), cfg.getMaxFieldLen());
    }

    /** Return allowlisted headers as a map of headerName -> value (utf-8 best effort). */
    /** Return headers as a map using configured redaction policy (best-effort utf-8). */
public static Map<String, String> headers(Iterable<Header> headers, KafkaSdkProperties.LoggingProperties cfg) {
    if (!cfg.isLogHeaders() || headers == null) return Map.of();

    HeaderRedactionMode mode = cfg.getHeaderRedactionMode() == null ? HeaderRedactionMode.ALLOWLIST : cfg.getHeaderRedactionMode();

    Set<String> allow = new HashSet<>();
    for (String h : cfg.getHeaderAllowlist()) {
        if (h != null) allow.add(h.toLowerCase(Locale.ROOT));
    }

    Set<String> block = new HashSet<>();
    for (String h : cfg.getHeaderBlocklist()) {
        if (h != null) block.add(h.toLowerCase(Locale.ROOT));
    }

    List<String> redactPrefixes = new ArrayList<>();
    for (String p : cfg.getHeaderPrefixRedact()) {
        if (p != null && !p.isBlank()) redactPrefixes.add(p.toLowerCase(Locale.ROOT));
    }

    Map<String, String> out = new LinkedHashMap<>();
    for (Header h : headers) {
        if (h == null || h.key() == null) continue;
        String k = h.key();
        String kl = k.toLowerCase(Locale.ROOT);

        boolean include = (mode == HeaderRedactionMode.ALLOWLIST) ? allow.contains(kl) : !block.contains(kl);
        if (!include) continue;

        boolean redact = false;
        for (String pref : redactPrefixes) {
            if (kl.startsWith(pref)) {
                redact = true;
                break;
            }
        }

        if (redact) {
            out.put(k, "***REDACTED***");
            continue;
        }

        byte[] v = h.value();
        if (v == null) {
            out.put(k, "");
        } else {
            out.put(k, truncate(new String(v, StandardCharsets.UTF_8), cfg.getMaxFieldLen()));
        }
    }
    return out;
}


private static String truncate(String s, int max) {
        if (s == null) return null;
        if (max <= 0) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "hash_error";
        }
    }
}
