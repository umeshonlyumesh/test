package com.truist.cps.kafka.util;

import com.truist.cps.kafka.config.SslProperties;
import org.apache.kafka.common.config.SslConfigs;

import java.util.Map;

public final class KafkaSslUtil {

    private KafkaSslUtil() {}

    public static void applyBrokerSsl(Map<String, Object> config, SslProperties ssl) {
        if (ssl == null) return;

        putIfNotBlank(config, SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ssl.getTruststoreLocation());
        putIfNotBlank(config, SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ssl.getTruststorePassword());
        putIfNotBlank(config, SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ssl.getKeystoreLocation());
        putIfNotBlank(config, SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ssl.getKeystorePassword());
        putIfNotBlank(config, SslConfigs.SSL_KEY_PASSWORD_CONFIG, ssl.getKeyPassword());

        // for dev/test you may want to set it blank, but default should be https
        if (ssl.getEndpointIdentificationAlgorithm() != null) {
            config.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, ssl.getEndpointIdentificationAlgorithm());
        }
    }

    private static void putIfNotBlank(Map<String, Object> config, String key, String value) {
        if (value != null && !value.isBlank()) {
            config.put(key, value);
        }
    }
}
