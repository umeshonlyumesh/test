package com.truist.cps.kafka.autoconfig;

import com.truist.cps.kafka.consumer.SdkConsumerManager;
import com.truist.cps.kafka.producer.SdkKafkaProducer;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaSdkAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(KafkaSdkAutoConfiguration.class))
            .withPropertyValues(
                    "kafka.sdk.bootstrap-servers=localhost:9092",
                    "kafka.sdk.group-id=test-group",
                    "kafka.sdk.client-id=test-client",
                    "kafka.sdk.format=json",
                    "kafka.sdk.ssl.endpoint-identification-algorithm="
            );

    @Test
    void contextLoadsAndCreatesBeans() {
        contextRunner.run(ctx -> {
            assertThat(ctx).hasBean("sdkKafkaListenerContainerFactory");
            assertThat(ctx).getBean(SdkKafkaProducer.class);
            assertThat(ctx).getBean(SdkConsumerManager.class);
        });
    }
}
