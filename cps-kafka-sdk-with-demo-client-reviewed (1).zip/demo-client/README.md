# Demo Client (uses cps-kafka-connector SDK)

## Run locally

1) Start Kafka locally (example, adjust as needed)
- broker: `localhost:9092`
- create topics:
  - `demo.topic`
  - `demo.topic.DLT`

2) Build & run from repo root:
```bash
mvn -q -DskipTests clean package
mvn -pl demo-client spring-boot:run
```

## Produce test messages
```bash
curl -X POST "http://localhost:8080/api/produce?mode=OK" -H "Content-Type: application/json" -d '{"hello":"world"}'
curl -X POST "http://localhost:8080/api/produce?mode=RETRY"
curl -X POST "http://localhost:8080/api/produce?mode=NON_RETRYABLE"
curl -X POST "http://localhost:8080/api/produce?mode=POISON"
```

### What to expect
- `OK` -> consumer acks -> offset committed
- `RETRY` -> SDK retries with backoff until max elapsed, then sends to DLT, commits recovered offset
- `NON_RETRYABLE` / `POISON` -> immediate recoverer (DLT or skip+commit if DLT disabled)

## Pause/Resume
```bash
curl -X POST "http://localhost:8080/api/consumer/pause/demoListener"
curl -X POST "http://localhost:8080/api/consumer/resume/demoListener"
curl "http://localhost:8080/api/consumer/state"
```

## Monitoring / Actuator
- Health: `GET /actuator/health`
- SDK listener state: `GET /actuator/sdkKafkaListenerState`
- Metrics: `GET /actuator/metrics`
  - `kafka.sdk.retry.count`
  - `kafka.sdk.dlt.count`
  - `kafka.sdk.poison.skip.count`
  - `kafka.sdk.consumer.lag` (tagged by groupId/topic/partition)

## Lag health + notifications
Enable/adjust in `application.yml`:
- `kafka.sdk.lag-health-*`
- `kafka.sdk.lag-alert-notifications.*`
- SMTP via `spring.mail.*`
- Teams webhook via `teams-webhook-url`

> Protect actuator endpoints with auth in real environments.
