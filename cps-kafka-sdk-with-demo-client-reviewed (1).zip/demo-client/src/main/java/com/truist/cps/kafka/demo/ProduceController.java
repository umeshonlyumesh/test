package com.truist.cps.kafka.demo;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import com.truist.cps.kafka.producer.SdkKafkaProducer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.UUID;

/**
 * Simple REST endpoint to produce demo messages with correlation headers.
 */
@RestController
@RequestMapping("/api")
public class ProduceController {

    private final SdkKafkaProducer producer;
    private final String topic;

    public ProduceController(SdkKafkaProducer producer,
                           @Value("${app.topic}") String topic) {
        this.producer = producer;
        this.topic = topic;
    }

    @PostMapping("/produce")
    public ResponseEntity<?> produce(@RequestParam(defaultValue = "OK") String mode,
                                     @RequestParam(required = false) String key,
                                     @RequestBody(required = false) String body) {

        String k = StringUtils.hasText(key) ? key : UUID.randomUUID().toString();
        String correlationId = UUID.randomUUID().toString();

        String payload = (body != null ? body : "{"ts":"" + Instant.now() + "","mode":"" + mode + ""}");

        // Mode is used by the consumer to simulate retry/non-retryable/ok processing.
        ProducerRecord<String, Object> record = new ProducerRecord<>(topic, k, payload);
        record.headers().add(new RecordHeader("x-correlation-id", correlationId.getBytes(StandardCharsets.UTF_8)));
        record.headers().add(new RecordHeader("x-request-id", ("req-" + correlationId).getBytes(StandardCharsets.UTF_8)));
        record.headers().add(new RecordHeader("demo-mode", mode.getBytes(StandardCharsets.UTF_8)));

        producer.send(record);

        return ResponseEntity.ok().body(
                java.util.Map.of(
                        "topic", topic,
                        "key", k,
                        "mode", mode,
                        "correlationId", correlationId,
                        "note", "Consumer behavior depends on mode: OK | RETRY | NON_RETRYABLE | POISON"
                )
        );
    }
}
