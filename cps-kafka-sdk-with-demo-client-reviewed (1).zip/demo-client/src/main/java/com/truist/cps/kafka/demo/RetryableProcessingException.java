package com.truist.cps.kafka.demo;

/**
 * Example retryable exception (handled by SDK retry/backoff policy).
 */
public class RetryableProcessingException extends RuntimeException {
    public RetryableProcessingException(String message) { super(message); }
    public RetryableProcessingException(String message, Throwable cause) { super(message, cause); }
}
