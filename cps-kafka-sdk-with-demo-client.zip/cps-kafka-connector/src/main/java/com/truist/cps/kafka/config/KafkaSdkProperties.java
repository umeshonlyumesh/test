package com.truist.cps.kafka.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

@Validated
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {

    /** Comma-separated bootstrap servers. */
    @NotBlank
    private String bootstrapServers;

    /** Consumer group id used by SDK consumer factory (if listener doesn't override groupId). */
    @NotBlank
    private String groupId;

    /** Logical client id prefix; SDK adds -producer/-consumer suffix. */
    @NotBlank
    private String clientId = "cps-kafka";

    /** Message format: json or avro. */
    @NotBlank
    private String format = "json";

    /** Topic missing should not crash app (helpful for lower env). */
    private boolean missingTopicsFatal = false;

    /** Concurrency for listener containers created with SDK container factory. */
    @Min(1)
    @Max(64)
    private int concurrency = 1;

    /** Idle between polls (ms). */
    @Min(0)
    private long idleBetweenPollsMs = 0;

    /** Poll timeout (ms). */
    @Min(50)
    private long pollTimeoutMs = 2000;

    /** max.poll.records */
    @Min(1)
    @Max(5000)
    private int maxPollRecords = 100;

    /** max.poll.interval.ms */
    @Min(1000)
    private int maxPollIntervalMs = 300000;

    /** auto.offset.reset */
    @NotBlank
    private String autoOffsetReset = "earliest";

    /** Producer delivery timeout (ms) */
    @Min(1000)
    private int producerDeliveryTimeoutMs = 120000;

    /** Producer acks ("all" recommended) */
    @NotBlank
    private String producerAcks = "all";

    /** Enable idempotence */
    private boolean enableIdempotence = true;

    /** max.in.flight.requests.per.connection (keep <= 5 with idempotence) */
    @Min(1)
    @Max(5)
    private int maxInFlightRequestsPerConnection = 5;

    /** Retries (Integer.MAX_VALUE recommended with delivery timeout + idempotence) */
    @Min(0)
    private int producerRetries = Integer.MAX_VALUE;

    /** SSL settings for brokers and (optionally) schema registry */
    private SslProperties ssl = new SslProperties();

    /** Schema Registry URL (only for avro) */
    private String schemaRegistryUrl;

    /** Use specific.avro.reader (only for avro consumer) */
    private boolean specificAvroReader = true;

    /** Retry configuration for the consumer error handler. */
    private RetryProperties retry = new RetryProperties();

    /** Enable actuator health indicator for Kafka SDK (requires actuator on classpath). */
    private Boolean healthEnabled = true;

    /** Timeout in ms for health checks using AdminClient. */
    private Long healthTimeoutMs = 2000L;

    /** Enable consumer lag metrics via AdminClient (requires Micrometer). */
    private Boolean lagMetricsEnabled = false;

    /** Poll interval seconds for lag metrics collection. */
    private Integer lagMetricsIntervalSeconds = 30;

    /** Enable lag-based health indicator (requires actuator + lag metrics enabled). */
    private Boolean lagHealthEnabled = false;

    /** Lag threshold above which health may be reported DOWN. */
    private Long lagHealthThreshold = 10000L;

    /** Number of consecutive intervals lag must exceed threshold before health turns DOWN. */
    private Integer lagHealthConsecutiveIntervals = 3;

    /** Notification configuration for lag health alerts. */
    private LagAlertNotificationProperties lagAlertNotifications = new LagAlertNotificationProperties();

    /**
     * Fully-qualified exception class names considered NOT retryable (poison).
     * These are handled immediately by the recoverer (DLT/skip).
     */
    private java.util.List<String> notRetryableExceptions = java.util.List.of(
            "org.springframework.kafka.support.serializer.DeserializationException",
            "org.apache.kafka.common.errors.SerializationException",
            "org.apache.kafka.common.errors.RecordDeserializationException",
            "java.lang.IllegalArgumentException"
    );

    /**
     * Fully-qualified exception class names that are explicitly retryable.
     * If empty, all exceptions not listed in {@code notRetryableExceptions} are treated as retryable.
     */
    private java.util.List<String> retryableExceptions = java.util.List.of();


    // getters/setters

    public String getBootstrapServers() { return bootstrapServers; }
    public void setBootstrapServers(String bootstrapServers) { this.bootstrapServers = bootstrapServers; }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public boolean isMissingTopicsFatal() { return missingTopicsFatal; }
    public void setMissingTopicsFatal(boolean missingTopicsFatal) { this.missingTopicsFatal = missingTopicsFatal; }

    public int getConcurrency() { return concurrency; }
    public void setConcurrency(int concurrency) { this.concurrency = concurrency; }

    public long getIdleBetweenPollsMs() { return idleBetweenPollsMs; }
    public void setIdleBetweenPollsMs(long idleBetweenPollsMs) { this.idleBetweenPollsMs = idleBetweenPollsMs; }

    public long getPollTimeoutMs() { return pollTimeoutMs; }
    public void setPollTimeoutMs(long pollTimeoutMs) { this.pollTimeoutMs = pollTimeoutMs; }

    public int getMaxPollRecords() { return maxPollRecords; }
    public void setMaxPollRecords(int maxPollRecords) { this.maxPollRecords = maxPollRecords; }

    public int getMaxPollIntervalMs() { return maxPollIntervalMs; }
    public void setMaxPollIntervalMs(int maxPollIntervalMs) { this.maxPollIntervalMs = maxPollIntervalMs; }

    public String getAutoOffsetReset() { return autoOffsetReset; }
    public void setAutoOffsetReset(String autoOffsetReset) { this.autoOffsetReset = autoOffsetReset; }

    public int getProducerDeliveryTimeoutMs() { return producerDeliveryTimeoutMs; }
    public void setProducerDeliveryTimeoutMs(int producerDeliveryTimeoutMs) { this.producerDeliveryTimeoutMs = producerDeliveryTimeoutMs; }

    public String getProducerAcks() { return producerAcks; }
    public void setProducerAcks(String producerAcks) { this.producerAcks = producerAcks; }

    public boolean isEnableIdempotence() { return enableIdempotence; }
    public void setEnableIdempotence(boolean enableIdempotence) { this.enableIdempotence = enableIdempotence; }

    public int getMaxInFlightRequestsPerConnection() { return maxInFlightRequestsPerConnection; }
    public void setMaxInFlightRequestsPerConnection(int maxInFlightRequestsPerConnection) {
        this.maxInFlightRequestsPerConnection = maxInFlightRequestsPerConnection;
    }

    public int getProducerRetries() { return producerRetries; }
    public void setProducerRetries(int producerRetries) { this.producerRetries = producerRetries; }

    public SslProperties getSsl() { return ssl; }
    public void setSsl(SslProperties ssl) { this.ssl = ssl; }

    public String getSchemaRegistryUrl() { return schemaRegistryUrl; }
    public void setSchemaRegistryUrl(String schemaRegistryUrl) { this.schemaRegistryUrl = schemaRegistryUrl; }

    public boolean isSpecificAvroReader() { return specificAvroReader; }
    public void setSpecificAvroReader(boolean specificAvroReader) { this.specificAvroReader = specificAvroReader; }

    /** Returns retry configuration for the consumer error handler. */
    public RetryProperties getRetry() { return retry; }
    public void setRetry(RetryProperties retry) { this.retry = retry; }

    /** Whether Kafka SDK actuator health indicator is enabled. */
    public Boolean getHealthEnabled() { return healthEnabled; }
    public void setHealthEnabled(Boolean healthEnabled) { this.healthEnabled = healthEnabled; }

    /** Timeout in ms for Kafka SDK health checks. */
    public Long getHealthTimeoutMs() { return healthTimeoutMs; }
    public void setHealthTimeoutMs(Long healthTimeoutMs) { this.healthTimeoutMs = healthTimeoutMs; }

    public Boolean getLagMetricsEnabled() { return lagMetricsEnabled; }
    public void setLagMetricsEnabled(Boolean lagMetricsEnabled) { this.lagMetricsEnabled = lagMetricsEnabled; }

    public Integer getLagMetricsIntervalSeconds() { return lagMetricsIntervalSeconds; }
    public void setLagMetricsIntervalSeconds(Integer lagMetricsIntervalSeconds) { this.lagMetricsIntervalSeconds = lagMetricsIntervalSeconds; }

    public Boolean getLagHealthEnabled() { return lagHealthEnabled; }
    public void setLagHealthEnabled(Boolean lagHealthEnabled) { this.lagHealthEnabled = lagHealthEnabled; }

    public Long getLagHealthThreshold() { return lagHealthThreshold; }
    public void setLagHealthThreshold(Long lagHealthThreshold) { this.lagHealthThreshold = lagHealthThreshold; }

    public Integer getLagHealthConsecutiveIntervals() { return lagHealthConsecutiveIntervals; }
    public void setLagHealthConsecutiveIntervals(Integer lagHealthConsecutiveIntervals) { this.lagHealthConsecutiveIntervals = lagHealthConsecutiveIntervals; }

    public LagAlertNotificationProperties getLagAlertNotifications() { return lagAlertNotifications; }
    public void setLagAlertNotifications(LagAlertNotificationProperties lagAlertNotifications) { this.lagAlertNotifications = lagAlertNotifications; }

    /** Returns list of non-retryable exception class names. */
    public java.util.List<String> getNotRetryableExceptions() { return notRetryableExceptions; }
    public void setNotRetryableExceptions(java.util.List<String> notRetryableExceptions) { this.notRetryableExceptions = notRetryableExceptions; }

    /** Returns list of explicitly retryable exception class names. */
    public java.util.List<String> getRetryableExceptions() { return retryableExceptions; }
    public void setRetryableExceptions(java.util.List<String> retryableExceptions) { this.retryableExceptions = retryableExceptions; }



/**
 * Retry configuration for the consumer error handler.
 * Retry is applied when the listener throws an exception that is considered retryable.
 */
public static class RetryProperties {

    /** Enable/disable retries (when disabled, recoverer is invoked immediately). */
    private boolean enabled = true;

    /** Initial backoff (ms) before first retry. */
    private long initialBackoffMs = 1000L;

    /** Backoff multiplier (e.g., 2.0 doubles each attempt). */
    private double backoffMultiplier = 2.0;

    /** Maximum backoff between attempts (ms). */
    private long maxBackoffMs = 60_000L;

    /** Total time budget for retries (ms). */
    private long maxElapsedMs = 5 * 60_000L;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public long getInitialBackoffMs() { return initialBackoffMs; }
    public void setInitialBackoffMs(long initialBackoffMs) { this.initialBackoffMs = initialBackoffMs; }

    public double getBackoffMultiplier() { return backoffMultiplier; }
    public void setBackoffMultiplier(double backoffMultiplier) { this.backoffMultiplier = backoffMultiplier; }

    public long getMaxBackoffMs() { return maxBackoffMs; }
    public void setMaxBackoffMs(long maxBackoffMs) { this.maxBackoffMs = maxBackoffMs; }

    public long getMaxElapsedMs() { return maxElapsedMs; }
    public void setMaxElapsedMs(long maxElapsedMs) { this.maxElapsedMs = maxElapsedMs; }
}



/**
 * Controls SDK logging behavior.
 * <p>
 * Defaults are safe for production (no payload logging, key hashing enabled).
 */

    /** Header redaction mode. */
    public enum HeaderRedactionMode {
        /** Log only allowlisted headers. */
        ALLOWLIST,
        /** Log all headers except blocklisted headers. */
        BLOCKLIST
    }

    public static class LoggingProperties {

    /** Log record keys (sanitized). */
    private boolean logKeys = true;

    /** Hash record keys (SHA-256) instead of logging raw keys. */
    private boolean keyHash = true;

    /** Log record headers (allowlist only). */
    private boolean logHeaders = true;

    /** Header allowlist to log (case-insensitive). */
    private java.util.List<String> headerAllowlist = java.util.List.of("traceparent", "x-correlation-id", "x-request-id");

    /** Log record payload (NOT recommended; defaults to false). */
    private boolean logPayload = false;

    /** Max length for any logged string field. */
    private int maxFieldLen = 256;

    public boolean isLogKeys() { return logKeys; }
    public void setLogKeys(boolean logKeys) { this.logKeys = logKeys; }

    public boolean isKeyHash() { return keyHash; }
    public void setKeyHash(boolean keyHash) { this.keyHash = keyHash; }

    public boolean isLogHeaders() { return logHeaders; }
    public void setLogHeaders(boolean logHeaders) { this.logHeaders = logHeaders; }

    public java.util.List<String> getHeaderAllowlist() { return headerAllowlist; }
    public void setHeaderAllowlist(java.util.List<String> headerAllowlist) { this.headerAllowlist = headerAllowlist; }

    public boolean isLogPayload() { return logPayload; }
    public void setLogPayload(boolean logPayload) { this.logPayload = logPayload; }

    public int getMaxFieldLen() { return maxFieldLen; }
    public void setMaxFieldLen(int maxFieldLen) { this.maxFieldLen = maxFieldLen; }
}

/**
 * Automatic pause/resume behavior when failures spike.
 * <p>
 * Protects downstream systems during outages by slowing consumption temporarily.
 */
public static class AutoPauseProperties {

    /** Enable automatic pause/resume. */
    private boolean enabled = false;

    /** Number of failures within the window that triggers a pause. */
    private int failureThreshold = 10;

    /** Window size in seconds for counting failures. */
    private int windowSeconds = 30;

    /** Pause duration in seconds before auto-resume. */
    private int pauseSeconds = 60;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public int getFailureThreshold() { return failureThreshold; }
    public void setFailureThreshold(int failureThreshold) { this.failureThreshold = failureThreshold; }

    public int getWindowSeconds() { return windowSeconds; }
    public void setWindowSeconds(int windowSeconds) { this.windowSeconds = windowSeconds; }

    public int getPauseSeconds() { return pauseSeconds; }
    public void setPauseSeconds(int pauseSeconds) { this.pauseSeconds = pauseSeconds; }
}



/**
 * Notification configuration for lag alerts.
 * <p>
 * Email notifications require Spring Boot mail to be configured in the client application (spring.mail.*).
 */
public static class LagAlertNotificationProperties {

    /** Enable notifications. */
    private boolean enabled = false;

    /** Email recipients (comma-separated list supported via YAML list). */
    private java.util.List<String> to = java.util.List.of();

    /** Optional from address (falls back to spring.mail.username if empty). */
    private String from;

    /** Email subject template. Available variables: {groupId}, {topic}, {partition}. */
    private String subject = "[Kafka SDK] Consumer lag alert: {groupId}";

    /** Cooldown minutes between notifications for the same partition key. */
    private int cooldownMinutes = 30;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public java.util.List<String> getTo() { return to; }
    public void setTo(java.util.List<String> to) { this.to = to; }

    public String getFrom() { return from; }
    public void setFrom(String from) { this.from = from; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public int getCooldownMinutes() { return cooldownMinutes; }
    public void setCooldownMinutes(int cooldownMinutes) { this.cooldownMinutes = cooldownMinutes; }
}
}
