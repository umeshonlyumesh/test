package com.truist.cps.kafka.config;

public class SslProperties {

    /** Truststore location (classpath: or file:) */
    private String truststoreLocation;

    /** Truststore password */
    private String truststorePassword;

    /** Keystore location (optional, for mTLS) */
    private String keystoreLocation;

    /** Keystore password */
    private String keystorePassword;

    /** Key password (optional) */
    private String keyPassword;

    /** Endpoint identification algorithm, usually https (can be blank in dev if needed) */
    private String endpointIdentificationAlgorithm = "https";

    public String getTruststoreLocation() { return truststoreLocation; }
    public void setTruststoreLocation(String truststoreLocation) { this.truststoreLocation = truststoreLocation; }

    public String getTruststorePassword() { return truststorePassword; }
    public void setTruststorePassword(String truststorePassword) { this.truststorePassword = truststorePassword; }

    public String getKeystoreLocation() { return keystoreLocation; }
    public void setKeystoreLocation(String keystoreLocation) { this.keystoreLocation = keystoreLocation; }

    public String getKeystorePassword() { return keystorePassword; }
    public void setKeystorePassword(String keystorePassword) { this.keystorePassword = keystorePassword; }

    public String getKeyPassword() { return keyPassword; }
    public void setKeyPassword(String keyPassword) { this.keyPassword = keyPassword; }

    public String getEndpointIdentificationAlgorithm() { return endpointIdentificationAlgorithm; }
    public void setEndpointIdentificationAlgorithm(String endpointIdentificationAlgorithm) {
        this.endpointIdentificationAlgorithm = endpointIdentificationAlgorithm;
    }
}
