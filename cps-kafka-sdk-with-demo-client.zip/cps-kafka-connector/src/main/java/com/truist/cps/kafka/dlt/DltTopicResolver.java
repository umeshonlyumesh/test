package com.truist.cps.kafka.dlt;

import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Resolves the destination topic used for dead-lettering failed records.
 * <p>
 * Implementations may use a fixed topic, suffix-based naming, routing by exception type,
 * or any other rule required by the platform.
 */
@FunctionalInterface
public interface DltTopicResolver {

    /**
     * Resolve the dead-letter topic for a failed record.
     *
     * @param record the original consumed record (never null)
     * @param exception the exception that caused the failure (never null)
     * @return the destination DLT topic name (never null/blank)
     */
    String resolveTopic(ConsumerRecord<?, ?> record, Exception exception);
}
