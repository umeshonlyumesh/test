package com.truist.cps.kafka.logging;

import org.slf4j.MDC;

import java.util.Map;

/**
 * Helper for setting and clearing MDC (Mapped Diagnostic Context) for consistent log correlation.
 */
public final class SdkMdc {

    private SdkMdc() {}

    /** Put MDC fields (null values are ignored). */
    public static void putAll(Map<String, String> fields) {
        if (fields == null) return;
        fields.forEach((k, v) -> {
            if (k != null && v != null) MDC.put(k, v);
        });
    }

    /** Remove a set of MDC keys. */
    public static void clearKeys(Iterable<String> keys) {
        if (keys == null) return;
        for (String k : keys) {
            if (k != null) MDC.remove(k);
        }
    }
}
