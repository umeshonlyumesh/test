package com.truist.cps.kafka.metrics;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.notify.LagAlertNotifier;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.Instant;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Registers and updates consumer lag gauges per topic-partition + groupId.
 * <p>
 * Gauge name: {@code kafka.sdk.consumer.lag}
 * Tags: {@code groupId}, {@code topic}, {@code partition}
 */
public class LagMetricsRegistrar {

    private static final Logger log = LoggerFactory.getLogger(LagMetricsRegistrar.class);

    private final KafkaSdkProperties props;
    private final SdkConsumerLagMeter lagMeter;
    private final KafkaListenerEndpointRegistry registry;
    private final MeterRegistry meterRegistry;

    private final SdkLagStateTracker lagState;
    private final LagAlertNotifier notifier;

    private final Map<String, Long> lagByKey = new ConcurrentHashMap<>();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "sdk-kafka-lag-metrics");
        t.setDaemon(true);
        return t;
    });

    public LagMetricsRegistrar(KafkaSdkProperties props,
                              SdkConsumerLagMeter lagMeter,
                              KafkaListenerEndpointRegistry registry,
                              MeterRegistry meterRegistry,
                              SdkLagStateTracker lagState,
                              LagAlertNotifier notifier) {
        this.props = Objects.requireNonNull(props, "props");
        this.lagMeter = Objects.requireNonNull(lagMeter, "lagMeter");
        this.registry = Objects.requireNonNull(registry, "registry");
        this.meterRegistry = Objects.requireNonNull(meterRegistry, "meterRegistry");
        this.lagState = Objects.requireNonNull(lagState, "lagState");
        this.notifier = Objects.requireNonNull(notifier, "notifier");
    }

    /** Start periodic lag collection and register gauges as partitions are discovered. */
    public void start() {
        if (props.getLagMetricsEnabled() == null || !props.getLagMetricsEnabled()) {
            return;
        }
        int interval = props.getLagMetricsIntervalSeconds() == null ? 30 : Math.max(5, props.getLagMetricsIntervalSeconds());
        scheduler.scheduleAtFixedRate(this::collect, 5, interval, TimeUnit.SECONDS);
        log.info("Kafka SDK lag metrics enabled; intervalSeconds={}", interval);
    }

    private void collect() {
        try {
            for (MessageListenerContainer c : registry.getListenerContainers()) {
                String groupId = c.getGroupId();
                if (groupId == null || groupId.isBlank()) continue;

                Map<TopicPartition, Long> lag = lagMeter.fetchLag(groupId);
                for (Map.Entry<TopicPartition, Long> e : lag.entrySet()) {
                    TopicPartition tp = e.getKey();
                    long v = e.getValue() == null ? 0L : e.getValue();
                    long threshold = props.getLagHealthThreshold() == null ? 10000L : props.getLagHealthThreshold();
                    lagState.update(groupId, tp.topic(), tp.partition(), v, threshold);
                    String key = key(groupId, tp.topic(), tp.partition());

                    // register gauge once
                    lagByKey.put(key, v);
                    ensureGauge(groupId, tp.topic(), tp.partition());
                }
            }

            maybeNotify();
        } catch (Exception ex) {
            log.debug("Lag collection failed: {}", ex.toString());
        }
    }

    private void ensureGauge(String groupId, String topic, int partition) {
        String key = key(groupId, topic, partition);
        // idempotent: Gauge.builder returns existing if same name+tags; safe in practice but we avoid duplicates
        Gauge.builder("kafka.sdk.consumer.lag", lagByKey, m -> m.getOrDefault(key, 0L))
                .description("Consumer lag computed via AdminClient endOffset - committedOffset")
                .tag("groupId", groupId)
                .tag("topic", topic)
                .tag("partition", Integer.toString(partition))
                .register(meterRegistry);
    }

    private static String key(String groupId, String topic, int partition) {
        return groupId + "|" + topic + "|" + partition;
    }

    private void maybeNotify() {
        KafkaSdkProperties.LagAlertNotificationProperties cfg = props.getLagAlertNotifications();
        if (cfg == null || !cfg.isEnabled()) return;
        if (props.getLagHealthEnabled() == null || !props.getLagHealthEnabled()) return;
        long threshold = props.getLagHealthThreshold() == null ? 10000L : props.getLagHealthThreshold();
        int consecutiveReq = props.getLagHealthConsecutiveIntervals() == null ? 3 : props.getLagHealthConsecutiveIntervals();
        var snap = lagState.snapshotLag();
        if (snap.isEmpty()) return;
        var worst = snap.entrySet().stream().max(java.util.Map.Entry.comparingByValue()).orElse(null);
        if (worst == null) return;
        var key = worst.getKey();
        long lag = worst.getValue() == null ? 0L : worst.getValue();
        int cons = lagState.consecutiveAbove(key.groupId, key.topic, key.partition);
        if (lag > threshold && cons >= consecutiveReq) {
            long cooldownMs = (long) cfg.getCooldownMinutes() * 60_000L;
            long now = System.currentTimeMillis();
            if (lagState.shouldNotify(key, now, cooldownMs)) {
                notifier.notify(key, lag, snap);
                lagState.markNotified(key, now);
            }
        }
    }
