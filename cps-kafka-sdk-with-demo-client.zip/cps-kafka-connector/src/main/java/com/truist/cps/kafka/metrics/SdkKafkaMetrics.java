package com.truist.cps.kafka.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Centralizes Micrometer metrics used by the Kafka SDK.
 * <p>
 * If Micrometer is not on the classpath or no {@link MeterRegistry} bean is present,
 * the SDK will fall back to a no-op implementation (no metrics will be recorded).
 */
public interface SdkKafkaMetrics {

    /** Increment when a record processing attempt is retried (delivery attempt > 1). */
    void incrementRetry();

    /** Increment when a record is published to the dead-letter topic (DLT). */
    void incrementDlt();

    /** Increment when a poison record is skipped without sending to DLT (DLT disabled). */
    void incrementPoisonSkip();

    /** Create a Micrometer-backed metrics implementation. */
    static SdkKafkaMetrics micrometer(MeterRegistry registry) {
        return new MicrometerSdkKafkaMetrics(registry);
    }

    /** No-op implementation. */
    static SdkKafkaMetrics noop() {
        return NoopSdkKafkaMetrics.INSTANCE;
    }

    final class MicrometerSdkKafkaMetrics implements SdkKafkaMetrics {
        private final Counter retry;
        private final Counter dlt;
        private final Counter poison;

        MicrometerSdkKafkaMetrics(MeterRegistry registry) {
            this.retry = Counter.builder("kafka.sdk.retry.count")
                    .description("Number of retry attempts performed by Kafka SDK error handler")
                    .register(registry);
            this.dlt = Counter.builder("kafka.sdk.dlt.count")
                    .description("Number of records published to DLT by Kafka SDK")
                    .register(registry);
            this.poison = Counter.builder("kafka.sdk.poison.skip.count")
                    .description("Number of poison records skipped+committed with DLT disabled")
                    .register(registry);
        }

        @Override public void incrementRetry() { retry.increment(); }
        @Override public void incrementDlt() { dlt.increment(); }
        @Override public void incrementPoisonSkip() { poison.increment(); }
    }

    enum NoopSdkKafkaMetrics implements SdkKafkaMetrics {
        INSTANCE;
        @Override public void incrementRetry() {}
        @Override public void incrementDlt() {}
        @Override public void incrementPoisonSkip() {}
    }
}
