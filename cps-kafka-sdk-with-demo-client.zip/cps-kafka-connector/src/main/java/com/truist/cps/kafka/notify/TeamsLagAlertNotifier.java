package com.truist.cps.kafka.notify;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.metrics.SdkLagStateTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Sends lag alerts to Microsoft Teams via Incoming Webhook.
 */
public class TeamsLagAlertNotifier implements LagAlertNotifier {

    private static final Logger log = LoggerFactory.getLogger(TeamsLagAlertNotifier.class);

    private final RestTemplate restTemplate = new RestTemplate();
    private final KafkaSdkProperties props;

    public TeamsLagAlertNotifier(KafkaSdkProperties props) {
        this.props = Objects.requireNonNull(props, "props");
    }

    @Override
    public void notify(SdkLagStateTracker.LagKey worstKey, long worstLag, Map<SdkLagStateTracker.LagKey, Long> snapshot) {
        KafkaSdkProperties.LagAlertNotificationProperties cfg = props.getLagAlertNotifications();
        if (cfg == null || !cfg.isEnabled() || cfg.getTeamsWebhookUrl() == null || cfg.getTeamsWebhookUrl().isBlank()) {
            return;
        }

        String text = "**Kafka Consumer Lag Alert**\n\n"
                + "**Worst partition:**\n"
                + "- Group: " + worstKey.groupId + "\n"
                + "- Topic: " + worstKey.topic + "\n"
                + "- Partition: " + worstKey.partition + "\n"
                + "- Lag: " + worstLag + "\n\n"
                + "**Top lag snapshot:**\n"
                + snapshot.entrySet().stream()
                    .sorted((a,b) -> Long.compare(b.getValue(), a.getValue()))
                    .limit(10)
                    .map(e -> "- " + e.getKey().toString() + ": " + e.getValue())
                    .collect(Collectors.joining("\n"));

        Map<String, Object> payload = Map.of("text", text);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            restTemplate.postForEntity(cfg.getTeamsWebhookUrl(), new HttpEntity<>(payload, headers), String.class);
            log.warn("Sent Microsoft Teams lag alert");
        } catch (Exception ex) {
            log.warn("Failed to send Teams lag alert: {}", ex.toString());
        }
    }
}
