package com.truist.cps.kafka.demo;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

/**
 * Demonstrates how the SDK handles:
 * - manual ack (commit only after successful processing)
 * - retryable exceptions (retries with backoff)
 * - non-retryable (poison) exceptions (recover to DLT or skip+commit)
 * - logging/MDC correlation (handled by SDK interceptor)
 */
@Component
public class DemoConsumer {

    @KafkaListener(
            id = "demoListener",
            topics = "${app.topic}",
            containerFactory = "sdkKafkaListenerContainerFactory"
    )
    public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {

        String mode = header(record, "demo-mode", "OK");
        String payload = record.value() == null ? "" : record.value().toString();

        // Simulate different failure types:
        switch (mode) {
            case "RETRY" -> throw new RetryableProcessingException("Simulated retryable failure");
            case "NON_RETRYABLE" -> throw new NonRetryableBusinessException("Simulated non-retryable business failure");
            case "POISON" -> throw new IllegalArgumentException("Simulated poison payload (IllegalArgumentException)");
            default -> {
                // "OK"
            }
        }

        // Success: manual ack => commit offset
        ack.acknowledge();
    }

    private static String header(ConsumerRecord<?, ?> record, String name, String def) {
        Header h = record.headers().lastHeader(name);
        if (h == null || h.value() == null) return def;
        return new String(h.value(), StandardCharsets.UTF_8);
    }
}
