package com.truist.cps.kafka.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Utility endpoints to pause/resume listener containers (manual ops).
 * SDK also supports auto-pause on repeated failures via config.
 */
@RestController
@RequestMapping("/api/consumer")
public class ListenerAdminController {

    private final KafkaListenerEndpointRegistry registry;

    public ListenerAdminController(KafkaListenerEndpointRegistry registry) {
        this.registry = registry;
    }

    @PostMapping("/pause/{id}")
    public ResponseEntity<?> pause(@PathVariable String id) {
        MessageListenerContainer c = registry.getListenerContainer(id);
        if (c == null) return ResponseEntity.notFound().build();
        c.pause();
        return ResponseEntity.ok(Map.of("listenerId", id, "pauseRequested", c.isPauseRequested()));
    }

    @PostMapping("/resume/{id}")
    public ResponseEntity<?> resume(@PathVariable String id) {
        MessageListenerContainer c = registry.getListenerContainer(id);
        if (c == null) return ResponseEntity.notFound().build();
        c.resume();
        return ResponseEntity.ok(Map.of("listenerId", id, "pauseRequested", c.isPauseRequested()));
    }

    @GetMapping("/state")
    public ResponseEntity<?> state() {
        Map<String, Object> out = new LinkedHashMap<>();
        registry.getListenerContainers().forEach(c -> out.put(
                c.getListenerId(),
                Map.of("running", c.isRunning(), "pauseRequested", c.isPauseRequested(), "groupId", c.getGroupId())
        ));
        return ResponseEntity.ok(out);
    }
}
