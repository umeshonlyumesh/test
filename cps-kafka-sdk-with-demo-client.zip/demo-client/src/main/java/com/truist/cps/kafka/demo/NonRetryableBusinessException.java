package com.truist.cps.kafka.demo;

/**
 * Example non-retryable exception (immediate recover: DLT or skip+commit).
 */
public class NonRetryableBusinessException extends RuntimeException {
    public NonRetryableBusinessException(String message) { super(message); }
    public NonRetryableBusinessException(String message, Throwable cause) { super(message, cause); }
}
