# CPS MQ Connector SDK (Jakarta)

- Spring Boot 3.5.7 compatible
- IBM MQ 9.4.4.0 (Jakarta JMS)
- Annotation-based consumer: `@CpsMqListener`
- Publisher with retry
- Consumer retry + DLQ routing
- Micrometer metrics & structured logging
- Auto-configuration for easy use in core API projects
