package com.cps.mq.config;

import com.cps.mq.factory.CpsMqConnectionFactoryProvider;
import com.cps.mq.listener.CpsMqListenerRegistrar;
import com.cps.mq.metrics.CpsMqMetrics;
import com.cps.mq.producer.CpsMqPublisher;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import jakarta.jms.ConnectionFactory;

@AutoConfiguration
@EnableConfigurationProperties(CpsMqProperties.class)
public class CpsMqAutoConfiguration {

    @Bean
    public ConnectionFactory cpsMqConnectionFactory(CpsMqProperties props) throws Exception {
        return CpsMqConnectionFactoryProvider.create(props);
    }

    @Bean
    public CpsMqMetrics cpsMqMetrics(ObjectProvider<MeterRegistry> registryProvider) {
        MeterRegistry registry = registryProvider.getIfAvailable();
        if (registry != null) {
            return new CpsMqMetrics(registry);
        }
        return CpsMqMetrics.noop();
    }

    @Bean
    public CpsMqPublisher cpsMqPublisher(ConnectionFactory connectionFactory,
                                         CpsMqProperties properties,
                                         CpsMqMetrics metrics) {
        return new CpsMqPublisher(connectionFactory, properties, metrics);
    }

    @Bean
    public CpsMqListenerRegistrar cpsMqListenerRegistrar(ApplicationContext context,
                                                         ConnectionFactory connectionFactory,
                                                         CpsMqProperties properties,
                                                         CpsMqPublisher publisher,
                                                         CpsMqMetrics metrics) {
        return new CpsMqListenerRegistrar(context, connectionFactory, properties, publisher, metrics);
    }
}
