package com.cps.mq.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CpsMqMetrics {

    private final Counter producerSuccess;
    private final Counter producerFailure;
    private final Counter consumerSuccess;
    private final Counter consumerFailure;
    private final Counter consumerDlq;

    public CpsMqMetrics(MeterRegistry registry) {
        this.producerSuccess = Counter.builder("cps.mq.producer.success")
                .description("Successful MQ producer sends")
                .register(registry);
        this.producerFailure = Counter.builder("cps.mq.producer.failure")
                .description("Failed MQ producer sends")
                .register(registry);
        this.consumerSuccess = Counter.builder("cps.mq.consumer.success")
                .description("Successful MQ consumer processing")
                .register(registry);
        this.consumerFailure = Counter.builder("cps.mq.consumer.failure")
                .description("Failed MQ consumer processing")
                .register(registry);
        this.consumerDlq = Counter.builder("cps.mq.consumer.dlq")
                .description("Messages routed to DLQ")
                .register(registry);

        log.info("CpsMqMetrics initialized with Micrometer registry");
    }

    private CpsMqMetrics() {
        this.producerSuccess = null;
        this.producerFailure = null;
        this.consumerSuccess = null;
        this.consumerFailure = null;
        this.consumerDlq = null;
    }

    public static CpsMqMetrics noop() {
        return new CpsMqMetrics();
    }

    public void incProducerSuccess() {
        if (producerSuccess != null) {
            producerSuccess.increment();
        }
    }

    public void incProducerFailure() {
        if (producerFailure != null) {
            producerFailure.increment();
        }
    }

    public void incConsumerSuccess() {
        if (consumerSuccess != null) {
            consumerSuccess.increment();
        }
    }

    public void incConsumerFailure() {
        if (consumerFailure != null) {
            consumerFailure.increment();
        }
    }

    public void incConsumerDlq() {
        if (consumerDlq != null) {
            consumerDlq.increment();
        }
    }
}
