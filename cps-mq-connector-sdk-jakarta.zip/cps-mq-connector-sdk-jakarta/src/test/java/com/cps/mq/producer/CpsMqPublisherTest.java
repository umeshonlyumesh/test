package com.cps.mq.producer;

import com.cps.mq.config.CpsMqProperties;
import com.cps.mq.metrics.CpsMqMetrics;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSContext;
import jakarta.jms.JMSProducer;
import jakarta.jms.Queue;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class CpsMqPublisherTest {

    @Test
    void publish_successOnFirstAttempt() {
        ConnectionFactory connectionFactory = mock(ConnectionFactory.class);
        JMSContext jmsContext = mock(JMSContext.class);
        JMSProducer jmsProducer = mock(JMSProducer.class);
        Queue queue = mock(Queue.class);

        when(connectionFactory.createContext(JMSContext.SESSION_TRANSACTED)).thenReturn(jmsContext);
        when(jmsContext.createQueue("TEST.Q")).thenReturn(queue);
        when(jmsContext.createProducer()).thenReturn(jmsProducer);

        CpsMqProperties props = new CpsMqProperties();
        props.setProducerMaxRetries(3);
        props.setProducerBackoffMillis(0);

        CpsMqMetrics metrics = CpsMqMetrics.noop();

        CpsMqPublisher publisher = new CpsMqPublisher(connectionFactory, props, metrics);

        publisher.publish("TEST.Q", "hello");

        verify(jmsProducer, times(1)).send(queue, "hello");
        verify(jmsContext, times(1)).commit();
    }

    @Test
    void publish_retriesAndFailsAfterMaxAttempts() {
        ConnectionFactory connectionFactory = mock(ConnectionFactory.class);
        JMSContext jmsContext = mock(JMSContext.class);
        JMSProducer jmsProducer = mock(JMSProducer.class);
        Queue queue = mock(Queue.class);

        when(connectionFactory.createContext(JMSContext.SESSION_TRANSACTED)).thenReturn(jmsContext);
        when(jmsContext.createQueue("TEST.Q")).thenReturn(queue);
        when(jmsContext.createProducer()).thenReturn(jmsProducer);

        doThrow(new RuntimeException("MQ down"))
                .when(jmsProducer).send(any(Queue.class), anyString());

        CpsMqProperties props = new CpsMqProperties();
        props.setProducerMaxRetries(2);
        props.setProducerBackoffMillis(0);

        CpsMqMetrics metrics = CpsMqMetrics.noop();

        CpsMqPublisher publisher = new CpsMqPublisher(connectionFactory, props, metrics);

        assertThrows(RuntimeException.class,
                () -> publisher.publish("TEST.Q", "payload"));

        verify(jmsProducer, times(2)).send(queue, "payload");
    }
}
