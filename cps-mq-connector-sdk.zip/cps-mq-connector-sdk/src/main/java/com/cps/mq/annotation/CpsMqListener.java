package com.cps.mq.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CpsMqListener {
    /**
     * MQ queue name to listen on.
     */
    String queue();
}
