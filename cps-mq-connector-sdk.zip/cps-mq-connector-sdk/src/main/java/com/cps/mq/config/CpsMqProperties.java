package com.cps.mq.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "cps.mq")
public class CpsMqProperties {

    private String host;
    private int port;
    private String channel;
    private String queueManager;

    private String user;
    private String password;

    private String sslCipherSuite;
    private String trustStore;
    private String trustStorePassword;
    private String keyStore;
    private String keyStorePassword;

    // Retry config for producer
    private int producerMaxRetries = 3;
    private long producerBackoffMillis = 200L;

    // Retry config for consumer (in-memory retries)
    private int consumerMaxRetries = 3;
    private long consumerBackoffMillis = 200L;

    // DLQ for poison messages
    private String dlqName = "CPS.DLQ.DEFAULT";
}
