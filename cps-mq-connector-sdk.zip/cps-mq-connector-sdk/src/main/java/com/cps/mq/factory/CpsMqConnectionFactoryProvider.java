package com.cps.mq.factory;

import com.cps.mq.config.CpsMqProperties;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.wmq.common.CommonConstants;

import javax.jms.ConnectionFactory;

public final class CpsMqConnectionFactoryProvider {

    private CpsMqConnectionFactoryProvider() {
    }

    public static ConnectionFactory create(CpsMqProperties props) throws Exception {
        MQConnectionFactory factory = new MQConnectionFactory();

        factory.setHostName(props.getHost());
        factory.setPort(props.getPort());
        factory.setQueueManager(props.getQueueManager());
        factory.setChannel(props.getChannel());
        factory.setTransportType(CommonConstants.WMQ_CM_CLIENT);

        if (props.getSslCipherSuite() != null && !props.getSslCipherSuite().isBlank()) {
            factory.setSSLCipherSuite(props.getSslCipherSuite());
        }

        if (props.getTrustStore() != null && !props.getTrustStore().isBlank()) {
            System.setProperty("javax.net.ssl.trustStore", props.getTrustStore());
        }
        if (props.getTrustStorePassword() != null && !props.getTrustStorePassword().isBlank()) {
            System.setProperty("javax.net.ssl.trustStorePassword", props.getTrustStorePassword());
        }
        if (props.getKeyStore() != null && !props.getKeyStore().isBlank()) {
            System.setProperty("javax.net.ssl.keyStore", props.getKeyStore());
        }
        if (props.getKeyStorePassword() != null && !props.getKeyStorePassword().isBlank()) {
            System.setProperty("javax.net.ssl.keyStorePassword", props.getKeyStorePassword());
        }

        // IBM specific: use standard cipher mapping
        System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");

        return factory;
    }
}
