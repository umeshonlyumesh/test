package com.cps.mq.listener;

import com.cps.mq.annotation.CpsMqListener;
import com.cps.mq.config.CpsMqProperties;
import com.cps.mq.metrics.CpsMqMetrics;
import com.cps.mq.producer.CpsMqPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import javax.annotation.PostConstruct;
import javax.jms.*;
import java.lang.reflect.Method;
import java.util.*;

@Slf4j
@RequiredArgsConstructor
public class CpsMqListenerRegistrar {

    private final ApplicationContext context;
    private final ConnectionFactory connectionFactory;
    private final CpsMqProperties properties;
    private final CpsMqPublisher publisher;
    private final CpsMqMetrics metrics;

    @PostConstruct
    public void registerListeners() {
        Map<String, List<ListenerInvocation>> mapping = scanForListeners();
        if (mapping.isEmpty()) {
            log.info("No @CpsMqListener methods found in application context");
            return;
        }

        mapping.forEach((queue, invocations) -> {
            log.info("Registering MQ listener for queue={} handlerCount={}", queue, invocations.size());
            DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
            container.setConnectionFactory(connectionFactory);
            container.setDestinationName(queue);
            container.setSessionTransacted(true);
            container.setConcurrency("1-5");

            container.setMessageListener(message -> handleMessage(queue, message, invocations));

            container.afterPropertiesSet();
            container.start();
        });
    }

    /**
     * Separated out for unit testing.
     */
    public Map<String, List<ListenerInvocation>> scanForListeners() {
        Map<String, List<ListenerInvocation>> mapping = new HashMap<>();

        String[] beanNames = context.getBeanNamesForType(Object.class);

        for (String beanName : beanNames) {
            Object bean = context.getBean(beanName);
            Class<?> targetClass = bean.getClass();

            for (Method method : targetClass.getMethods()) {
                CpsMqListener ann = method.getAnnotation(CpsMqListener.class);
                if (ann != null) {
                    String queue = ann.queue();
                    mapping.computeIfAbsent(queue, q -> new ArrayList<>())
                           .add(new ListenerInvocation(bean, method));
                    log.info("Detected @CpsMqListener bean={} method={} queue={}",
                            beanName, method.getName(), queue);
                }
            }
        }

        return mapping;
    }

    private void handleMessage(String queue, Message message, List<ListenerInvocation> invocations) {
        String correlationId = null;
        String payload = null;
        try {
            correlationId = message.getJMSCorrelationID();
            if (message instanceof TextMessage textMessage) {
                payload = textMessage.getText();
            }
        } catch (JMSException e) {
            log.warn("Failed to extract payload/correlationId from message queue={} error={}", queue, e.getMessage(), e);
        }

        int maxRetries = Math.max(1, properties.getConsumerMaxRetries());
        long backoff = Math.max(0L, properties.getConsumerBackoffMillis());

        boolean success = false;
        RuntimeException lastEx = null;

        for (int attempt = 1; attempt <= maxRetries && !success; attempt++) {
            try {
                log.info("Processing MQ message queue={} attempt={} correlationId={} payloadSize={}",
                        queue, attempt, correlationId, payload != null ? payload.length() : 0);

                for (ListenerInvocation inv : invocations) {
                    inv.invoke(payload);
                }

                metrics.incConsumerSuccess();
                success = true;
                log.info("Successfully processed MQ message queue={} attempt={} correlationId={}",
                        queue, attempt, correlationId);
            } catch (RuntimeException ex) {
                metrics.incConsumerFailure();
                lastEx = ex;
                log.warn("Failed processing MQ message queue={} attempt={} maxRetries={} correlationId={} error={}",
                        queue, attempt, maxRetries, correlationId, ex.getMessage(), ex);

                if (attempt < maxRetries && backoff > 0) {
                    try {
                        Thread.sleep(backoff);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }

        if (!success) {
            // Route to DLQ
            String dlqName = properties.getDlqName();
            try {
                log.error("Routing message to DLQ queue={} dlq={} correlationId={}",
                        queue, dlqName, correlationId, lastEx);
                publisher.publish(dlqName,
                        payload != null ? payload : "<null-payload-from-queue-" + queue + ">");
                metrics.incConsumerDlq();
            } catch (RuntimeException ex) {
                log.error("Failed to route message to DLQ dlq={} originalQueue={} correlationId={} error={}",
                        dlqName, queue, correlationId, ex.getMessage(), ex);
                // At this point, container will still commit/ack the original message.
            }
        }
    }

    public record ListenerInvocation(Object bean, Method method) {

        public void invoke(String payload) {
            try {
                if (method.getParameterCount() == 0) {
                    method.invoke(bean);
                } else if (method.getParameterCount() == 1 &&
                        method.getParameterTypes()[0].equals(String.class)) {
                    method.invoke(bean, payload);
                } else {
                    throw new IllegalStateException("Unsupported @CpsMqListener method signature: " + method);
                }
            } catch (Exception ex) {
                throw new RuntimeException("Failed to invoke @CpsMqListener method: " + method, ex);
            }
        }
    }
}
