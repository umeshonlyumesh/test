package com.cps.mq.producer;

import com.cps.mq.config.CpsMqProperties;
import com.cps.mq.metrics.CpsMqMetrics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;

@Slf4j
@RequiredArgsConstructor
public class CpsMqPublisher {

    private final ConnectionFactory connectionFactory;
    private final CpsMqProperties properties;
    private final CpsMqMetrics metrics;

    public void publish(String queueName, String message) {
        int maxRetries = Math.max(1, properties.getProducerMaxRetries());
        long backoff = Math.max(0L, properties.getProducerBackoffMillis());

        RuntimeException lastEx = null;

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try (JMSContext context = connectionFactory.createContext(JMSContext.SESSION_TRANSACTED)) {

                Queue queue = context.createQueue(queueName);
                JMSProducer producer = context.createProducer();

                log.info("Publishing MQ message queue={} attempt={} payloadSize={}",
                        queueName, attempt, message != null ? message.length() : 0);

                producer.send(queue, message);
                context.commit();

                metrics.incProducerSuccess();
                log.info("Successfully published MQ message queue={} attempt={}", queueName, attempt);
                return;
            } catch (RuntimeException ex) {
                metrics.incProducerFailure();
                lastEx = ex;
                log.warn("Failed to publish MQ message queue={} attempt={} maxRetries={} error={}",
                        queueName, attempt, maxRetries, ex.getMessage(), ex);

                if (attempt < maxRetries && backoff > 0) {
                    try {
                        Thread.sleep(backoff);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }

        throw new RuntimeException("Failed to publish MQ message to queue=" + queueName
                + " after " + maxRetries + " attempts", lastEx);
    }
}
