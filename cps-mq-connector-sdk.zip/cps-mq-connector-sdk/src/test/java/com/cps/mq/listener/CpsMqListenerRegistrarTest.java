package com.cps.mq.listener;

import com.cps.mq.annotation.CpsMqListener;
import com.cps.mq.config.CpsMqProperties;
import com.cps.mq.metrics.CpsMqMetrics;
import com.cps.mq.producer.CpsMqPublisher;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.StaticApplicationContext;

import javax.jms.ConnectionFactory;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class CpsMqListenerRegistrarTest {

    static class TestListenerBean {

        String last;

        @CpsMqListener(queue = "CPS.TEST.Q")
        public void onMessage(String payload) {
            last = payload;
        }
    }

    @Test
    void scanForListeners_findsAnnotatedMethods() {
        StaticApplicationContext ctx = new StaticApplicationContext();
        ctx.registerSingleton("testListenerBean", TestListenerBean.class);

        ConnectionFactory cf = mock(ConnectionFactory.class);
        CpsMqProperties props = new CpsMqProperties();
        CpsMqPublisher publisher = mock(CpsMqPublisher.class);
        CpsMqMetrics metrics = CpsMqMetrics.noop();

        CpsMqListenerRegistrar registrar =
                new CpsMqListenerRegistrar(ctx, cf, props, publisher, metrics);

        Map<String, List<CpsMqListenerRegistrar.ListenerInvocation>> mapping = registrar.scanForListeners();

        assertFalse(mapping.isEmpty());
        assertTrue(mapping.containsKey("CPS.TEST.Q"));
        List<CpsMqListenerRegistrar.ListenerInvocation> invocations = mapping.get("CPS.TEST.Q");
        assertEquals(1, invocations.size());

        CpsMqListenerRegistrar.ListenerInvocation inv = invocations.get(0);
        TestListenerBean bean = (TestListenerBean) ctx.getBean("testListenerBean");
        inv.invoke("hello");
        assertEquals("hello", bean.last);
    }
}
