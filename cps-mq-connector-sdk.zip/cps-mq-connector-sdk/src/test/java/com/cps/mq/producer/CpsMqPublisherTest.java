package com.cps.mq.producer;

import com.cps.mq.config.CpsMqProperties;
import com.cps.mq.metrics.CpsMqMetrics;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.jms.ConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CpsMqPublisherTest {

    @Test
    void publish_success_onFirstAttempt() {
        ConnectionFactory connectionFactory = mock(ConnectionFactory.class);
        JMSContext jmsContext = mock(JMSContext.class);
        JMSProducer jmsProducer = mock(JMSProducer.class);
        Queue queue = mock(Queue.class);

        when(connectionFactory.createContext(JMSContext.SESSION_TRANSACTED)).thenReturn(jmsContext);
        when(jmsContext.createQueue("TEST.Q")).thenReturn(queue);
        when(jmsContext.createProducer()).thenReturn(jmsProducer);

        CpsMqProperties props = new CpsMqProperties();
        props.setProducerMaxRetries(3);
        props.setProducerBackoffMillis(0);

        CpsMqMetrics metrics = CpsMqMetrics.noop();

        CpsMqPublisher publisher = new CpsMqPublisher(connectionFactory, props, metrics);

        publisher.publish("TEST.Q", "hello");

        verify(jmsProducer, times(1)).send(queue, "hello");
        verify(jmsContext, times(1)).commit();
    }

    @Test
    void publish_retries_andFailsAfterMaxAttempts() {
        ConnectionFactory connectionFactory = mock(ConnectionFactory.class);
        JMSContext jmsContext = mock(JMSContext.class);
        JMSProducer jmsProducer = mock(JMSProducer.class);
        Queue queue = mock(Queue.class);

        when(connectionFactory.createContext(JMSContext.SESSION_TRANSACTED)).thenReturn(jmsContext);
        when(jmsContext.createQueue("TEST.Q")).thenReturn(queue);
        when(jmsContext.createProducer()).thenReturn(jmsProducer);

        doThrow(new RuntimeException("MQ down"))
                .when(jmsProducer).send(any(Queue.class), anyString());

        CpsMqProperties props = new CpsMqProperties();
        props.setProducerMaxRetries(2);
        props.setProducerBackoffMillis(0);

        CpsMqMetrics metrics = CpsMqMetrics.noop();

        CpsMqPublisher publisher = new CpsMqPublisher(connectionFactory, props, metrics);

        assertThrows(RuntimeException.class,
                () -> publisher.publish("TEST.Q", "payload"));

        verify(jmsProducer, times(2)).send(queue, "payload");
    }
}
