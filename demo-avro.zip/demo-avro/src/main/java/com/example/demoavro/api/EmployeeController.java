package com.example.demoavro.api;

import com.example.demoavro.producer.EmployeeProducer;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/employees")
@Validated
public class EmployeeController {

    private final EmployeeProducer producer;

    public EmployeeController(EmployeeProducer producer) {
        this.producer = producer;
    }

    public record EmployeeRequest(
            @NotBlank String firstName,
            @NotBlank String lastName,
            @NotBlank @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "dob must be yyyy-MM-dd") String dob
    ) {}

    @PostMapping
    public CompletableFuture<ResponseEntity<Map<String, Object>>> publish(@Valid @RequestBody EmployeeRequest request) {
        // Validate DOB format strictly
        try {
            LocalDate.parse(request.dob(), DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (DateTimeParseException e) {
            return CompletableFuture.completedFuture(ResponseEntity.badRequest().body(Map.of(
                    "error", "Invalid dob format, expected yyyy-MM-dd"
            )));
        }

        return producer.send(request.firstName(), request.lastName(), request.dob())
                .thenApply(md -> ResponseEntity.status(HttpStatus.ACCEPTED).body(Map.of(
                        "topic", (Object) md.topic(),
                        "partition", (Object) md.partition(),
                        "offset", (Object) md.offset(),
                        "timestamp", (Object) md.timestamp()
                )))
                .exceptionally(ex -> ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("error", (Object) ex.getMessage())));
    }
}
