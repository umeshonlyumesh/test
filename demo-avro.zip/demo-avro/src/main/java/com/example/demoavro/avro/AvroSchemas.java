package com.example.demoavro.avro;

import org.apache.avro.Schema;
import org.apache.avro.SchemaParseException;
import org.apache.avro.SchemaValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;

@Component
public class AvroSchemas {

    private static final Logger log = LoggerFactory.getLogger(AvroSchemas.class);

    private Schema employeeSchema;

    public Schema employeeSchema() {
        if (employeeSchema == null) {
            employeeSchema = load("avro/employee-v1.avsc");
        }
        return employeeSchema;
    }

    private Schema load(String classpathLocation) {
        ClassPathResource resource = new ClassPathResource(classpathLocation);
        try (InputStream is = resource.getInputStream()) {
            return new Schema.Parser().parse(is);
        } catch (IOException | SchemaParseException e) {
            log.error("Failed to load Avro schema {}: {}", classpathLocation, e.getMessage(), e);
            throw new IllegalStateException("Cannot load Avro schema " + classpathLocation, e);
        }
    }
}
