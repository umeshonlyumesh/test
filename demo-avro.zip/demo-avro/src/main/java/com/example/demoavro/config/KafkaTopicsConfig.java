package com.example.demoavro.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaTopicsConfig {

    @Value("${app.topics.employee}")
    private String employeeTopic;

    @Value("${app.topics.employee-dlt}")
    private String employeeDltTopic;

    @Bean
    public NewTopic employeeTopic() {
        return TopicBuilder.name(employeeTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    @Bean
    public NewTopic employeeDltTopic() {
        return TopicBuilder.name(employeeDltTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
