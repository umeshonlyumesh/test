package com.example.demoavro.consumer;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class EmployeeConsumer {

    private static final Logger log = LoggerFactory.getLogger(EmployeeConsumer.class);

    @KafkaListener(topics = "${app.topics.employee}", containerFactory = "kafkaListenerContainerFactory")
    public void onEmployee(ConsumerRecord<String, GenericRecord> record) {
        GenericRecord employee = record.value();
        String key = record.key();
        log.info("Consumed Employee: key={}, name={} {}, dob={}, from partition={}, offset={}",
                key, employee.get("firstName"), employee.get("lastName"), employee.get("dob"), record.partition(), record.offset());
    }

    @KafkaListener(topics = "${app.topics.employee-dlt}", containerFactory = "kafkaListenerContainerFactory")
    public void onEmployeeDlt(ConsumerRecord<String, GenericRecord> record) {
        log.error("Received message on DLT: topic={}, partition={}, offset={}, key={}, value={}",
                record.topic(), record.partition(), record.offset(), record.key(), record.value());
    }
}
