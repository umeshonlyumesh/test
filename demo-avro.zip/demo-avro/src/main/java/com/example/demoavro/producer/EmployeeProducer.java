package com.example.demoavro.producer;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class EmployeeProducer {

    private static final Logger log = LoggerFactory.getLogger(EmployeeProducer.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final Schema employeeSchema;

    @Value("${app.topics.employee}")
    private String employeeTopic;

    public EmployeeProducer(KafkaTemplate<String, Object> kafkaTemplate,
                            com.example.demoavro.avro.AvroSchemas schemas) {
        this.kafkaTemplate = kafkaTemplate;
        this.employeeSchema = schemas.employeeSchema();
    }

    public CompletableFuture<RecordMetadata> send(String firstName, String lastName, String dob) {
        String key = firstName + ":" + lastName;
        GenericRecord record = new GenericData.Record(employeeSchema);
        record.put("firstName", firstName);
        record.put("lastName", lastName);
        record.put("dob", dob);
        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(employeeTopic, key, record);
        return future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send Employee to topic {}: {}", employeeTopic, ex.getMessage(), ex);
                    } else if (result != null) {
                        RecordMetadata metadata = result.getRecordMetadata();
                        log.info("Sent Employee [{} {}] to {}-{}@offset {}", firstName, lastName, metadata.topic(), metadata.partition(), metadata.offset());
                    }
                })
                .thenApply(SendResult::getRecordMetadata);
    }
}
