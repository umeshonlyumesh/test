package com.example.demoavro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAvroApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoAvroApplication.class, args);
    }

}
