package com.example.demoavro.api;

import com.example.demoavro.producer.UnifiedProducer;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/publish")
@Validated
public class GenericPublishController {

    private final UnifiedProducer producer;

    public GenericPublishController(UnifiedProducer producer) {
        this.producer = producer;
    }

    public record PublishRequest(
            @NotBlank String topic,
            @NotBlank String schemaFile,
            String key,
            @NotNull Map<String, Object> payload
    ) {}

    public record StringPublishRequest(
            @NotBlank String topic,
            String key,
            @NotBlank String value
    ) {}

    @PostMapping
    public CompletableFuture<ResponseEntity<Map<String, Object>>> publish(@Valid @RequestBody PublishRequest request) {
        return producer.sendAvro(request.topic(), request.schemaFile(), request.key(), request.payload())
                .thenApply(md -> ResponseEntity.status(HttpStatus.ACCEPTED).body(Map.of(
                        "topic", (Object) md.topic(),
                        "partition", (Object) md.partition(),
                        "offset", (Object) md.offset(),
                        "timestamp", (Object) md.timestamp()
                )))
                .exceptionally(ex -> ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", (Object) ex.getMessage())));
    }

    @PostMapping("/string")
    public CompletableFuture<ResponseEntity<Map<String, Object>>> publishString(@Valid @RequestBody StringPublishRequest request) {
        return producer.sendString(request.topic(), request.key(), request.value())
                .thenApply(md -> ResponseEntity.status(HttpStatus.ACCEPTED).body(Map.of(
                        "topic", (Object) md.topic(),
                        "partition", (Object) md.partition(),
                        "offset", (Object) md.offset(),
                        "timestamp", (Object) md.timestamp()
                )))
                .exceptionally(ex -> ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", (Object) ex.getMessage())));
    }
}
