package com.example.demoavro.consumer;

import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class UnifiedConsumer {

    private static final Logger log = LoggerFactory.getLogger(UnifiedConsumer.class);

    @KafkaListener(topics = "${app.topics.employee}", containerFactory = "kafkaListenerContainerFactory")
    public void onEmployee(ConsumerRecord<String, Object> record) {
        Object value = record.value();
        String key = record.key();
        if (value instanceof GenericRecord employee) {
            log.info("Consumed Employee (Avro): key={}, name={} {}, dob={}, from partition={}, offset={}",
                    key, employee.get("firstName"), employee.get("lastName"), employee.get("dob"), record.partition(), record.offset());
        } else if (value instanceof String s) {
            log.info("Consumed Employee (String): key={}, value='{}', from partition={}, offset={}",
                    key, s, record.partition(), record.offset());
        } else if (value == null) {
            log.warn("Consumed null value: key={}, partition={}, offset={}", key, record.partition(), record.offset());
        } else {
            log.info("Consumed Employee (Unknown type {}): key={}, value={}, partition={}, offset={}",
                    value.getClass().getName(), key, value, record.partition(), record.offset());
        }
    }

    @KafkaListener(topics = "${app.topics.employee-dlt}", containerFactory = "kafkaListenerContainerFactory")
    public void onEmployeeDlt(ConsumerRecord<String, Object> record) {
        log.error("Received message on DLT: topic={}, partition={}, offset={}, key={}, value={}",
                record.topic(), record.partition(), record.offset(), record.key(), record.value());
    }
}
