package com.example.demoavro.producer;

import com.example.demoavro.avro.AvroSchemas;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class GenericAvroProducer {

    private static final Logger log = LoggerFactory.getLogger(GenericAvroProducer.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final AvroSchemas schemas;

    public GenericAvroProducer(KafkaTemplate<String, Object> kafkaTemplate, AvroSchemas schemas) {
        this.kafkaTemplate = kafkaTemplate;
        this.schemas = schemas;
    }

    /**
     * Send a message built from the provided Avro schema file located under classpath resources.
     *
     * @param topic Kafka topic to publish to
     * @param schemaFile file name under classpath folder resources/avro (e.g., "employee-v1.avsc" or "customer-v1.avsc").
     *                   You can also pass a full classpath like "avro/customer-v1.avsc".
     * @param key Partitioning key; if null or blank, a random key will be generated
     * @param payload Map of field values for the Avro record
     */
    public CompletableFuture<RecordMetadata> send(String topic, String schemaFile, String key, Map<String, Object> payload) {
        Objects.requireNonNull(topic, "topic must not be null");
        Objects.requireNonNull(schemaFile, "schemaFile must not be null");
        Objects.requireNonNull(payload, "payload must not be null");

        Schema schema = schemaFile.startsWith("avro/") ? schemas.schema(schemaFile) : schemas.schemaByName(schemaFile);
        validateRequiredFields(schema, payload);
        GenericRecord record = buildRecord(schema, payload);

        String finalKey = (key == null || key.isBlank()) ? ("auto-" + UUID.randomUUID()) : key;
        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, finalKey, record);
        return future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send Avro to topic {} using schema {}: {}", topic, schema.getFullName(), ex.getMessage(), ex);
                    } else if (result != null) {
                        RecordMetadata metadata = result.getRecordMetadata();
                        log.info("Sent Avro {} to {}-{}@offset {} with key={} ", schema.getName(), metadata.topic(), metadata.partition(), metadata.offset(), finalKey);
                    }
                })
                .thenApply(SendResult::getRecordMetadata);
    }

    private static GenericRecord buildRecord(Schema schema, Map<String, Object> payload) {
        GenericRecord record = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            Object value = payload.get(field.name());
            // Simple coercions can be added here if needed. For now, pass through.
            record.put(field.name(), value);
        }
        return record;
    }

    private static void validateRequiredFields(Schema schema, Map<String, Object> payload) {
        Set<String> missing = new HashSet<>();
        for (Schema.Field field : schema.getFields()) {
            boolean hasDefault = field.hasDefaultValue();
            boolean nullable = isNullable(field.schema());
            if (!hasDefault && !nullable) {
                if (!payload.containsKey(field.name()) || payload.get(field.name()) == null) {
                    missing.add(field.name());
                }
            }
        }
        if (!missing.isEmpty()) {
            throw new IllegalArgumentException("Missing required fields for schema '" + schema.getFullName() + "': " + missing);
        }
    }

    private static boolean isNullable(Schema fieldSchema) {
        if (fieldSchema.getType() == Schema.Type.NULL) return true;
        if (fieldSchema.getType() == Schema.Type.UNION) {
            for (Schema s : fieldSchema.getTypes()) {
                if (s.getType() == Schema.Type.NULL) return true;
            }
        }
        return false;
    }
}
