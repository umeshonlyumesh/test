package com.example.demoavro.producer;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class GenericStringProducer {

    private static final Logger log = LoggerFactory.getLogger(GenericStringProducer.class);

    private final KafkaTemplate<String, String> kafkaTemplate;

    public GenericStringProducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public CompletableFuture<RecordMetadata> send(String topic, String key, String value) {
        Objects.requireNonNull(topic, "topic must not be null");
        Objects.requireNonNull(value, "value must not be null");

        String finalKey = (key == null || key.isBlank()) ? ("auto-" + UUID.randomUUID()) : key;
        CompletableFuture<SendResult<String, String>> future = kafkaTemplate.send(topic, finalKey, value);
        return future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send String to topic {}: {}", topic, ex.getMessage(), ex);
                    } else if (result != null) {
                        RecordMetadata md = result.getRecordMetadata();
                        log.info("Sent String message to {}-{}@offset {} with key={}", md.topic(), md.partition(), md.offset(), finalKey);
                    }
                })
                .thenApply(SendResult::getRecordMetadata);
    }
}
