package com.example.demoavro.producer;

import com.example.demoavro.avro.AvroSchemas;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
public class UnifiedProducer {

    private static final Logger log = LoggerFactory.getLogger(UnifiedProducer.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final AvroSchemas schemas;

    @Value("${app.messaging.format:avro}")
    private String messagingFormat;

    public UnifiedProducer(KafkaTemplate<String, Object> kafkaTemplate, AvroSchemas schemas) {
        this.kafkaTemplate = kafkaTemplate;
        this.schemas = schemas;
    }

    private boolean isAvro() {
        return "avro".equalsIgnoreCase(messagingFormat);
    }

    public CompletableFuture<RecordMetadata> sendAvro(String topic, String schemaFile, String key, Map<String, Object> payload) {
        if (!isAvro()) {
            throw new IllegalStateException("Application is configured for '" + messagingFormat + "' messaging, Avro publishing is disabled.");
        }
        Objects.requireNonNull(topic, "topic must not be null");
        Objects.requireNonNull(schemaFile, "schemaFile must not be null");
        Objects.requireNonNull(payload, "payload must not be null");

        Schema schema = schemaFile.startsWith("avro/") ? schemas.schema(schemaFile) : schemas.schemaByName(schemaFile);
        validateRequiredFields(schema, payload);
        GenericRecord record = buildRecord(schema, payload);

        String finalKey = (key == null || key.isBlank()) ? ("auto-" + UUID.randomUUID()) : key;
        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, finalKey, record);
        return future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send Avro to topic {} using schema {}: {}", topic, schema.getFullName(), ex.getMessage(), ex);
                    } else if (result != null) {
                        RecordMetadata metadata = result.getRecordMetadata();
                        log.info("Sent Avro {} to {}-{}@offset {} with key={}", schema.getName(), metadata.topic(), metadata.partition(), metadata.offset(), finalKey);
                    }
                })
                .thenApply(SendResult::getRecordMetadata);
    }

    public CompletableFuture<RecordMetadata> sendString(String topic, String key, String value) {
        if (isAvro()) {
            throw new IllegalStateException("Application is configured for '" + messagingFormat + "' messaging, String publishing is disabled.");
        }
        Objects.requireNonNull(topic, "topic must not be null");
        Objects.requireNonNull(value, "value must not be null");
        String finalKey = (key == null || key.isBlank()) ? ("auto-" + UUID.randomUUID()) : key;
        CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, finalKey, value);
        return future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send String to topic {}: {}", topic, ex.getMessage(), ex);
                    } else if (result != null) {
                        RecordMetadata md = result.getRecordMetadata();
                        log.info("Sent String message to {}-{}@offset {} with key={}", md.topic(), md.partition(), md.offset(), finalKey);
                    }
                })
                .thenApply(SendResult::getRecordMetadata);
    }

    private static GenericRecord buildRecord(Schema schema, Map<String, Object> payload) {
        GenericRecord record = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            Object value = payload.get(field.name());
            record.put(field.name(), value);
        }
        return record;
    }

    private static void validateRequiredFields(Schema schema, Map<String, Object> payload) {
        Set<String> missing = new HashSet<>();
        for (Schema.Field field : schema.getFields()) {
            boolean hasDefault = field.hasDefaultValue();
            boolean nullable = isNullable(field.schema());
            if (!hasDefault && !nullable) {
                if (!payload.containsKey(field.name()) || payload.get(field.name()) == null) {
                    missing.add(field.name());
                }
            }
        }
        if (!missing.isEmpty()) {
            throw new IllegalArgumentException("Missing required fields for schema '" + schema.getFullName() + "': " + missing);
        }
    }

    private static boolean isNullable(Schema fieldSchema) {
        if (fieldSchema.getType() == Schema.Type.NULL) return true;
        if (fieldSchema.getType() == Schema.Type.UNION) {
            for (Schema s : fieldSchema.getTypes()) {
                if (s.getType() == Schema.Type.NULL) return true;
            }
        }
        return false;
    }
}
