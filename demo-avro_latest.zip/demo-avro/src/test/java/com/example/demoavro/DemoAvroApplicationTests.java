package com.example.demoavro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAvroApplicationTests {

    @Test
    void contextLoads() {
    }

}
