package com.truist.cps.kafka.consumer;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Objects;

public class SdkConsumerManager {

    private final ObjectProvider<KafkaListenerEndpointRegistry> registryProvider;

    public SdkConsumerManager(ObjectProvider<KafkaListenerEndpointRegistry> registryProvider) {
        this.registryProvider = Objects.requireNonNull(registryProvider, "registryProvider");
    }

    public void pause(String listenerId) {
        container(listenerId).pause();
    }

    public void resume(String listenerId) {
        container(listenerId).resume();
    }

    public boolean isPaused(String listenerId) {
        return container(listenerId).isPauseRequested();
    }

    private MessageListenerContainer container(String listenerId) {
        if (listenerId == null || listenerId.isBlank()) {
            throw new IllegalArgumentException("listenerId is required");
        }
        KafkaListenerEndpointRegistry registry = registryProvider.getIfAvailable();
        if (registry == null) {
            throw new IllegalStateException("KafkaListenerEndpointRegistry not initialized yet");
        }
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        if (container == null) {
            throw new IllegalArgumentException("No listener container found for id=" + listenerId);
        }
        return container;
    }
}
