package com.truist.cps.kafka.metrics;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.config.SslProperties;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Computes consumer lag per topic-partition for a consumer group using Kafka {@link AdminClient}.
 * <p>
 * Lag formula: {@code endOffset - committedOffset}.
 * <p>
 * Notes:
 * <ul>
 *   <li>Uses AdminClient, so it is independent of the consumer thread and safe for monitoring.</li>
 *   <li>Designed for periodic polling; keep the interval moderate (e.g., 15-60s).</li>
 * </ul>
 */
public class SdkConsumerLagMeter {

    private static final Logger log = LoggerFactory.getLogger(SdkConsumerLagMeter.class);

    private final KafkaSdkProperties props;

    public SdkConsumerLagMeter(KafkaSdkProperties props) {
        this.props = Objects.requireNonNull(props, "props");
    }

    /**
     * Fetch lag per partition for the configured group.
     *
     * @param groupId consumer group id
     * @return map of TopicPartition -> lag (>=0). Empty map if unavailable.
     */
    public Map<TopicPartition, Long> fetchLag(String groupId) {
        if (groupId == null || groupId.isBlank()) return Map.of();

        String bootstrap = props.getBootstrapServers();
        if (bootstrap == null || bootstrap.isBlank()) return Map.of();

        long timeoutMs = props.getHealthTimeoutMs() != null ? props.getHealthTimeoutMs() : 2000L;

        Properties cfg = new Properties();
        cfg.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);

        SslProperties ssl = props.getSsl();
        if (ssl != null) {
            cfg.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
            put(cfg, "ssl.truststore.location", ssl.getTruststoreLocation());
            put(cfg, "ssl.truststore.password", ssl.getTruststorePassword());
            put(cfg, "ssl.keystore.location", ssl.getKeystoreLocation());
            put(cfg, "ssl.keystore.password", ssl.getKeystorePassword());
            put(cfg, "ssl.key.password", ssl.getKeyPassword());
        }

        try (AdminClient admin = AdminClient.create(cfg)) {
            Map<TopicPartition, OffsetAndMetadata> committed = admin.listConsumerGroupOffsets(groupId)
                    .partitionsToOffsetAndMetadata()
                    .get(timeoutMs, TimeUnit.MILLISECONDS);

            if (committed == null || committed.isEmpty()) return Map.of();

            Map<TopicPartition, OffsetSpec> req = new HashMap<>();
            for (TopicPartition tp : committed.keySet()) {
                req.put(tp, OffsetSpec.latest());
            }

            Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> end = admin.listOffsets(req)
                    .all()
                    .get(timeoutMs, TimeUnit.MILLISECONDS);

            Map<TopicPartition, Long> lag = new HashMap<>();
            for (Map.Entry<TopicPartition, OffsetAndMetadata> e : committed.entrySet()) {
                TopicPartition tp = e.getKey();
                long committedOffset = e.getValue() == null ? -1L : e.getValue().offset();
                long endOffset = end.get(tp) == null ? -1L : end.get(tp).offset();
                if (committedOffset >= 0 && endOffset >= 0) {
                    lag.put(tp, Math.max(0L, endOffset - committedOffset));
                }
            }
            return lag;
        } catch (Exception ex) {
            log.debug("Lag fetch failed for groupId={}: {}", groupId, ex.toString());
            return Map.of();
        }
    }

    private static void put(Properties cfg, String key, String value) {
        if (value != null && !value.isBlank()) cfg.put(key, value);
    }
}
