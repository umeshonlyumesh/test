package com.truist.cps.kafka.metrics;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tracks lag history per group-topic-partition to support lag health and notifications.
 */
public class SdkLagStateTracker {

    public static final class LagKey {
        public final String groupId;
        public final String topic;
        public final int partition;

        public LagKey(String groupId, String topic, int partition) {
            this.groupId = groupId;
            this.topic = topic;
            this.partition = partition;
        }

        @Override public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof LagKey)) return false;
            LagKey k = (LagKey) o;
            return partition == k.partition && Objects.equals(groupId, k.groupId) && Objects.equals(topic, k.topic);
        }

        @Override public int hashCode() { return Objects.hash(groupId, topic, partition); }

        @Override public String toString() { return groupId + "|" + topic + "|" + partition; }
    }

    private final Map<LagKey, AtomicInteger> consecutiveAbove = new ConcurrentHashMap<>();
    private final Map<LagKey, Long> latestLag = new ConcurrentHashMap<>();
    private final Map<LagKey, Long> lastNotifiedEpochMs = new ConcurrentHashMap<>();

    public void update(String groupId, String topic, int partition, long lag, long threshold) {
        LagKey key = new LagKey(groupId, topic, partition);
        latestLag.put(key, lag);

        if (lag > threshold) {
            consecutiveAbove.computeIfAbsent(key, k -> new AtomicInteger()).incrementAndGet();
        } else {
            AtomicInteger c = consecutiveAbove.get(key);
            if (c != null) c.set(0);
        }
    }

    public int consecutiveAbove(String groupId, String topic, int partition) {
        AtomicInteger c = consecutiveAbove.get(new LagKey(groupId, topic, partition));
        return c == null ? 0 : c.get();
    }

    public Map<LagKey, Long> snapshotLag() {
        return new LinkedHashMap<>(latestLag);
    }

    public boolean shouldNotify(LagKey key, long nowEpochMs, long cooldownMs) {
        Long last = lastNotifiedEpochMs.get(key);
        return last == null || nowEpochMs - last >= cooldownMs;
    }

    public void markNotified(LagKey key, long nowEpochMs) {
        lastNotifiedEpochMs.put(key, nowEpochMs);
    }
}
