package com.truist.cps.kafka.metrics;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tracks listener activity for metrics and actuator reporting.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Maintain last processed timestamp per listener id.</li>
 *   <li>Maintain last poll/seen timestamp per listener id.</li>
 * </ul>
 */
public class SdkListenerStateTracker {

    private final Map<String, AtomicLong> lastSeenEpochMs = new ConcurrentHashMap<>();
    private final Map<String, AtomicLong> lastProcessedEpochMs = new ConcurrentHashMap<>();

    public void markSeen(String listenerId) {
        if (listenerId == null) return;
        lastSeenEpochMs.computeIfAbsent(listenerId, k -> new AtomicLong()).set(System.currentTimeMillis());
    }

    public void markProcessed(String listenerId) {
        if (listenerId == null) return;
        lastProcessedEpochMs.computeIfAbsent(listenerId, k -> new AtomicLong()).set(System.currentTimeMillis());
    }

    public long lastSeen(String listenerId) {
        AtomicLong v = lastSeenEpochMs.get(listenerId);
        return v == null ? 0L : v.get();
    }

    public long lastProcessed(String listenerId) {
        AtomicLong v = lastProcessedEpochMs.get(listenerId);
        return v == null ? 0L : v.get();
    }
}
