package com.truist.cps.kafka.producer;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

public class SdkKafkaProducer {

    private final KafkaTemplate<String, Object> template;

    public SdkKafkaProducer(KafkaTemplate<String, Object> template) {
        this.template = Objects.requireNonNull(template, "template");
    }

    public CompletableFuture<SendResult<String, Object>> send(String topic, String key, Object value) {
        if (topic == null || topic.isBlank()) throw new IllegalArgumentException("topic is required");
        return template.send(topic, key, value);
    }

    public CompletableFuture<RecordMetadata> sendAndReturnMetadata(String topic, String key, Object value) {
        return send(topic, key, value).thenApply(SendResult::getRecordMetadata);
    }
}
