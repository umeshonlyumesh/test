package com.example.kafkaavro;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaAvroDemoApplication {
    public static void main(String[] args){
        SpringApplication.run(SpringKafkaAvroDemoApplication.class, args);
    }
}
