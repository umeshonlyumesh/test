package com.example.kafkaavro.config;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.*;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import com.example.kafkaavro.model.Customer;
import java.util.*;

@Configuration
@EnableKafka
public class KafkaConsumerConfig {
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrap;
    @Value("${spring.kafka.properties.schema.registry.url}")
    private String schemaRegistry;

    @Bean
    public ConsumerFactory<String, Customer> consumerFactory() {
        Map<String,Object> config=new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        config.put(ConsumerConfig.GROUP_ID_CONFIG, "customer-group");
        config.put("schema.registry.url", schemaRegistry);
        config.put("specific.avro.reader", true);
        return new DefaultKafkaConsumerFactory<>(config);
    }
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String,Customer> kafkaListenerContainerFactory(){
        var f=new ConcurrentKafkaListenerContainerFactory<String,Customer>();
        f.setConsumerFactory(consumerFactory());
        return f;
    }
}
