package com.example.kafkaavro.config;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.*;
import com.example.kafkaavro.model.Customer;
import org.apache.kafka.clients.producer.ProducerConfig;
import java.util.*;

@Configuration
public class KafkaProducerConfig {
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrap;
    @Value("${spring.kafka.properties.schema.registry.url}")
    private String schemaRegistry;
    @Bean
    public ProducerFactory<String, Customer> producerFactory() {
        Map<String,Object> config=new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        config.put("schema.registry.url", schemaRegistry);
        return new DefaultKafkaProducerFactory<>(config);
    }
    @Bean
    public KafkaTemplate<String, Customer> kafkaTemplate(){
        return new KafkaTemplate<>(producerFactory());
    }
}
