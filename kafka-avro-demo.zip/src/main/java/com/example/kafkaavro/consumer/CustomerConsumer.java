package com.example.kafkaavro.consumer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import com.example.kafkaavro.model.Customer;

@Service
public class CustomerConsumer {
    @KafkaListener(topics="${topic.customer}", groupId="customer-group")
    public void consume(Customer c){
        System.out.println("Received: "+c);
    }
}
