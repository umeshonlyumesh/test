package com.example.kafkaavro.controller;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.example.kafkaavro.producer.CustomerProducer;
import com.example.kafkaavro.model.Customer;

@RestController
@RequiredArgsConstructor
@RequestMapping("/customer")
public class PublishController {
    private final CustomerProducer producer;
    @PostMapping("/publish")
    public String publish(@RequestBody Customer customer){
        producer.send(customer);
        return "Message Sent";
    }
}
