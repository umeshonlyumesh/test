package com.example.kafkaavro.producer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import com.example.kafkaavro.model.Customer;

@Service
@RequiredArgsConstructor
public class CustomerProducer {
    private final KafkaTemplate<String, Customer> kafkaTemplate;
    @Value("${topic.customer}")
    private String topic;
    public void send(Customer customer){
        kafkaTemplate.send(topic, customer.getId(), customer);
    }
}
