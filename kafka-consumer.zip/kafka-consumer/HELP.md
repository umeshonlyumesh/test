# Getting Started

This project demonstrates a robust Kafka consumer and producer using the low-level kafka-clients API under Spring Boot.
It now includes a tiny example that sends a few messages on startup and consumes them.

## Prerequisites
- Java 21+
- A running Kafka broker at localhost:9092 (or change `kafka.bootstrap.servers`)
- A topic named `test-topic` (or change `kafka.topic` and `producer.topic` in `src/main/resources/application.yml`)

## How to run
1. Start Kafka locally and create the topic if needed.
2. Build and run the app:
   - Windows PowerShell:
     - `./mvnw.cmd spring-boot:run`
   - Or build a jar and run:
     - `./mvnw.cmd clean package`
     - `java -jar target/kafka-consumer-0.0.1-SNAPSHOT.jar`

## What happens
- On startup, `ProducerConsumerExample` enqueues a handful of demo messages using `RobustKafkaProducer`.
- `RobustKafkaProducer` will dispatch them to Kafka with retry/backoff.
- `RobustKafkaConsumer` consumes from the same topic and logs the records.

Look for logs like:
- `Example enqueued=... key=key-0 value=hello kafka` (producer example)
- `Produced topic=... partition=... offset=...` (producer send callback)
- `Consumed key=... value=... partition=... offset=...` (consumer)

## Configuration
Adjust settings in `application.yml`, e.g.:
- `kafka.bootstrap.servers` – broker address
- `kafka.topic` and `producer.topic` – topic names
- `producer.*` – producer reliability and performance tuning (uses standard KafkaProducer only).
- Backpressure: when `buffer.memory` fills, `KafkaProducer.send` may block up to `max.block.ms` (default). Tune `linger.ms`, `batch.size`, `buffer.memory` for throughput vs latency. There are no app-level queue knobs; this aligns with Kafka best practices.
- `consumer.concurrent.handlers` – consumer processing threads


### Producer error handling when broker is down/unreachable
If you need the caller to get a timeout or a standard Kafka exception instead of background retries, use the synchronous API:

```
@Autowired
RobustKafkaProducer producer;

try {
    // waits up to 5 seconds
    RecordMetadata md = producer.sendSync("my-key", "payload", 5000);
    // success
} catch (org.apache.kafka.common.errors.TimeoutException te) {
    // timed out waiting for broker; decide if/when to retry
} catch (org.apache.kafka.common.errors.RetriableException re) {
    // transient error reported by Kafka; caller may retry with backoff
} catch (org.apache.kafka.common.KafkaException ke) {
    // non-retriable or other Kafka failure; decide appropriate action
}
```

Notes:
- `sendSync(...)` bypasses the internal queue and background retry loop to provide immediate feedback.
- It throws `TimeoutException` if the wait exceeds the provided timeout.
- It rethrows the underlying Kafka exceptions (including `RetriableException`) so your code can handle them and implement its own retry/backoff policy.
- The existing `offer(...)` methods remain non-blocking and continue to rely on background retries.

### Configure consumer via annotation
You can override the consumer topic and group id using an annotation on any Spring bean method:

```java
@Component
class MyConsumerConfig {
    @KafkaConsumerConfig(topic = "orders", groupId = "orders-group")
    void configure() { /* no-op */ }
}
```

Notes:
- The annotation is discovered at startup and applied before the consumer starts.
- Values from the annotation take precedence over application.properties for `kafka.topic` and `kafka.group.id`.
- If multiple annotations are present, the first one discovered is used (a log line will mention this).

## Reference Documentation
- [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
- [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.0.1/maven-plugin)
- [Create an OCI image](https://docs.spring.io/spring-boot/4.0.1/maven-plugin/build-image.html)



## Controlling the consumer at runtime (pause/resume/start/stop)
You can programmatically control the RobustKafkaConsumer lifecycle and fetch flow from any Spring-managed bean.

Basic operations:
- Start: `robustKafkaConsumer.start()` (only needed if you disable auto-start)
- Stop: `robustKafkaConsumer.stop()`
- Pause: `robustKafkaConsumer.requestPause()` — safe to call from any thread; applied on the next poll loop
- Resume: `robustKafkaConsumer.requestResume()` — safe to call from any thread; applied on the next poll loop
- Check state: `robustKafkaConsumer.isRunning()` and `robustKafkaConsumer.isPaused()`

Example (see ConsumerAnnotationExample):
```java
@Component
public class MyControllerOrService {
    private final RobustKafkaConsumer consumer;
    public MyControllerOrService(RobustKafkaConsumer consumer) { this.consumer = consumer; }

    public void temporarilyStopIngestion() { consumer.requestPause(); }
    public void resumeIngestion() { consumer.requestResume(); }
    public void stopConsumer() { consumer.stop(); }
    public void startConsumer() { consumer.start(); }
}
```

Notes:
- Pause/resume is implemented by pausing/resuming the currently assigned partitions on the consumer thread. While paused, the consumer still polls for heartbeats; no new records are returned.
- On rebalance, the next loop iteration reapplies requested state.
- These calls are non-blocking; to ensure immediate effect, a light `wakeup()` is issued to break out of a blocking poll.

## Consumer-only example
If you only want to see the consumer in action without producing from this app:
- Start Kafka and ensure the topic exists.
- Run this app normally. The RobustKafkaConsumer bean starts automatically.
- In a separate terminal, produce messages to the topic using kafka-console-producer, e.g.:
  - Windows PowerShell:
    - kafka-console-producer --broker-list localhost:9092 --topic test-topic
- Watch the application logs for lines like:
  - "Partitions assigned: ..."
  - "Consumed key=... value=... partition=... offset=..."

Notes:
- A helper runner ConsumerOnlyExample logs a reminder at startup and points you to RobustKafkaConsumer.process(...)
  where you can customize how incoming records are handled.


## Consumer timeout handling (broker down or network issues)
When the broker is down, slow, or the network is partitioned, the consumer can experience timeouts from poll() or commitSync(). The RobustKafkaConsumer now explicitly handles these timeouts and backs off safely.

What happens:
- The consumer loop catches org.apache.kafka.common.errors.TimeoutException.
- A clear log line is emitted: "Kafka TIMEOUT in consumer loop: ...".
- The overridable hook onConsumerTimeout(TimeoutException) is invoked.
- The loop sleeps for kafka.retry.backoff.ms (default 1000 ms) before retrying.

How to customize behavior:
- Extend RobustKafkaConsumer and override the protected method onConsumerTimeout(TimeoutException te) to add metrics, alerting, or custom backoff strategies.

Tuning tips:
- kafka.request.timeout.ms: Upper bound for a single fetch request attempt. Lower it to detect unresponsive brokers quicker.
- kafka.retry.backoff.ms: How long to wait between retries on retriable errors and timeouts in the app loop.
- kafka.poll.timeout.ms: How long poll() waits for data; independent from request timeouts, but shorter polls make the app more responsive to shutdown and control actions.

Notes:
- TimeoutException is treated similarly to other retriable conditions — the consumer keeps running and will recover automatically once the broker/network is healthy.
- Commit-on-revoke paths also handle TimeoutException and invoke onConsumerTimeout to keep behavior consistent.

## Handling lost group membership and commit failures (CommitFailedException / UNKNOWN_MEMBER_ID)
In some scenarios, your consumer can temporarily lose its group membership (e.g., due to a rebalance or coordinator decision). During that window, any commitSync/commitAsync using the old generation will fail with CommitFailedException, and heartbeats may show UNKNOWN_MEMBER_ID.

What happens now:
- Pre-processing commit (commitSync before processing) is wrapped in a try/catch for CommitFailedException.
- If a commit fails due to membership loss, the consumer logs it, invokes onCommitFailed(...), backs off briefly, and SKIPS processing that batch. The next poll() triggers re-join and fetches again once the member is part of the group.
- Commit-on-revoke also catches CommitFailedException and invokes onCommitFailed(...); failures here are non-fatal as the rebalance is already in progress.

How to customize:
- Override the protected hook onCommitFailed(CommitFailedException ex) to plug in metrics/alerts or specialized behavior.

Why skip processing on failed pre-commit?
- With at-most-once semantics, we commit offsets before processing. If the commit fails, we must not process those records; doing so could cause duplicates later. Skipping ensures correctness: once the consumer rejoins, it will attempt to commit again for the next batch before processing.

## Handling deserialization failures without stopping the consumer
If a message cannot be deserialized (for example, corrupt bytes or an unexpected schema), the consumer will now smartly skip just that message, log the failure, and continue with the next one.

What happens:
- The poll loop catches org.apache.kafka.common.errors.RecordDeserializationException.
- The code logs the topic-partition and offset of the bad record.
- It seeks past the bad record (offset + 1) and commits that position, so the consumer does not get stuck retrying the same corrupt message.
- The overridable hook onDeserializationFailure(tp, offset, ex) is invoked so you can add metrics or route details to a dead-letter topic from a subclass.
- Processing continues immediately with the next records.

Notes and implications:
- Because this project uses at-most-once semantics (commit before processing), skipping a bad record is safe and won’t cause duplicates.
- If you rely on null values to represent tombstones, they are still processed normally — the skip logic only triggers when Kafka raises a RecordDeserializationException.
- You can tune logging or integrate DLT behavior by subclassing RobustKafkaConsumer and overriding onDeserializationFailure.
