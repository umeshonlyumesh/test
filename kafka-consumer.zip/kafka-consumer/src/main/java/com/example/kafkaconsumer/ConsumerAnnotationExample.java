package com.example.kafkaconsumer;

import org.springframework.stereotype.Component;

/**
 * Demonstrates configuring the RobustKafkaConsumer using the @KafkaConsumerConfig annotation.
 *
 * This bean does not need to call anything at runtime; the presence of the annotation
 * is enough for {@link KafkaConsumerConfigurator} to pick up the topic and group id and
 * apply them to {@link RobustKafkaConsumer} before it starts.
 */
@Component
public class ConsumerAnnotationExample {

    private final RobustKafkaConsumer consumer;

    public ConsumerAnnotationExample(RobustKafkaConsumer consumer) {
        this.consumer = consumer;
    }

    /**
     * Configure the consumer to subscribe to "test-topic" with the group id "annotated-consumer-group".
     * Adjust these values to your needs.
     */
    @KafkaConsumerConfig(topic = "test-topic", groupId = "annotated-consumer-group")
    public void configureConsumer() {
        // no-op; configuration is applied by KafkaConsumerConfigurator
    }

    /**
     * Demonstrates how to pause the consumer at runtime.
     * Safe to call from any thread. The pause applies on the next poll cycle.
     */
    public void pauseConsumer() {
        consumer.requestPause();
    }

    /**
     * Demonstrates how to resume the consumer after a pause.
     * Safe to call from any thread. The resume applies on the next poll cycle.
     */
    public void resumeConsumer() {
        consumer.requestResume();
    }

    /**
     * Demonstrates how to manually start the consumer if auto-start is disabled.
     */
    public void startConsumer() {
        consumer.start();
    }

    /**
     * Demonstrates how to stop the consumer.
     */
    public void stopConsumer() {
        consumer.stop();
    }
}
