package com.example.kafkaconsumer;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Minimal consumer-only example that runs at startup and explains how to observe the consumer.
 *
 * This runner does NOT produce any messages. It simply logs guidance so you can
 * run the application and watch {@link RobustKafkaConsumer} consume from the configured topic.
 *
 * How to use:
 * - Ensure a Kafka broker is running (default: localhost:9092) and the topic exists (kafka.topic).
 * - Start an external producer (kafka-console-producer or any app) to send messages to the topic.
 * - Run this Spring Boot app and observe consumer logs produced by RobustKafkaConsumer.
 *
 * Tip: To customize how consumed messages are handled, override the process(...) method
 * in RobustKafkaConsumer or adapt it to call your business logic.
 */
@Order(2) // run after ProducerConsumerExample if both are enabled
@Component
public class ConsumerOnlyExample implements CommandLineRunner {

    /**
     * Logs a short note reminding where to look to see consumer activity.
     *
     * @param args application args (unused)
     */
    @Override
    public void run(String... args) {
        System.out.println("Consumer-only example active: RobustKafkaConsumer starts automatically. " +
                "Send messages to the configured topic to see consumption logs. " +
                "See RobustKafkaConsumer.process(...) to customize handling.");
    }
}
