package com.example.kafkaconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot entry point for the Kafka consumer/producer demo application.
 * Boots the application context and starts all SmartLifecycle components
 * (RobustKafkaConsumer and RobustKafkaProducer) automatically.
 */
@SpringBootApplication
public class KafkaConsumerApplication {

    /**
     * Application main method. Delegates to Spring Boot to start the
     * application context and embedded lifecycle-managed components.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(KafkaConsumerApplication.class, args);
    }

}
