package com.example.kafkaconsumer;

import java.lang.annotation.*;

/**
 * Annotation to configure the RobustKafkaConsumer via a simple annotated method.
 *
 * Usage:
 * <pre>
 * {@code
 *  @Component
 *  class MyConfigBean {
 *      @KafkaConsumerConfig(topic = "orders", groupId = "orders-consumer")
 *      void configureConsumer() {}
 *  }
 * }
 * </pre>
 *
 * The annotated method need not have a body; it serves as a carrier for configuration
 * that will be picked up by {@link KafkaConsumerConfigurator} during context initialization.
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface KafkaConsumerConfig {
    /**
     * Kafka topic to subscribe to.
     */
    String topic();

    /**
     * Kafka consumer group id to use.
     */
    String groupId();
}
