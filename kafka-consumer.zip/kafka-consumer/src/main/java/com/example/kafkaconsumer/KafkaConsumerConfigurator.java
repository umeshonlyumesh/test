package com.example.kafkaconsumer;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Scans application beans for methods annotated with {@link KafkaConsumerConfig}
 * and applies the provided topic and groupId to the {@link RobustKafkaConsumer}
 * bean via its setters before it starts.
 *
 * Precedence:
 * - If at least one method is annotated, the first discovered configuration is applied.
 * - application.properties values remain defaults; the annotation overrides them.
 */
@Component
public class KafkaConsumerConfigurator implements SmartInitializingSingleton, ApplicationContextAware, Ordered {

    private ApplicationContext applicationContext;

    @Override
    public void afterSingletonsInstantiated() {
        RobustKafkaConsumer consumer = safeGetConsumer();
        if (consumer == null) {
            return; // no consumer bean present
        }

        List<Config> configs = findAnnotatedMethods();
        if (configs.isEmpty()) {
            return; // nothing to apply
        }

        // Pick the first configuration found
        Config cfg = configs.get(0);
        try {
            consumer.setTopic(cfg.topic);
            consumer.setGroupId(cfg.groupId);
            System.out.println("[KafkaConsumerConfigurator] Applied annotation-based config: topic=" + cfg.topic + ", groupId=" + cfg.groupId);
        } catch (Exception e) {
            System.err.println("[KafkaConsumerConfigurator] Failed to apply config: " + e.getMessage());
        }

        if (configs.size() > 1) {
            System.out.println("[KafkaConsumerConfigurator] Multiple @KafkaConsumerConfig detected (" + configs.size() + "). Using the first found.");
        }
    }

    private RobustKafkaConsumer safeGetConsumer() {
        try {
            return applicationContext.getBean(RobustKafkaConsumer.class);
        } catch (BeansException ex) {
            return null;
        }
    }

    private List<Config> findAnnotatedMethods() {
        List<Config> out = new ArrayList<>();
        String[] beanNames = applicationContext.getBeanDefinitionNames();
        for (String name : beanNames) {
            Object bean;
            try {
                bean = applicationContext.getBean(name);
            } catch (BeansException ex) {
                continue;
            }
            Class<?> type = bean.getClass();
            // walk class hierarchy to catch proxied beans
            while (type != null && type != Object.class) {
                for (Method m : type.getDeclaredMethods()) {
                    KafkaConsumerConfig ann = m.getAnnotation(KafkaConsumerConfig.class);
                    if (ann != null) {
                        out.add(new Config(ann.topic(), ann.groupId(), bean, m));
                    }
                }
                type = type.getSuperclass();
            }
        }
        return out;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public int getOrder() {
        // Run early (low value) to apply settings before SmartLifecycle start phase
        return Ordered.HIGHEST_PRECEDENCE;
    }

    private record Config(String topic, String groupId, Object bean, Method method) {}
}
