package com.example.kafkaconsumer;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.errors.RetriableException;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * Simple producer/consumer example that runs at application startup.
 *
 * What it does:
 * - Uses the RobustKafkaProducer to send a few sample messages to the configured topic.
 * - Demonstrates handling of all relevant Kafka exceptions, including timeouts.
 * - The RobustKafkaConsumer (managed separately as a SmartLifecycle bean) will consume and log them.
 *
 * How to see it:
 * - Start a local Kafka broker (default: localhost:9092) and ensure the topic exists (application.properties producer.topic / kafka.topic).
 * - Run the Spring Boot app. You should see logs from this runner for produced messages
 *   and logs from RobustKafkaConsumer for consumed messages.
 */
@Order(1) // run early after context ready
@Component
public class ProducerConsumerExample implements CommandLineRunner {

    private final RobustKafkaProducer producer;

    @Autowired
    public ProducerConsumerExample(RobustKafkaProducer producer) {
        this.producer = producer;
    }

    /**
     * Sends a few demo messages using the RobustKafkaProducer. Uses the synchronous
     * send API so that exceptions (including TimeoutException) are surfaced to the caller
     * and handled explicitly in this example. This bypasses the internal async queue so
     * we can demonstrate exception handling behavior clearly.
     *
     * @param args application arguments (unused)
     */
    @Override
    public void run(String... args) {
        String[] msgs = new String[]{
                "hello kafka",
                "quick brown fox",
                "robust producer",
                "and resilient consumer",
                "done"
        };
        long timeoutMs = 5000; // demo timeout per record
        for (int i = 0; i < msgs.length; i++) {
            String key = "key-" + i;
            String value = msgs[i];
            try {
                RecordMetadata md = producer.sendSync(key, value, timeoutMs);
                System.out.printf(Locale.ROOT,
                        "Example sent OK topic=%s partition=%d offset=%d key=%s value=%s%n",
                        md.topic(), md.partition(), md.offset(), key, value);
            } catch (TimeoutException te) {
                System.err.printf(Locale.ROOT,
                        "Example send TIMEOUT after %dms for key=%s value=%s: %s%n",
                        timeoutMs, key, value, te.getMessage());
                // caller could implement custom retry/backoff here if desired
            } catch (RetriableException re) {
                System.err.printf(Locale.ROOT,
                        "Example send RETRIABLE error for key=%s value=%s: %s%n",
                        key, value, re.getMessage());
                // caller may retry with backoff
            } catch (KafkaException ke) {
                System.err.printf(Locale.ROOT,
                        "Example send FAILED (KafkaException) for key=%s value=%s: %s%n",
                        key, value, ke.getMessage());
            } catch (IllegalStateException ise) {
                System.err.printf(Locale.ROOT,
                        "Example send FAILED (producer not started) for key=%s value=%s: %s%n",
                        key, value, ise.getMessage());
            } catch (Exception e) {
                // Catch-all to ensure example doesn't crash on unexpected errors
                System.err.printf(Locale.ROOT,
                        "Example send FAILED (unexpected) for key=%s value=%s: %s%n",
                        key, value, e.toString());
            }
        }
    }
}
