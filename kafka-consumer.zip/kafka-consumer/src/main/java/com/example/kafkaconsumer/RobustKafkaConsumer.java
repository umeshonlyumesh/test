package com.example.kafkaconsumer;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * High-scalable robust Kafka consumer built on kafka-clients (core) API.
 *
 * Key characteristics:
 * - Manual offset control (enable.auto.commit=false).
 * - Commits offsets BEFORE processing records to guarantee at-most-once semantics (no duplicate processing),
 *   as requested for non-idempotent processing. Note: this may lose a message if the app crashes mid-processing.
 * - Graceful shutdown using wakeup and lifecycle hooks.
 * - Handles rebalances via ConsumerRebalanceListener and commits on revoke.
 * - Resilient to broker/network outages with retry and backoff.
 */
@Component
public class RobustKafkaConsumer implements SmartLifecycle {

    // Control flags for external pause/resume requests
    private final AtomicBoolean pauseRequested = new AtomicBoolean(false);
    private final AtomicBoolean resumeRequested = new AtomicBoolean(false);
    private final AtomicBoolean paused = new AtomicBoolean(false);

    @Value("${kafka.bootstrap.servers:localhost:9092}")
    private String bootstrapServers;

    @Value("${kafka.group.id:robust-consumer-group}")
    private String groupId;

    @Value("${kafka.topic:test-topic}")
    private String topic;

    @Value("${kafka.max.poll.records:500}")
    private int maxPollRecords;

    @Value("${kafka.max.poll.interval.ms:300000}")
    private int maxPollIntervalMs;

    @Value("${kafka.session.timeout.ms:45000}")
    private int sessionTimeoutMs;

    @Value("${kafka.heartbeat.interval.ms:3000}")
    private int heartbeatIntervalMs;

    @Value("${kafka.request.timeout.ms:60000}")
    private int requestTimeoutMs;

    @Value("${kafka.fetch.max.wait.ms:500}")
    private int fetchMaxWaitMs;

    @Value("${kafka.fetch.min.bytes:1}")
    private int fetchMinBytes;

    @Value("${kafka.security.protocol:PLAINTEXT}")
    private String securityProtocol;

    @Value("${kafka.client.id:robust-consumer}")
    private String clientId;

    @Value("${kafka.poll.timeout.ms:2000}")
    private int pollTimeoutMs;

    @Value("${kafka.retry.backoff.ms:1000}")
    private long retryBackoffMs;

    @Value("${kafka.enable.auto.commit:false}")
    private boolean enableAutoCommit;

    @Value("${kafka.auto.offset.reset:latest}")
    private String autoOffsetReset;

    @Value("${consumer.concurrent.handlers:4}")
    private int concurrentHandlers;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "robust-kafka-consumer-thread");
        t.setDaemon(true);
        return t;
    });

    private volatile KafkaConsumer<String, String> consumer;

    /**
     * Requests that the consumer pause fetching from all currently assigned partitions.
     * The actual pause is applied on the consumer polling thread at the next loop iteration.
     * This method is thread-safe and returns immediately.
     */
    public void requestPause() {
        pauseRequested.set(true);
        KafkaConsumer<String, String> c = consumer;
        if (c != null) {
            try { c.wakeup(); } catch (Exception ignored) {}
        }
    }

    /**
     * Requests that the consumer resume fetching from all previously paused partitions.
     * The actual resume is applied on the consumer polling thread at the next loop iteration.
     * This method is thread-safe and returns immediately.
     */
    public void requestResume() {
        resumeRequested.set(true);
        KafkaConsumer<String, String> c = consumer;
        if (c != null) {
            try { c.wakeup(); } catch (Exception ignored) {}
        }
    }

    /**
     * Returns true if the consumer is currently paused (no records will be returned on poll()).
     * Note that partitions may change on rebalance; this reflects the last applied state.
     */
    public boolean isPaused() {
        return paused.get();
    }

    /**
     * Starts the consumer component by spawning a background thread that runs the
     * poll/commit/process loop. This method is idempotent and safe to call once.
     */
    @Override
    public void start() {
        if (running.compareAndSet(false, true)) {
            executor.submit(this::runConsumerLoop);
        }
    }

    /**
     * Stops the consumer gracefully by delegating to stop(Runnable) with a no-op callback.
     */
    @Override
    public void stop() {
        stop(() -> {});
    }

    /**
     * Signals the consumer loop to stop, triggers a wakeup on the KafkaConsumer to break out of poll,
     * and schedules the provided callback to run once shutdown work is finished.
     *
     * @param callback code to execute after shutdown completes
     */
    @Override
    public void stop(Runnable callback) {
        try {
            running.set(false);
            KafkaConsumer<String, String> c = consumer;
            if (c != null) {
                c.wakeup();
            }
        } finally {
            // allow the loop to end and close resources
        }
        // execute callback after thread finishes close
        executor.submit(callback);
    }

    /**
     * Indicates whether the consumer loop is currently active.
     *
     * @return true if running, false otherwise
     */
    @Override
    public boolean isRunning() {
        return running.get();
    }

    /**
     * Defines SmartLifecycle startup/shutdown ordering. Using a large value ensures
     * this consumer starts late (after most beans) and stops early during shutdown.
     *
     * @return the phase ordering value
     */
    @Override
    public int getPhase() {
        // start after default, stop before others if needed
        return Integer.MAX_VALUE;
    }

    /**
     * Specifies that this consumer should start automatically on application startup.
     *
     * @return true to auto-start
     */
    @Override
    public boolean isAutoStartup() {
        return true;
    }

    /**
     * Main consumer loop that configures the KafkaConsumer, subscribes with a rebalance listener,
     * polls records, commits offsets before processing to provide at-most-once semantics, and
     * dispatches records to a handler pool. The loop handles wakeups and retriable errors
     * with backoff and ensures graceful shutdown and resource cleanup.
     */
    private void runConsumerLoop() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, String.valueOf(enableAutoCommit));
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, String.valueOf(maxPollRecords));
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, String.valueOf(maxPollIntervalMs));
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, String.valueOf(sessionTimeoutMs));
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, String.valueOf(heartbeatIntervalMs));
        props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, String.valueOf(requestTimeoutMs));
        props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, String.valueOf(fetchMaxWaitMs));
        props.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG, String.valueOf(fetchMinBytes));
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        props.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
        props.put(ConsumerConfig.RETRY_BACKOFF_MS_CONFIG, String.valueOf(retryBackoffMs));

        try (KafkaConsumer<String, String> cons = new KafkaConsumer<>(props)) {
            this.consumer = cons;

            Map<TopicPartition, OffsetAndMetadata> lastCommitted = new ConcurrentHashMap<>();

            ConsumerRebalanceListener rebalanceListener = new ConsumerRebalanceListener() {
                /**
                 * Invoked before a rebalance when partitions are revoked from this consumer.
                 * Commits the last known offsets to avoid reprocessing after rebalance.
                 */
                @Override
                public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                    // Commit any last moved offsets when partitions are revoked
                    if (!lastCommitted.isEmpty()) {
                        try {
                            cons.commitSync(lastCommitted);
                            System.out.println("Committed on revoke: " + lastCommitted);
                        } catch (org.apache.kafka.common.errors.TimeoutException te) {
                            System.err.println("Commit on revoke TIMEOUT: " + te.getMessage());
                            onConsumerTimeout(te);
                        } catch (org.apache.kafka.clients.consumer.CommitFailedException cfe) {
                            System.err.println("Commit on revoke FAILED due to lost membership/rebalance: " + cfe.getMessage());
                            onCommitFailed(cfe);
                        } catch (Exception e) {
                            System.err.println("Commit on revoke failed: " + e.getMessage());
                        }
                    }
                }

                /**
                 * Invoked after a rebalance when partitions are assigned to this consumer.
                 * Logs the new assignment; no seek is performed because we rely on committed offsets.
                 */
                @Override
                public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                    System.out.println("Partitions assigned: " + partitions);
                }
            };

            cons.subscribe(Collections.singletonList(topic), rebalanceListener);

            // simple fixed thread pool for downstream processing, if needed
            ExecutorService handlers = Executors.newFixedThreadPool(Math.max(1, concurrentHandlers));

            while (running.get()) {
                // Apply external pause/resume requests in a thread-safe way on the consumer thread
                try {
                    if (pauseRequested.getAndSet(false)) {
                        Set<TopicPartition> assigned = cons.assignment();
                        if (!assigned.isEmpty()) {
                            cons.pause(assigned);
                        }
                        paused.set(true);
                        System.out.println("Consumer pause requested. Paused partitions=" + assigned);
                    }
                    if (resumeRequested.getAndSet(false)) {
                        Set<TopicPartition> pausedParts = cons.paused();
                        if (!pausedParts.isEmpty()) {
                            cons.resume(pausedParts);
                        }
                        paused.set(false);
                        System.out.println("Consumer resume requested. Resumed partitions=" + pausedParts);
                    }
                } catch (Exception e) {
                    System.err.println("Error applying pause/resume: " + e.getMessage());
                }
                try {
                    ConsumerRecords<String, String> records = cons.poll(Duration.ofMillis(pollTimeoutMs));
                    if (records.isEmpty()) {
                        continue;
                    }

                    // At-most-once: commit offsets BEFORE processing
                    Map<TopicPartition, OffsetAndMetadata> offsetsToCommit = new HashMap<>();
                    for (TopicPartition tp : records.partitions()) {
                        List<ConsumerRecord<String, String>> partitionRecords = records.records(tp);
                        long lastOffset = partitionRecords.get(partitionRecords.size() - 1).offset();
                        offsetsToCommit.put(tp, new OffsetAndMetadata(lastOffset + 1));
                    }

                    if (!offsetsToCommit.isEmpty()) {
                        try {
                            cons.commitSync(offsetsToCommit);
                            lastCommitted.clear();
                            lastCommitted.putAll(offsetsToCommit);
                            System.out.println("Committed offsets pre-processing: " + offsetsToCommit);
                        } catch (org.apache.kafka.clients.consumer.CommitFailedException cfe) {
                            // Lost group membership or rebalance in progress; do not process this batch
                            System.err.println("Commit FAILED due to lost group membership/rebalance: " + cfe.getMessage() + " -> skipping batch and rejoining");
                            onCommitFailed(cfe);
                            sleep(retryBackoffMs);
                            continue; // skip processing; next poll will rejoin and fetch again
                        }
                    }

                    // Process after commit — guarantees no duplicate processing
                    for (TopicPartition tp : records.partitions()) {
                        for (ConsumerRecord<String, String> rec : records.records(tp)) {
                            dispatchRecord(handlers, rec);
                        }
                    }
                } catch (WakeupException we) {
                    if (running.get()) {
                        // unexpected wakeup, continue
                        System.err.println("Wakeup while running: " + we.getMessage());
                        continue;
                    } else {
                        // shutdown path
                        break;
                    }
                } catch (org.apache.kafka.common.errors.TimeoutException te) {
                    // Covers timeouts from poll() and commitSync() when broker/network is slow or down
                    System.err.println("Kafka TIMEOUT in consumer loop: " + te.getMessage());
                    onConsumerTimeout(te);
                    sleep(retryBackoffMs);
                } catch (RecordDeserializationException rde) {
                    // A single record could not be deserialized; skip it and continue.
                    TopicPartition tp = rde.topicPartition();
                    long badOffset = rde.offset();
                    System.err.println("DESERIALIZATION FAILED for " + tp + "@" + badOffset + ": " + rde.getMessage() + " -> skipping this record");
                    try {
                        // Seek past the bad record and commit so we don't get stuck on it
                        cons.seek(tp, badOffset + 1);
                        cons.commitSync(Collections.singletonMap(tp, new OffsetAndMetadata(badOffset + 1)));
                        onDeserializationFailure(tp, badOffset, rde);
                    } catch (Exception ce) {
                        System.err.println("Failed to skip/commit after deserialization error: " + ce.getMessage());
                    }
                    // continue loop without backoff to remain responsive
                    continue;
                } catch (org.apache.kafka.common.errors.RetriableException re) {
                    System.err.println("Retriable Kafka error: " + re.getMessage());
                    sleep(retryBackoffMs);
                } catch (Exception e) {
                    System.err.println("Unexpected error in poll loop: " + e.getMessage());
                    sleep(retryBackoffMs);
                }
            }

            // graceful close: attempt final commit of last known committed (no-op) and close consumer
            try {
                cons.close(Duration.ofSeconds(10));
            } catch (Exception e) {
                System.err.println("Error on consumer close: " + e.getMessage());
            } finally {
                handlers.shutdown();
                try {
                    handlers.awaitTermination(5, TimeUnit.SECONDS);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
            }
        } catch (Exception e) {
            System.err.println("Consumer loop terminated with error: " + e.getMessage());
        } finally {
            running.set(false);
            this.consumer = null;
        }
    }

    /**
     * Submits a record to the handler executor for asynchronous processing.
     * Offloading allows polling to continue without blocking. Since offsets are
     * committed before processing, failures are logged but not retried to avoid duplicates.
     *
     * @param handlers the executor service used for processing
     * @param rec      the consumed record to process
     */
    private void dispatchRecord(ExecutorService handlers, ConsumerRecord<String, String> rec) {
        // In a real app, consider backpressure control and bounded queues.
        handlers.submit(() -> {
            try {
                // Simulate user processing
                process(rec);
            } catch (Exception e) {
                // Since we already committed, logging is the only option to avoid duplicates.
                System.err.println("Processing failed after commit for record " + rec.topic() + "-" + rec.partition() + "@" + rec.offset() + ": " + e.getMessage());
            }
        });
    }

    /**
     * Placeholder for actual business logic applied to each consumed record.
     * In this sample, it simply logs the key, value, partition, and offset.
     * Override this method to implement domain-specific processing.
     *
     * @param record the consumed record
     */
    protected void process(ConsumerRecord<String, String> record) {
        System.out.printf(Locale.ROOT, "Consumed key=%s value=%s partition=%d offset=%d%n",
                record.key(), record.value(), record.partition(), record.offset());
    }

    /**
     * Sleeps for the given number of milliseconds, preserving the interrupt status
     * if interrupted during sleep.
     *
     * @param millis duration to sleep in milliseconds
     */
    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Hook invoked when a TimeoutException occurs in the consumer loop (e.g., during poll or commit).
     * Subclasses can override this to implement custom behavior such as metrics, alerts, or
     * adaptive backoff. The default implementation just logs a brief message.
     *
     * @param te the timeout exception thrown by the Kafka client
     */
    protected void onConsumerTimeout(TimeoutException te) {
        System.err.println("onConsumerTimeout: backing off after timeout: " + te.getMessage());
    }

    /**
     * Hook invoked when a single record cannot be deserialized (e.g., corrupt bytes or schema mismatch).
     * Default behavior logs a concise message; override to add metrics, dead-letter production, etc.
     *
     * Note: The caller already seeks past the bad record and commits the next offset to avoid being stuck.
     *
     * @param tp the topic-partition of the failed record
     * @param offset the offset of the failed record
     * @param ex the deserialization exception from Kafka client
     */
    protected void onDeserializationFailure(TopicPartition tp, long offset, RecordDeserializationException ex) {
        System.err.println("onDeserializationFailure: skipped " + tp + "@" + offset + ": " + ex.getMessage());
    }

    /**
     * Hook invoked when an offset commit fails due to group membership loss or rebalance
     * (e.g., CommitFailedException / UNKNOWN_MEMBER_ID). The default implementation logs
     * a concise message. Override to add metrics, alerts, or custom recovery behavior.
     *
     * Note: In the main loop, when this occurs for the pre-processing commit, the consumer
     * skips processing the current batch and continues, allowing it to rejoin the group on
     * the next poll.
     *
     * @param ex the CommitFailedException raised by the Kafka client
     */
    protected void onCommitFailed(org.apache.kafka.clients.consumer.CommitFailedException ex) {
        System.err.println("onCommitFailed: commit failed due to membership/rebalance: " + ex.getMessage());
    }

    /**
     * Allows programmatic override of the consumer group id before the consumer starts.
     * Values provided here take precedence over application.properties when set before start().
     *
     * @param groupId the Kafka consumer group id to use
     */
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * Allows programmatic override of the subscribed topic before the consumer starts.
     * Values provided here take precedence over application.properties when set before start().
     *
     * @param topic the Kafka topic to subscribe to
     */
    public void setTopic(String topic) {
        this.topic = topic;
    }
}
