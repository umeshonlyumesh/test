package com.example.kafkaconsumer;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * High-scalable robust Kafka producer built on kafka-clients (core) API.
 *
 * Key characteristics:
 * - Uses the standard KafkaProducer API directly (no extra internal BlockingQueue or dispatcher threads).
 * - Callers can choose between async send (offer -> producer.send) and sync send (sendSync with timeout).
 * - Graceful start/stop via Spring SmartLifecycle to create/close the underlying KafkaProducer.
 * - Configurable producer options mirroring consumer style.
 */
@Component
public class RobustKafkaProducer implements SmartLifecycle {

    @Value("${kafka.bootstrap.servers:localhost:9092}")
    private String bootstrapServers;

    @Value("${producer.topic:test-topic}")
    private String topic;

    @Value("${producer.client.id:robust-producer}")
    private String clientId;

    @Value("${producer.acks:all}")
    private String acks;

    @Value("${producer.enable.idempotence:true}")
    private boolean enableIdempotence;

    @Value("${producer.compression.type:snappy}")
    private String compressionType;

    @Value("${producer.linger.ms:10}")
    private int lingerMs;

    @Value("${producer.batch.size:32768}")
    private int batchSize;

    @Value("${producer.max.in.flight.requests.per.connection:5}")
    private int maxInFlight;

    @Value("${producer.request.timeout.ms:30000}")
    private int requestTimeoutMs;

    @Value("${producer.delivery.timeout.ms:120000}")
    private int deliveryTimeoutMs;

    @Value("${producer.retries:2147483647}")
    private int retries;

    @Value("${producer.retry.backoff.ms:1000}")
    private long retryBackoffMs;

    @Value("${producer.buffer.memory:67108864}")
    private long bufferMemory;


    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile KafkaProducer<String, String> producer;

    /**
     * Starts the producer lifecycle. Initializes the KafkaProducer.
     * This method is idempotent and will only start once per application lifecycle.
     */
    @Override
    public void start() {
        if (running.compareAndSet(false, true)) {
            // Create the underlying KafkaProducer only; no extra internal queues/threads.
            this.producer = new KafkaProducer<>(buildProps());
        }
    }


    /**
     * Stops the producer gracefully by delegating to stop(Runnable) with a no-op callback.
     * Ensures that background loops exit and resources are released.
     */
    @Override
    public void stop() {
        stop(() -> {});
    }

    /**
     * Stops the producer gracefully.
     * - Marks the component as not running.
     * - Flushes and closes the underlying KafkaProducer.
     * - Invokes the provided callback after resources are released.
     *
     * @param callback code to run after shutdown completes
     */
    @Override
    public void stop(Runnable callback) {
        running.set(false);
        KafkaProducer<String, String> p = producer;
        if (p != null) {
            try {
                p.flush();
                p.close(Duration.ofSeconds(10));
            } catch (Exception e) {
                System.err.println("Error closing producer: " + e.getMessage());
            } finally {
                producer = null;
            }
        }
        callback.run();
    }

    /**
     * Indicates whether the producer component is currently running.
     * This reflects whether background dispatcher threads are active.
     *
     * @return true if running, false otherwise
     */
    @Override
    public boolean isRunning() {
        return running.get();
    }

    /**
     * Defines the startup/shutdown phase for Spring's SmartLifecycle ordering.
     * A slightly smaller value than Integer.MAX_VALUE ensures this component
     * starts a bit earlier than the consumer if both are present.
     *
     * @return the phase ordering value
     */
    @Override
    public int getPhase() {
        return Integer.MAX_VALUE - 1; // start a bit earlier than consumer if both exist
    }

    /**
     * Specifies that this component should start automatically on application context refresh.
     *
     * @return true to auto-start
     */
    @Override
    public boolean isAutoStartup() {
        return true;
    }

    /**
     * Builds and returns the Kafka producer Properties based on Spring-configured values.
     * Values include client id, acks, idempotence, compression, batching, timeouts,
     * retry policy, and buffer memory. Serializers are set to String for both key and value.
     *
     * @return configured Properties for KafkaProducer
     */
    private Properties buildProps() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
        props.put(ProducerConfig.ACKS_CONFIG, acks);
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, String.valueOf(enableIdempotence));
        props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, compressionType);
        props.put(ProducerConfig.LINGER_MS_CONFIG, String.valueOf(lingerMs));
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, String.valueOf(batchSize));
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, String.valueOf(maxInFlight));
        props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, String.valueOf(requestTimeoutMs));
        props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, String.valueOf(deliveryTimeoutMs));
        props.put(ProducerConfig.RETRIES_CONFIG, String.valueOf(retries));
        props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, String.valueOf(retryBackoffMs));
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, String.valueOf(bufferMemory));
        return props;
    }




    /**
     * Synchronously sends a record to the default topic and waits up to timeoutMs for the broker
     * to acknowledge it. If the timeout expires, throws org.apache.kafka.common.errors.TimeoutException.
     * If the broker is unreachable or another error occurs, throws the underlying KafkaException
     * so the caller can decide whether/how to retry.
     *
     * This method bypasses the internal queue and background retry loop to give the caller
     * immediate, reliable feedback about success or failure.
     *
     * @param key       record key
     * @param value     record value
     * @param timeoutMs maximum time to wait for the send to complete
     * @return RecordMetadata on success
     * @throws TimeoutException if the wait times out
     * @throws KafkaException   for Kafka-related failures (including retriable/non-retriable)
     * @throws IllegalStateException if the producer hasn't been started yet
     */
    public RecordMetadata sendSync(String key, String value, long timeoutMs) {
        return sendSync(this.topic, key, value, timeoutMs);
    }

    /**
     * Synchronously sends a record to the specified topic and waits up to timeoutMs for the broker
     * to acknowledge it. If the timeout expires, throws org.apache.kafka.common.errors.TimeoutException.
     * If the broker is unreachable or another error occurs, throws the underlying KafkaException
     * so the caller can decide whether/how to retry.
     *
     * This method bypasses the internal queue and background retry loop to give the caller
     * immediate, reliable feedback about success or failure.
     *
     * @param topic     target topic
     * @param key       record key
     * @param value     record value
     * @param timeoutMs maximum time to wait for the send to complete
     * @return RecordMetadata on success
     * @throws TimeoutException if the wait times out
     * @throws KafkaException   for Kafka-related failures (including retriable/non-retriable)
     * @throws IllegalStateException if the producer hasn't been started yet
     */
    public RecordMetadata sendSync(String topic, String key, String value, long timeoutMs) {
        KafkaProducer<String, String> p = this.producer;
        if (p == null) {
            throw new IllegalStateException("Producer not initialized or not started yet");
        }
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);
        Future<RecordMetadata> future = p.send(record);
        try {
            return future.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (java.util.concurrent.TimeoutException te) {
            throw new TimeoutException("Timed out after " + timeoutMs + " ms waiting for Kafka send to complete", te);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new KafkaException("Interrupted while waiting for Kafka send to complete", ie);
        } catch (ExecutionException ee) {
            Throwable cause = ee.getCause();
            if (cause instanceof KafkaException ke) {
                throw ke; // includes RetriableException, TimeoutException, etc.
            }
            // Wrap non-Kafka checked exceptions
            throw new KafkaException("Send failed: " + cause.getMessage(), cause);
        }
    }

}
