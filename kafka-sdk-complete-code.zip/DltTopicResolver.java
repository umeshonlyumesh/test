package com.example.springkafka.sdk;

/**
 * Resolves a DLQ topic name based on SDK properties.
 */
public final class DltTopicResolver {

    private DltTopicResolver() { }

    public static String resolve(KafkaSdkProperties props, String originalTopic) {
        KafkaSdkProperties.Dlq dlq = props.getDlq();
        if (dlq == null) {
            return originalTopic + ".DLT";
        }
        String strategy = dlq.getStrategy() == null ? "suffix" : dlq.getStrategy().trim().toLowerCase();

        if ("fixed".equals(strategy)) {
            String fixed = dlq.getFixedTopic();
            if (fixed == null || fixed.isBlank()) {
                // safe fallback
                return originalTopic + (dlq.getSuffix() == null ? ".DLT" : dlq.getSuffix());
            }
            return fixed;
        }

        String suffix = dlq.getSuffix();
        if (suffix == null || suffix.isBlank()) {
            suffix = ".DLT";
        }
        return originalTopic + suffix;
    }
}
