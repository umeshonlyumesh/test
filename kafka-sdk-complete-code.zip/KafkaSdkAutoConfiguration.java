package com.example.springkafka.sdk;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.apache.kafka.common.errors.SerializationException;

/**
 * Auto-configuration for a safe-by-default Spring for Apache Kafka SDK.
 *
 * Design goals
 * - Preserve per-partition message ordering while avoiding message loss when you manage offsets manually.
 * - Provide robust producer defaults (idempotence, acks=all, retries) to prevent duplicates and lost writes.
 * - Support both JSON (String payload) and Avro (via Confluent serializer/deserializer) with minimal app code.
 * - Make operational behavior explicit and tunable through {@link KafkaSdkProperties}.
 *
 * Beans provided
 * - sdkProducerFactory: Configures a Kafka Producer with reliability-focused settings.
 * - sdkKafkaTemplate: Convenience template built from the producer factory.
 * - sdkConsumerFactory: Configures a Kafka Consumer aligned with manual offset control.
 * - sdkKafkaListenerContainerFactory: Listener container tuned for manual acks and strict ordering.
 * - sdkCommonErrorHandler: Retries with backoff and never commits on failures (the app decides when to commit).
 * - sdkKafkaProducer / sdkConsumerManager: Thin helpers to send and to pause/resume listeners during incidents.
 *
 * Producer configuration rationale (key properties)
 * - bootstrap.servers: From kafka.sdk.bootstrap-servers – where to connect.
 * - client.id: Identifies this client instance; we suffix "-producer" for clarity in metrics/logs.
 * - acks=all: The leader waits for all in-sync replicas; maximizes durability (no acknowledged loss on broker failover).
 * - enable.idempotence=true: Guarantees exactly-once send semantics per session; avoids duplicates on retries.
 * - max.in.flight.requests.per.connection=5: Safe with idempotence to retain high throughput without reordering on retry.
 * - retries=Integer.MAX_VALUE: Allow infinite application-level retries (bounded by delivery.timeout.ms) to mask transient issues.
 * - delivery.timeout.ms=120000: Upper bound for a single send attempt including retries; surfaces errors in reasonable time.
 * - serializers:
 *   - JSON: StringSerializer for key and value (treat payload as UTF-8 text/JSON).
 *   - Avro: KafkaAvroSerializer (requires io.confluent:kafka-avro-serializer) and schema.registry.url.
 *
 * Consumer configuration rationale (key properties)
 * - bootstrap.servers: From kafka.sdk.bootstrap-servers.
 * - group.id: From kafka.sdk.group-id; controls subscription group coordination.
 * - client.id: Suffix "-consumer" for observability.
 * - enable.auto.commit=false: We commit manually only after successful processing to prevent message loss.
 * - max.poll.interval.ms: From kafka.sdk.max-poll-interval-ms; increase for long processing to avoid rebalance.
 * - max.poll.records: From kafka.sdk.max-poll-records; bound batch size and memory.
 * - auto.offset.reset=earliest: Start from beginning when no committed offset exists (safer in new groups).
 * - metadata.max.age.ms=30000: Refresh cluster metadata more frequently to react quickly to topology changes.
 * - deserializers:
 *   - JSON: StringDeserializer for key and value.
 *   - Avro: KafkaAvroDeserializer with schema.registry.url; specific.avro.reader=true to return SpecificRecord when available.
 *
 * Listener container tuning (ordering and loss avoidance)
 * - AckMode.MANUAL_IMMEDIATE: Offsets are committed immediately when your listener calls acknowledge(),
 *   minimizing the crash window between processing and commit. This preserves ordering and avoids skipping.
 * - syncCommits=true: Make offset commits synchronous so a commit failure is visible to the listener thread;
 *   on failure, the offset is not advanced, preventing silent loss.
 * - pollTimeout=2000ms and idleBetweenPolls: Sensible defaults to balance responsiveness and CPU usage.
 * - pauseImmediate=true: Prevent buffering additional records after a pause request (useful when auto-pausing on errors).
 * - missingTopicsFatal=false: Don’t fail fast if a topic is not yet created in lower environments.
 *
 * Error handling policy
 * - DefaultErrorHandler with exponential backoff; we do NOT auto-commit on failures (ackAfterHandle=false,
 *   commitRecovered=false). The failed record will be retried and ordering per partition is preserved.
 *
 * Format selection
 * - kafka.sdk.format=json|avro – switches serializers/deserializers. For Avro you must also set
 *   kafka.sdk.schema-registry-url and include the Confluent serializer dependency.
 */
@Configuration
@EnableConfigurationProperties(KafkaSdkProperties.class)
@ConditionalOnProperty(prefix = "kafka.sdk")
public class KafkaSdkAutoConfiguration {

    /**
     * Create the SDK's ProducerFactory with reliability-focused defaults and
     * serializers selected based on kafka.sdk.format.
     *
     * What it does
     * - Assembles a map of ProducerConfig settings prioritizing durability and idempotence.
     * - Selects StringSerializer for JSON payloads or KafkaAvroSerializer for Avro and applies
     *   Schema Registry configuration (including optional Basic Auth) when needed.
     * - Returns a DefaultKafkaProducerFactory used to build KafkaTemplate and producers.
     *
     * @param props the SDK properties holding connection, client id, and format settings
     * @return a ProducerFactory ready to create producers with the configured settings
     */
    @Bean
    @ConditionalOnMissingBean(name = "sdkProducerFactory")
    public ProducerFactory<String, Object> sdkProducerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        // Where to connect: list of Kafka broker addresses
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        // For observability; suffixed to distinguish producer vs consumer instances
        config.put(ProducerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-producer");
        // Durability: wait for all in-sync replicas
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        // Avoid duplicates on retry; enables EOS per session
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        // Throughput without reordering when idempotent
        config.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        // Retry indefinitely (bounded by delivery.timeout.ms)
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        // Upper bound for send including retries (ms)
        config.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 120000);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                // Avoid compile-time dependency on Confluent by using FQCN string
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer");
                if (props.getSchemaRegistryUrl() == null || props.getSchemaRegistryUrl().isBlank()) {
                    throw new IllegalStateException("kafka.sdk.schema-registry-url is required when kafka.sdk.format=avro (producer)");
                }
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
                // Optional basic auth settings for Schema Registry
                if (props.getSchemaRegistryAuthSource() != null && !props.getSchemaRegistryAuthSource().isBlank()) {
                    config.put("basic.auth.credentials.source", props.getSchemaRegistryAuthSource());
                }
                if (props.getSchemaRegistryBasicAuthUserInfo() != null && !props.getSchemaRegistryBasicAuthUserInfo().isBlank()) {
                    config.put("basic.auth.user.info", props.getSchemaRegistryBasicAuthUserInfo());
                }
            }
            case "json" -> {
                // JSON(String): Use String key and String value serializer
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
        }
        return new DefaultKafkaProducerFactory<>(config);
    }

    /**
     * Create a KafkaTemplate using the SDK's ProducerFactory.
     *
     * What it does
     * - Wraps the configured ProducerFactory into a KafkaTemplate to simplify
     *   producing records with convenient APIs and type parameters.
     * - The template inherits all reliability guarantees from sdkProducerFactory.
     *
     * @param sdkProducerFactory the producer factory created by {@link #sdkProducerFactory(KafkaSdkProperties)}
     * @return a KafkaTemplate for sending messages
     */
    @Bean
    @ConditionalOnMissingBean(name = "sdkKafkaTemplate")
    public KafkaTemplate<String, Object> sdkKafkaTemplate(ProducerFactory<String, Object> sdkProducerFactory) {
        return new KafkaTemplate<>(sdkProducerFactory);
    }

    /**
     * Create the SDK's ConsumerFactory aligned with manual offset management.
     *
     * What it does
     * - Disables auto-commit so the application controls when offsets advance (after successful processing).
     * - Applies sensible defaults for max.poll.interval.ms, max.poll.records, and auto.offset.reset.
     * - Selects StringDeserializer for JSON payloads or KafkaAvroDeserializer for Avro and wires
     *   required Schema Registry configuration (including optional Basic Auth) when format=avro.
     *
     * @param props the SDK properties affecting connection, group id, client id, and format
     * @return a ConsumerFactory for creating consumers used by listener containers
     */
    @Bean
    @ConditionalOnMissingBean(name = "sdkConsumerFactory")
    public ConsumerFactory<String, Object> sdkConsumerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, props.getGroupId());
        config.put(ConsumerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-consumer");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, props.getMaxPollIntervalMs());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, props.getMaxPollRecords());
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(CommonClientConfigs.METADATA_MAX_AGE_CONFIG, 30000);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
                // Use FQCN to avoid compile-time dependency
                config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroDeserializer");
                if (props.getSchemaRegistryUrl() == null || props.getSchemaRegistryUrl().isBlank()) {
                    throw new IllegalStateException("kafka.sdk.schema-registry-url is required when kafka.sdk.format=avro (consumer)");
                }
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
                config.put("specific.avro.reader", true);
                // Optional basic auth settings for Schema Registry
                if (props.getSchemaRegistryAuthSource() != null && !props.getSchemaRegistryAuthSource().isBlank()) {
                    config.put("basic.auth.credentials.source", props.getSchemaRegistryAuthSource());
                }
                if (props.getSchemaRegistryBasicAuthUserInfo() != null && !props.getSchemaRegistryBasicAuthUserInfo().isBlank()) {
                    config.put("basic.auth.user.info", props.getSchemaRegistryBasicAuthUserInfo());
                }
            }
            case "json" -> {
                // JSON(String)
                config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
                config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
        }
        return new DefaultKafkaConsumerFactory<>(config);
    }

    /**
     * Create the SDK's ConcurrentKafkaListenerContainerFactory tuned for manual acks
     * and strict per-partition ordering.
     *
     * What it does
     * - Wires the ConsumerFactory and applies container properties that ensure offsets are committed
     *   immediately on acknowledge() and that commit failures are surfaced synchronously.
     * - Sets polling and pause behavior to balance responsiveness and avoid buffering after pause.
     * - Injects the common error handler that retries without advancing offsets on failures.
     *
     * @param sdkConsumerFactory the consumer factory to create consumers
     * @param props              SDK properties used for concurrency and poll tuning
     * @param sdkCommonErrorHandler the error handler specifying retry policy and commit behavior
     * @return a listener container factory to be referenced by @KafkaListener(containerFactory = ...)
     */
    @Bean(name = "sdkKafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "sdkKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, Object> sdkKafkaListenerContainerFactory(
            ConsumerFactory<String, Object> sdkConsumerFactory,
            KafkaSdkProperties props,
            DefaultErrorHandler sdkDefaultErrorHandler) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(sdkConsumerFactory);
        factory.setConcurrency(props.getConcurrency());
        // Ensure single-record listener semantics for strict processing order
        factory.setBatchListener(false);
        // Use MANUAL_IMMEDIATE to commit offsets immediately on acknowledge(), minimizing window for loss on crash
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        // Ensure commits are synchronous so failures surface to the listener thread
        factory.getContainerProperties().setSyncCommits(true);
        factory.getContainerProperties().setPollTimeout(2000);
        factory.getContainerProperties().setIdleBetweenPolls(props.getIdleBetweenPollsMs());
        factory.getContainerProperties().setPauseImmediate(true); // avoid buffering when paused
        factory.getContainerProperties().setMissingTopicsFatal(false);
        factory.setCommonErrorHandler(sdkDefaultErrorHandler);
        return factory;
    }

    /**
     * Create the CommonErrorHandler used by all SDK listener containers.
     *
     * What it does
     * - Configures an exponential backoff retry policy for record processing failures.
     * - Disables committing offsets on failures (ackAfterHandle=false, commitRecovered=false)
     *   so the failed record is redelivered and ordering is preserved per partition.
     * - Provides a hook for logging/metrics on failures.
     *
     * @return a DefaultErrorHandler instance shared by listener containers
     */
    @Bean
    @ConditionalOnMissingBean
    public SdkNotifier sdkNotifier() {
        return SdkNotifier.noop();
    }

@Bean
    @ConditionalOnMissingBean(name = "sdkDefaultErrorHandler")
    public DefaultErrorHandler sdkDefaultErrorHandler(KafkaTemplate<String, Object> sdkKafkaTemplate,
                                                     KafkaSdkProperties props,
                                                     SdkNotifier sdkNotifier) {

        NotifyingDeadLetterRecoverer recoverer = new NotifyingDeadLetterRecoverer(sdkKafkaTemplate, props, sdkNotifier);

        // Build retry policy: total attempts = retry.maxAttempts (initial + retries)
        FixedBackOff backOff = SdkBackOffFactory.buildBackOff(props);

        DefaultErrorHandler errorHandler = new DefaultErrorHandler(recoverer, backOff);

        // IMPORTANT: commit the recovered offset (after DLQ publish / skip) so the record is not reprocessed.
        errorHandler.setCommitRecovered(props.getDlq().isEnabled() && props.getDlq().isCommitRecovered());
        errorHandler.setAckAfterHandle(false);

        // Bad payload should not retry; send to recoverer immediately (DLQ + notify).
        errorHandler.addNotRetryableExceptions(
                DeserializationException.class,
                SerializationException.class,
                RecordDeserializationException.class
        );

        return errorHandler;
    }


    /**
     * Expose the SDK's thin Kafka producer helper built on the configured KafkaTemplate.
     *
     * What it does
     * - Provides a minimal API for sending messages while inheriting the SDK's reliability guarantees.
     *
     * @param sdkKafkaTemplate the template produced by {@link #sdkKafkaTemplate(ProducerFactory)}
     * @return an SdkKafkaProducer ready to use in controllers/services
     */
    @Bean
    @ConditionalOnMissingBean
    public SdkKafkaProducer sdkKafkaProducer(KafkaTemplate<String, Object> sdkKafkaTemplate) {
        return new SdkKafkaProducer(sdkKafkaTemplate);
    }

    /**
     * Expose SdkConsumerManager to control pause/resume of @KafkaListener containers by id.
     *
     * What it does
     * - Looks up containers from the KafkaListenerEndpointRegistry and issues pause/resume requests.
     * - Useful for operational controls (e.g., auto-pausing on repeated failures).
     *
     * @param registry the Spring registry holding listener containers
     * @return a manager for pausing/resuming consumers
     */
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnBean(KafkaListenerEndpointRegistry.class)
    public SdkConsumerManager sdkConsumerManager(KafkaListenerEndpointRegistry registry) {
        return new SdkConsumerManager(registry);
    }
}