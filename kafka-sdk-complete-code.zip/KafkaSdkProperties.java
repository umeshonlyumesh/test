package com.example.springkafka.sdk;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for the Kafka SDK.
 *
 * Keep it simple:
 * - retry.maxAttempts controls total processing attempts (initial try + retries)
 * - dlq.* controls where to publish after retries exhausted (or immediately for bad payload)
 */
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {

    /**
     * Message format: json or avro.
     */
    private String format = "json"; // json | avro

    /**
     * Kafka bootstrap servers.
     */
    private String bootstrapServers = "localhost:9092";

    /**
     * Schema Registry URL (required when format=avro).
     */
    private String schemaRegistryUrl = "http://localhost:8081";

    /**
     * Schema Registry auth credentials source (e.g. USER_INFO) when SR requires Basic Auth.
     * Maps to Confluent property: basic.auth.credentials.source
     */
    private String schemaRegistryAuthSource;

    /**
     * Schema Registry basic auth user info in the form "username:password" when SR requires Basic Auth.
     * Maps to Confluent property: basic.auth.user.info
     */
    private String schemaRegistryBasicAuthUserInfo;

    /**
     * Consumer group id (default for container factory; can be overridden per-listener).
     */
    private String groupId = "spring-kafka-sdk-group";

    /**
     * Client id prefix.
     */
    private String clientId = "spring-kafka-sdk";

    /**
     * Max poll interval to avoid rebalances during long processing (ms).
     */
    private Integer maxPollIntervalMs = 300000; // 5 min

    /**
     * Max records per poll to limit memory.
     */
    private Integer maxPollRecords = 50;

    /**
     * Concurrency for listener containers.
     */
    private Integer concurrency = 1;

    /**
     * Time to sleep between polls when idle (ms).
     */
    private Long idleBetweenPollsMs = 1000L;

    /**
     * Simple retry settings for consumer processing.
     */
    private Retry retry = new Retry();

    /**
     * DLQ/DTL settings.
     */
    private Dlq dlq = new Dlq();

    // ---------------- getters/setters ----------------

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public String getBootstrapServers() { return bootstrapServers; }
    public void setBootstrapServers(String bootstrapServers) { this.bootstrapServers = bootstrapServers; }

    public String getSchemaRegistryUrl() { return schemaRegistryUrl; }
    public void setSchemaRegistryUrl(String schemaRegistryUrl) { this.schemaRegistryUrl = schemaRegistryUrl; }

    public String getSchemaRegistryAuthSource() { return schemaRegistryAuthSource; }
    public void setSchemaRegistryAuthSource(String schemaRegistryAuthSource) { this.schemaRegistryAuthSource = schemaRegistryAuthSource; }

    public String getSchemaRegistryBasicAuthUserInfo() { return schemaRegistryBasicAuthUserInfo; }
    public void setSchemaRegistryBasicAuthUserInfo(String schemaRegistryBasicAuthUserInfo) { this.schemaRegistryBasicAuthUserInfo = schemaRegistryBasicAuthUserInfo; }

    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public Integer getMaxPollIntervalMs() { return maxPollIntervalMs; }
    public void setMaxPollIntervalMs(Integer maxPollIntervalMs) { this.maxPollIntervalMs = maxPollIntervalMs; }

    public Integer getMaxPollRecords() { return maxPollRecords; }
    public void setMaxPollRecords(Integer maxPollRecords) { this.maxPollRecords = maxPollRecords; }

    public Integer getConcurrency() { return concurrency; }
    public void setConcurrency(Integer concurrency) { this.concurrency = concurrency; }

    public Long getIdleBetweenPollsMs() { return idleBetweenPollsMs; }
    public void setIdleBetweenPollsMs(Long idleBetweenPollsMs) { this.idleBetweenPollsMs = idleBetweenPollsMs; }

    public Retry getRetry() { return retry; }
    public void setRetry(Retry retry) { this.retry = retry; }

    public Dlq getDlq() { return dlq; }
    public void setDlq(Dlq dlq) { this.dlq = dlq; }

    // ---------------- nested types ----------------

    public static class Retry {
        /**
         * Enable/disable retries.
         * If disabled -> no retries -> immediate recovery (DLQ) on first failure.
         */
        private boolean enabled = true;

        /**
         * Total attempts (initial try + retries). Example: 3 => try once + retry twice.
         */
        private int maxAttempts = 3;

        /**
         * Fixed backoff between retries (ms).
         */
        private long backoffMs = 1000L;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }

        public int getMaxAttempts() { return maxAttempts; }
        public void setMaxAttempts(int maxAttempts) { this.maxAttempts = maxAttempts; }

        public long getBackoffMs() { return backoffMs; }
        public void setBackoffMs(long backoffMs) { this.backoffMs = backoffMs; }
    }

    public static class Dlq {
        /**
         * Enable/disable DLQ publishing.
         */
        private boolean enabled = true;

        /**
         * suffix or fixed.
         * suffix: publish to <originalTopic><suffix>
         * fixed: publish to fixedTopic
         */
        private String strategy = "suffix"; // suffix | fixed

        private String suffix = ".DLT";
        private String fixedTopic;

        /**
         * After a record is recovered (sent to DLQ or skipped), commit the offset so it does not reprocess again.
         */
        private boolean commitRecovered = true;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }

        public String getStrategy() { return strategy; }
        public void setStrategy(String strategy) { this.strategy = strategy; }

        public String getSuffix() { return suffix; }
        public void setSuffix(String suffix) { this.suffix = suffix; }

        public String getFixedTopic() { return fixedTopic; }
        public void setFixedTopic(String fixedTopic) { this.fixedTopic = fixedTopic; }

        public boolean isCommitRecovered() { return commitRecovered; }
        public void setCommitRecovered(boolean commitRecovered) { this.commitRecovered = commitRecovered; }
    }
}
