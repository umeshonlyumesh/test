package com.example.springkafka.sdk;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.springframework.kafka.core.KafkaOperations;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.apache.kafka.common.errors.SerializationException;

/**
 * Dead-letter recoverer that publishes to DLQ/DTL and triggers notifications.
 *
 * IMPORTANT: Do NOT wrap this recoverer in a lambda when creating DefaultErrorHandler.
 * Pass it directly so Spring can correctly commit recovered offsets.
 */
public class NotifyingDeadLetterRecoverer extends DeadLetterPublishingRecoverer {

    private final KafkaSdkProperties props;
    private final SdkNotifier notifier;

    public NotifyingDeadLetterRecoverer(KafkaOperations<?, ?> template,
                                        KafkaSdkProperties props,
                                        SdkNotifier notifier) {
        super(template, (ConsumerRecord<?, ?> record, Exception ex) ->
                new TopicPartition(DltTopicResolver.resolve(props, record.topic()), record.partition()));
        this.props = props;
        this.notifier = notifier == null ? SdkNotifier.noop() : notifier;
    }

    @Override
    public void accept(ConsumerRecord<?, ?> record, Exception exception) {

        // If DLQ disabled: just notify and return; commitRecovered decides whether to move forward.
        if (props.getDlq() == null || !props.getDlq().isEnabled()) {
            notifyByType(record, exception, null);
            return;
        }

        String dlqTopic = DltTopicResolver.resolve(props, record.topic());

        try {
            // Publish to DLQ
            super.accept(record, exception);
            notifyByType(record, exception, dlqTopic);
        } catch (Exception publishEx) {
            // If DLQ publish fails, notify. Do NOT throw endlessly.
            notifier.onDlqPublishFailed(record, exception, publishEx);
        }
    }

    private void notifyByType(ConsumerRecord<?, ?> record, Exception exception, String dlqTopic) {
        if (isBadPayload(exception)) {
            notifier.onBadPayload(record, exception);
            // also treat as DLQ event when we actually published
            if (dlqTopic != null) {
                notifier.onDlqPublished(record, exception, dlqTopic);
            }
            return;
        }
        if (dlqTopic != null) {
            notifier.onDlqPublished(record, exception, dlqTopic);
        }
    }

    private boolean isBadPayload(Exception ex) {
        return ex instanceof DeserializationException
                || ex instanceof SerializationException
                || ex instanceof RecordDeserializationException;
    }
}
