package com.example.springkafka.sdk;

import org.springframework.util.backoff.BackOff;
import org.springframework.util.backoff.FixedBackOff;

/**
 * Builds a BackOff from {@link KafkaSdkProperties}.
 *
 * Spring expects the number of *retries*, not attempts.
 * totalAttempts = retries + 1
 */
public final class SdkBackOffFactory {

    private SdkBackOffFactory() { }

    public static FixedBackOff buildBackOff(KafkaSdkProperties props) {
        KafkaSdkProperties.Retry retry = props.getRetry();

        // Retry disabled -> no retries (one attempt total)
        if (retry == null || !retry.isEnabled()) {
            return new FixedBackOff(0L, 0L);
        }

        long backoffMs = retry.getBackoffMs() > 0 ? retry.getBackoffMs() : 1000L;

        int maxAttempts = retry.getMaxAttempts() > 0 ? retry.getMaxAttempts() : 1;

        long maxRetries = Math.max(0, (long) maxAttempts - 1);

        return new FixedBackOff(backoffMs, maxRetries);
    }
}
