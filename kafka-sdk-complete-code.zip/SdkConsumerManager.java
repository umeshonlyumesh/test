package com.example.springkafka.sdk;

import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Provides pause/resume controls for Kafka listener containers, with safeguards for long pauses.
 */
public class SdkConsumerManager {

    private final KafkaListenerEndpointRegistry registry;
    private final Set<String> pausedContainers = ConcurrentHashMap.newKeySet();

    /**
     * Create a manager bound to the application's KafkaListenerEndpointRegistry.
     * The registry is used to look up listener containers by their listener id.
     *
     * @param registry the Spring registry that holds listener containers; must not be null
     * @throws NullPointerException if registry is null
     */
    public SdkConsumerManager(KafkaListenerEndpointRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    /**
     * Pause a listener container by id.
     *
     * Semantics
     * - If the container is found, a pause is requested on it and the id is recorded in an internal set
     *   for observability via {@link #pausedListenerIds()}.
     * - If no container exists for the given id, the method returns false and no state changes occur.
     *
     * @param listenerId the listener id used in @KafkaListener(id = ...)
     * @return true if a container was found and a pause was requested; false otherwise
     */
    public boolean pause(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        if (container == null) return false;
        container.pause();
        pausedContainers.add(listenerId);
        return true;
    }

    /**
     * Resume a previously paused listener container by id.
     *
     * @param listenerId the listener id
     * @return true if a container was found and a resume was requested; false otherwise
     */
    public boolean resume(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        if (container == null) return false;
        container.resume();
        pausedContainers.remove(listenerId);
        return true;
    }

    /**
     * Check whether a listener is currently requested to be paused.
     * Uses the underlying container's pause state rather than only the internal set.
     *
     * @param listenerId the listener id
     * @return true if the container exists and is in a pause-requested state; false otherwise
     */
    public boolean isPaused(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        return container != null && container.isPauseRequested();
    }

    /**
     * Get an immutable snapshot of listener ids that this manager has paused.
     *
     * Note: This reflects ids recorded at the time pause(String) was called via this manager;
     * it may differ from the container's actual state if changed elsewhere.
     *
     * @return unmodifiable set of paused listener ids
     */
    public Set<String> pausedListenerIds() {
        return Collections.unmodifiableSet(pausedContainers);
    }
}
