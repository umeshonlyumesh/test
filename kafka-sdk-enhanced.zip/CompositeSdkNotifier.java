package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
@RequiredArgsConstructor
public class CompositeSdkNotifier implements SdkNotifier {

    private final List<SdkNotifier> delegates;

    @Override
    public void notify(SdkNotification notification) {
        for (SdkNotifier d : delegates) {
            try {
                d.notify(notification);
            } catch (Exception e) {
                log.warn("Notifier {} failed for type={}", d.getClass().getSimpleName(), notification.getType(), e);
            }
        }
    }
}
