package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.util.Objects;

@Slf4j
@RequiredArgsConstructor
public class EmailSdkNotifier implements SdkNotifier {

    private final JavaMailSender mailSender;
    private final KafkaSdkProperties props;

    @Override
    public void notify(SdkNotification notification) {
        if (!props.getNotifications().isEnabled() || !props.getNotifications().getEmail().isEnabled()) {
            return;
        }
        String to = props.getNotifications().getEmail().getTo();
        if (to == null || to.isBlank()) {
            log.debug("Email notification skipped (no kafka.sdk.notifications.email.to)");
            return;
        }

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(to.split(","));
        if (props.getNotifications().getEmail().getFrom() != null && !props.getNotifications().getEmail().getFrom().isBlank()) {
            msg.setFrom(props.getNotifications().getEmail().getFrom());
        }
        msg.setSubject(subject(notification));
        msg.setText(body(notification));

        mailSender.send(msg);
    }

    private String subject(SdkNotification n) {
        String prefix = Objects.toString(props.getNotifications().getEmail().getSubjectPrefix(), "Kafka-SDK");
        return prefix + " - " + n.getType();
    }

    private String body(SdkNotification n) {
        StringBuilder sb = new StringBuilder();
        sb.append("Type: ").append(n.getType()).append("\n");
        sb.append("Time: ").append(n.getTimestamp()).append("\n\n");
        sb.append(n.getMessage()).append("\n\n");
        if (n.getTags() != null && !n.getTags().isEmpty()) {
            sb.append("Details:\n");
            n.getTags().forEach((k, v) -> sb.append(" - ").append(k).append(": ").append(v).append("\n"));
        }
        return sb.toString();
    }
}
