package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.*;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.util.backoff.FixedBackOff;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.http.HttpClient;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Auto-configuration for the SDK.
 *
 * Keep it simple:
 * - Consumer retry: fixed backoff + max attempts
 * - DLQ: suffix or fixed topic
 * - Notifications: email + Teams on DLQ / BAD_PAYLOAD / lag threshold
 */
@Slf4j
@Configuration
@EnableScheduling
@EnableConfigurationProperties(KafkaSdkProperties.class)
@ConditionalOnClass(KafkaTemplate.class)
@RequiredArgsConstructor
public class KafkaSdkAutoConfiguration {

    private final KafkaSdkProperties props;

    // -------------------------
    // Producer
    // -------------------------

    @Bean
    @ConditionalOnMissingBean(name = "sdkProducerFactory")
    public ProducerFactory<String, Object> sdkProducerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ProducerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-producer");
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        config.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 120_000);
        config.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, 30_000);
        config.put(ProducerConfig.LINGER_MS_CONFIG, 5);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer");
                if (props.getSchemaRegistryUrl() == null || props.getSchemaRegistryUrl().isBlank()) {
                    throw new IllegalStateException("kafka.sdk.schema-registry-url is required when kafka.sdk.format=avro (producer)");
                }
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
                if (props.getSchemaRegistryAuthSource() != null && !props.getSchemaRegistryAuthSource().isBlank()) {
                    config.put("basic.auth.credentials.source", props.getSchemaRegistryAuthSource());
                }
                if (props.getSchemaRegistryBasicAuthUserInfo() != null && !props.getSchemaRegistryBasicAuthUserInfo().isBlank()) {
                    config.put("basic.auth.user.info", props.getSchemaRegistryBasicAuthUserInfo());
                }
            }
            case "json" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format=" + props.getFormat());
        }

        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    @ConditionalOnMissingBean(name = "sdkKafkaTemplate")
    public KafkaTemplate<String, Object> sdkKafkaTemplate(ProducerFactory<String, Object> sdkProducerFactory) {
        return new KafkaTemplate<>(sdkProducerFactory);
    }

    @Bean
    @ConditionalOnMissingBean
    public SdkKafkaProducer sdkKafkaProducer(KafkaTemplate<String, Object> sdkKafkaTemplate, SdkNotifier notifier, KafkaSdkProperties props) {
        return new SdkKafkaProducer(sdkKafkaTemplate, props, notifier);
    }

    // -------------------------
    // Consumer
    // -------------------------

    @Bean
    @ConditionalOnMissingBean(name = "sdkConsumerFactory")
    public ConsumerFactory<String, Object> sdkConsumerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, props.getGroupId());
        config.put(ConsumerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-consumer");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, props.getMaxPollIntervalMs());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, props.getMaxPollRecords());
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(CommonClientConfigs.METADATA_MAX_AGE_CONFIG, 30_000);

        // BAD_PAYLOAD safety: use ErrorHandlingDeserializer so deserialization failures go to the error handler (and DLQ).
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
                // Use FQCN to avoid compile-time dependency
                config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, "io.confluent.kafka.serializers.KafkaAvroDeserializer");
                if (props.getSchemaRegistryUrl() == null || props.getSchemaRegistryUrl().isBlank()) {
                    throw new IllegalStateException("kafka.sdk.schema-registry-url is required when kafka.sdk.format=avro (consumer)");
                }
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
                config.put("specific.avro.reader", true);
                if (props.getSchemaRegistryAuthSource() != null && !props.getSchemaRegistryAuthSource().isBlank()) {
                    config.put("basic.auth.credentials.source", props.getSchemaRegistryAuthSource());
                }
                if (props.getSchemaRegistryBasicAuthUserInfo() != null && !props.getSchemaRegistryBasicAuthUserInfo().isBlank()) {
                    config.put("basic.auth.user.info", props.getSchemaRegistryBasicAuthUserInfo());
                }
            }
            case "json" -> {
                config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
                config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format=" + props.getFormat());
        }

        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean(name = "sdkKafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "sdkKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, Object> sdkKafkaListenerContainerFactory(
        ConsumerFactory<String, Object> sdkConsumerFactory,
        CommonErrorHandler sdkCommonErrorHandler
    ) {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(sdkConsumerFactory);
        factory.setConcurrency(props.getConcurrency());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.getContainerProperties().setIdleBetweenPolls(props.getIdleBetweenPollsMs());
        factory.setCommonErrorHandler(sdkCommonErrorHandler);
        return factory;
    }

    // -------------------------
    // Pause/Resume manager
    // -------------------------

    @Bean
    @ConditionalOnBean(KafkaListenerEndpointRegistry.class)
    @ConditionalOnMissingBean
    public SdkConsumerManager sdkConsumerManager(KafkaListenerEndpointRegistry registry) {
        return new SdkConsumerManager(registry);
    }

    // -------------------------
    // Retry + DLQ + Notifications
    // -------------------------

    @Bean
    @ConditionalOnMissingBean(name = "sdkCommonErrorHandler")
    public CommonErrorHandler sdkCommonErrorHandler(KafkaTemplate<String, Object> sdkKafkaTemplate, SdkNotifier notifier) {

        long interval = Math.max(0, props.getRetry().getBackoffMs());
        long maxRetries = props.getRetry().isEnabled() ? Math.max(0, props.getRetry().getMaxAttempts() - 1L) : 0L;
        FixedBackOff backOff = new FixedBackOff(interval, maxRetries);

        DeadLetterPublishingRecoverer recoverer = null;
        if (props.getDlq().isEnabled()) {
            recoverer = new NotifyingDlqRecoverer(sdkKafkaTemplate, notifier, props);
        }

        DefaultErrorHandler errorHandler = (recoverer == null)
            ? new DefaultErrorHandler(backOff)
            : new DefaultErrorHandler(recoverer, backOff);

        // Manual ack: app acks on success. Error handler should not ack.
        errorHandler.setAckAfterHandle(false);

        // When record is published to DLQ, commit that offset so the partition continues.
        errorHandler.setCommitRecovered(props.getDlq().isCommitRecovered());

        return errorHandler;
    }

    /**
     * Recoverer that publishes to DLQ and triggers notifications.
     */
    static class NotifyingDlqRecoverer extends DeadLetterPublishingRecoverer {

        private final SdkNotifier notifier;
        private final KafkaSdkProperties props;

        NotifyingDlqRecoverer(KafkaTemplate<Object, Object> template, SdkNotifier notifier, KafkaSdkProperties props) {
            super(template, (record, ex) -> {
                String dlqTopic = resolveDlqTopic(props, record.topic());
                return new TopicPartition(dlqTopic, record.partition());
            });
            this.notifier = notifier;
            this.props = props;
        }

        @Override
        public void accept(org.apache.kafka.clients.consumer.ConsumerRecord<?, ?> record, Exception exception) {
            super.accept(record, exception);

            String type = isBadPayload(exception) ? "BAD_PAYLOAD" : "DLQ";
            notifier.notify(SdkNotification.builder()
                .type(type)
                .timestamp(Instant.now())
                .message("Record sent to DLQ. cause=" + exception.getClass().getSimpleName() + " msg=" + safe(exception.getMessage()))
                .tags(Map.of(
                    "groupId", String.valueOf(props.getGroupId()),
                    "topic", String.valueOf(record.topic()),
                    "partition", String.valueOf(record.partition()),
                    "offset", String.valueOf(record.offset()),
                    "dlqTopic", resolveDlqTopic(props, record.topic())
                ))
                .build());
        }

        private boolean isBadPayload(Exception e) {
            // Spring Kafka wraps deserialization issues as DeserializationException; class is in spring-kafka.
            return e.getClass().getName().contains("DeserializationException");
        }

        private String safe(String s) {
            if (s == null) return "";
            return s.length() > 512 ? s.substring(0, 512) : s;
        }

        private static String resolveDlqTopic(KafkaSdkProperties props, String originalTopic) {
            if ("fixed".equalsIgnoreCase(props.getDlq().getStrategy())) {
                String fixed = props.getDlq().getFixedTopic();
                if (fixed == null || fixed.isBlank()) {
                    throw new IllegalStateException("kafka.sdk.dlq.fixed-topic must be set when kafka.sdk.dlq.strategy=fixed");
                }
                return fixed;
            }
            return originalTopic + props.getDlq().getSuffix();
        }
    }

    // -------------------------
    // Notifications wiring
    // -------------------------

    @Bean
    @ConditionalOnMissingBean
    public SdkNotifier sdkNotifier(List<SdkNotifier> notifiers) {
        // If user didn't enable notifications, the notifiers will no-op.
        return new CompositeSdkNotifier(notifiers);
    }

    @Bean
    @ConditionalOnClass(name = "org.springframework.mail.javamail.JavaMailSender")
    @ConditionalOnMissingBean
    public EmailSdkNotifier emailSdkNotifier(org.springframework.mail.javamail.JavaMailSender mailSender, KafkaSdkProperties props) {
        return new EmailSdkNotifier(mailSender, props);
    }

    @Bean
    @ConditionalOnMissingBean
    public TeamsSdkNotifier teamsSdkNotifier(KafkaSdkProperties props) {
        return new TeamsSdkNotifier(HttpClient.newHttpClient(), props);
    }

    // -------------------------
    // Lag monitor
    // -------------------------

    @Bean
    @ConditionalOnProperty(prefix = "kafka.sdk.notifications", name = "enabled", havingValue = "true")
    @ConditionalOnProperty(prefix = "kafka.sdk.notifications.lag", name = "enabled", havingValue = "true")
    @ConditionalOnMissingBean
    public AdminClient sdkAdminClient() {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        cfg.put(AdminClientConfig.CLIENT_ID_CONFIG, props.getClientId() + "-admin");
        return AdminClient.create(cfg);
    }

    @Bean
    @ConditionalOnProperty(prefix = "kafka.sdk.notifications", name = "enabled", havingValue = "true")
    @ConditionalOnProperty(prefix = "kafka.sdk.notifications.lag", name = "enabled", havingValue = "true")
    @ConditionalOnMissingBean
    public SdkLagMonitor sdkLagMonitor(AdminClient sdkAdminClient, KafkaSdkProperties props, SdkNotifier notifier) {
        return new SdkLagMonitor(sdkAdminClient, props, notifier);
    }
}
