package com.example.springkafka.sdk;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.ArrayList;
import java.util.List;

/**
 * SDK configuration (keep it simple).
 *
 * - retry + DLQ: configurable, minimal knobs
 * - notifications: email + MS Teams + lag threshold
 */
@Data
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {

    /**
     * Message format: json or avro.
     */
    private String format = "json"; // json | avro

    /**
     * Kafka bootstrap servers.
     */
    private String bootstrapServers = "localhost:9092";

    /**
     * Schema Registry URL (required when format=avro).
     */
    private String schemaRegistryUrl = "http://localhost:8081";

    /**
     * Schema Registry auth credentials source (e.g. USER_INFO) when SR requires Basic Auth.
     * Maps to Confluent property: basic.auth.credentials.source
     */
    private String schemaRegistryAuthSource;

    /**
     * Schema Registry basic auth user info in the form "username:password" when SR requires Basic Auth.
     * Maps to Confluent property: basic.auth.user.info
     */
    private String schemaRegistryBasicAuthUserInfo;

    /**
     * Consumer group id (default for container factory; can be overridden per-listener).
     */
    private String groupId = "spring-kafka-sdk-group";

    /**
     * Client id prefix.
     */
    private String clientId = "spring-kafka-sdk";

    /**
     * Max poll interval to avoid rebalances during long processing (ms).
     */
    private Integer maxPollIntervalMs = 300000; // 5 min

    /**
     * Max records per poll to limit memory.
     */
    private Integer maxPollRecords = 50;

    /**
     * Concurrency for listener containers.
     */
    private Integer concurrency = 1;

    /**
     * Time to sleep between polls when idle (ms).
     */
    private Long idleBetweenPollsMs = 1000L;

    /**
     * Consumer retry policy (applies to ALL exceptions uniformly; no rules).
     */
    private Retry retry = new Retry();

    /**
     * Consumer DLQ policy (applies after retries are exhausted; also used for BAD_PAYLOAD/deserialization failures).
     */
    private Dlq dlq = new Dlq();

    /**
     * Producer retry + optional producer DLQ (simple).
     */
    private Producer producer = new Producer();

    /**
     * Notifications: email + MS Teams + lag threshold.
     */
    private Notifications notifications = new Notifications();

    @Data
    public static class Retry {
        /**
         * Enable retry for listener failures.
         */
        private boolean enabled = true;

        /**
         * Total attempts including the first try. Example: 5 = 1 initial + 4 retries.
         */
        private int maxAttempts = 5;

        /**
         * Backoff between retries (ms).
         */
        private long backoffMs = 1000;
    }

    @Data
    public static class Dlq {
        /**
         * Enable sending failed records to DLQ.
         */
        private boolean enabled = true;

        /**
         * suffix | fixed
         * suffix: <topic> + suffix
         * fixed:  fixedTopic
         */
        private String strategy = "suffix";

        private String suffix = ".DLT";

        private String fixedTopic;

        /**
         * After publishing to DLQ, commit recovered offset so the partition continues.
         */
        private boolean commitRecovered = true;
    }

    @Data
    public static class Producer {
        /**
         * Application-level retry around send failures (in addition to Kafka producer retries).
         */
        private boolean retryEnabled = true;

        /**
         * Total attempts including the first send.
         */
        private int maxAttempts = 3;

        /**
         * Backoff between attempts (ms).
         */
        private long backoffMs = 500;

        /**
         * Optional producer DLQ. If enabled and send ultimately fails, publish an envelope to this topic.
         */
        private boolean dlqEnabled = false;

        private String dlqTopic;
    }

    @Data
    public static class Notifications {
        private boolean enabled = false;

        private Email email = new Email();
        private Teams teams = new Teams();
        private Lag lag = new Lag();

        @Data
        public static class Email {
            private boolean enabled = false;
            /**
             * Comma-separated recipients.
             */
            private String to;
            private String from;
            private String subjectPrefix = "Kafka-SDK";
        }

        @Data
        public static class Teams {
            private boolean enabled = false;
            /**
             * MS Teams Incoming Webhook URL.
             */
            private String webhookUrl;
        }

        @Data
        public static class Lag {
            private boolean enabled = false;

            /**
             * Notify when max partition lag >= threshold (in records).
             */
            private long threshold = 0;

            /**
             * Topics to check (keep it explicit and simple).
             */
            private List<String> topics = new ArrayList<>();

            /**
             * How often to check lag.
             */
            private long checkIntervalMs = 60000;
        }
    }
}
