package com.example.springkafka.sdk;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ProducerDlqEnvelope {
    String originalTopic;
    String failureTs;
    String exceptionClass;
    String exceptionMessage;

    String key;
    Object payload;
}
