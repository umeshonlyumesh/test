package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * Minimal producer wrapper:
 * - optional simple retry (fixed backoff)
 * - optional producer DLQ (publish an envelope message when send ultimately fails)
 * - notification on final failure / DLQ publish attempt
 */
@Slf4j
@RequiredArgsConstructor
public class SdkKafkaProducer {

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final KafkaSdkProperties props;
    private final SdkNotifier notifier;

    public CompletableFuture<SendResult<String, Object>> send(String topic, String key, Object value) {
        if (!props.getProducer().isRetryEnabled()) {
            return rawSend(topic, key, value).exceptionallyCompose(ex -> onFinalFailure(topic, key, value, ex));
        }
        int attempts = Math.max(1, props.getProducer().getMaxAttempts());
        return attempt(topic, key, value, 1, attempts);
    }

    private CompletableFuture<SendResult<String, Object>> attempt(String topic, String key, Object value, int attempt, int maxAttempts) {
        return rawSend(topic, key, value).handle((res, ex) -> {
            if (ex == null) {
                return CompletableFuture.completedFuture(res);
            }
            if (attempt >= maxAttempts) {
                return onFinalFailure(topic, key, value, ex);
            }
            long delay = Math.max(0, props.getProducer().getBackoffMs());
            log.warn("Producer send failed (attempt {}/{}). Retrying in {}ms. topic={}", attempt, maxAttempts, delay, topic, ex);
            return CompletableFuture.supplyAsync(() -> null, CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS))
                .thenCompose(ignored -> attempt(topic, key, value, attempt + 1, maxAttempts));
        }).thenCompose(x -> x);
    }

    private CompletableFuture<SendResult<String, Object>> rawSend(String topic, String key, Object value) {
        return kafkaTemplate.send(topic, key, value);
    }

    private CompletableFuture<SendResult<String, Object>> onFinalFailure(String topic, String key, Object value, Throwable ex) {
        notifier.notify(SdkNotification.builder()
            .type("PRODUCER_SEND_FAILED")
            .timestamp(Instant.now())
            .message("Producer send failed after retries. topic=" + topic + " cause=" + ex.getClass().getSimpleName() + " msg=" + safe(ex.getMessage()))
            .tags(Map.of("topic", topic))
            .build());

        if (!props.getProducer().isDlqEnabled()) {
            CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
            failed.completeExceptionally(ex);
            return failed;
        }
        String dlqTopic = props.getProducer().getDlqTopic();
        if (dlqTopic == null || dlqTopic.isBlank()) {
            CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
            failed.completeExceptionally(new IllegalStateException("kafka.sdk.producer.dlq-topic must be set when kafka.sdk.producer.dlq-enabled=true", ex));
            return failed;
        }

        ProducerDlqEnvelope envelope = ProducerDlqEnvelope.builder()
            .originalTopic(topic)
            .key(key)
            .payload(value)
            .failureTs(Instant.now().toString())
            .exceptionClass(ex.getClass().getName())
            .exceptionMessage(safe(ex.getMessage()))
            .build();

        // try publish to producer DLQ (best effort)
        return kafkaTemplate.send(dlqTopic, key, envelope)
            .handle((dlqRes, dlqEx) -> {
                if (dlqEx != null) {
                    log.warn("Producer DLQ publish failed. dlqTopic={}", dlqTopic, dlqEx);
                } else {
                    notifier.notify(SdkNotification.builder()
                        .type("PRODUCER_DLQ")
                        .timestamp(Instant.now())
                        .message("Producer failure published to producer DLQ topic=" + dlqTopic)
                        .tags(Map.of("dlqTopic", dlqTopic, "originalTopic", topic))
                        .build());
                }
                CompletableFuture<SendResult<String, Object>> failed = new CompletableFuture<>();
                failed.completeExceptionally(ex);
                return failed;
            }).thenCompose(x -> x);
    }

    private String safe(String s) {
        if (s == null) return "";
        return s.length() > 512 ? s.substring(0, 512) : s;
    }
}
