package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.common.TopicPartition;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Simple lag monitor:
 * - checks lag for configured topics for the configured consumer group
 * - sends a notification when any partition lag >= threshold
 *
 * Keep it intentionally simple (no metrics registry, no complex state machine).
 */
@Slf4j
@RequiredArgsConstructor
public class SdkLagMonitor {

    private final AdminClient adminClient;
    private final KafkaSdkProperties props;
    private final SdkNotifier notifier;

    @Scheduled(fixedDelayString = "${kafka.sdk.notifications.lag.check-interval-ms:60000}")
    public void checkLag() {
        if (!props.getNotifications().isEnabled() || !props.getNotifications().getLag().isEnabled()) {
            return;
        }

        String groupId = props.getGroupId();
        List<String> topics = props.getNotifications().getLag().getTopics();
        long threshold = props.getNotifications().getLag().getThreshold();

        if (groupId == null || groupId.isBlank() || topics == null || topics.isEmpty() || threshold <= 0) {
            return;
        }

        try {
            // partitions for topics
            DescribeTopicsResult dtr = adminClient.describeTopics(topics);
            Map<String, TopicDescription> desc = dtr.all().get(10, TimeUnit.SECONDS);

            Set<TopicPartition> tps = desc.values().stream()
                .flatMap(td -> td.partitions().stream().map(p -> new TopicPartition(td.name(), p.partition())))
                .collect(Collectors.toSet());

            // committed offsets for group
            Map<TopicPartition, OffsetAndMetadata> committed =
                adminClient.listConsumerGroupOffsets(groupId).partitionsToOffsetAndMetadata().get(10, TimeUnit.SECONDS);

            // end offsets
            Map<TopicPartition, OffsetSpec> req = new HashMap<>();
            for (TopicPartition tp : tps) {
                req.put(tp, OffsetSpec.latest());
            }
            Map<TopicPartition, ListOffsetsResult.ListOffsetsResultInfo> end =
                adminClient.listOffsets(req).all().get(10, TimeUnit.SECONDS);

            // compute max lag
            long maxLag = 0;
            TopicPartition worstTp = null;

            for (TopicPartition tp : tps) {
                long endOffset = end.get(tp).offset();
                long committedOffset = Optional.ofNullable(committed.get(tp)).map(OffsetAndMetadata::offset).orElse(-1L);
                long lag = (committedOffset < 0) ? endOffset : Math.max(0, endOffset - committedOffset);
                if (lag > maxLag) {
                    maxLag = lag;
                    worstTp = tp;
                }
            }

            if (worstTp != null && maxLag >= threshold) {
                notifier.notify(SdkNotification.builder()
                    .type("LAG_THRESHOLD")
                    .timestamp(Instant.now())
                    .message("Consumer lag crossed threshold: lag=" + maxLag + " (threshold=" + threshold + ")")
                    .tags(Map.of(
                        "groupId", groupId,
                        "topic", worstTp.topic(),
                        "partition", String.valueOf(worstTp.partition()),
                        "lag", String.valueOf(maxLag)
                    ))
                    .build());
            }
        } catch (Exception e) {
            log.debug("Lag monitor failed", e);
        }
    }
}
