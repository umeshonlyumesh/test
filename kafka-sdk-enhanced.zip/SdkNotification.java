package com.example.springkafka.sdk;

import lombok.Builder;
import lombok.Value;

import java.time.Instant;
import java.util.Map;

@Value
@Builder
public class SdkNotification {
    String type;              // e.g., DLQ, BAD_PAYLOAD, LAG_THRESHOLD
    String message;           // human readable
    Instant timestamp;        // when it happened
    Map<String, String> tags; // topic, partition, groupId, etc.
}
