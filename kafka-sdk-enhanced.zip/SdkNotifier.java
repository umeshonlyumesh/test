package com.example.springkafka.sdk;

public interface SdkNotifier {
    void notify(SdkNotification notification);
}
