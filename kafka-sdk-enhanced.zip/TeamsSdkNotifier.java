package com.example.springkafka.sdk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

@Slf4j
@RequiredArgsConstructor
public class TeamsSdkNotifier implements SdkNotifier {

    private final HttpClient httpClient;
    private final KafkaSdkProperties props;

    @Override
    public void notify(SdkNotification notification) {
        if (!props.getNotifications().isEnabled() || !props.getNotifications().getTeams().isEnabled()) {
            return;
        }
        String webhook = props.getNotifications().getTeams().getWebhookUrl();
        if (webhook == null || webhook.isBlank()) {
            log.debug("Teams notification skipped (no kafka.sdk.notifications.teams.webhook-url)");
            return;
        }

        // Microsoft Teams Incoming Webhook expects a JSON payload with "text" (simple) or cards.
        String text = buildText(notification);
        String json = "{\"text\":" + jsonString(text) + "}";

        try {
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(webhook))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

            HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
                log.warn("Teams webhook returned status={} body={}", resp.statusCode(), resp.body());
            }
        } catch (Exception e) {
            log.warn("Teams notification failed", e);
        }
    }

    private String buildText(SdkNotification n) {
        StringBuilder sb = new StringBuilder();
        sb.append("**").append(n.getType()).append("**").append("\n");
        sb.append(n.getMessage()).append("\n");
        if (n.getTags() != null && !n.getTags().isEmpty()) {
            sb.append("\n");
            n.getTags().forEach((k, v) -> sb.append("- ").append(k).append(": ").append(v).append("\n"));
        }
        return sb.toString();
    }

    private String jsonString(String s) {
        // minimal JSON escaping
        return "\"" + s.replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "")
                        .replace("\t", " ") + "\"";
    }
}
