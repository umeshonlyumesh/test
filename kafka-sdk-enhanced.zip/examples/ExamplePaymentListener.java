package com.example.demo;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * Example consumer using the SDK containerFactory:
 * - manual ack on success
 * - throw exception to trigger retry, then DLQ, then notification (email/teams) if enabled
 * - BAD_PAYLOAD (deserialization) is also routed to DLQ by SDK
 */
@Component
public class ExamplePaymentListener {

    @KafkaListener(
        id = "paymentListener",
        topics = "${app.topic}",
        containerFactory = "sdkKafkaListenerContainerFactory"
    )
    public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {
        Object payload = record.value();

        // Example: simulate processing failure (retry -> DLQ)
        if (payload != null && payload.toString().contains("FAIL")) {
            throw new RuntimeException("Simulated processing failure");
        }

        // success => commit offset
        ack.acknowledge();
    }
}
