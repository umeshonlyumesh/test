package com.example.demo;

import com.example.springkafka.sdk.SdkKafkaProducer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ExamplePublisher {

    private final SdkKafkaProducer producer;

    public void publish(String topic, String key, String jsonPayload) {
        producer.send(topic, key, jsonPayload);
    }
}
