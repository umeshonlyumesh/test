package com.example.springkafka.sdk;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/**
 * Thin wrapper around Spring's KafkaTemplate providing a concise, typed entry point
 * for producing messages using the SDK's reliability-focused producer configuration.
 *
 * Responsibility
 * - Delegates to KafkaTemplate to asynchronously send a record to a topic using the
 *   configured key and value serializers (JSON or Avro as selected via KafkaSdkProperties).
 * - Keeps the surface area minimal so applications depend on this single helper rather
 *   than the full KafkaTemplate API.
 */
public class SdkKafkaProducer {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    /**
     * Create a new SDK producer.
     *
     * @param kafkaTemplate the underlying template configured by KafkaSdkAutoConfiguration;
     *                      must not be null
     * @throws NullPointerException if kafkaTemplate is null
     */
    public SdkKafkaProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = Objects.requireNonNull(kafkaTemplate, "kafkaTemplate");
    }

    /**
     * Send a record to Kafka asynchronously.
     *
     * Behavior and guarantees
     * - Uses the SDK's producer settings (acks=all, idempotence enabled, infinite retries bounded by
     *   delivery.timeout.ms) to maximize durability and avoid duplicates on retry.
     * - Completes the returned future when the broker acknowledges the write (on success) or when
     *   the send ultimately fails (on error).
     *
     * @param topic the destination topic
     * @param key   the record key (may be null)
     * @param value the record value (JSON string or Avro Specific/GenericRecord depending on format)
     * @return a future that completes with the SendResult containing RecordMetadata on success
     */
    public CompletableFuture<SendResult<String, Object>> send(String topic, String key, Object value) {
        return kafkaTemplate.send(topic, key, value);
    }
}
