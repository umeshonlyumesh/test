package com.example.springkafka.sdk;

import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Notification abstraction. Keep it simple and non-blocking.
 * Provide your own bean to send email/MS Teams etc.
 */
public interface SdkNotifier {

    void onDlqPublished(ConsumerRecord<?, ?> record, Exception exception, String dlqTopic);

    void onBadPayload(ConsumerRecord<?, ?> record, Exception exception);

    void onDlqPublishFailed(ConsumerRecord<?, ?> record, Exception originalException, Exception publishException);

    static SdkNotifier noop() {
        return new SdkNotifier() {
            @Override
            public void onDlqPublished(ConsumerRecord<?, ?> record, Exception exception, String dlqTopic) { }

            @Override
            public void onBadPayload(ConsumerRecord<?, ?> record, Exception exception) { }

            @Override
            public void onDlqPublishFailed(ConsumerRecord<?, ?> record, Exception originalException, Exception publishException) { }
        };
    }
}
