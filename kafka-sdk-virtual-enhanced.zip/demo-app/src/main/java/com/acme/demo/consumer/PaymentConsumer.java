package com.acme.demo.consumer;
import com.acme.kafkasdk.annotation.KafkaConsumerListener;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Component;
@Slf4j @Component
public class PaymentConsumer {
    @KafkaConsumerListener(topic="payments", groupId="payment-group")
    public void onPayment(ConsumerRecord<String,String> record){
        log.info("Payment: topic={}, partition={}, offset={}, key={}, value={}", record.topic(), record.partition(), record.offset(), record.key(), record.value());
        // To test DLQ: uncomment next line
        // if (record.value()!=null && record.value().contains("fail")) throw new RuntimeException("boom");
    }
}
