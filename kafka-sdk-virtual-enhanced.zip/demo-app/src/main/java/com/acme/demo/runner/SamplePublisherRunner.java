package com.acme.demo.runner;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner; import org.springframework.stereotype.Component;
@Component @RequiredArgsConstructor
public class SamplePublisherRunner implements CommandLineRunner {
    private final KafkaProducerClient producer;
    @Override public void run(String... args) throws Exception {
        try { producer.sendSync("payments", "txn-1", "{\"amount\": 100}"); } catch (Exception ignored) {}
    }
}
