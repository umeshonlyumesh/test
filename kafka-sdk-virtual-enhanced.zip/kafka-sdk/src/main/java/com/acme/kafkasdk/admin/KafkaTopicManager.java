package com.acme.kafkasdk.admin;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.*;
import java.util.*; import java.util.concurrent.ExecutionException;
@Slf4j
public class KafkaTopicManager implements AutoCloseable {
    private final AdminClient adminClient;
    public KafkaTopicManager(String bootstrapServers, Map<String,Object> props){
        Properties cfg=new Properties();
        cfg.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        if(props!=null) cfg.putAll(props);
        this.adminClient=AdminClient.create(cfg);
    }
    public void createTopicIfNotExists(String topic, int partitions, short rf){
        try{
            Set<String> names=adminClient.listTopics().names().get();
            if(!names.contains(topic)){
                adminClient.createTopics(Collections.singleton(new NewTopic(topic, partitions, rf))).all().get();
            }
        }catch(InterruptedException|ExecutionException e){ Thread.currentThread().interrupt(); throw new RuntimeException("ensure topic "+topic, e); }
    }
    @Override public void close(){ if(adminClient!=null) adminClient.close(); }
}
