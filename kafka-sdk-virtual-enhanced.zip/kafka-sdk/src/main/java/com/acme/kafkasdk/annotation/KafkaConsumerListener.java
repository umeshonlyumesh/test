package com.acme.kafkasdk.annotation;
import java.lang.annotation.*;
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface KafkaConsumerListener {
    String topic();
    String groupId() default "default-group";
    int pollIntervalMs() default 1000;
}
