package com.acme.kafkasdk.config;
import com.acme.kafkasdk.admin.KafkaTopicManager;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean; import org.springframework.context.annotation.Configuration;
import java.util.HashMap; import java.util.Map;
@Configuration
public class KafkaSdkConfig {
    @Bean public KafkaTopicManager kafkaTopicManager(KafkaSdkProperties props){
        Map<String,Object> ssl=new HashMap<>(); var s=props.getProducer().getSsl();
        if(s.getTrustStoreLocation()!=null){ ssl.put("ssl.truststore.location", s.getTrustStoreLocation()); ssl.put("ssl.truststore.password", s.getTrustStorePassword()); ssl.put("ssl.truststore.type", s.getTrustStoreType()); }
        if(s.getKeyStoreLocation()!=null){ ssl.put("ssl.keystore.location", s.getKeyStoreLocation()); ssl.put("ssl.keystore.password", s.getKeyStorePassword()); ssl.put("ssl.keystore.type", s.getKeyStoreType()); ssl.put("ssl.key.password", s.getKeyPassword()); }
        ssl.put("security.protocol","SSL"); return new KafkaTopicManager(props.getBootstrapServers(), ssl);
    }
    @Bean public KafkaProducerClient kafkaProducerClient(KafkaSdkProperties props, KafkaTopicManager tm, MeterRegistry registry){
        return new KafkaProducerClient(props, tm, registry);
    }
}
