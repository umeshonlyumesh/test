package com.acme.kafkasdk.config;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
@Data
@Component
@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {
    private String bootstrapServers;
    private boolean autoCreateTopics = true;
    private Producer producer = new Producer();
    private Consumer consumer = new Consumer();
    private Dlq dlq = new Dlq();
    private Retry retry = new Retry();
    @Data public static class Producer { private Ssl ssl = new Ssl(); }
    @Data public static class Consumer {
        private String defaultGroupId = "default-group";
        private Ssl ssl = new Ssl();
    }
    @Data public static class Ssl {
        private String keyStoreType; private String keyStoreLocation; private String keyStorePassword; private String keyPassword;
        private String trustStoreType; private String trustStoreLocation; private String trustStorePassword;
        private String protocol = "TLSv1.3";
    }
    @Data public static class Dlq { private boolean enabled = true; private String topicOverride; }
    @Data public static class Retry { private int maxAttempts = 3; private long backoffMillis = 200L; }
}
