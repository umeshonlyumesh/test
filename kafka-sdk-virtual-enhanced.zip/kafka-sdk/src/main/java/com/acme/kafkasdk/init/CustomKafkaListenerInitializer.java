package com.acme.kafkasdk.init;
import com.acme.kafkasdk.admin.KafkaTopicManager;
import com.acme.kafkasdk.config.KafkaSdkProperties;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import com.acme.kafkasdk.runtime.KafkaConsumerRunner;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
@Component
public class CustomKafkaListenerInitializer implements ApplicationListener<ApplicationReadyEvent> {
    private final KafkaSdkProperties props; private final KafkaTopicManager topicManager; private final ApplicationContext ctx; private final KafkaProducerClient producerClient; private final MeterRegistry meterRegistry;
    public CustomKafkaListenerInitializer(KafkaSdkProperties props, KafkaTopicManager topicManager, KafkaProducerClient producerClient, MeterRegistry meterRegistry, ApplicationContext ctx){
        this.props=props; this.topicManager=topicManager; this.producerClient=producerClient; this.meterRegistry=meterRegistry; this.ctx=ctx;
    }
    @Override public void onApplicationEvent(ApplicationReadyEvent event){
        KafkaConsumerRunner runner=new KafkaConsumerRunner(props, topicManager, producerClient, meterRegistry);
        ctx.getBeansWithAnnotation(org.springframework.stereotype.Component.class).values().forEach(runner::registerListeners);
    }
}
