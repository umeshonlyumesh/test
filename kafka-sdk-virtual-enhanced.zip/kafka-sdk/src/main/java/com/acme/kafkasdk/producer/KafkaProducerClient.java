package com.acme.kafkasdk.producer;
import com.acme.kafkasdk.admin.KafkaTopicManager;
import com.acme.kafkasdk.config.KafkaSdkProperties;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.*; import org.apache.kafka.common.serialization.StringSerializer;
import java.util.Properties; import java.util.concurrent.CompletableFuture;
@Slf4j
public class KafkaProducerClient {
    private final KafkaSdkProperties props; private final KafkaTopicManager topicManager; private final MeterRegistry meterRegistry;
    private volatile Producer<String,String> producer;
    private final Counter sendCounter; private final Counter errorCounter; private final Timer sendTimer;
    public KafkaProducerClient(KafkaSdkProperties props, KafkaTopicManager topicManager, MeterRegistry meterRegistry){
        this.props=props; this.topicManager=topicManager; this.meterRegistry=meterRegistry;
        this.sendCounter=Counter.builder("kafka.sdk.producer.send.count").register(meterRegistry);
        this.errorCounter=Counter.builder("kafka.sdk.producer.error.count").register(meterRegistry);
        this.sendTimer=Timer.builder("kafka.sdk.producer.send.timer").register(meterRegistry);
    }
    private Producer<String,String> getProducer(){
        if(producer==null){ synchronized(this){ if(producer==null){
            Properties cfg=new Properties();
            cfg.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
            cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
            cfg.put("security.protocol","SSL");
            var ssl=props.getProducer().getSsl();
            if(ssl.getTrustStoreLocation()!=null){ cfg.put("ssl.truststore.location", ssl.getTrustStoreLocation()); cfg.put("ssl.truststore.password", ssl.getTrustStorePassword()); cfg.put("ssl.truststore.type", ssl.getTrustStoreType()); }
            if(ssl.getKeyStoreLocation()!=null){ cfg.put("ssl.keystore.location", ssl.getKeyStoreLocation()); cfg.put("ssl.keystore.password", ssl.getKeyStorePassword()); cfg.put("ssl.keystore.type", ssl.getKeyStoreType()); cfg.put("ssl.key.password", ssl.getKeyPassword()); }
            producer=new KafkaProducer<>(cfg);
        }}}
        return producer;
    }
    private void ensureTopic(String topic){ if(props.isAutoCreateTopics()) topicManager.createTopicIfNotExists(topic,3,(short)1); }
    private String dlqTopic(String original){ String t=props.getDlq().getTopicOverride(); return (t==null||t.isBlank())? (original+"-dlq") : t; }
    public CompletableFuture<RecordMetadata> sendAsync(String topic, String key, String value){
        ensureTopic(topic);
        var fut=new CompletableFuture<RecordMetadata>();
        sendTimer.record(()-> doSendWithRetry(topic,key,value,fut,0));
        return fut;
    }
    private void doSendWithRetry(String topic,String key,String value,CompletableFuture<RecordMetadata> fut,int attempt){
        getProducer().send(new ProducerRecord<>(topic,key,value),(md,ex)->{
            if(ex!=null){
                if(attempt+1<props.getRetry().getMaxAttempts()){
                    try{ Thread.sleep(props.getRetry().getBackoffMillis()); }catch(InterruptedException ignored){}
                    doSendWithRetry(topic,key,value,fut,attempt+1);
                }else{
                    errorCounter.increment();
                    if(props.getDlq().isEnabled()){
                        String dlq=dlqTopic(topic); ensureTopic(dlq);
                        getProducer().send(new ProducerRecord<>(dlq,key,value),(dmd,dex)->{
                            if(dex!=null) fut.completeExceptionally(dex); else fut.completeExceptionally(ex);
                        });
                    }else fut.completeExceptionally(ex);
                }
            }else{ sendCounter.increment(); fut.complete(md); }
        });
    }
    public RecordMetadata sendSync(String topic,String key,String value) throws Exception { return sendAsync(topic,key,value).get(); }
}
