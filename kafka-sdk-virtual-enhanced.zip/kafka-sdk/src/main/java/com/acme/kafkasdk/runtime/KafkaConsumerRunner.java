package com.acme.kafkasdk.runtime;
import com.acme.kafkasdk.annotation.KafkaConsumerListener;
import com.acme.kafkasdk.admin.KafkaTopicManager;
import com.acme.kafkasdk.config.KafkaSdkProperties;
import com.acme.kafkasdk.producer.KafkaProducerClient;
import io.micrometer.core.instrument.Counter; import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.*; import org.apache.kafka.common.serialization.StringDeserializer;
import java.lang.reflect.Method; import java.time.Duration; import java.util.*; import java.util.concurrent.ExecutorService; import java.util.concurrent.Executors;
@Slf4j
public class KafkaConsumerRunner {
    private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
    private final KafkaSdkProperties props; private final KafkaTopicManager topicManager; private final KafkaProducerClient producerClient;
    private final Counter consumedCounter; private final Counter handlerErrorCounter;
    public KafkaConsumerRunner(KafkaSdkProperties props, KafkaTopicManager topicManager, KafkaProducerClient producerClient, MeterRegistry registry){
        this.props=props; this.topicManager=topicManager; this.producerClient=producerClient;
        this.consumedCounter=Counter.builder("kafka.sdk.consumer.consumed.count").register(registry);
        this.handlerErrorCounter=Counter.builder("kafka.sdk.consumer.handler.error.count").register(registry);
    }
    public void registerListeners(Object bean){
        for(Method m: bean.getClass().getDeclaredMethods()){
            KafkaConsumerListener ann = m.getAnnotation(KafkaConsumerListener.class);
            if(ann!=null){ ensureTopic(ann.topic()); startConsumerVirtualThread(bean,m,ann); }
        }
    }
    private void ensureTopic(String topic){ if(props.isAutoCreateTopics()) topicManager.createTopicIfNotExists(topic,3,(short)1); }
    private void startConsumerVirtualThread(Object bean, Method method, KafkaConsumerListener ann){
        executor.submit(()->{
            Properties cfg=new Properties();
            cfg.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
            cfg.put(ConsumerConfig.GROUP_ID_CONFIG, ann.groupId().isBlank()? props.getConsumer().getDefaultGroupId(): ann.groupId());
            cfg.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            cfg.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
            cfg.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
            cfg.put("security.protocol","SSL");
            var ssl=props.getConsumer().getSsl();
            if(ssl.getTrustStoreLocation()!=null){ cfg.put("ssl.truststore.location", ssl.getTrustStoreLocation()); cfg.put("ssl.truststore.password", ssl.getTrustStorePassword()); cfg.put("ssl.truststore.type", ssl.getTrustStoreType()); }
            if(ssl.getKeyStoreLocation()!=null){ cfg.put("ssl.keystore.location", ssl.getKeyStoreLocation()); cfg.put("ssl.keystore.password", ssl.getKeyStorePassword()); cfg.put("ssl.keystore.type", ssl.getKeyStoreType()); cfg.put("ssl.key.password", ssl.getKeyPassword()); }
            try(KafkaConsumer<String,String> consumer=new KafkaConsumer<>(cfg)){
                consumer.subscribe(Collections.singletonList(ann.topic()));
                while(true){
                    ConsumerRecords<String,String> records=consumer.poll(Duration.ofMillis(ann.pollIntervalMs()));
                    for(ConsumerRecord<String,String> rec: records){
                        try{ method.invoke(bean, rec); consumedCounter.increment(); }
                        catch(Exception e){
                            handlerErrorCounter.increment();
                            if(props.getDlq().isEnabled()){
                                String dlq = (props.getDlq().getTopicOverride()==null||props.getDlq().getTopicOverride().isBlank())? rec.topic()+"-dlq" : props.getDlq().getTopicOverride();
                                try{ producerClient.sendSync(dlq, rec.key(), rec.value()); }catch(Exception ex){ /* swallow but log */ }
                            }
                        }
                    }
                }
            }catch(Exception e){}
        });
    }
}
