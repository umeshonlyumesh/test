package com.acme.kafkasdk.core;
public enum PoisonPolicy { SKIP, DLT, STOP }
