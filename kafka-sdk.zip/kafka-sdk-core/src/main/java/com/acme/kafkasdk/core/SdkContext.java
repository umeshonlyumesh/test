package com.acme.kafkasdk.core;
import org.apache.kafka.clients.consumer.ConsumerRecord;
public interface SdkContext {
  ConsumerRecord<?, ?> record();
  void pause();
  void resume();
  boolean isPaused();
}
