package com.acme.kafkasdk.core;
import java.lang.annotation.*;
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface SdkKafkaListener {
  String id();
  String[] topics();
  String groupId() default "";
}
