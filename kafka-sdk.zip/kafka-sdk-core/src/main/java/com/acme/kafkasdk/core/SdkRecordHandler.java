package com.acme.kafkasdk.core;
public interface SdkRecordHandler<T> {
  void handle(T value, SdkContext context) throws Exception;
}
