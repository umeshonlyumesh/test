package com.acme.kafkasdk.spring;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
public class KafkaControlService {
  private final KafkaListenerEndpointRegistry registry;
  public KafkaControlService(KafkaListenerEndpointRegistry registry) { this.registry = registry; }
  public void pause(String id) {
    MessageListenerContainer c = registry.getListenerContainer(id);
    if (c != null) c.pause();
  }
  public void resume(String id) {
    MessageListenerContainer c = registry.getListenerContainer(id);
    if (c != null) c.resume();
  }
  public boolean isPaused(String id) {
    MessageListenerContainer c = registry.getListenerContainer(id);
    return c != null && c.isContainerPaused();
  }
}
