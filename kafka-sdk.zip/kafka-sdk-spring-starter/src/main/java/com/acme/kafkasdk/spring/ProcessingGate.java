package com.acme.kafkasdk.spring;
import java.util.concurrent.atomic.AtomicBoolean;
public class ProcessingGate {
  private final AtomicBoolean enabled;
  public ProcessingGate(boolean enabled) { this.enabled = new AtomicBoolean(enabled); }
  public boolean isEnabled() { return enabled.get(); }
  public void enable() { enabled.set(true); }
  public void disable() { enabled.set(false); }
}
