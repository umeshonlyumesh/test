package com.acme.kafkasdk.spring;
import com.acme.kafkasdk.core.PoisonPolicy;
import org.springframework.boot.context.properties.ConfigurationProperties;
@ConfigurationProperties(prefix="kafka.sdk")
public class SdkKafkaProperties {
  private boolean processingEnabled = true;
  private PoisonPolicy poisonPolicy = PoisonPolicy.SKIP;
  private String dltSuffix = ".DLT";
  private int concurrency = 3;
  public boolean isProcessingEnabled() { return processingEnabled; }
  public void setProcessingEnabled(boolean v) { this.processingEnabled = v; }
  public PoisonPolicy getPoisonPolicy() { return poisonPolicy; }
  public void setPoisonPolicy(PoisonPolicy p) { this.poisonPolicy = p; }
  public String getDltSuffix() { return dltSuffix; }
  public void setDltSuffix(String s) { this.dltSuffix = s; }
  public int getConcurrency() { return concurrency; }
  public void setConcurrency(int c) { this.concurrency = c; }
}
