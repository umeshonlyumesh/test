package com.truist.cps.kafka.autoconfig;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.consumer.SdkConsumerManager;
import com.truist.cps.kafka.dlt.DeadLetterProducer;
import com.truist.cps.kafka.dlt.DefaultDltTopicResolver;
import com.truist.cps.kafka.dlt.DltTopicResolver;
import com.truist.cps.kafka.metrics.SdkKafkaMetrics;
import com.truist.cps.kafka.metrics.SdkListenerStateTracker;
import com.truist.cps.kafka.metrics.SdkConsumerLagMeter;
import com.truist.cps.kafka.metrics.SdkLagStateTracker;
import com.truist.cps.kafka.notify.LagAlertNotifier;
import com.truist.cps.kafka.notify.EmailLagAlertNotifier;
import com.truist.cps.kafka.notify.TeamsLagAlertNotifier;

import com.truist.cps.kafka.error.SdkErrorHandler;
import com.truist.cps.kafka.producer.SdkKafkaProducer;
import com.truist.cps.kafka.util.KafkaSslUtil;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.util.backoff.ExponentialBackOff;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

@AutoConfiguration
@EnableKafka
@EnableConfigurationProperties(KafkaSdkProperties.class)
@ConditionalOnClass({KafkaTemplate.class, ConcurrentKafkaListenerContainerFactory.class})
public class KafkaSdkAutoConfiguration {

    private final KafkaSdkProperties props;

    public KafkaSdkAutoConfiguration(KafkaSdkProperties props) {
        this.props = props;
    }


    private static final Logger log = LoggerFactory.getLogger(KafkaSdkAutoConfiguration.class);



    @Bean(name = "sdkProducerFactory")
    @ConditionalOnMissingBean(name = "sdkProducerFactory")
public ProducerFactory<String, Object> sdkProducerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        KafkaSslUtil.applyBrokerSsl(config, props.getSsl());

        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ProducerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-producer");
        config.put(ProducerConfig.ACKS_CONFIG, props.getProducerAcks());
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, props.isEnableIdempotence());
        config.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, props.getMaxInFlightRequestsPerConnection());
        config.put(ProducerConfig.RETRIES_CONFIG, props.getProducerRetries());
        config.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, props.getProducerDeliveryTimeoutMs());

        String format = normalize(props.getFormat());
        switch (format) {
            case "avro" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                // You can replace this with your Confluent serializer if on classpath:
                // config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, io.confluent.kafka.serializers.KafkaAvroSerializer.class);
                // config.put("schema.registry.url", props.getSchemaRegistryUrl());
                // For now, keep Object with String serializer unless you add Avro dependency.
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                log.warn("format=avro selected but no Avro serializer wired; defaulting value serializer to StringSerializer. Add Confluent serializer to enable Avro.");
            }
            case "json" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
        }

        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean(name = "sdkKafkaTemplate")
    @ConditionalOnMissingBean(name = "sdkKafkaTemplate")
    public KafkaTemplate<String, Object> sdkKafkaTemplate(ProducerFactory<String, Object> sdkProducerFactory) {
        return new KafkaTemplate<>(sdkProducerFactory);
    }

    @Bean(name = "sdkConsumerFactory")
    @ConditionalOnMissingBean(name = "sdkConsumerFactory")
    public ConsumerFactory<String, Object> sdkConsumerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        KafkaSslUtil.applyBrokerSsl(config, props.getSsl());

        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, props.getGroupId());
        config.put(ConsumerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-consumer");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, props.getMaxPollIntervalMs());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, props.getMaxPollRecords());
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, props.getAutoOffsetReset());
        config.put(CommonClientConfigs.METADATA_MAX_AGE_CONFIG, 30_000);

        String format = normalize(props.getFormat());

// Always wrap with ErrorHandlingDeserializer so poison payload/deserialization errors
// can be handled by DefaultErrorHandler and offsets can be committed when we skip.
config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);

switch (format) {
    case "avro" -> {
        config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class.getName());
        // Wire Avro deserializer if dependency exists:
        // config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, "io.confluent.kafka.serializers.KafkaAvroDeserializer");
        // config.put("schema.registry.url", props.getSchemaRegistryUrl());
        // config.put("specific.avro.reader", props.isSpecificAvroReader());
        // For now, default delegate to StringDeserializer to keep the SDK dependency-light.
        config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class.getName());
        log.warn("format=avro selected but no Avro deserializer wired; defaulting value delegate to StringDeserializer. Add Confluent deserializer to enable Avro.");
    }
    case "json" -> {
        config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class.getName());
        config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, StringDeserializer.class.getName());
    }
    default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
}

        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean(name = "sdkKafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "sdkKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, Object> sdkKafkaListenerContainerFactory(ConsumerFactory<String, Object> sdkConsumerFactory,
            KafkaSdkProperties props,
            CommonErrorHandler sdkCommonErrorHandler) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(sdkConsumerFactory);
        factory.setConcurrency(props.getConcurrency());

        ContainerProperties cp = factory.getContainerProperties();
        cp.setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        cp.setPollTimeout(props.getPollTimeoutMs());
        cp.setIdleBetweenPolls(props.getIdleBetweenPollsMs());
        cp.setPauseImmediate(true); // avoid buffering when paused
        cp.setMissingTopicsFatal(props.isMissingTopicsFatal());

        factory.setCommonErrorHandler(sdkCommonErrorHandler);

        return factory;
    }

    /**
 * Build the common error handler used by all listeners that reference {@code sdkKafkaListenerContainerFactory}.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Retry transient failures with exponential backoff.</li>
 *   <li>Immediately treat deserialization/schema errors as not-retryable.</li>
 *   <li>On recovery: either publish to DLT (if enabled) or skip poison records and commit offsets.</li>
 * </ul>
 *
 * @param deadLetterProducer DLT publisher utility
 * @param props SDK properties
 * @return configured common error handler
 */
/**
 * Build the common error handler used by all listeners that reference {@code sdkKafkaListenerContainerFactory}.
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Retry transient failures with exponential backoff (configurable).</li>
 *   <li>Immediately treat deserialization/schema errors as not-retryable (poison).</li>
 *   <li>On recovery: publish to DLT (if enabled) or skip poison records and commit offsets.</li>
 *   <li>Optionally auto-pause containers on repeated failures to protect downstream dependencies.</li>
 * </ul>
 */
@Bean(name = "sdkCommonErrorHandler")
@ConditionalOnMissingBean(name = "sdkCommonErrorHandler")
public CommonErrorHandler sdkCommonErrorHandler(DeadLetterProducer deadLetterProducer,
                                               KafkaSdkProperties props,
                                               SdkKafkaMetrics sdkKafkaMetrics) {

    KafkaSdkProperties.RetryProperties r = props.getRetry();

    ExponentialBackOff backOff = new ExponentialBackOff(
            r != null ? r.getInitialBackoffMs() : 1000L,
            r != null ? r.getBackoffMultiplier() : 2.0
    );
    backOff.setMaxInterval(r != null ? r.getMaxBackoffMs() : 60_000L);
    backOff.setMaxElapsedTime(r != null ? r.getMaxElapsedMs() : 300_000L);

    org.springframework.util.backoff.BackOff effectiveBackOff =
            (r == null || r.isEnabled()) ? backOff : new FixedBackOff(0L, 0L);

    java.util.function.BiConsumer<org.apache.kafka.clients.consumer.ConsumerRecord<?, ?>, Exception> recoverer = (record, ex) -> {
        if (props.isDltEnabled()) {
            deadLetterProducer.publish(record, ex);
            return;
        }

        if (isPoison(ex)) {
            sdkKafkaMetrics.incrementPoisonSkip();
            log.warn("Skipping poison record (DLT disabled) topic={} partition={} offset={} key={} dueTo={}",
                    record.topic(), record.partition(), record.offset(), record.key(),
                    ex.getClass().getSimpleName(), ex);
            return;
        }

        log.error("Retries exhausted for non-poison error; NOT committing offset. topic={} partition={} offset={} key={}",
                record.topic(), record.partition(), record.offset(), record.key(), ex);

        throw (ex instanceof RuntimeException re) ? re : new RuntimeException(ex);
    };

    SdkErrorHandler errorHandler = new SdkErrorHandler(props, sdkKafkaMetrics, recoverer, effectiveBackOff);

    Class<? extends Exception>[] nonRetryable = loadExceptionClasses(props.getNotRetryableExceptions());
    if (nonRetryable.length > 0) {
        errorHandler.addNotRetryableExceptions(nonRetryable);
    }

    Class<? extends Exception>[] explicitRetryable = loadExceptionClasses(props.getRetryableExceptions());
    if (explicitRetryable.length > 0) {
        errorHandler.addRetryableExceptions(explicitRetryable);
    }

    errorHandler.setCommitRecovered(true);
    errorHandler.setAckAfterHandle(false);
    return errorHandler;
}

private static boolean isPoison(Exception ex) {
    if (ex == null) return false;
    // DeserializationException may wrap the real cause; treat it as poison.
    if (ex instanceof DeserializationException) return true;
    if (ex instanceof SerializationException) return true;
    if (ex instanceof RecordDeserializationException) return true;
    if (ex instanceof IllegalArgumentException) return true;
    // unwrap common wrapper types
    Throwable cause = ex.getCause();
    return cause instanceof SerializationException
            || cause instanceof RecordDeserializationException
            || cause instanceof IllegalArgumentException;
}


/**
 * SDK metrics recorder.
 * If a {@link MeterRegistry} is present, metrics are recorded via Micrometer; otherwise no-op.
 */
@Bean
@ConditionalOnMissingBean
public SdkKafkaMetrics sdkKafkaMetrics(ObjectProvider<MeterRegistry> registryProvider) {
    MeterRegistry reg = registryProvider.getIfAvailable();
    return reg != null ? SdkKafkaMetrics.micrometer(reg) : SdkKafkaMetrics.noop();
}

/**
 * Tracks listener activity for observability (last seen/processed timestamps).
 */
@Bean
@ConditionalOnMissingBean
public SdkListenerStateTracker sdkListenerStateTracker() {
    return new SdkListenerStateTracker();
}


/**
 * Tracks lag state across intervals for health + notifications.
 */
@Bean
@ConditionalOnMissingBean
public SdkLagStateTracker sdkLagStateTracker() {
    return new SdkLagStateTracker();
}

public SdkConsumerLagMeter sdkConsumerLagMeter(KafkaSdkProperties props) {
    return new SdkConsumerLagMeter(props);
}



/**
 * Lag alert notifier (email).
 * Requires {@link JavaMailSender} bean and {@code kafka.sdk.lag-alert-notifications.enabled=true}.
 */
@Bean
@ConditionalOnMissingBean
@ConditionalOnClass(JavaMailSender.class)
@ConditionalOnProperty(prefix = "kafka.sdk.lag-alert-notifications", name = "enabled", havingValue = "true")
public LagAlertNotifier sdkLagAlertNotifier(ObjectProvider<JavaMailSender> mailSenderProvider, KafkaSdkProperties props) {
    JavaMailSender sender = mailSenderProvider.getIfAvailable();
    if (sender != null) {
            return new EmailLagAlertNotifier(sender, props);
        }
        // fallback to Teams webhook if configured
        if (props.getLagAlertNotifications() != null && props.getLagAlertNotifications().getTeamWebHookUrl() != null) {
            return new TeamsLagAlertNotifier(props);
        }
        return LagAlertNotifier.noop();
}




    @Bean
    @ConditionalOnMissingBean
public DltTopicResolver sdkDltTopicResolver(KafkaSdkProperties props) {

    return new DefaultDltTopicResolver(props);
}

/**
 * Dead-letter producer utility.
 *
 * @param sdkKafkaTemplate SDK KafkaTemplate
 * @param sdkDltTopicResolver resolver for DLT topic name
 * @return producer used by error handler to publish DLT messages
 */
@Bean
@ConditionalOnMissingBean
public DeadLetterProducer sdkDeadLetterProducer(KafkaTemplate<String, Object> sdkKafkaTemplate,
                                                    DltTopicResolver sdkDltTopicResolver,
                                                    SdkKafkaMetrics sdkKafkaMetrics) {
        @SuppressWarnings({"unchecked", "rawtypes"})
        KafkaTemplate<Object, Object> cast = (KafkaTemplate) sdkKafkaTemplate;
        return new DeadLetterProducer(cast, sdkDltTopicResolver, sdkKafkaMetrics, props);
}

public SdkKafkaProducer sdkKafkaProducer(KafkaTemplate<String, Object> sdkKafkaTemplate) {
        return new SdkKafkaProducer(sdkKafkaTemplate);
    }

    @Bean
    @ConditionalOnMissingBean
    public SdkConsumerManager sdkConsumerManager(ObjectProvider<KafkaListenerEndpointRegistry> registryProvider) {
        return new SdkConsumerManager(registryProvider);
    }

    @SuppressWarnings("unchecked")
    private static Class<? extends Exception>[] loadExceptionClasses(java.util.List<String> names) {
        if (names == null || names.isEmpty()) {
            return (Class<? extends Exception>[]) new Class[0];
        }
        java.util.List<Class<? extends Exception>> out = new java.util.ArrayList<>();
        for (String n : names) {
            if (n == null || n.isBlank()) continue;
            try {
                Class<?> c = Class.forName(n.trim());
                if (Exception.class.isAssignableFrom(c)) {
                    out.add((Class<? extends Exception>) c);
                } else {
                    log.warn("Configured exception class is not an Exception: {}", n);
                }
            } catch (ClassNotFoundException e) {
                log.warn("Configured exception class not found (ignored): {}", n);
            }
        }
        return out.toArray((Class<? extends Exception>[]) new Class[0]);
    }

    private static String normalize(String v) {
        return v == null ? "" : v.trim().toLowerCase();
    }
}
