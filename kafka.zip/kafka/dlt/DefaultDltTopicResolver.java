package com.truist.cps.kafka.dlt;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.util.Objects;

/**
 * Default dead-letter topic resolver.
 * <ul>
 *   <li>If {@code kafka.sdk.dlt-topic} is set (non-blank), it is used as the DLT topic.</li>
 *   <li>Otherwise, the DLT topic is computed as {@code <originalTopic><kafka.sdk.dlt-topic-suffix>}.</li>
 * </ul>
 */
public class DefaultDltTopicResolver implements DltTopicResolver {

    private final KafkaSdkProperties props;

    /**
     * Create a resolver using SDK configuration properties.
     *
     * @param props SDK properties (required)
     */
    public DefaultDltTopicResolver(KafkaSdkProperties props) {
        this.props = Objects.requireNonNull(props, "props");
    }

    @Override
    public String resolveTopic(ConsumerRecord<?, ?> record, Exception exception) {
        Objects.requireNonNull(record, "record");
        Objects.requireNonNull(exception, "exception");
        String fixed = props.getDltTopic();
        if (fixed != null && !fixed.isBlank()) {
            return fixed.trim();
        }
        String suffix = props.getDltTopicSuffix() == null ? ".DLT" : props.getDltTopicSuffix();
        return record.topic() + suffix;
    }
}
