package com.truist.cps.kafka.notify;

import com.truist.cps.kafka.config.KafkaSdkProperties;
import com.truist.cps.kafka.metrics.SdkLagStateTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Sends lag alert notifications via email using Spring Boot {@link JavaMailSender}.
 * <p>
 * Requires the client app to configure SMTP settings via {@code spring.mail.*}.
 */
public class EmailLagAlertNotifier implements LagAlertNotifier {

    private static final Logger log = LoggerFactory.getLogger(EmailLagAlertNotifier.class);

    private final JavaMailSender mailSender;
    private final KafkaSdkProperties props;

    public EmailLagAlertNotifier(JavaMailSender mailSender, KafkaSdkProperties props) {
        this.mailSender = Objects.requireNonNull(mailSender, "mailSender");
        this.props = Objects.requireNonNull(props, "props");
    }

    @Override
    public void notify(SdkLagStateTracker.LagKey worstKey, long worstLag, Map<SdkLagStateTracker.LagKey, Long> snapshot) {
        KafkaSdkProperties.LagAlertNotificationProperties cfg = props.getLagAlertNotifications();
        if (cfg == null || !cfg.isEnabled() || cfg.getTo() == null || cfg.getTo().isEmpty()) {
            return;
        }

        String subj = cfg.getSubject() == null ? "[Kafka SDK] Consumer lag alert" : cfg.getSubject();
        subj = subj.replace("{groupId}", safe(worstKey.groupId))
                .replace("{topic}", safe(worstKey.topic))
                .replace("{partition}", Integer.toString(worstKey.partition));

        String body = "Kafka SDK detected consumer lag above threshold."
                + "Worst partition:"
                + "  groupId: " + worstKey.groupId
                + "  topic: " + worstKey.topic
                + "  partition: " + worstKey.partition
                + "  lag: " + worstLag
                + "Snapshot (top entries):"
                + snapshot.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(25)
                .map(e -> e.getKey().toString() + " -> " + e.getValue())
                .collect(Collectors.joining(""));

        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            if (cfg.getFrom() != null && !cfg.getFrom().isBlank()) {
                msg.setFrom(cfg.getFrom());
            }
            msg.setTo(cfg.getTo().toArray(new String[0]));
            msg.setSubject(subj);
            msg.setText(body);

            mailSender.send(msg);
            log.warn("Sent lag alert email to={} subject={}", cfg.getTo(), subj);
        } catch (Exception ex) {
            log.warn("Failed to send lag alert email: {}", ex.toString());
        }
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}
