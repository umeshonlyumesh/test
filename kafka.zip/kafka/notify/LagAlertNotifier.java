package com.truist.cps.kafka.notify;

import com.truist.cps.kafka.metrics.SdkLagStateTracker;

import java.util.Map;

/**
 * Notifies external systems about lag alerts (e.g., email).
 */
public interface LagAlertNotifier {

    /**
     * Notify about a lag alert.
     *
     * @param worstKey worst offending partition key
     * @param worstLag worst lag value
     * @param snapshot current lag snapshot (may be limited)
     */
    void notify(SdkLagStateTracker.LagKey worstKey, long worstLag, Map<SdkLagStateTracker.LagKey, Long> snapshot);

    static LagAlertNotifier noop() {
        return (k, l, s) -> {};
    }
}
