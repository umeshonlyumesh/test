
package com.example.coreapi.common.http;

public class DownstreamServiceException extends RuntimeException {

    private final String serviceName;
    private final int statusCode;
    private final String responseBody;

    public DownstreamServiceException(String serviceName, int statusCode, String responseBody) {
        super("Downstream call failed. service=" + serviceName + ", status=" + statusCode);
        this.serviceName = serviceName;
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    public String getServiceName() { return serviceName; }
    public int getStatusCode() { return statusCode; }
    public String getResponseBody() { return responseBody; }
}
