
package com.example.coreapi.common.http;

import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.ClientTlsStrategyBuilder;
import org.apache.hc.client5.http.ssl.DefaultClientTlsStrategy;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.hc.core5.util.Timeout;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Map;

public class HttpClientFactory {

    public RestClient createRestClient(ClientConfig config) {

        CloseableHttpClient httpClient = buildHttpClient(config);

        HttpComponentsClientHttpRequestFactory requestFactory =
                new HttpComponentsClientHttpRequestFactory(httpClient);

        return RestClient.builder()
                .requestFactory(requestFactory)
                .baseUrl(config.baseUrl())
                .defaultHeaders(headers -> {
                    headers.set("Content-Type", "application/json");
                    config.headers().forEach(headers::add);
                })
                .build();
    }

    private CloseableHttpClient buildHttpClient(ClientConfig config) {
        try {

            PoolingHttpClientConnectionManagerBuilder connectionManager =
                    PoolingHttpClientConnectionManagerBuilder.create();

            if (config.ssl() != null && config.ssl().isEnabled()) {

                SSLContext sslContext = buildSslContext(config.ssl());

                DefaultClientTlsStrategy tlsStrategy =
                        ClientTlsStrategyBuilder.create()
                                .setSslContext(sslContext)
                                .buildClassic();

                connectionManager.setTlsSocketStrategy(tlsStrategy);
            }

            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(Timeout.ofMilliseconds(config.connectTimeout()))
                    .setResponseTimeout(Timeout.ofMilliseconds(config.readTimeout()))
                    .build();

            return HttpClients.custom()
                    .setConnectionManager(connectionManager.build())
                    .setDefaultRequestConfig(requestConfig)
                    .build();

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    private SSLContext buildSslContext(SslClientProperties ssl) throws Exception {

        KeyStore keyStore = KeyStore.getInstance(ssl.getKeyStoreType());
        keyStore.load(new FileInputStream(ssl.getKeyStorePath()),
                ssl.getKeyStorePassword().toCharArray());

        KeyStore trustStore = KeyStore.getInstance(ssl.getTrustStoreType());
        trustStore.load(new FileInputStream(ssl.getTrustStorePath()),
                ssl.getTrustStorePassword().toCharArray());

        return SSLContextBuilder.create()
                .loadKeyMaterial(keyStore, ssl.getKeyPassword().toCharArray())
                .loadTrustMaterial(trustStore, null)
                .build();
    }

    public record ClientConfig(
            String serviceName,
            String baseUrl,
            int connectTimeout,
            int readTimeout,
            Map<String,String> headers,
            SslClientProperties ssl
    ){}
}
