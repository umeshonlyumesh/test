
package com.example.coreapi.fraud.client;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class FraudApiClient {

    private final RestClient restClient;

    public FraudApiClient(@Qualifier("fraudRestClient") RestClient restClient) {
        this.restClient = restClient;
    }

    public String evaluateFraud(Object request) {

        return restClient.post()
                .uri("/fraud/check")
                .body(request)
                .retrieve()
                .body(String.class);
    }
}
