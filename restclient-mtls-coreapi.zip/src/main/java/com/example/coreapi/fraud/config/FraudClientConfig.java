
package com.example.coreapi.fraud.config;

import com.example.coreapi.common.http.HttpClientFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Configuration
public class FraudClientConfig {

    @Bean("fraudRestClient")
    public RestClient fraudRestClient(FraudClientProperties props) {

        HttpClientFactory factory = new HttpClientFactory();

        return factory.createRestClient(
                new HttpClientFactory.ClientConfig(
                        "fraud",
                        props.getBaseUrl(),
                        props.getConnectTimeoutMs(),
                        props.getReadTimeoutMs(),
                        Map.of(
                                "X-Client-Id", props.getClientId(),
                                "X-Api-Key", props.getApiKey()
                        ),
                        props.getSsl()
                )
        );
    }
}
