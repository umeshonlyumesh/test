
package com.example.coreapi.fraud.config;

import com.example.coreapi.common.http.SslClientProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "sdk.fraud")
public class FraudClientProperties {

    private String baseUrl;
    private int connectTimeoutMs;
    private int readTimeoutMs;
    private String clientId;
    private String apiKey;
    private SslClientProperties ssl = new SslClientProperties();

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }

    public int getConnectTimeoutMs() { return connectTimeoutMs; }
    public void setConnectTimeoutMs(int connectTimeoutMs) { this.connectTimeoutMs = connectTimeoutMs; }

    public int getReadTimeoutMs() { return readTimeoutMs; }
    public void setReadTimeoutMs(int readTimeoutMs) { this.readTimeoutMs = readTimeoutMs; }

    public String getClientId() { return clientId; }
    public void setClientId(String clientId) { this.clientId = clientId; }

    public String getApiKey() { return apiKey; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }

    public SslClientProperties getSsl() { return ssl; }
    public void setSsl(SslClientProperties ssl) { this.ssl = ssl; }
}
