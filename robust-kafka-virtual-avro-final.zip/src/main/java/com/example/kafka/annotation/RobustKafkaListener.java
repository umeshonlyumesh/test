package com.example.kafka.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RobustKafkaListener {
String topic();
String groupId();
}
