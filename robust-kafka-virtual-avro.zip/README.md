# robust-kafka-virtual-avro

Final verified project.
- Core kafka-clients only
- Annotation based consumer (topic + groupId)
- Safe Avro deserialization
- Ordered per-partition processing
- Manual commit
- Virtual threads
