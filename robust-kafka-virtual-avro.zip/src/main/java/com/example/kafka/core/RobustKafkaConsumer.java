package com.example.kafka.core;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RobustKafkaConsumer<V> {

  private final KafkaConsumer<String, V> consumer;
  private final String topic;
  private final RecordProcessor<V> processor;
  private final DlqPublisher<V> dlq;
  private final int maxRetries;
  private final long pollTimeoutMs;

  private final AtomicBoolean running = new AtomicBoolean(false);
  private final Map<TopicPartition, Long> lastSuccess = new ConcurrentHashMap<>();
  private final Map<TopicPartition, Map<Long, Integer>> retries = new ConcurrentHashMap<>();

  private final ExecutorService pollExecutor =
      Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "robust-kafka-poll-" + topic);
        t.setDaemon(true);
        return t;
      });

  private final ExecutorService workerPool =
      Executors.newThreadPerTaskExecutor(Thread.ofVirtual().name("robust-kafka-worker-", 0).factory());

  public RobustKafkaConsumer(KafkaConsumer<String, V> consumer,
                            String topic,
                            RecordProcessor<V> processor,
                            DlqPublisher<V> dlq,
                            int maxRetries,
                            long pollTimeoutMs) {
    this.consumer = consumer;
    this.topic = topic;
    this.processor = processor;
    this.dlq = dlq;
    this.maxRetries = maxRetries;
    this.pollTimeoutMs = pollTimeoutMs;
  }

  public void start() {
    if (!running.compareAndSet(false, true)) return;
    pollExecutor.submit(this::pollLoop);
  }

  public void stop() {
    if (!running.compareAndSet(true, false)) return;
    consumer.wakeup();
    pollExecutor.shutdown();
    workerPool.shutdown();
  }

  private void pollLoop() {
    try {
      consumer.subscribe(Collections.singletonList(topic),
          new ConsumerRebalanceListener() {
            @Override
            public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
              commit();
            }
            @Override
            public void onPartitionsAssigned(Collection<TopicPartition> partitions) {}
          });

      while (running.get()) {
        ConsumerRecords<String, V> records =
            consumer.poll(Duration.ofMillis(pollTimeoutMs));

        for (TopicPartition tp : records.partitions()) {
          for (ConsumerRecord<String, V> r : records.records(tp)) {
            if (!processOne(tp, r)) break;
          }
        }
        commit();
      }
    } catch (WakeupException ignore) {
    } finally {
      try { commit(); } catch (Exception ignore) {}
      consumer.close();
    }
  }

  private boolean processOne(TopicPartition tp, ConsumerRecord<String, V> r) {

    if (r.value() == null) {
      System.err.printf(
          "BAD_PAYLOAD | topic=%s partition=%d offset=%d%n",
          r.topic(), r.partition(), r.offset()
      );
      lastSuccess.put(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;
    }

    try {
      Future<?> f = workerPool.submit(() -> processor.process(r));
      f.get();
      lastSuccess.put(tp, r.offset());
      clearRetry(tp, r.offset());
      return true;

    } catch (Exception e) {
      return handleFailure(tp, r, e);
    }
  }

  private boolean handleFailure(TopicPartition tp, ConsumerRecord<String, V> r, Exception e) {
    int attempt = incRetry(tp, r.offset());
    if (attempt <= maxRetries) return false;

    dlq.publish(r, e);
    lastSuccess.put(tp, r.offset());
    clearRetry(tp, r.offset());
    return true;
  }

  private void commit() {
    if (lastSuccess.isEmpty()) return;
    Map<TopicPartition, OffsetAndMetadata> map = new HashMap<>();
    lastSuccess.forEach((tp, off) -> map.put(tp, new OffsetAndMetadata(off + 1)));
    consumer.commitSync(map);
  }

  private int incRetry(TopicPartition tp, long offset) {
    return retries.computeIfAbsent(tp, k -> new ConcurrentHashMap<>())
        .merge(offset, 1, Integer::sum);
  }

  private void clearRetry(TopicPartition tp, long offset) {
    Map<Long, Integer> m = retries.get(tp);
    if (m != null) m.remove(offset);
  }

  @FunctionalInterface
  public interface RecordProcessor<V> {
    void process(ConsumerRecord<String, V> record) throws Exception;
  }

  @FunctionalInterface
  public interface DlqPublisher<V> {
    void publish(ConsumerRecord<String, V> record, Exception cause);
  }
}
