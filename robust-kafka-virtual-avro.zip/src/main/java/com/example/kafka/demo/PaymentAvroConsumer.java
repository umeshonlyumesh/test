package com.example.kafka.demo;

import com.example.kafka.annotation.RobustKafkaListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Component;

@Component
public class PaymentAvroConsumer {

  @RobustKafkaListener(topic = "payments-topic", groupId = "payments-group")
  public void onMessage(ConsumerRecord<String, Object> record) {
    System.out.println("Processed record: " + record.value());
  }
}
