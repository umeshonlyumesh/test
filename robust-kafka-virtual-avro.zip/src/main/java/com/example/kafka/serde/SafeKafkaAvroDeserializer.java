package com.example.kafka.serde;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.common.header.Headers;
import java.util.Base64;

public class SafeKafkaAvroDeserializer extends KafkaAvroDeserializer {

  @Override
  public Object deserialize(String topic, Headers headers, byte[] bytes) {
    try {
      return super.deserialize(topic, headers, bytes);
    } catch (Exception ex) {
      String sample = (bytes == null) ? "null" : Base64.getEncoder().encodeToString(
          bytes.length > 256 ? java.util.Arrays.copyOf(bytes, 256) : bytes
      );
      System.err.printf(
          "BAD_PAYLOAD_DESERIALIZATION | topic=%s bytesSampleBase64=%s error=%s%n",
          topic, sample, ex.toString()
      );
      return null;
    }
  }
}
