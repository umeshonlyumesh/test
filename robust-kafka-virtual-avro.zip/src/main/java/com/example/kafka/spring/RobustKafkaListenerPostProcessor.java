package com.example.kafka.spring;

import com.example.kafka.annotation.RobustKafkaListener;
import com.example.kafka.core.RobustKafkaConsumer;
import com.example.kafka.serde.SafeKafkaAvroDeserializer;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.SmartLifecycle;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.*;

@Component
public class RobustKafkaListenerPostProcessor implements BeanPostProcessor, SmartLifecycle {

  private final Environment env;
  private final List<RobustKafkaConsumer<?>> consumers = new ArrayList<>();
  private boolean running;

  public RobustKafkaListenerPostProcessor(Environment env) {
    this.env = env;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
    ReflectionUtils.doWithMethods(bean.getClass(), method -> {
      RobustKafkaListener ann = method.getAnnotation(RobustKafkaListener.class);
      if (ann == null) return;

      method.setAccessible(true);
      Properties props = new Properties();

      props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
          env.getProperty("kafka.bootstrap.servers", "localhost:9092"));
      props.put(ConsumerConfig.GROUP_ID_CONFIG, ann.groupId());
      props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
      props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
      props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, SafeKafkaAvroDeserializer.class.getName());
      props.put("schema.registry.url",
          env.getProperty("kafka.schema.registry.url", "http://localhost:8081"));
      props.put("specific.avro.reader", "true");

      KafkaConsumer<String, Object> kc = new KafkaConsumer<>(props);

      RobustKafkaConsumer<Object> rc = new RobustKafkaConsumer<>(
          kc,
          ann.topic(),
          r -> method.invoke(bean, r),
          (r, e) -> System.err.println("DLQ: " + r.offset()),
          Integer.parseInt(env.getProperty("robust.max.retries", "3")),
          Long.parseLong(env.getProperty("robust.poll.timeout.ms", "1000"))
      );
      consumers.add(rc);
    });
    return bean;
  }

  @Override public void start() {
    consumers.forEach(RobustKafkaConsumer::start);
    running = true;
  }
  @Override public void stop() {
    consumers.forEach(RobustKafkaConsumer::stop);
    running = false;
  }
  @Override public boolean isRunning() { return running; }
  @Override public boolean isAutoStartup() { return true; }
  @Override public int getPhase() { return 0; }
  @Override public void stop(Runnable callback) { stop(); callback.run(); }
}
