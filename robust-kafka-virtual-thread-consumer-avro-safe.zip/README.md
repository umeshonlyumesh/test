# robust-kafka-virtual-avro (Core Kafka + Virtual Threads + Avro Safe Deserialization)

This project demonstrates a production-style Kafka consumer using **ONLY** `kafka-clients`
(no Spring Kafka), while still supporting **annotation-based listeners** and Spring lifecycle.

## Key features
- Single poll/commit thread (KafkaConsumer is not thread-safe)
- Per-partition ordered processing
- Virtual threads for per-record processing (Java 21)
- Manual commit per partition (offset + 1)
- Business failure: retry N times -> DLQ placeholder -> commit
- **Avro deserialization failure**: SafeKafkaAvroDeserializer returns `null` -> log BAD_PAYLOAD -> commit+skip

## Configure
Edit `src/main/resources/application.properties`:
- `kafka.bootstrap.servers`
- `kafka.schema.registry.url`

## Run
```bash
mvn clean spring-boot:run
```

## Notes
- Replace the DLQ placeholder in `RobustKafkaListenerPostProcessor` with a real KafkaProducer to publish to your DLQ topic.
- `specific.avro.reader=true` enables SpecificRecord if you generated classes.