package com.example.kafka.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RobustKafkaListener {
    String topic();
    String groupId();

    int maxRetries() default 3;
    long pollTimeoutMs() default 1000;

    /**
     * If true, deserialization failures are skipped (logged as BAD_PAYLOAD),
     * and the offset is committed so the consumer continues.
     */
    boolean skipBadPayload() default true;

    String clientIdPrefix() default "robust-consumer";
}