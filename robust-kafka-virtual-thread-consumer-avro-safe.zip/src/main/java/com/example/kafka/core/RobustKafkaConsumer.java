package com.example.kafka.core;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Robust, production-style consumer using ONLY kafka-clients.
 *
 * - Single poll/commit thread (KafkaConsumer is NOT thread-safe)
 * - Per-partition ordered processing
 * - Virtual threads for per-record processing
 * - Track last-success offset per partition
 * - Business failure: retry N, then DLQ and mark success
 * - Deserialization failure: value == null (from SafeKafkaAvroDeserializer) -> log + skip + commit
 */
public class RobustKafkaConsumer<V> implements Runnable {

    private final KafkaConsumer<String, V> consumer;
    private final String topic;
    private final RecordProcessor<V> processor;
    private final DlqPublisher<V> dlq;
    private final int maxRetries;
    private final long pollTimeoutMs;
    private final boolean skipBadPayload;

    private final AtomicBoolean running = new AtomicBoolean(true);

    // Last successful offset per partition
    private final Map<TopicPartition, Long> lastSuccess = new ConcurrentHashMap<>();

    // Retry count per (partition, offset) for business failures
    private final Map<TopicPartition, Map<Long, Integer>> retries = new ConcurrentHashMap<>();

    // Virtual threads for processing (safe because KafkaConsumer access stays on poll thread)
    private final ExecutorService workerPool =
            Executors.newThreadPerTaskExecutor(
                    Thread.ofVirtual().name("robust-kafka-worker-", 0).factory()
            );

    public RobustKafkaConsumer(KafkaConsumer<String, V> consumer,
                              String topic,
                              RecordProcessor<V> processor,
                              DlqPublisher<V> dlq,
                              int maxRetries,
                              long pollTimeoutMs,
                              boolean skipBadPayload) {
        this.consumer = Objects.requireNonNull(consumer);
        this.topic = Objects.requireNonNull(topic);
        this.processor = Objects.requireNonNull(processor);
        this.dlq = Objects.requireNonNull(dlq);
        this.maxRetries = maxRetries;
        this.pollTimeoutMs = pollTimeoutMs;
        this.skipBadPayload = skipBadPayload;
    }

    @Override
    public void run() {
        try {
            consumer.subscribe(Collections.singletonList(topic), new ConsumerRebalanceListener() {
                @Override
                public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                    // commit progress before losing partitions
                    commit();
                }
                @Override
                public void onPartitionsAssigned(Collection<TopicPartition> partitions) { }
            });

            while (running.get()) {
                ConsumerRecords<String, V> records =
                        consumer.poll(Duration.ofMillis(pollTimeoutMs));

                if (records.isEmpty()) continue;

                // Process per partition in order
                for (TopicPartition tp : records.partitions()) {
                    for (ConsumerRecord<String, V> r : records.records(tp)) {
                        if (!processOne(tp, r)) {
                            // preserve ordering: stop this partition on a business failure (no commit past it)
                            break;
                        }
                    }
                }

                commit();
            }
        } catch (WakeupException we) {
            // expected on shutdown
        } finally {
            try {
                commit();
            } catch (Exception ignore) { }
            try {
                consumer.close();
            } finally {
                workerPool.shutdown();
            }
        }
    }

    /**
     * @return true if we can continue on this partition; false to stop due to business failure needing retry.
     */
    private boolean processOne(TopicPartition tp, ConsumerRecord<String, V> r) {
        // Deserialization failure path: SafeKafkaAvroDeserializer returns null
        if (r.value() == null) {
            if (!skipBadPayload) {
                // If you ever want to STOP on bad payload (not recommended), set skipBadPayload=false
                throw new IllegalStateException(
                        "Bad payload encountered (value==null) at " + tp + " offset=" + r.offset());
            }

            System.err.printf(
                    "BAD_PAYLOAD | topic=%s partition=%d offset=%d key=%s%n",
                    r.topic(), r.partition(), r.offset(), r.key()
            );
            // mark as success so we commit and move on
            lastSuccess.put(tp, r.offset());
            clearRetry(tp, r.offset());
            return true;
        }

        try {
            Future<?> f = workerPool.submit(() -> processor.process(r));
            f.get(); // preserves per-partition ordering (do not process next until this completes)
            lastSuccess.put(tp, r.offset());
            clearRetry(tp, r.offset());
            return true;

        } catch (ExecutionException ee) {
            Exception e = (ee.getCause() instanceof Exception ex) ? ex : new RuntimeException(ee.getCause());
            return handleBusinessFailure(tp, r, e);

        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            return handleBusinessFailure(tp, r, ie);

        } catch (Exception e) {
            return handleBusinessFailure(tp, r, e);
        }
    }

    private boolean handleBusinessFailure(TopicPartition tp, ConsumerRecord<String, V> r, Exception e) {
        int attempt = incRetry(tp, r.offset());

        if (attempt <= maxRetries) {
            System.err.printf(
                    "PROCESSING_FAILED_RETRY | topic=%s partition=%d offset=%d attempt=%d error=%s%n",
                    r.topic(), r.partition(), r.offset(), attempt, e.toString()
            );
            // stop this partition; do not commit; Kafka will redeliver
            return false;
        }

        // Poison message after retries -> DLQ then mark success so we can commit and continue
        System.err.printf(
                "POISON_TO_DLQ | topic=%s partition=%d offset=%d attempts=%d error=%s%n",
                r.topic(), r.partition(), r.offset(), attempt, e.toString()
        );
        dlq.publish(r, e);

        lastSuccess.put(tp, r.offset());
        clearRetry(tp, r.offset());
        return true;
    }

    private void commit() {
        if (lastSuccess.isEmpty()) return;

        Map<TopicPartition, OffsetAndMetadata> map = new HashMap<>();
        lastSuccess.forEach((tp, off) -> map.put(tp, new OffsetAndMetadata(off + 1)));
        consumer.commitSync(map);
    }

    private int incRetry(TopicPartition tp, long offset) {
        return retries.computeIfAbsent(tp, k -> new ConcurrentHashMap<>())
                .merge(offset, 1, Integer::sum);
    }

    private void clearRetry(TopicPartition tp, long offset) {
        Map<Long, Integer> m = retries.get(tp);
        if (m != null) m.remove(offset);
    }

    public void shutdown() {
        running.set(false);
        consumer.wakeup();
    }

    @FunctionalInterface
    public interface RecordProcessor<V> {
        void process(ConsumerRecord<String, V> record) throws Exception;
    }

    @FunctionalInterface
    public interface DlqPublisher<V> {
        void publish(ConsumerRecord<String, V> record, Exception cause);
    }
}