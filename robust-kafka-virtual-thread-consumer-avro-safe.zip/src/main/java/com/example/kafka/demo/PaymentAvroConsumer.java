package com.example.kafka.demo;

import com.example.kafka.annotation.RobustKafkaListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.stereotype.Component;

/**
 * Demo listener.
 *
 * - If Avro deserialization fails, SafeKafkaAvroDeserializer returns null value.
 *   RobustKafkaConsumer logs BAD_PAYLOAD and commits that offset to move on.
 * - If processing throws exception, it retries N times; then "DLQ" placeholder and commits.
 */
@Component
public class PaymentAvroConsumer {

    @RobustKafkaListener(
            topic = "payments-topic",
            groupId = "payments-group",
            maxRetries = 3,
            pollTimeoutMs = 1000,
            skipBadPayload = true
    )
    public void onMessage(ConsumerRecord<String, Object> record) {
        // record.value() is an Avro object (GenericRecord or SpecificRecord) depending on your setup.
        // Demo: throw on certain condition to simulate processing failure.
        if (record.value() != null && record.value().toString().contains("FAIL_PROCESSING")) {
            throw new RuntimeException("Simulated processing failure");
        }

        System.out.printf("OK | topic=%s partition=%d offset=%d value=%s%n",
                record.topic(), record.partition(), record.offset(), record.value());
    }
}