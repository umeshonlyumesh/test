package com.example.kafka.serde;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import org.apache.kafka.common.header.Headers;

import java.util.Base64;

/**
 * Best-practice for Avro: never let deserialization exceptions crash poll loop.
 * Return null on failure; caller can log topic/partition/offset and commit+skip.
 */
public class SafeKafkaAvroDeserializer extends KafkaAvroDeserializer {

    @Override
    public Object deserialize(String topic, Headers headers, byte[] bytes) {
        try {
            return super.deserialize(topic, headers, bytes);
        } catch (Exception ex) {
            // Note: offset/partition are not available here; log minimal info + sample bytes.
            String sample = (bytes == null) ? "null" : Base64.getEncoder().encodeToString(
                    bytes.length > 256 ? java.util.Arrays.copyOf(bytes, 256) : bytes
            );

            System.err.printf(
                    "BAD_PAYLOAD_DESERIALIZATION | topic=%s bytesSampleBase64=%s error=%s%n",
                    topic, sample, ex.toString()
            );
            return null;
        }
    }
}