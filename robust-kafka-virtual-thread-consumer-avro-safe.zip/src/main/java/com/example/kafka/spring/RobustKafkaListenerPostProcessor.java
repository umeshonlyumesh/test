package com.example.kafka.spring;

import com.example.kafka.annotation.RobustKafkaListener;
import com.example.kafka.core.RobustKafkaConsumer;
import com.example.kafka.serde.SafeKafkaAvroDeserializer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.SmartLifecycle;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Scans Spring beans for @RobustKafkaListener and starts one RobustKafkaConsumer per annotated method.
 *
 * Note: Still NO Spring Kafka; this uses Spring only for annotation scanning + lifecycle.
 */
@Component
public class RobustKafkaListenerPostProcessor implements BeanPostProcessor, SmartLifecycle {

    private final Environment env;
    private final ExecutorService pollExecutor =
            Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r);
                t.setName("robust-kafka-poll-" + t.threadId());
                t.setDaemon(true);
                return t;
            });

    private final List<RobustKafkaConsumer<?>> consumers = new ArrayList<>();
    private volatile boolean running;

    public RobustKafkaListenerPostProcessor(Environment env) {
        this.env = env;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        ReflectionUtils.doWithMethods(bean.getClass(), method -> {
            RobustKafkaListener ann = method.getAnnotation(RobustKafkaListener.class);
            if (ann == null) return;

            validate(method);
            method.setAccessible(true);

            Properties props = baseConsumerProps(ann);

            @SuppressWarnings("unchecked")
            KafkaConsumer<String, Object> kafkaConsumer = new KafkaConsumer<>(props);

            RobustKafkaConsumer<Object> rc = new RobustKafkaConsumer<>(
                    kafkaConsumer,
                    ann.topic(),
                    (ConsumerRecord<String, Object> rec) -> method.invoke(bean, rec),
                    (rec, ex) -> System.err.printf(
                            "DLQ_PUBLISH_PLACEHOLDER | topic=%s partition=%d offset=%d error=%s%n",
                            rec.topic(), rec.partition(), rec.offset(), ex.toString()
                    ),
                    ann.maxRetries(),
                    ann.pollTimeoutMs(),
                    ann.skipBadPayload()
            );

            consumers.add(rc);

        }, m -> m.isAnnotationPresent(RobustKafkaListener.class));

        return bean;
    }

    private Properties baseConsumerProps(RobustKafkaListener ann) {
        Properties p = new Properties();

        p.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, env.getProperty("kafka.bootstrap.servers", "localhost:9092"));
        p.put(ConsumerConfig.GROUP_ID_CONFIG, ann.groupId());
        p.put(ConsumerConfig.CLIENT_ID_CONFIG, ann.clientIdPrefix() + "-" + ann.groupId());

        p.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        p.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        // Key as string (customize if needed)
        p.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

        // Value as Avro via Schema Registry; safe wrapper returns null on bad payload
        p.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, SafeKafkaAvroDeserializer.class.getName());
        p.put("schema.registry.url", env.getProperty("kafka.schema.registry.url", "http://localhost:8081"));

        // If you use SpecificRecord, enable this (still returns Object at runtime but will be SpecificRecord)
        p.put("specific.avro.reader", "true");

        // Optional tuning from properties
        putIfPresent(p, ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "kafka.max.poll.records");
        putIfPresent(p, ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "kafka.max.poll.interval.ms");
        putIfPresent(p, ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "kafka.session.timeout.ms");
        putIfPresent(p, ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "kafka.heartbeat.interval.ms");

        return p;
    }

    private void putIfPresent(Properties p, String kafkaConfigKey, String propertyKey) {
        String v = env.getProperty(propertyKey);
        if (v != null && !v.isBlank()) {
            p.put(kafkaConfigKey, v);
        }
    }

    private void validate(Method method) {
        if (method.getParameterCount() != 1 || !ConsumerRecord.class.isAssignableFrom(method.getParameterTypes()[0])) {
            throw new IllegalStateException("@RobustKafkaListener method must have exactly 1 parameter of type ConsumerRecord");
        }
    }

    @Override
    public void start() {
        if (running) return;
        consumers.forEach(pollExecutor::submit);
        running = true;
    }

    @Override
    public void stop() {
        consumers.forEach(RobustKafkaConsumer::shutdown);
        pollExecutor.shutdown();
        running = false;
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override public boolean isAutoStartup() { return true; }
    @Override public int getPhase() { return 0; }

    @Override
    public void stop(Runnable callback) {
        stop();
        callback.run();
    }
}