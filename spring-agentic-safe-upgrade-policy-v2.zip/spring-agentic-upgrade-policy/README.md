# Spring Agentic Safe Upgrade Policy

Production-oriented policy pack for an AI vulnerability-remediation agent upgrading Spring Boot applications.

## Core safety model

The agent is a proposer, not the final authority. A deterministic policy engine MUST approve the proposed dependency graph before source changes or an MR are considered safe.

Decision order:

1. Detect build system, Java, Spring Boot, BOMs, explicit overrides, plugins and dependency graph.
2. Determine ownership of every affected dependency (Boot BOM, Spring Cloud BOM, other BOM, direct application management, transitive).
3. Resolve the smallest security-remediating target.
4. Prefer an upgrade already managed by a supported Spring Boot release.
5. Never cross a framework/platform major boundary as an ordinary dependency bump.
6. Treat scanner "fixed version" as security evidence, NOT compatibility evidence.
7. Generate a candidate in an isolated branch/worktree.
8. Re-resolve the complete graph and compare it with baseline.
9. Compile, test, run integration/contract checks, startup checks and security scans.
10. Reject on policy violation, regression, unresolved CVE, dependency convergence failure, or insufficient evidence.
11. Require human approval for migration-class changes.

## Decisions

- `SAFE_PATCH`: candidate stays inside the same supported platform line and passes all gates.
- `SAFE_MINOR`: compatible minor update with official evidence and all gates passing.
- `BOM_ALIGNMENT`: remove unsafe overrides / align with an authoritative BOM.
- `REVIEW_REQUIRED`: technically plausible but impact or evidence requires human review.
- `MIGRATION_REQUIRED`: platform/framework major migration; never silent auto-fix.
- `NO_SAFE_FIX`: no compatible remediation found in allowed platform lines.
- `BLOCKED_UNKNOWN`: compatibility cannot be established.

## Important design rule

Do not use static version ranges as the sole compatibility source. The authoritative dependency set is the BOM of the selected Spring Boot release plus the official compatibility matrix for portfolio projects such as Spring Cloud. Static rules in this repository are *guardrails and generation boundaries*.

## Contents

`policies/` contains machine-readable rules; `schema/` contains a JSON Schema; `docs/AGENT_INSTRUCTIONS.md` contains the execution protocol; `docs/ECOSYSTEM_COVERAGE.md` defines portfolio coverage; `examples/` contains decisions.

## Runtime evidence

At execution time, record URLs, document/release version, retrieval timestamp, checksum where possible, and the exact evidence used. Never let the model invent a compatibility fact.

## Updating this policy

Refresh authoritative Spring metadata before production use and continuously test the policy engine against representative applications. Security fixes and support lines change over time.
