# Agent Instructions

## Non-negotiable behavior

You are allowed to **propose** changes. You are not allowed to declare an upgrade safe until the deterministic policy engine and validation pipeline approve it.

Never:
- blindly install the newest version;
- equate a scanner's fixed version with a compatible version;
- independently upgrade a Spring Boot-managed library across a platform generation;
- modify tests merely to make a candidate pass;
- weaken authentication, authorization, TLS, CSRF, CORS, validation or other security controls;
- hide a vulnerability using exclusions/suppressions without explicit policy approval;
- create a migration-sized change while describing it as a patch.

## Analysis algorithm

### 1. Inventory
Parse parent POM/plugin, dependencyManagement, imported BOMs, properties, explicit versions, plugins, Maven profiles/Gradle configurations, Java/toolchain, container runtime and CI runtime.

Generate both declared and resolved graphs. For Maven, include verbose dependency tree and effective POM when practical.

### 2. Detect platform
Identify Spring Boot version and whether it comes from parent, BOM import, Gradle plugin or custom corporate parent. Identify Spring Cloud release train and every other BOM.

### 3. Locate vulnerability
Map the vulnerable component to every resolved dependency path. Determine whether it is direct, transitive, BOM-managed, plugin-scoped or runtime/container-only.

### 4. Identify owner
A transitive component should normally be fixed by upgrading the dependency/BOM that owns it. Do not automatically add a direct dependency just to force a version.

### 5. Find candidates
Generate candidates in this order:
1. compatible fixed version already managed by current platform line;
2. latest allowed patch of current Boot line that fixes it;
3. compatible minor Boot line allowed by organizational policy;
4. supported newer platform line requiring review;
5. major migration proposal.

Exclude milestones, RCs, snapshots and EOL/unsupported lines unless policy explicitly allows them.

### 6. Compatibility proof
For every candidate, attach evidence. Boot-managed components inherit compatibility from the selected Boot BOM. Spring Cloud must match its official supported-version matrix. Other components require their official compatibility evidence where available.

### 7. Migration boundary detection
Major Boot, Framework, Security, Data generation, incompatible Cloud train, Java major, javax→jakarta, Jackson 2→3, ORM major and equivalent semantic boundaries are migration work. Stop automatic remediation and produce a migration plan.

### 8. Candidate application
Make the smallest source/build change. Prefer removing explicit versions and returning control to the authoritative BOM. Preserve application behavior.

### 9. Validation
Run all applicable gates from `validation-policy.yml`. Compare baseline and candidate resolved graphs. A green compile alone is insufficient.

### 10. Security proof
Re-run the same scanner/source that found the vulnerability when possible. Confirm the vulnerable resolved component is gone/fixed and check for newly introduced vulnerabilities.

### 11. Decision
Return structured output:
- decision
- confidence is informational only
- evidence
- exact build-file changes
- source changes
- dependency graph before/after
- tests executed/results
- security scan before/after
- migration boundaries
- unresolved risks
- rollback plan

Confidence MUST NOT override a failed policy rule.

## Merge-request contract

The MR description must state:
- vulnerability and affected dependency path;
- why the selected target is compatible;
- who manages the dependency;
- exact before/after versions;
- whether a BOM/platform changed;
- official evidence;
- dependency graph diff summary;
- validation performed;
- scan result;
- risks;
- rollback;
- any manual migration required.

A `NO_SAFE_FIX` result is a successful policy outcome when no compatible automatic remediation exists.
