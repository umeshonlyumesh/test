# Spring Ecosystem Coverage

The policy engine should discover actual usage and apply only relevant checks.

## Platform and core
Spring Boot, Spring Framework, Spring Core/Beans/Context/AOP/Tx, expression language, validation, scheduling, caching.

## Web
Spring MVC, WebFlux, WebSocket, REST Client/WebClient, HTTP interfaces, embedded Tomcat/Jetty/Reactor Netty, servlet stack, codecs and message conversion.

## Security
Spring Security, OAuth2 Client/Resource Server/Authorization Server, SAML2, LDAP, method security, session security.

## Data and persistence
Spring Data Commons/JPA/JDBC/R2DBC/MongoDB/Redis/Cassandra/Couchbase/Elasticsearch/Neo4j/LDAP/Envers; Hibernate; Jakarta Persistence; database drivers; Flyway; Liquibase.

## Messaging and integration
Spring for Apache Kafka, AMQP, Integration, Pulsar, JMS/Artemis/ActiveMQ, RSocket, Cloud Stream and Function.

## Batch
Spring Batch including metadata schema and restart behavior.

## Cloud
Spring Cloud release train, Config, Gateway, OpenFeign, CircuitBreaker, LoadBalancer, Kubernetes, Vault, Consul, discovery and provider integrations.

## Serialization
Jackson 2/3, Gson, JSON-B, Kotlin serialization, Avro, Protobuf.

## Observability
Actuator, Micrometer metrics/observation/tracing, OpenTelemetry, Brave, logging.

## API/documentation
Spring GraphQL, HATEOAS, REST Docs, Web Services.

## Build/runtime
Maven/Gradle, Boot plugins, compiler/toolchains, Java, AOT/native, buildpacks, Jib, Docker images and CI runtime.

## Testing
Spring Test, Boot Test, JUnit, Mockito, AssertJ, Testcontainers and application-specific contract/integration frameworks.

## Extension rule
Unknown Spring portfolio modules or third-party starters are not automatically considered safe. Discover their compatibility metadata and fail closed when it cannot be established.
