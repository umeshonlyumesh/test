# Authoritative Reference Sources

The runtime resolver should prefer official sources and persist retrieved evidence.

- Spring Boot reference documentation and managed dependency appendix
- Spring Boot release notes and migration guides
- Spring Framework upgrade notes
- Spring Security migration documentation
- Spring Cloud supported versions matrix / release train documentation
- Individual Spring project release notes and migration guides
- Vendor/project security advisories
- The organization's approved vulnerability source/scanner

## Current design facts captured when this pack was generated (2026-09-16)

Spring Boot documentation exposes the dependency versions managed by each Boot release. Boot 4's migration guide instructs applications to move to the latest 3.5.x before a 4.0 migration, review non-Boot-managed dependencies, and calls out major Spring portfolio upgrades. It also documents Jackson 3 as Boot 4's preferred JSON library and a temporary Jackson 2 compatibility module.

These facts are deliberately not converted into broad permanent version ranges. Resolve exact versions dynamically for the target release.
