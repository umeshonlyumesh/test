# Changelog

## 2.0.0 — 2026-09-16
- Initial production-oriented policy pack.
- BOM-first compatibility model.
- Fail-closed migration boundaries.
- Full Spring portfolio coverage map.
- Validation, evidence, vulnerability and testing gates.
