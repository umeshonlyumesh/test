# V3 Architecture

V3 is a fail-closed policy and migration orchestration pack for agentic remediation of Spring applications.

## Decision model
Every candidate fix is classified as SAFE_PATCH, SAFE_MINOR, MIGRATION_REQUIRED, BLOCKED, or HUMAN_REVIEW.
`MIGRATION_REQUIRED` is not a refusal: it routes the agent through controlled migration analysis, approval, implementation, compilation, behavioral verification, security rescan, and final policy gate.

## Authority order
1. Application constraints and supported runtime
2. Official Spring project compatibility/BOM metadata
3. Official migration guides and release notes
4. Build-resolved dependency graph
5. Source/configuration/API usage
6. Vulnerability scanner evidence
7. Agent proposal

Scanner fixed versions are security evidence, not compatibility proof.
