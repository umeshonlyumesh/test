# Prompt 01 — Discover
Analyze only. Do not modify files.
Read all V3 policies, flow, migrations and schemas. Inventory build tool, Java, Spring Boot, Spring ecosystem, managed/unmanaged dependencies, plugins, source, tests, configuration, CI/container/runtime and scanner findings. Produce a baseline with evidence and unresolved questions.
