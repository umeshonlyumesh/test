# Prompt 02 — Security Analysis
Correlate each vulnerability to the resolved dependency graph and owning BOM/parent/direct dependency. Distinguish direct vs transitive. Treat scanner fixed versions as security evidence only. Do not propose an incompatible override. Identify the smallest compatible remediation candidate or classify MIGRATION_REQUIRED.
