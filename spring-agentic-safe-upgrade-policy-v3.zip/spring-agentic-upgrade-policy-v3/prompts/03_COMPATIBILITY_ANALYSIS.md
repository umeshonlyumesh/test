# Prompt 03 — Compatibility Analysis
Resolve compatibility from official project metadata, BOMs, compatibility matrices, migration guides and application constraints. Do not rely on model memory for version compatibility. Record evidence, target generation, Java/runtime requirements and managed dependency ownership.
