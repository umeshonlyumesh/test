# Prompt 05 — Source/API Analysis
Scan main, test and generated Java sources for imports, constructors, methods, signatures, annotations, reflection strings, SPI/service-loader files and framework integration APIs affected by the target. For Jackson migration, perform symbol inventory and semantic JSON boundary analysis; never blindly replace package prefixes.
