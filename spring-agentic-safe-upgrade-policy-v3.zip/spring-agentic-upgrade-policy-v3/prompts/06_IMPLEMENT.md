# Prompt 06 — Implement
Apply only the approved migration plan. Prefer BOM/parent/platform ownership over arbitrary explicit versions. Make the smallest coherent set of dependency, Java source, configuration, test, build plugin, runtime and CI changes. Keep an evidence ledger of every change and reason.
