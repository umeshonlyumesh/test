# Prompt 07 — Compile/Fix Loop
Compile main sources first. Fix only migration-related compiler errors with documented target APIs. Then compile tests and fix migration-related test compilation. Never delete tests, weaken assertions, suppress compiler errors or remove production behavior merely to obtain a green build.
