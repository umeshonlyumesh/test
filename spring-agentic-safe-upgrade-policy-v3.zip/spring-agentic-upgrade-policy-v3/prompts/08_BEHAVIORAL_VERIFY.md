# Prompt 08 — Behavioral Verification
Run unit, integration, startup, security and contract tests. Compare representative before/after REST JSON, Kafka payloads, persisted/cache JSON and persistence behavior. Classify differences as BACKWARD_COMPATIBLE, EXPECTED_MIGRATION_CHANGE, BREAKING_CHANGE or UNKNOWN. Breaking/unknown blocks automatic approval.
