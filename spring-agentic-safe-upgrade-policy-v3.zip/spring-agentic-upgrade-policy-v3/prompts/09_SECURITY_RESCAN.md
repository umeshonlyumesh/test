# Prompt 09 — Security Rescan
Re-run applicable SAST, dependency, container and secret scans. Verify the selected vulnerability is actually remediated and no unacceptable new finding was introduced. Do not dismiss/suppress findings to claim success.
