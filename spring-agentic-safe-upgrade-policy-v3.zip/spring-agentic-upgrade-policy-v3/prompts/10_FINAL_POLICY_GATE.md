# Prompt 10 — Final Policy Gate
Evaluate all V3 policies deterministically. Require build/test/startup/behavioral/security/dependency-graph evidence. Fail closed on missing evidence or unknown compatibility. Produce migration-result.md and machine-readable decision output.
