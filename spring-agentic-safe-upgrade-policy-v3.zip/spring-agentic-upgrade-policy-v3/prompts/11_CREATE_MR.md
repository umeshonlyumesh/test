# Prompt 11 — Create MR/PR
Create a reviewable change only after the final gate passes. Include vulnerability IDs, root cause, dependency ownership, compatibility evidence, migration guide references, source/config changes, tests, behavior diffs, scan results, rollback steps and residual risks.
