# Spring Kafka SDK - Production-grade building blocks

This project adds a small, reusable SDK layer around Spring for Apache Kafka so that other services can:
- Switch between JSON(String) and Avro payloads via configuration (no code change).
- Use manual offset commits (commit on success; do not commit on failure).
- Pause and resume consumers safely to handle downstream outages without OOM or excessive rebalancing.

## Modules provided by the SDK (package `com.example.springkafka.sdk`)
- KafkaSdkProperties: Externalized configuration bound to `kafka.sdk.*`.
- KafkaSdkAutoConfiguration: Auto-configures producer, consumer factory, and a listener container factory with MANUAL ack.
- SdkKafkaProducer: A simple wrapper over KafkaTemplate to send messages.
- SdkConsumerManager: Pause/resume control for listener containers through Spring's KafkaListenerEndpointRegistry.

Notes:
- JSON mode uses String key/value serdes. For JSON payloads, serialize to String (e.g., Jackson) in your application.
- Avro mode expects Confluent serializers. To use Avro at runtime, ensure `io.confluent:kafka-avro-serializer` is on the classpath and configure `kafka.sdk.schema-registry-url`.
  We avoid a hard compile-time dependency by referencing serializers/deserializers via their FQCN.

## Configuration
See `src/main/resources/application.properties` for defaults. Key properties:

```
kafka.sdk.bootstrap-servers=localhost:9092
kafka.sdk.group-id=sdk-group
kafka.sdk.client-id=sdk-client
kafka.sdk.format=json   # json or avro
# If avro
# kafka.sdk.schema-registry-url=http://localhost:8081
kafka.sdk.max-poll-interval-ms=300000
kafka.sdk.max-poll-records=50
kafka.sdk.concurrency=1
kafka.sdk.idle-between-polls-ms=1000
```

## Using the SDK in your app

1) Producer usage

```
@Autowired SdkKafkaProducer producer;
producer.send("topic.name", "key1", somePayloadStringOrAvroRecord);
```
- When `kafka.sdk.format=json`, send String values.
- When `kafka.sdk.format=avro`, send Avro SpecificRecord instances and ensure Confluent Avro serializer is available.

2) Consumer with manual commit

```
@KafkaListener(id = "orders-listener", topics = "orders", containerFactory = "sdkKafkaListenerContainerFactory")
public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {
    try {
        // process record.value()
        ack.acknowledge(); // commit offset only after successful processing
    } catch (Exception e) {
        // do not ack; message will be redelivered after backoff or on restart
    }
}
```

3) Pause/resume via SdkConsumerManager

```
@Autowired SdkConsumerManager consumerManager;
consumerManager.pause("orders-listener");
// later
consumerManager.resume("orders-listener");
```
- The example consumers in this repo automatically pause their listener if processing throws an exception; resume via the REST endpoint or SdkConsumerManager.

## Client projects in this repo
This repository now contains:
- SDK library (this project): reusable auto-configuration, producer wrapper, and pause/resume manager.
- Example app inside the SDK project (ExampleConsumer/ExampleController) for quick testing.
- A separate client project `spring-kafka-client` that depends on the SDK as a normal application would, demonstrating produce and pause/resume via REST.

### Endpoints (default server port 8080)
Both example apps expose similar endpoints:
- POST `/api/produce?value=hello` optionally `&topic=yourTopic&key=k1` — produces a message using `SdkKafkaProducer`.
- POST `/api/pause` — pauses the consumer.
- POST `/api/resume` — resumes the consumer.
- GET  `/api/status` — returns pause status and the set of paused listeners.

### Run the SDK example app (inside this module)
1. Ensure Kafka is running and accessible at `kafka.sdk.bootstrap-servers` (default `localhost:9092`). Create the topic (default `test-topic`).
2. Start the app: `./mvnw spring-boot:run` (or run the main class `SpringKafkaApplication`).
3. Produce a message:
   - Windows PowerShell: `Invoke-RestMethod -Method Post "http://localhost:8080/api/produce?value=hello"`
   - curl: `curl -X POST "http://localhost:8080/api/produce?value=hello"`
4. Pause the consumer: `curl -X POST http://localhost:8080/api/pause`
5. Check status: `curl http://localhost:8080/api/status`
6. Resume: `curl -X POST http://localhost:8080/api/resume`

### Build and run the separate client project
1. Build and install the SDK into your local Maven repository:
   - Windows: `./mvnw.cmd -DskipTests install`
   - Linux/macOS: `./mvnw -DskipTests install`
2. Change directory to the client project: `cd spring-kafka-client`.
3. Run the client app:
   - Windows: `../mvnw.cmd spring-boot:run`
   - Linux/macOS: `../mvnw spring-boot:run`
4. Use the same endpoints listed above. The client's consumer id is `client-example-listener` (topic default `test-topic`).

Avro mode:
- Add Confluent serializer dependency in your POM and set `kafka.sdk.format=avro` and `kafka.sdk.schema-registry-url`. The example producer endpoint will send String payloads; for Avro, adapt controllers or use `SdkKafkaProducer` directly from your services with Avro records.

## OOM and Rebalance Safety During Long Pauses
- The listener container is configured with `pauseImmediate=true` and `idleBetweenPolls` so that when you pause, the client does not buffer more records in memory.
- Keep `max.poll.interval.ms` sufficiently large (property `kafka.sdk.max-poll-interval-ms`) to reduce the chance of a rebalance while processing long-running messages.
- If a pause must be very long, consider stopping the application or increasing `max.poll.interval.ms` further; the container settings help, but brokers can still rebalance if the group is unresponsive.

## Add Avro at Runtime (optional)
To enable Avro without changing source code, add this dependency to your application POM and set `kafka.sdk.format=avro`:

```
<dependency>
  <groupId>io.confluent</groupId>
  <artifactId>kafka-avro-serializer</artifactId>
  <version>7.6.0</version>
</dependency>
```
Also set:
```
kafka.sdk.schema-registry-url=http://localhost:8081
```

## References
- Spring for Apache Kafka: https://docs.spring.io/spring-boot/4.0.2/reference/messaging/kafka.html

