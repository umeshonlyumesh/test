package com.example.client;

import com.example.springkafka.sdk.SdkConsumerManager;
import com.example.springkafka.sdk.SdkKafkaProducer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@ConditionalOnBean(name = {"sdkKafkaListenerContainerFactory"})
public class ClientController {

    private final SdkKafkaProducer producer;
    private final SdkConsumerManager consumerManager;

    public ClientController(SdkKafkaProducer producer, SdkConsumerManager consumerManager) {
        this.producer = producer;
        this.consumerManager = consumerManager;
    }

    @PostMapping("/produce")
    public ResponseEntity<?> produce(@RequestParam String value,
                                     @RequestParam(required = false) String key,
                                     @RequestParam(defaultValue = "${example.topic:test-topic}") String topic) {
        return ResponseEntity.accepted().body(
                producer.send(topic, key, value)
                        .thenApply(res -> Map.of(
                                "topic", res.getRecordMetadata().topic(),
                                "partition", res.getRecordMetadata().partition(),
                                "offset", res.getRecordMetadata().offset()))
        );
    }

    @PostMapping("/pause")
    public Map<String, Object> pause(@RequestParam(defaultValue = "client-example-listener") String id) {
        boolean ok = consumerManager.pause(id);
        Map<String, Object> resp = new HashMap<>();
        resp.put("paused", ok);
        resp.put("id", id);
        resp.put("isPausedNow", consumerManager.isPaused(id));
        resp.put("pausedIds", consumerManager.pausedListenerIds());
        return resp;
    }

    @PostMapping("/resume")
    public Map<String, Object> resume(@RequestParam(defaultValue = "client-example-listener") String id) {
        boolean ok = consumerManager.resume(id);
        Map<String, Object> resp = new HashMap<>();
        resp.put("resumed", ok);
        resp.put("id", id);
        resp.put("isPausedNow", consumerManager.isPaused(id));
        resp.put("pausedIds", consumerManager.pausedListenerIds());
        return resp;
    }

    @GetMapping("/status")
    public Map<String, Object> status(@RequestParam(defaultValue = "client-example-listener") String id) {
        Map<String, Object> resp = new HashMap<>();
        resp.put("id", id);
        resp.put("isPaused", consumerManager.isPaused(id));
        resp.put("pausedIds", consumerManager.pausedListenerIds());
        return resp;
    }
}
