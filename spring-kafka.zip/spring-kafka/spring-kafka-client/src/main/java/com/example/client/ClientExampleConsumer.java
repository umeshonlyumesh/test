package com.example.client;

import com.example.springkafka.sdk.SdkConsumerManager;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnBean(name = "sdkKafkaListenerContainerFactory")
public class ClientExampleConsumer {

    private static final Logger log = LoggerFactory.getLogger(ClientExampleConsumer.class);
    private final SdkConsumerManager consumerManager;

    public ClientExampleConsumer(SdkConsumerManager consumerManager) {
        this.consumerManager = consumerManager;
    }

    @KafkaListener(id = "client-example-listener", topics = "${example.topic:test-topic}", containerFactory = "sdkKafkaListenerContainerFactory")
    public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {
        try {
            Object val = record.value();
            String valueStr = val == null ? null : String.valueOf(val);
            log.info("[CLIENT] Received topic={} partition={} offset={} key={} value={}",
                    record.topic(), record.partition(), record.offset(), record.key(), valueStr);

            if (valueStr != null && valueStr.toLowerCase().contains("fail")) {
                throw new RuntimeException("Simulated processing failure due to payload containing 'fail'");
            }

            // business logic
            ack.acknowledge();
            log.info("[CLIENT] Acked offset {} for partition {}", record.offset(), record.partition());
        } catch (Exception ex) {
            log.warn("[CLIENT] Processing failed for offset {} (key={}, topic={}). Not acknowledging. Cause: {}",
                    record.offset(), record.key(), record.topic(), ex.toString());
            // Auto-pause this listener so the application can investigate and resume later
            boolean paused = consumerManager.pause("client-example-listener");
            log.warn("[CLIENT] Auto-paused listener 'client-example-listener' status={}", paused);
        }
    }
}
