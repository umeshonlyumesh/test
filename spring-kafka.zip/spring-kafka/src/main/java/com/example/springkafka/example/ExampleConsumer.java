package com.example.springkafka.example;

import com.example.springkafka.sdk.SdkConsumerManager;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnBean(name = "sdkKafkaListenerContainerFactory")
public class ExampleConsumer {

    private static final Logger log = LoggerFactory.getLogger(ExampleConsumer.class);
    private final SdkConsumerManager consumerManager;

    public ExampleConsumer(SdkConsumerManager consumerManager) {
        this.consumerManager = consumerManager;
    }

    // Demonstrates manual ack, and leaving offset uncommitted on failure
    @KafkaListener(id = "example-listener", topics = "${example.topic:test-topic}", containerFactory = "sdkKafkaListenerContainerFactory")
    public void onMessage(ConsumerRecord<String, Object> record, Acknowledgment ack) {
        try {
            Object val = record.value();
            String valueStr = val == null ? null : String.valueOf(val);
            log.info("Received message topic={} partition={} offset={} key={} value={}",
                    record.topic(), record.partition(), record.offset(), record.key(), valueStr);

            // Simulate a business rule failure when payload contains the word 'fail'
            if (valueStr != null && valueStr.toLowerCase().contains("fail")) {
                throw new RuntimeException("Simulated processing failure due to payload containing 'fail'");
            }

            // Business logic would go here
            // ...

            // Commit offset only on success
            ack.acknowledge();
            log.info("Acked offset {} for partition {}", record.offset(), record.partition());
        } catch (Exception ex) {
            // Do not ack so it can be retried or handled later
            log.warn("Processing failed for offset {} (key={}, topic={}). Not acknowledging to allow retry. Cause: {}",
                    record.offset(), record.key(), record.topic(), ex.toString());
            // Auto-pause this listener until an operator resumes it
            boolean paused = consumerManager.pause("example-listener");
            log.warn("Auto-paused listener 'example-listener' status={}", paused);
        }
    }
}
