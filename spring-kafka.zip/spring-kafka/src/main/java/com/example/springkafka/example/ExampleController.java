package com.example.springkafka.example;

import com.example.springkafka.sdk.SdkConsumerManager;
import com.example.springkafka.sdk.SdkKafkaProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.SendResult;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api")
@ConditionalOnBean(SdkConsumerManager.class)
public class ExampleController {

    private static final Logger log = LoggerFactory.getLogger(ExampleController.class);

    private final SdkKafkaProducer producer;
    private final SdkConsumerManager consumerManager;

    @Value("${example.topic:test-topic}")
    private String defaultTopic;

    public ExampleController(SdkKafkaProducer producer, SdkConsumerManager consumerManager) {
        this.producer = producer;
        this.consumerManager = consumerManager;
    }

    @PostMapping("/produce")
    public CompletableFuture<ResponseEntity<Map<String, Object>>> produce(
            @RequestParam(value = "topic", required = false) String topic,
            @RequestParam(value = "key", required = false) String key,
            @RequestParam("value") String value
    ) {
        String t = (topic == null || topic.isBlank()) ? defaultTopic : topic;
        CompletableFuture<SendResult<String, Object>> future = producer.send(t, key, value);
        return future.thenApply(result -> {
            var md = result.getRecordMetadata();
            log.info("Produced message to topic={} partition={} offset={}", md.topic(), md.partition(), md.offset());
            return ResponseEntity.ok(Map.of(
                    "topic", md.topic(),
                    "partition", md.partition(),
                    "offset", md.offset()
            ));
        });
    }

    @PostMapping("/pause")
    public ResponseEntity<Map<String, Object>> pause() {
        boolean ok = consumerManager.pause("example-listener");
        return ResponseEntity.ok(Map.of(
                "listenerId", "example-listener",
                "paused", ok
        ));
    }

    @PostMapping("/resume")
    public ResponseEntity<Map<String, Object>> resume() {
        boolean ok = consumerManager.resume("example-listener");
        return ResponseEntity.ok(Map.of(
                "listenerId", "example-listener",
                "resumed", ok
        ));
    }

    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> status() {
        boolean paused = consumerManager.isPaused("example-listener");
        return ResponseEntity.ok(Map.of(
                "listenerId", "example-listener",
                "paused", paused,
                "pausedSet", consumerManager.pausedListenerIds()
        ));
    }
}
