package com.example.springkafka.sdk;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.ExponentialBackOff;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableConfigurationProperties(KafkaSdkProperties.class)
@ConditionalOnProperty(prefix = "kafka.sdk", name = "bootstrap-servers")
public class KafkaSdkAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(name = "sdkProducerFactory")
    public ProducerFactory<String, Object> sdkProducerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ProducerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-producer");
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        config.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        config.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        config.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, 120000);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                // Avoid compile-time dependency on Confluent by using FQCN string
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer");
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
            }
            case "json" -> {
                // JSON(String): Use String key and String value serializer
                config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
                config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
        }
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    @ConditionalOnMissingBean(name = "sdkKafkaTemplate")
    public KafkaTemplate<String, Object> sdkKafkaTemplate(ProducerFactory<String, Object> sdkProducerFactory) {
        return new KafkaTemplate<>(sdkProducerFactory);
    }

    @Bean
    @ConditionalOnMissingBean(name = "sdkConsumerFactory")
    public ConsumerFactory<String, Object> sdkConsumerFactory(KafkaSdkProperties props) {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, props.getGroupId());
        config.put(ConsumerConfig.CLIENT_ID_CONFIG, props.getClientId() + "-consumer");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, props.getMaxPollIntervalMs());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, props.getMaxPollRecords());
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(CommonClientConfigs.METADATA_MAX_AGE_CONFIG, 30000);

        String format = props.getFormat().toLowerCase();
        switch (format) {
            case "avro" -> {
                config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
                // Use FQCN to avoid compile-time dependency
                config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroDeserializer");
                config.put("schema.registry.url", props.getSchemaRegistryUrl());
                config.put("specific.avro.reader", true);
            }
            case "json" -> {
                // JSON(String)
                config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
                config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
            }
            default -> throw new IllegalArgumentException("Unsupported kafka.sdk.format: " + format);
        }
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean(name = "sdkKafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "sdkKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, Object> sdkKafkaListenerContainerFactory(
            ConsumerFactory<String, Object> sdkConsumerFactory,
            KafkaSdkProperties props,
            CommonErrorHandler sdkCommonErrorHandler) {

        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(sdkConsumerFactory);
        factory.setConcurrency(props.getConcurrency());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.getContainerProperties().setPollTimeout(2000);
        factory.getContainerProperties().setIdleBetweenPolls(props.getIdleBetweenPollsMs());
        factory.getContainerProperties().setPauseImmediate(true); // avoid buffering when paused
        factory.getContainerProperties().setMissingTopicsFatal(false);
        factory.setCommonErrorHandler(sdkCommonErrorHandler);
        return factory;
    }

    @Bean
    @ConditionalOnMissingBean(name = "sdkCommonErrorHandler")
    public CommonErrorHandler sdkCommonErrorHandler() {
        // Do not commit on failure, allow user to decide; use backoff to retry transient issues
        ExponentialBackOff backOff = new ExponentialBackOff(1000, 2.0);
        backOff.setMaxInterval(60_000);
        backOff.setMaxElapsedTime(5 * 60_000);
        DefaultErrorHandler errorHandler = new DefaultErrorHandler((record, ex) -> {
            // log or metrics can be added here
        }, backOff);
        errorHandler.setAckAfterHandle(false);
        errorHandler.setCommitRecovered(false);
        return errorHandler;
    }

    @Bean
    @ConditionalOnMissingBean
    public SdkKafkaProducer sdkKafkaProducer(KafkaTemplate<String, Object> sdkKafkaTemplate) {
        return new SdkKafkaProducer(sdkKafkaTemplate);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnBean(KafkaListenerEndpointRegistry.class)
    public SdkConsumerManager sdkConsumerManager(KafkaListenerEndpointRegistry registry) {
        return new SdkConsumerManager(registry);
    }
}
