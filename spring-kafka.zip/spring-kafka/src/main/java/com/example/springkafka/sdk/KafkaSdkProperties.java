package com.example.springkafka.sdk;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "kafka.sdk")
public class KafkaSdkProperties {
    /**
     * Message format: json or avro.
     */
    private String format = "json"; // json | avro

    /**
     * Kafka bootstrap servers.
     */
    private String bootstrapServers = "localhost:9092";

    /**
     * Schema Registry URL (required when format=avro).
     */
    private String schemaRegistryUrl = "http://localhost:8081";

    /**
     * Consumer group id (default for container factory; can be overridden per-listener).
     */
    private String groupId = "spring-kafka-sdk-group";

    /**
     * Client id prefix.
     */
    private String clientId = "spring-kafka-sdk";

    /**
     * Max poll interval to avoid rebalances during long processing (ms).
     */
    private Integer maxPollIntervalMs = 300000; // 5 min

    /**
     * Max records per poll to limit memory.
     */
    private Integer maxPollRecords = 50;

    /**
     * Concurrency for listener containers.
     */
    private Integer concurrency = 1;

    /**
     * Time to sleep between polls when idle (ms).
     */
    private Long idleBetweenPollsMs = 1000L;

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public void setBootstrapServers(String bootstrapServers) {
        this.bootstrapServers = bootstrapServers;
    }

    public String getSchemaRegistryUrl() {
        return schemaRegistryUrl;
    }

    public void setSchemaRegistryUrl(String schemaRegistryUrl) {
        this.schemaRegistryUrl = schemaRegistryUrl;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Integer getMaxPollIntervalMs() {
        return maxPollIntervalMs;
    }

    public void setMaxPollIntervalMs(Integer maxPollIntervalMs) {
        this.maxPollIntervalMs = maxPollIntervalMs;
    }

    public Integer getMaxPollRecords() {
        return maxPollRecords;
    }

    public void setMaxPollRecords(Integer maxPollRecords) {
        this.maxPollRecords = maxPollRecords;
    }

    public Integer getConcurrency() {
        return concurrency;
    }

    public void setConcurrency(Integer concurrency) {
        this.concurrency = concurrency;
    }

    public Long getIdleBetweenPollsMs() {
        return idleBetweenPollsMs;
    }

    public void setIdleBetweenPollsMs(Long idleBetweenPollsMs) {
        this.idleBetweenPollsMs = idleBetweenPollsMs;
    }
}
