package com.example.springkafka.sdk;

import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Provides pause/resume controls for Kafka listener containers, with safeguards for long pauses.
 */
public class SdkConsumerManager {

    private final KafkaListenerEndpointRegistry registry;
    private final Set<String> pausedContainers = ConcurrentHashMap.newKeySet();

    public SdkConsumerManager(KafkaListenerEndpointRegistry registry) {
        this.registry = Objects.requireNonNull(registry, "registry");
    }

    public boolean pause(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        if (container == null) return false;
        container.pause();
        pausedContainers.add(listenerId);
        return true;
    }

    public boolean resume(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        if (container == null) return false;
        container.resume();
        pausedContainers.remove(listenerId);
        return true;
    }

    public boolean isPaused(String listenerId) {
        MessageListenerContainer container = registry.getListenerContainer(listenerId);
        return container != null && container.isPauseRequested();
    }


    public Set<String> pausedListenerIds() {
        return Collections.unmodifiableSet(pausedContainers);
    }
}
