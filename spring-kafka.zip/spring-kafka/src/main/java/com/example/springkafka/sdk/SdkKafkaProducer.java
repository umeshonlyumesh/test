package com.example.springkafka.sdk;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

public class SdkKafkaProducer {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public SdkKafkaProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = Objects.requireNonNull(kafkaTemplate, "kafkaTemplate");
    }

    public CompletableFuture<SendResult<String, Object>> send(String topic, String key, Object value) {
        return kafkaTemplate.send(topic, key, value);
    }
}
