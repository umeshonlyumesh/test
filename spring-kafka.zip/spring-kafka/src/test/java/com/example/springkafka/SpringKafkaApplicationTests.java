package com.example.springkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "kafka.sdk.bootstrap-servers=false")
class SpringKafkaApplicationTests {

    @Test
    void contextLoads() {
    }

}
