package com.trusit.orchestrator.config;

import com.trusit.orchestrator.logging.MdcContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configures async executor with MDC propagation for orchestrator async workflows.
 */
@Configuration
@EnableAsync
public class MdcAsyncExecutionConfig {

    /**
     * Primary task executor used by {@code @Async} methods.
     *
     * <p>Uses {@link MdcContext#taskDecorator()} so worker threads inherit caller MDC.</p>
     *
     * @return configured executor
     */
    @Bean(name = {"taskExecutor", "applicationTaskExecutor"})
    public Executor mdcAwareTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        int cpus = Runtime.getRuntime().availableProcessors();
        executor.setCorePoolSize(Math.max(4, cpus));
        executor.setMaxPoolSize(Math.max(8, cpus * 2));
        executor.setQueueCapacity(1000);
        executor.setThreadNamePrefix("core-api-async-");
        executor.setTaskDecorator(MdcContext.taskDecorator());
        executor.initialize();
        return executor;
    }
}
