package com.trusit.orchestrator.exception;

import lombok.Getter;

@Getter
public class CoreApiException extends RuntimeException {
    private final String errorCode;

    public CoreApiException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
}
