package com.trusit.orchestrator.exception;

import com.trusit.common.model.StandardResponse;
import com.trusit.common.util.LogMasker;
import com.trusit.orchestrator.logging.MdcContext;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(CoreApiException.class)
    public ResponseEntity<StandardResponse<Object>> handleCoreApiException(CoreApiException ex, HttpServletRequest request) {
        log.error("CoreApiException: {}", LogMasker.sanitize(ex.getMessage()));
        StandardResponse<Object> response = StandardResponse.builder()
                .status("ERROR")
                .message(ex.getMessage())
                .correlationId(MdcContext.currentRequestId())
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<StandardResponse<Object>> handleValidationException(MethodArgumentNotValidException ex) {
        String errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .collect(Collectors.joining(", "));
        
        log.error("Validation error: {}", LogMasker.sanitize(errorMessage));
        
        StandardResponse<Object> response = StandardResponse.builder()
                .status("VALIDATION_ERROR")
                .message(errorMessage)
                .correlationId(MdcContext.currentRequestId())
                .build();
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<StandardResponse<Object>> handleGeneralException(Exception ex) {
        log.error("Unexpected error occurred: {}", ex.getMessage(), ex);
        StandardResponse<Object> response = StandardResponse.builder()
                .status("INTERNAL_SERVER_ERROR")
                .message("Error: " + ex.getClass().getSimpleName() + " - " + ex.getMessage())
                .correlationId(MdcContext.currentRequestId())
                .build();
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
