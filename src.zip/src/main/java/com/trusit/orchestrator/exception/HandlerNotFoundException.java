package com.trusit.orchestrator.exception;

public class HandlerNotFoundException extends CoreApiException {
    public HandlerNotFoundException(String message) {
        super(message, "HANDLER_NOT_FOUND");
    }
}
