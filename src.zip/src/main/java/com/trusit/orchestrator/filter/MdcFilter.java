package com.trusit.orchestrator.filter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.trusit.common.model.StandardRequest;
import com.trusit.orchestrator.logging.MdcContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequestWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Initializes per-request MDC and restores previous MDC at request end.
 */
@Component
public class MdcFilter extends OncePerRequestFilter {
    private static final String CORE_PROCESS_PATH = "/api/v1/process";
    private static final String APPLICATION_JSON = "application/json";
    private static final int MAX_MDC_PARSE_PAYLOAD_BYTES = 64 * 1024;
    private static final Logger log = LoggerFactory.getLogger(MdcFilter.class);

    private final ObjectMapper objectMapper;

    @Autowired
    public MdcFilter(ObjectProvider<ObjectMapper> objectMapperProvider) {
        this.objectMapper = objectMapperProvider.getIfAvailable(ObjectMapper::new);
    }

    MdcFilter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Clears MDC at ingress and, for core process requests, sets MDC from request body.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String headerRequestId = request.getHeader(MdcContext.REQUEST_ID_HEADER);
        if (!isCoreProcessJsonRequest(request)) {
            try (MdcContext.MdcScope ignored = MdcContext.openMdcScope(headerRequestId, null)) {
                exposeRequestIdResponseHeader(response);
                filterChain.doFilter(request, response);
            }
            return;
        }

        if (isTooLargeForMdcParsing(request)) {
            log.warn("Skipping MDC payload parsing for [{}] because content length exceeds {} bytes", CORE_PROCESS_PATH, MAX_MDC_PARSE_PAYLOAD_BYTES);
            try (MdcContext.MdcScope ignored = MdcContext.openMdcScope(null, null)) {
                exposeRequestIdResponseHeader(response);
                filterChain.doFilter(request, response);
            }
            return;
        }

        var wrappedRequest = new ReReadableRequest(request);
        StandardRequest coreRequest = toCoreRequest(wrappedRequest.body());
        try (MdcContext.MdcScope ignored = MdcContext.openMdcScopeFromCoreRequest(coreRequest)) {
            exposeRequestIdResponseHeader(response);
            filterChain.doFilter(wrappedRequest, response);
        }
    }

    private void exposeRequestIdResponseHeader(HttpServletResponse response) {
        String requestId = MdcContext.currentRequestId();
        if (requestId != null) {
            response.setHeader(MdcContext.REQUEST_ID_HEADER, requestId);
        }
    }

    private boolean isCoreProcessJsonRequest(HttpServletRequest request) {
        var isProcessEndpoint = "POST".equalsIgnoreCase(request.getMethod())
                && request.getRequestURI() != null
                && request.getRequestURI().endsWith(CORE_PROCESS_PATH);
        if (!isProcessEndpoint) {
            return false;
        }

        var contentType = request.getContentType();
        return contentType != null && contentType.toLowerCase().startsWith(APPLICATION_JSON);
    }

    private boolean isTooLargeForMdcParsing(HttpServletRequest request) {
        long contentLength = request.getContentLengthLong();
        return contentLength > MAX_MDC_PARSE_PAYLOAD_BYTES;
    }

    private StandardRequest toCoreRequest(byte[] requestBody) {
        if (requestBody.length == 0) {
            return null;
        }
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> requestMap = objectMapper.readValue(requestBody, new TypeReference<Map<String, Object>>() {});
            return StandardRequest.fromJson(requestMap);
        } catch (Exception ex) {
            log.debug("Unable to parse core request payload for MDC; continuing without payload MDC context", ex);
            return null;
        }
    }

    private static final class ReReadableRequest extends HttpServletRequestWrapper {
        private final byte[] body;

        private ReReadableRequest(HttpServletRequest request) throws IOException {
            super(request);
            this.body = request.getInputStream().readAllBytes();
        }

        private byte[] body() {
            return body;
        }

        @Override
        public ServletInputStream getInputStream() {
            var inputStream = new ByteArrayInputStream(body);
            return new ServletInputStream() {
                @Override
                public int read() {
                    return inputStream.read();
                }

                @Override
                public boolean isFinished() {
                    return inputStream.available() == 0;
                }

                @Override
                public boolean isReady() {
                    return true;
                }

                @Override
                public void setReadListener(ReadListener readListener) {
                    // no-op
                }
            };
        }

        @Override
        public BufferedReader getReader() {
            return new BufferedReader(new InputStreamReader(getInputStream(), StandardCharsets.UTF_8));
        }
    }
}
