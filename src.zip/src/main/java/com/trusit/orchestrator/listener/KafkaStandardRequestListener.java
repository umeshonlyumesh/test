package com.trusit.orchestrator.listener;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.orchestrator.logging.MdcListenerSupport;
import com.trusit.orchestrator.service.OrchestrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class KafkaStandardRequestListener {

    private static final Logger log = LoggerFactory.getLogger(KafkaStandardRequestListener.class);

    private final OrchestrationService orchestrationService;

    public KafkaStandardRequestListener(OrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    @KafkaListener(
            topics = "${app.messaging.kafka.standard-request-topic:core-standard-request}",
            groupId = "${app.messaging.kafka.group-id:core-api-orchestrator}"
    )
    public void listen(StandardRequest request) {
        MdcListenerSupport.runListenerWithCoreRequest(request, () -> {
            StandardResponse<Object> response = orchestrationService.processRequest(request);
            log.info("Kafka StandardResponse: {}", response);
        });
    }
}
