package com.trusit.orchestrator.listener;

import com.trusit.common.model.StandardRequest;
import com.trusit.common.model.StandardResponse;
import com.trusit.orchestrator.logging.MdcListenerSupport;
import com.trusit.orchestrator.service.OrchestrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class MqStandardRequestListener {

    private static final Logger log = LoggerFactory.getLogger(MqStandardRequestListener.class);

    private final OrchestrationService orchestrationService;

    public MqStandardRequestListener(OrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    @RabbitListener(queues = "${app.messaging.mq.standard-request-queue:core.standard.request.queue}")
    public void listen(StandardRequest request) {
        MdcListenerSupport.runListenerWithCoreRequest(request, () -> {
            StandardResponse<Object> response = orchestrationService.processRequest(request);
            log.info("MQ StandardResponse: {}", response);
        });
    }
}
