package com.trusit.orchestrator.logging;

import com.trusit.common.model.StandardRequest;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

import java.util.Map;

/**
 * Central utility for orchestrator MDC lifecycle and propagation.
 *
 * <p>This class standardizes how request-scoped logging context is set and restored for:
 * synchronous execution, asynchronous task handoff, and listener entry points.</p>
 *
 * <p>Request ID policy is intentionally strict:
 * value comes from core request/message data and is never auto-generated.</p>
 */
public final class MdcContext {
    /** MDC key used by log pattern for request correlation. */
    public static final String REQUEST_ID_MDC_KEY = "requestId";
    /** MDC key used by log pattern for operation type correlation. */
    public static final String OPERATION_TYPE_MDC_KEY = "operationType";
    /** Canonical header name used when request-id is carried in HTTP transport headers. */
    public static final String REQUEST_ID_HEADER = "X-Request-ID";

    private MdcContext() {
    }

    /**
     * Returns request-id currently present in MDC.
     *
     * @return request-id from MDC, or {@code null} when absent
     */
    public static String currentRequestId() {
        return MDC.get(REQUEST_ID_MDC_KEY);
    }

    /**
     * Returns operation type currently present in MDC.
     *
     * @return operation type from MDC, or {@code null} when absent
     */
    public static String currentOperationType() {
        return MDC.get(OPERATION_TYPE_MDC_KEY);
    }

    /**
     * Applies request-id and operation-type directly to current MDC.
     *
     * @param requestId request-id value (nullable)
     * @param operationType operation type value (nullable)
     */
    public static void putCoreRequestContext(String requestId, String operationType) {
        String normalizedRequestId = normalizeText(requestId);
        if (normalizedRequestId == null) {
            MDC.remove(REQUEST_ID_MDC_KEY);
        } else {
            MDC.put(REQUEST_ID_MDC_KEY, normalizedRequestId);
        }

        String normalizedOperationType = normalizeText(operationType);
        if (normalizedOperationType == null) {
            MDC.remove(OPERATION_TYPE_MDC_KEY);
        } else {
            MDC.put(OPERATION_TYPE_MDC_KEY, normalizedOperationType);
        }
    }

    /**
     * Applies request-id and operation-type from core request directly to current MDC.
     *
     * @param coreRequest source request (nullable)
     */
    public static void putCoreRequestContext(StandardRequest coreRequest) {
        if (coreRequest == null) {
            putCoreRequestContext(null, null);
            return;
        }
        putCoreRequestContext(coreRequest.requestId(), coreRequest.operationType());
    }

    /**
     * Opens an MDC scope using explicit request and operation values.
     *
     * <p>Previous MDC is restored when returned scope is closed.</p>
     *
     * @param requestId request-id to write into MDC; {@code null} removes key
     * @param operationType operation type to write into MDC; {@code null} removes key
     * @return closeable scope that restores previous MDC state
     */
    public static MdcScope openMdcScope(String requestId, String operationType) {
        Map<String, String> previousContext = MDC.getCopyOfContextMap();
        putCoreRequestContext(requestId, operationType);

        return () -> restore(previousContext);
    }

    /**
     * Opens an MDC scope using only request-id.
     *
     * @param requestId request-id to write into MDC; {@code null} removes key
     * @return closeable scope that restores previous MDC state
     */
    public static MdcScope openMdcScope(String requestId) {
        return openMdcScope(requestId, null);
    }

    /**
     * Opens an MDC scope using values from {@link StandardRequest}.
     *
     * @param coreRequest core request; when {@code null}, request-id and operation are removed
     * @return closeable scope that restores previous MDC state
     */
    public static MdcScope openMdcScopeFromCoreRequest(StandardRequest coreRequest) {
        if (coreRequest == null) {
            return openMdcScope(null, null);
        }
        return openMdcScope(coreRequest.requestId(), coreRequest.operationType());
    }


    private static Runnable decorate(Runnable delegate) {
        Map<String, String> captured = MDC.getCopyOfContextMap();
        return () -> {
            Map<String, String> previous = MDC.getCopyOfContextMap();
            restore(captured);
            try {
                delegate.run();
            } finally {
                restore(previous);
            }
        };
    }

    /**
     * Returns a Spring {@link TaskDecorator} that propagates MDC into worker threads.
     *
     * @return task decorator for MDC propagation
     */
    public static TaskDecorator taskDecorator() {
        return MdcContext::decorate;
    }

    private static void restore(Map<String, String> contextMap) {
        if (contextMap == null || contextMap.isEmpty()) {
            MDC.clear();
            return;
        }
        MDC.setContextMap(contextMap);
    }

    private static String normalizeText(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    /**
     * Closeable MDC handle. Closing restores the previous MDC state.
     */
    @FunctionalInterface
    public interface MdcScope extends AutoCloseable {
        /**
         * Restores previous MDC context.
         */
        @Override
        void close();
    }
}
