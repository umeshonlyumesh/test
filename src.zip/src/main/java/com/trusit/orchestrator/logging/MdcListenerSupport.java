package com.trusit.orchestrator.logging;

import com.trusit.common.model.StandardRequest;

import java.util.function.Supplier;

/**
 * Listener-oriented MDC helper methods.
 *
 * <p>Use this class at listener boundaries (Kafka, MQ, JMS, Rabbit) so listener logic
 * runs with consistent MDC population and automatic restore.</p>
 */
public final class MdcListenerSupport {

    private MdcListenerSupport() {
    }

    /**
     * Runs listener logic using request-id/operation from a core request payload.
     *
     * @param coreRequest core request carrying request-id and operation type
     * @param runnable listener logic
     */
    public static void runListenerWithCoreRequest(StandardRequest coreRequest, Runnable runnable) {
        try (MdcContext.MdcScope ignored = MdcContext.openMdcScopeFromCoreRequest(coreRequest)) {
            runnable.run();
        }
    }

    /**
     * Calls listener logic using request-id/operation from a core request payload.
     *
     * @param coreRequest core request carrying request-id and operation type
     * @param supplier listener logic with return value
     * @param <T> supplier return type
     * @return supplier result
     */
    public static <T> T callListenerWithCoreRequest(StandardRequest coreRequest, Supplier<T> supplier) {
        try (MdcContext.MdcScope ignored = MdcContext.openMdcScopeFromCoreRequest(coreRequest)) {
            return supplier.get();
        }
    }

}
