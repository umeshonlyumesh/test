package com.trusit.orchestrator.registry;

import com.trusit.orchestrator.exception.HandlerNotFoundException;
import com.trusit.sdk.spi.SdkHandler;
import org.springframework.stereotype.Component;

import java.util.SequencedCollection;

@Component
public class SdkRegistry {

    private final SequencedCollection<SdkHandler> handlers;

    public SdkRegistry(SequencedCollection<SdkHandler> handlers) {
        this.handlers = handlers;
    }

    public SdkHandler getHandler(String operationType, String subOperationType) {
        return handlers.stream()
                .filter(h -> h.supports(operationType, subOperationType))
                .findFirst()
                .orElseThrow(() -> new HandlerNotFoundException(
                        String.format("No handler found for operationType: %s and subOperationType: %s", operationType, subOperationType)));
    }
}
