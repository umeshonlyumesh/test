package com.trusit.orchestrator.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trusit.orchestrator.logging.MdcContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class MdcFilterTest {

    private final MdcFilter filter = new MdcFilter(new ObjectMapper());

    @AfterEach
    void clearMdc() {
        MDC.clear();
    }

    @Test
    void doFilterInternal_shouldPopulateFromCorePayloadAndRestoreMdc() throws ServletException, IOException {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/v1/process");
        request.setContentType("application/json");
        request.setContent("""
                {"requestId":"req-101","operationType":"FRAUD"}
                """.getBytes());
        MockHttpServletResponse response = new MockHttpServletResponse();

        FilterChain chain = (req, res) -> {
            assertEquals("req-101", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertEquals("FRAUD", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        };

        filter.doFilter(request, response, chain);

        assertEquals("req-101", response.getHeader(MdcContext.REQUEST_ID_HEADER));
        assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }

    @Test
    void doFilterInternal_shouldUseHeaderRequestIdForNonCoreRequestAndRestoreMdc() throws ServletException, IOException {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/health");
        request.addHeader(MdcContext.REQUEST_ID_HEADER, "hdr-777");
        MockHttpServletResponse response = new MockHttpServletResponse();

        FilterChain chain = (req, res) -> {
            assertEquals("hdr-777", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        };

        filter.doFilter(request, response, chain);

        assertEquals("hdr-777", response.getHeader(MdcContext.REQUEST_ID_HEADER));
        assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }

    @Test
    void doFilterInternal_shouldSkipMdcParsingWhenPayloadTooLarge() throws ServletException, IOException {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/v1/process");
        request.setContentType("application/json");
        request.setContent(new byte[70 * 1024]);
        MockHttpServletResponse response = new MockHttpServletResponse();

        FilterChain chain = (req, res) -> {
            assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        };

        filter.doFilter(request, response, chain);

        assertNull(response.getHeader(MdcContext.REQUEST_ID_HEADER));
        assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }
}
