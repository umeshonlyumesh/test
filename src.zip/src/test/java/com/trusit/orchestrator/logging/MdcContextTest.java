package com.trusit.orchestrator.logging;

import com.trusit.common.model.StandardRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class MdcContextTest {

    @AfterEach
    void clearMdc() {
        MDC.clear();
    }

    @Test
    void openMdcScope_shouldSetAndRestorePreviousValues() {
        MDC.put(MdcContext.REQUEST_ID_MDC_KEY, "prev-req");
        MDC.put(MdcContext.OPERATION_TYPE_MDC_KEY, "prev-op");

        try (MdcContext.MdcScope ignored = MdcContext.openMdcScope("new-req", "new-op")) {
            assertEquals("new-req", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertEquals("new-op", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        }

        assertEquals("prev-req", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertEquals("prev-op", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }

    @Test
    void openMdcScope_shouldRemoveKeysWhenNull() {
        MDC.put(MdcContext.REQUEST_ID_MDC_KEY, "existing-req");
        MDC.put(MdcContext.OPERATION_TYPE_MDC_KEY, "existing-op");

        try (MdcContext.MdcScope ignored = MdcContext.openMdcScope(null, null)) {
            assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        }

        assertEquals("existing-req", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertEquals("existing-op", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }

    @Test
    void openMdcScopeFromCoreRequest_shouldUseCoreRequestValues() {
        StandardRequest request = new StandardRequest("", "FRAUD", null, null, null, null, Map.of());

        try (MdcContext.MdcScope ignored = MdcContext.openMdcScopeFromCoreRequest(request)) {
            assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertEquals("FRAUD", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        }
    }

    @Test
    void taskDecorator_shouldPropagateContext() {
        AtomicReference<String> seenByDecoratorTask = new AtomicReference<>();

        TaskDecorator decorator = MdcContext.taskDecorator();

        MDC.put(MdcContext.REQUEST_ID_MDC_KEY, "req-for-decorator");
        Runnable decorated = decorator.decorate(() -> seenByDecoratorTask.set(MDC.get(MdcContext.REQUEST_ID_MDC_KEY)));
        decorated.run();

        assertEquals("req-for-decorator", seenByDecoratorTask.get());
    }

    @Test
    void putCoreRequestContext_shouldSetValuesFromCoreRequest() {
        StandardRequest request = new StandardRequest("req-core", "DEPOSIT", null, null, null, null, Map.of());
        MdcContext.putCoreRequestContext(request);
        assertEquals("req-core", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertEquals("DEPOSIT", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }
}
