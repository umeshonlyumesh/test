package com.trusit.orchestrator.logging;

import com.trusit.common.model.StandardRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class MdcListenerSupportTest {

    @AfterEach
    void clearMdc() {
        MDC.clear();
    }

    @Test
    void runAndCallWithCoreRequest_shouldPopulateAndRestoreMdc() {
        MDC.put(MdcContext.REQUEST_ID_MDC_KEY, "before");
        StandardRequest request = new StandardRequest("core-req", "FRAUD", null, null, null, null, Map.of());

        MdcListenerSupport.runListenerWithCoreRequest(request, () -> {
            assertEquals("core-req", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
            assertEquals("FRAUD", MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
        });

        String value = MdcListenerSupport.callListenerWithCoreRequest(request,
                () -> MDC.get(MdcContext.REQUEST_ID_MDC_KEY) + ":" + MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));

        assertEquals("core-req:FRAUD", value);
        assertEquals("before", MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
    }

    @Test
    void runAndCallWithBlankRequestId_shouldKeepOperationAndNotFallback() {
        StandardRequest request = new StandardRequest("   ", "ALERT", null, null, null, null, Map.of());

        String value = MdcListenerSupport.callListenerWithCoreRequest(
                request,
                () -> MDC.get(MdcContext.REQUEST_ID_MDC_KEY) + ":" + MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY)
        );

        assertEquals("null:ALERT", value);

        assertNull(MDC.get(MdcContext.REQUEST_ID_MDC_KEY));
        assertNull(MDC.get(MdcContext.OPERATION_TYPE_MDC_KEY));
    }
}
