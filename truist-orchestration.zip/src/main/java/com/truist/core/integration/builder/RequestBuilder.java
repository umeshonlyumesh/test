package com.truist.core.integration.builder;

import com.truist.core.integration.model.*;

public final class RequestBuilder {

    private RequestBuilder() {}

    public static OrchestratedRequest prepareRequest(CoreIntegrationRequest req) {
        String operation = req.getHeader().getOperation();
        OrchestratedRequest.OrchestratedRequestBuilder builder =
                OrchestratedRequest.builder()
                    .header(req.getHeader());

        switch (operation.toUpperCase()) {
            case "FRAUDCHECK" -> builder.operationType("FraudCheck").requestPayload(req.getFraudCheck());
            case "QUALIFICATION" -> builder.operationType("Qualification").requestPayload(req.getQualification());
            case "POSTING" -> builder.operationType("Posting").requestPayload(req.getPosting());
            default -> throw new IllegalArgumentException("Unsupported operation: " + operation);
        }

        return builder.build();
    }
}
