package com.truist.core.integration.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
public class RestClientConfig {

    @Bean(name = "depositRestClient")
    public RestClient depositRestClient(RestClient.Builder builder) {
        // Set a placeholder base URL. Replace in application.yml if needed.
        return builder
                .baseUrl("https://postman-echo.com") // demo endpoint works in tests; replace for real
                .build();
    }
}
