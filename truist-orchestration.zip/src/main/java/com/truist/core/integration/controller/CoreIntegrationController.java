package com.truist.core.integration.controller;

import com.truist.core.integration.builder.RequestBuilder;
import com.truist.core.integration.model.CoreIntegrationRequest;
import com.truist.core.integration.model.CoreIntegrationResponse;
import com.truist.core.integration.model.OrchestratedRequest;
import com.truist.core.integration.orchestration.OrchestrationService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/integration/v1")
public class CoreIntegrationController {

    private final OrchestrationService orchestrationService;

    public CoreIntegrationController(OrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    @PostMapping
    public CoreIntegrationResponse handleOperation(@RequestBody CoreIntegrationRequest req) {
        OrchestratedRequest request = RequestBuilder.prepareRequest(req);
        return orchestrationService.orchestrate(request);
    }
}
