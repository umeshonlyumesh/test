package com.truist.core.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CoreIntegrationRequest {
    private Header header;
    private FraudRequest fraudCheck;
    private QualificationRequest qualification;
    private DepositRequest posting;
}
