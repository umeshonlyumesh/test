package com.truist.core.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CoreIntegrationResponse {
    private String status; // SUCCESS / FAILED
    private String errorMessage;
    private String requestId;
    private String sourceId;
    private Object payload;

    public static CoreIntegrationResponse success(Header header, Object payload) {
        return CoreIntegrationResponse.builder()
                .status("SUCCESS")
                .requestId(header != null ? header.getRequestId() : null)
                .sourceId(header != null ? header.getSourceId() : null)
                .payload(payload)
                .build();
    }

    public static CoreIntegrationResponse failure(Header header, String message) {
        return CoreIntegrationResponse.builder()
                .status("FAILED")
                .requestId(header != null ? header.getRequestId() : null)
                .sourceId(header != null ? header.getSourceId() : null)
                .errorMessage(message)
                .build();
    }
}
