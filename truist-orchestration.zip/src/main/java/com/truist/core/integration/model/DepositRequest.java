package com.truist.core.integration.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DepositRequest {
    private String accountNumber;
    private String accountType;
    private Double amount;
}
