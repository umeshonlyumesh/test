package com.truist.core.integration.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DepositResponse {
    private String confirmationId;
    private String status;
}
