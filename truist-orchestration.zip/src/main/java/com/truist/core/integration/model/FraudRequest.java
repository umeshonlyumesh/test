package com.truist.core.integration.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FraudRequest {
    private String customerId;
    private String deviceId;
}
