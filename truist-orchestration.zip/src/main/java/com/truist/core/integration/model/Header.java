package com.truist.core.integration.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Header {
    private String requestId;
    private String sourceId;
    private String operation; // FraudCheck, Qualification, Posting
}
