package com.truist.core.integration.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrchestratedRequest {
    private String operationType;
    private Header header;
    private Object requestPayload;
}
