package com.truist.core.integration.model;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QualificationRequest {
    private String accountNumber;
    private String qualificationType;
}
