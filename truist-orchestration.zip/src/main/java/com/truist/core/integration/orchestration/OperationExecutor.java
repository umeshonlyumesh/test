package com.truist.core.integration.orchestration;

import com.truist.core.integration.model.OrchestratedRequest;

public interface OperationExecutor {
    String getOperationName();
    Object execute(OrchestratedRequest request);
}
