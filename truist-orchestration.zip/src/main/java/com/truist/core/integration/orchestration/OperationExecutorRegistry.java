package com.truist.core.integration.orchestration;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OperationExecutorRegistry {

    private final Map<String, OperationExecutor> executorMap;

    public OperationExecutorRegistry(List<OperationExecutor> executors) {
        this.executorMap = executors.stream()
                .collect(Collectors.toMap(OperationExecutor::getOperationName, e -> e));
    }

    public OperationExecutor getExecutor(String operationType) {
        return executorMap.get(operationType);
    }
}
