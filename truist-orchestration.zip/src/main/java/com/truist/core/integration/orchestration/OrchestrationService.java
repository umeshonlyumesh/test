package com.truist.core.integration.orchestration;

import com.truist.core.integration.model.CoreIntegrationResponse;
import com.truist.core.integration.model.Header;
import com.truist.core.integration.model.OrchestratedRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class OrchestrationService {

    private static final Logger log = LoggerFactory.getLogger(OrchestrationService.class);

    private final OperationExecutorRegistry registry;

    public OrchestrationService(OperationExecutorRegistry registry) {
        this.registry = registry;
    }

    public CoreIntegrationResponse orchestrate(OrchestratedRequest request) {
        try {
            OperationExecutor executor = registry.getExecutor(request.getOperationType());
            if (executor == null) {
                throw new IllegalArgumentException("No executor found for operation " + request.getOperationType());
            }
            Object payload = executor.execute(request);
            Header header = request.getHeader();
            return CoreIntegrationResponse.success(header, payload);
        } catch (Exception e) {
            log.error("Orchestration failed: {}", e.getMessage(), e);
            return CoreIntegrationResponse.failure(request.getHeader(), e.getMessage());
        }
    }
}
