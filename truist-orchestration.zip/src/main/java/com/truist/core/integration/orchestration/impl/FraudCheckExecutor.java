package com.truist.core.integration.orchestration.impl;

import com.truist.core.integration.model.FraudRequest;
import com.truist.core.integration.model.OrchestratedRequest;
import com.truist.core.integration.orchestration.OperationExecutor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class FraudCheckExecutor implements OperationExecutor {

    @Override
    public String getOperationName() {
        return "FraudCheck";
    }

    @Override
    public Object execute(OrchestratedRequest request) {
        FraudRequest payload = (FraudRequest) request.getRequestPayload();
        // Simulate a fraud check response
        return Map.of("fraudScore", 12, "riskLevel", "LOW", "customerId", payload.getCustomerId());
    }
}
