package com.truist.core.integration.orchestration.impl;

import com.truist.core.integration.model.DepositRequest;
import com.truist.core.integration.model.DepositResponse;
import com.truist.core.integration.model.OrchestratedRequest;
import com.truist.core.integration.orchestration.OperationExecutor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.UUID;

@Component
public class PostingExecutor implements OperationExecutor {

    private final RestClient restClient;

    public PostingExecutor(@Qualifier("depositRestClient") RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public String getOperationName() {
        return "Posting";
    }

    @Override
    public Object execute(OrchestratedRequest request) {
        DepositRequest payload = (DepositRequest) request.getRequestPayload();

        // Example: call external deposit service (dummy echo endpoint by default)
        // Replace URI with your actual deposit endpoint.
        try {
            DepositResponse resp = restClient.post()
                    .uri("/echo/deposit")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(payload)
                    .retrieve()
                    .body(DepositResponse.class);

            if (resp == null) {
                // Fallback demo response
                return DepositResponse.builder()
                        .confirmationId(UUID.randomUUID().toString())
                        .status("POSTED")
                        .build();
            }
            return resp;
        } catch (Exception ex) {
            // Fallback for demo; in real system, rethrow a domain exception
            return DepositResponse.builder()
                    .confirmationId(UUID.randomUUID().toString())
                    .status("POSTED")
                    .build();
        }
    }
}
