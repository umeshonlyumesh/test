package com.truist.core.integration.orchestration.impl;

import com.truist.core.integration.model.OrchestratedRequest;
import com.truist.core.integration.model.QualificationRequest;
import com.truist.core.integration.orchestration.OperationExecutor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class QualificationExecutor implements OperationExecutor {

    @Override
    public String getOperationName() {
        return "Qualification";
    }

    @Override
    public Object execute(OrchestratedRequest request) {
        QualificationRequest payload = (QualificationRequest) request.getRequestPayload();
        boolean qualified = "CHK".equalsIgnoreCase(payload.getQualificationType());
        return Map.of("qualified", qualified, "accountNumber", payload.getAccountNumber());
    }
}
