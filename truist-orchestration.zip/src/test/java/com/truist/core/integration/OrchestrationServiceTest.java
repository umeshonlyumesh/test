package com.truist.core.integration;

import com.truist.core.integration.model.*;
import com.truist.core.integration.orchestration.OperationExecutor;
import com.truist.core.integration.orchestration.OperationExecutorRegistry;
import com.truist.core.integration.orchestration.OrchestrationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrchestrationServiceTest {

    @Mock
    private OperationExecutorRegistry registry;

    @Mock
    private OperationExecutor executor;

    @InjectMocks
    private OrchestrationService orchestrationService;

    @Test
    void orchestrate_success_posting() {
        Header header = Header.builder().requestId("REQ-1").sourceId("CORE").operation("Posting").build();
        OrchestratedRequest request = OrchestratedRequest.builder()
                .operationType("Posting")
                .header(header)
                .requestPayload(DepositRequest.builder().accountNumber("123").amount(10.0).build())
                .build();

        when(registry.getExecutor("Posting")).thenReturn(executor);
        when(executor.execute(any())).thenReturn(DepositResponse.builder().confirmationId("ABC").status("POSTED").build());

        CoreIntegrationResponse resp = orchestrationService.orchestrate(request);

        assertEquals("SUCCESS", resp.getStatus());
        assertNotNull(resp.getPayload());
        verify(executor, times(1)).execute(any());
    }

    @Test
    void orchestrate_no_executor_found() {
        OrchestratedRequest request = OrchestratedRequest.builder()
                .operationType("UnknownOp")
                .header(Header.builder().requestId("R2").build())
                .build();

        when(registry.getExecutor("UnknownOp")).thenReturn(null);

        CoreIntegrationResponse resp = orchestrationService.orchestrate(request);
        assertEquals("FAILED", resp.getStatus());
        assertTrue(resp.getErrorMessage().contains("No executor"));
    }
}
